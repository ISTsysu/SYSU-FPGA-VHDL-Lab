library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity exp1 is
    Port ( 
        clk1    : in  std_logic;
        clk2    : in  std_logic;
        sw1     : in  std_logic;                -- 总开关
        an1     : in  std_logic;                -- 模式切换按钮
        segcode2: out std_logic_vector(6 downto 0);  -- 数码管段码2
        segcode1: out std_logic_vector(6 downto 0);  -- 数码管段码1
        segcode0: out std_logic_vector(6 downto 0);  -- 数码管段码0
        cled    : buffer std_logic_vector(10 downto 0)  -- 彩灯控制信号
    );
end exp1;

architecture Behavioral of exp1 is
    signal mode     : std_logic_vector(3 downto 0);
    signal flag     : std_logic;
    signal ancounter  : std_logic_vector(9 downto 0);
    signal mode_disp: std_logic_vector(6 downto 0);
	 signal clk_di   : std_logic;
	 signal counter   : integer range 0 to 24999999 := 0;
begin

-- 彩灯控制进程
process(clk_di, sw1, an1, cled)
begin
    if sw1 = '1' then  -- 总开关使能
        if rising_edge(clk_di) then
            case mode is
                when "0000" =>  -- 模式0：复位
                    cled <= (others => '0');
                    
                when "0001" =>  -- 模式1：左至右移位亮
                    if cled = "00000000000" then
                        cled(10) <= '1';
                    else
                        cled <= '0' & cled(10 downto 1);
                    end if;
                    
                when "0010" =>  -- 模式2：右至左移位亮
                    if cled = "00000000000" then
                        cled(0) <= '1';
                    else
                        cled <= cled(9 downto 0) & '0';
                    end if;
                    
                when "0011" =>  -- 模式3：从中间向两边移位亮
                    if cled = "00000000000" then
                        cled(5) <= '1';
                    else
                        cled(10 downto 5) <= cled(9 downto 5) & '0';
                        cled(5 downto 0) <= '0' & cled(5 downto 1);
                    end if;
                    
                when "0100" =>  -- 模式4：从两边向中间移位亮
                    if cled = "00000000000" then
                        cled(10) <= '1';
                        cled(0) <= '1';
                    else
                        cled(10 downto 5) <= '0' & cled(10 downto 6);
                        cled(4 downto 0) <= cled(3 downto 0) & '0';
                    end if;

                when "0101" =>  -- 模式5：从左至右依次亮，从右至左依次灭
                    if flag = '0' then
                        cled <= '1' & cled(10 downto 1);
                    else
                        cled <= cled(9 downto 0) & '0';
                    end if;

                when "0110" =>  -- 模式6：从中间向两边依次亮，反向依次灭
                    if flag = '0' then
                        cled(10 downto 5) <= cled(9 downto 5) & '1';
                        cled(5 downto 0) <= '1' & cled(5 downto 1);
                    else
                        cled(10 downto 5) <= '0' & cled(10 downto 6);
                        cled(5 downto 0) <= cled(4 downto 0) & '0';
                    end if;

                when "0111" =>  -- 模式7：从两边向中间依次亮，反向依次灭
                    if flag = '0' then
                        cled(10 downto 5) <= '1' & cled(10 downto 6);
                        cled(5 downto 0) <= cled(4 downto 0) & '1';
                    else
                        cled(10 downto 5) <= cled(9 downto 5) & '0';
                        cled(5 downto 0) <= '0' & cled(5 downto 1);
                    end if;

                when "1000" =>  -- 模式8：全部彩灯闪烁
                    if flag = '0' then
                        cled <= (others => '1');
                    else
                        cled <= (others => '0');
                    end if;

                when others => cled <= (others => '0');
            end case;
        end if;

        if cled = "00000000000" then
				flag <= '0';
		  elsif cled = "11111111111" then
				flag <= '1';
		  else
				null;
		  end if;
    else
		  null;
    end if;
end process;

process (sw1, mode, mode_disp)		--显示控制进程
begin
    if sw1 = '1' then
        if mode = "0000" then			--显示"clr"
            segcode0 <= not "1010000";
            segcode1 <= not "0111000";
            segcode2 <= not "0111001";
        else								--显示"LF*",*为模式编号
            segcode0 <= mode_disp;
            segcode1 <= not "1110001";
            segcode2 <= not "0111000";
        end if;
        
        case mode is
            when "0001" => mode_disp <= not "0000110";	--显示"1-8"段码
            when "0010" => mode_disp <= not "1011011";
            when "0011" => mode_disp <= not "1001111";
            when "0100" => mode_disp <= not "1100110";
            when "0101" => mode_disp <= not "1101101";
            when "0110" => mode_disp <= not "1111101";
            when "0111" => mode_disp <= not "0000111";
            when "1000" => mode_disp <= not "1111111";
            when others => mode_disp <= not "0000000";
        end case;
    else
        segcode0 <= not "1110001";			--显示"OFF"
        segcode1 <= not "1110001";
        segcode2 <= not "0111111";
    end if;
end process;

-- 键盘防抖进程
process(clk2, an1)
begin
    if an1 = '1' then
        if rising_edge(clk2) then
            if ancounter(9) = '0' then
                ancounter <= ancounter + 1;
				elsif ancounter(9) = '1' then
                null;
            end if;
        end if;
    else
        ancounter <= (others => '0');
    end if;
end process;

-- 模式切换进程
process(ancounter(9), sw1)
begin
    if sw1 = '1' then
        if rising_edge(ancounter(9)) then
            if mode = "1000" then
                mode <= "0000";
            else
                mode <= mode + 1;
            end if;
			else
				null;
        end if;
    else
        mode <= "0000";
    end if;
end process;

-- 分频进程
process(clk1)
begin
    if rising_edge(clk1) then
        if counter = 9999999 then
            counter <= 0;
            clk_di <= not clk_di;
        else
            counter <= counter + 1;
        end if;
    end if;
end process;

end Behavioral;