library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

--七段数码管映射  地址、写、读（从左到右）
--S8-S1为数据输入
--S17-S13为地址输入
--S0  写使能
--K0  时钟按键

--先给地址和数据，把s0置为1，启用写功能，再按下key0，则最右边读出数据
--按两秒左右key0 按两次，读出就和写入一样了
entity ram_top is
	port(
		clk_key:in std_logic;
		we_en:in std_logic;
		addr:in std_logic_vector(4 downto 0);
		datain:in std_logic_vector(7 downto 0);
		addr_seg1:out std_logic_vector(6 downto 0);
		addr_seg2:out std_logic_vector(6 downto 0);
		wdata_seg1:out std_logic_vector(6 downto 0);
		wdata_seg2:out std_logic_vector(6 downto 0);
		rdata_seg1:out std_logic_vector(6 downto 0);
		rdata_seg2:out std_logic_vector(6 downto 0));
end ram_top;

architecture behav of ram_top is

component ram_1p_ip
	port(
		address	: IN STD_LOGIC_VECTOR (4 DOWNTO 0);
		clock		: IN STD_LOGIC  := '1';
		data		: IN STD_LOGIC_VECTOR (7 DOWNTO 0);
		wren		: IN STD_LOGIC ;
		q			: OUT STD_LOGIC_VECTOR (7 DOWNTO 0));
end component ram_1p_ip;

component seg_sel is
	port(
		num:in std_logic_vector(3 downto 0);
		seg:out std_logic_vector(6 downto 0));
end component seg_sel;
signal flip_clk:std_logic;
signal addr8:std_logic_vector(7 downto 0);
signal data8:std_logic_vector(7 downto 0);
begin
	addr8<="000"&addr;
	flip_clk<=not clk_key;
	seg1:seg_sel port map(num=>datain(3 downto 0),seg=>wdata_seg1);
	seg2:seg_sel port map(num=>datain(7 downto 4),seg=>wdata_seg2);
	
	seg3:seg_sel port map(num=>addr8(3 downto 0),seg=>addr_seg1);
	seg4:seg_sel port map(num=>addr8(7 downto 4),seg=>addr_seg2);
	
	seg5:seg_sel port map(num=>data8(3 downto 0),seg=>rdata_seg1);
	seg6:seg_sel port map(num=>data8(7 downto 4),seg=>rdata_seg2);
	
	r1:ram_1p_ip port map(address=>addr,clock=>flip_clk,data=>datain,wren=>we_en,q=>data8);
end behav;