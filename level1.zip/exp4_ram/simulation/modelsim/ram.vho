-- Copyright (C) 1991-2015 Altera Corporation. All rights reserved.
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, the Altera Quartus II License Agreement,
-- the Altera MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Altera and sold by Altera or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 15.0.0 Build 145 04/22/2015 SJ Full Version"

-- DATE "11/26/2020 10:48:22"

-- 
-- Device: Altera EP4CE115F29C7 Package FBGA780
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY CYCLONEIVE;
LIBRARY IEEE;
USE CYCLONEIVE.CYCLONEIVE_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	ram_top IS
    PORT (
	clk_key : IN std_logic;
	we_en : IN std_logic;
	addr : IN std_logic_vector(4 DOWNTO 0);
	datain : IN std_logic_vector(7 DOWNTO 0);
	addr_seg1 : OUT std_logic_vector(6 DOWNTO 0);
	addr_seg2 : OUT std_logic_vector(6 DOWNTO 0);
	wdata_seg1 : OUT std_logic_vector(6 DOWNTO 0);
	wdata_seg2 : OUT std_logic_vector(6 DOWNTO 0);
	rdata_seg1 : OUT std_logic_vector(6 DOWNTO 0);
	rdata_seg2 : OUT std_logic_vector(6 DOWNTO 0)
	);
END ram_top;

-- Design Ports Information
-- addr_seg1[0]	=>  Location: PIN_AA17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr_seg1[1]	=>  Location: PIN_AB16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr_seg1[2]	=>  Location: PIN_AA16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr_seg1[3]	=>  Location: PIN_AB17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr_seg1[4]	=>  Location: PIN_AB15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr_seg1[5]	=>  Location: PIN_AA15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr_seg1[6]	=>  Location: PIN_AC17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr_seg2[0]	=>  Location: PIN_AD17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr_seg2[1]	=>  Location: PIN_AE17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr_seg2[2]	=>  Location: PIN_AG17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr_seg2[3]	=>  Location: PIN_AH17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr_seg2[4]	=>  Location: PIN_AF17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr_seg2[5]	=>  Location: PIN_AG18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr_seg2[6]	=>  Location: PIN_AA14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- wdata_seg1[0]	=>  Location: PIN_AB19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- wdata_seg1[1]	=>  Location: PIN_AA19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- wdata_seg1[2]	=>  Location: PIN_AG21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- wdata_seg1[3]	=>  Location: PIN_AH21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- wdata_seg1[4]	=>  Location: PIN_AE19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- wdata_seg1[5]	=>  Location: PIN_AF19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- wdata_seg1[6]	=>  Location: PIN_AE18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- wdata_seg2[0]	=>  Location: PIN_AD18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- wdata_seg2[1]	=>  Location: PIN_AC18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- wdata_seg2[2]	=>  Location: PIN_AB18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- wdata_seg2[3]	=>  Location: PIN_AH19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- wdata_seg2[4]	=>  Location: PIN_AG19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- wdata_seg2[5]	=>  Location: PIN_AF18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- wdata_seg2[6]	=>  Location: PIN_AH18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rdata_seg1[0]	=>  Location: PIN_AA25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rdata_seg1[1]	=>  Location: PIN_AA26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rdata_seg1[2]	=>  Location: PIN_Y25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rdata_seg1[3]	=>  Location: PIN_W26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rdata_seg1[4]	=>  Location: PIN_Y26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rdata_seg1[5]	=>  Location: PIN_W27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rdata_seg1[6]	=>  Location: PIN_W28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rdata_seg2[0]	=>  Location: PIN_V21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rdata_seg2[1]	=>  Location: PIN_U21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rdata_seg2[2]	=>  Location: PIN_AB20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rdata_seg2[3]	=>  Location: PIN_AA21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rdata_seg2[4]	=>  Location: PIN_AD24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rdata_seg2[5]	=>  Location: PIN_AF23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- rdata_seg2[6]	=>  Location: PIN_Y19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr[2]	=>  Location: PIN_AA22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr[0]	=>  Location: PIN_AA24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr[3]	=>  Location: PIN_Y24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr[1]	=>  Location: PIN_AA23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- addr[4]	=>  Location: PIN_Y23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datain[2]	=>  Location: PIN_AD27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datain[0]	=>  Location: PIN_AC28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datain[3]	=>  Location: PIN_AB27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datain[1]	=>  Location: PIN_AC27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datain[6]	=>  Location: PIN_AB26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datain[4]	=>  Location: PIN_AC26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datain[7]	=>  Location: PIN_AC25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- datain[5]	=>  Location: PIN_AD26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- we_en	=>  Location: PIN_AB28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk_key	=>  Location: PIN_M23,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF ram_top IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk_key : std_logic;
SIGNAL ww_we_en : std_logic;
SIGNAL ww_addr : std_logic_vector(4 DOWNTO 0);
SIGNAL ww_datain : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_addr_seg1 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_addr_seg2 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_wdata_seg1 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_wdata_seg2 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_rdata_seg1 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_rdata_seg2 : std_logic_vector(6 DOWNTO 0);
SIGNAL \r1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAIN_bus\ : std_logic_vector(17 DOWNTO 0);
SIGNAL \r1|altsyncram_component|auto_generated|ram_block1a0_PORTAADDR_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \r1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\ : std_logic_vector(17 DOWNTO 0);
SIGNAL \addr_seg1[0]~output_o\ : std_logic;
SIGNAL \addr_seg1[1]~output_o\ : std_logic;
SIGNAL \addr_seg1[2]~output_o\ : std_logic;
SIGNAL \addr_seg1[3]~output_o\ : std_logic;
SIGNAL \addr_seg1[4]~output_o\ : std_logic;
SIGNAL \addr_seg1[5]~output_o\ : std_logic;
SIGNAL \addr_seg1[6]~output_o\ : std_logic;
SIGNAL \addr_seg2[0]~output_o\ : std_logic;
SIGNAL \addr_seg2[1]~output_o\ : std_logic;
SIGNAL \addr_seg2[2]~output_o\ : std_logic;
SIGNAL \addr_seg2[3]~output_o\ : std_logic;
SIGNAL \addr_seg2[4]~output_o\ : std_logic;
SIGNAL \addr_seg2[5]~output_o\ : std_logic;
SIGNAL \addr_seg2[6]~output_o\ : std_logic;
SIGNAL \wdata_seg1[0]~output_o\ : std_logic;
SIGNAL \wdata_seg1[1]~output_o\ : std_logic;
SIGNAL \wdata_seg1[2]~output_o\ : std_logic;
SIGNAL \wdata_seg1[3]~output_o\ : std_logic;
SIGNAL \wdata_seg1[4]~output_o\ : std_logic;
SIGNAL \wdata_seg1[5]~output_o\ : std_logic;
SIGNAL \wdata_seg1[6]~output_o\ : std_logic;
SIGNAL \wdata_seg2[0]~output_o\ : std_logic;
SIGNAL \wdata_seg2[1]~output_o\ : std_logic;
SIGNAL \wdata_seg2[2]~output_o\ : std_logic;
SIGNAL \wdata_seg2[3]~output_o\ : std_logic;
SIGNAL \wdata_seg2[4]~output_o\ : std_logic;
SIGNAL \wdata_seg2[5]~output_o\ : std_logic;
SIGNAL \wdata_seg2[6]~output_o\ : std_logic;
SIGNAL \rdata_seg1[0]~output_o\ : std_logic;
SIGNAL \rdata_seg1[1]~output_o\ : std_logic;
SIGNAL \rdata_seg1[2]~output_o\ : std_logic;
SIGNAL \rdata_seg1[3]~output_o\ : std_logic;
SIGNAL \rdata_seg1[4]~output_o\ : std_logic;
SIGNAL \rdata_seg1[5]~output_o\ : std_logic;
SIGNAL \rdata_seg1[6]~output_o\ : std_logic;
SIGNAL \rdata_seg2[0]~output_o\ : std_logic;
SIGNAL \rdata_seg2[1]~output_o\ : std_logic;
SIGNAL \rdata_seg2[2]~output_o\ : std_logic;
SIGNAL \rdata_seg2[3]~output_o\ : std_logic;
SIGNAL \rdata_seg2[4]~output_o\ : std_logic;
SIGNAL \rdata_seg2[5]~output_o\ : std_logic;
SIGNAL \rdata_seg2[6]~output_o\ : std_logic;
SIGNAL \addr[2]~input_o\ : std_logic;
SIGNAL \addr[0]~input_o\ : std_logic;
SIGNAL \addr[3]~input_o\ : std_logic;
SIGNAL \addr[1]~input_o\ : std_logic;
SIGNAL \seg3|seg[0]~0_combout\ : std_logic;
SIGNAL \seg3|seg[1]~1_combout\ : std_logic;
SIGNAL \seg3|seg[2]~2_combout\ : std_logic;
SIGNAL \seg3|seg[3]~3_combout\ : std_logic;
SIGNAL \seg3|seg[4]~4_combout\ : std_logic;
SIGNAL \seg3|seg[5]~5_combout\ : std_logic;
SIGNAL \seg3|seg[6]~6_combout\ : std_logic;
SIGNAL \addr[4]~input_o\ : std_logic;
SIGNAL \datain[1]~input_o\ : std_logic;
SIGNAL \datain[0]~input_o\ : std_logic;
SIGNAL \datain[2]~input_o\ : std_logic;
SIGNAL \datain[3]~input_o\ : std_logic;
SIGNAL \seg1|seg[0]~0_combout\ : std_logic;
SIGNAL \seg1|seg[1]~1_combout\ : std_logic;
SIGNAL \seg1|seg[2]~2_combout\ : std_logic;
SIGNAL \seg1|seg[3]~3_combout\ : std_logic;
SIGNAL \seg1|seg[4]~4_combout\ : std_logic;
SIGNAL \seg1|seg[5]~5_combout\ : std_logic;
SIGNAL \seg1|seg[6]~6_combout\ : std_logic;
SIGNAL \datain[4]~input_o\ : std_logic;
SIGNAL \datain[5]~input_o\ : std_logic;
SIGNAL \datain[7]~input_o\ : std_logic;
SIGNAL \datain[6]~input_o\ : std_logic;
SIGNAL \seg2|seg[0]~0_combout\ : std_logic;
SIGNAL \seg2|seg[1]~1_combout\ : std_logic;
SIGNAL \seg2|seg[2]~2_combout\ : std_logic;
SIGNAL \seg2|seg[3]~3_combout\ : std_logic;
SIGNAL \seg2|seg[4]~4_combout\ : std_logic;
SIGNAL \seg2|seg[5]~5_combout\ : std_logic;
SIGNAL \seg2|seg[6]~6_combout\ : std_logic;
SIGNAL \we_en~input_o\ : std_logic;
SIGNAL \clk_key~input_o\ : std_logic;
SIGNAL \seg5|seg[0]~0_combout\ : std_logic;
SIGNAL \seg5|seg[1]~1_combout\ : std_logic;
SIGNAL \seg5|seg[2]~2_combout\ : std_logic;
SIGNAL \seg5|seg[3]~3_combout\ : std_logic;
SIGNAL \seg5|seg[4]~4_combout\ : std_logic;
SIGNAL \seg5|seg[5]~5_combout\ : std_logic;
SIGNAL \seg5|seg[6]~6_combout\ : std_logic;
SIGNAL \seg6|seg[0]~0_combout\ : std_logic;
SIGNAL \seg6|seg[1]~1_combout\ : std_logic;
SIGNAL \seg6|seg[2]~2_combout\ : std_logic;
SIGNAL \seg6|seg[3]~3_combout\ : std_logic;
SIGNAL \seg6|seg[4]~4_combout\ : std_logic;
SIGNAL \seg6|seg[5]~5_combout\ : std_logic;
SIGNAL \seg6|seg[6]~6_combout\ : std_logic;
SIGNAL \r1|altsyncram_component|auto_generated|q_a\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \ALT_INV_clk_key~input_o\ : std_logic;
SIGNAL \seg6|ALT_INV_seg[6]~6_combout\ : std_logic;
SIGNAL \seg5|ALT_INV_seg[6]~6_combout\ : std_logic;
SIGNAL \seg2|ALT_INV_seg[6]~6_combout\ : std_logic;
SIGNAL \seg1|ALT_INV_seg[6]~6_combout\ : std_logic;
SIGNAL \seg3|ALT_INV_seg[6]~6_combout\ : std_logic;

BEGIN

ww_clk_key <= clk_key;
ww_we_en <= we_en;
ww_addr <= addr;
ww_datain <= datain;
addr_seg1 <= ww_addr_seg1;
addr_seg2 <= ww_addr_seg2;
wdata_seg1 <= ww_wdata_seg1;
wdata_seg2 <= ww_wdata_seg2;
rdata_seg1 <= ww_rdata_seg1;
rdata_seg2 <= ww_rdata_seg2;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\r1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAIN_bus\ <= (gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & gnd & \datain[7]~input_o\ & \datain[6]~input_o\ & \datain[5]~input_o\ & \datain[4]~input_o\ & \datain[3]~input_o\ & 
\datain[2]~input_o\ & \datain[1]~input_o\ & \datain[0]~input_o\);

\r1|altsyncram_component|auto_generated|ram_block1a0_PORTAADDR_bus\ <= (\addr[4]~input_o\ & \addr[3]~input_o\ & \addr[2]~input_o\ & \addr[1]~input_o\ & \addr[0]~input_o\);

\r1|altsyncram_component|auto_generated|q_a\(0) <= \r1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(0);
\r1|altsyncram_component|auto_generated|q_a\(1) <= \r1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(1);
\r1|altsyncram_component|auto_generated|q_a\(2) <= \r1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(2);
\r1|altsyncram_component|auto_generated|q_a\(3) <= \r1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(3);
\r1|altsyncram_component|auto_generated|q_a\(4) <= \r1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(4);
\r1|altsyncram_component|auto_generated|q_a\(5) <= \r1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(5);
\r1|altsyncram_component|auto_generated|q_a\(6) <= \r1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(6);
\r1|altsyncram_component|auto_generated|q_a\(7) <= \r1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\(7);
\ALT_INV_clk_key~input_o\ <= NOT \clk_key~input_o\;
\seg6|ALT_INV_seg[6]~6_combout\ <= NOT \seg6|seg[6]~6_combout\;
\seg5|ALT_INV_seg[6]~6_combout\ <= NOT \seg5|seg[6]~6_combout\;
\seg2|ALT_INV_seg[6]~6_combout\ <= NOT \seg2|seg[6]~6_combout\;
\seg1|ALT_INV_seg[6]~6_combout\ <= NOT \seg1|seg[6]~6_combout\;
\seg3|ALT_INV_seg[6]~6_combout\ <= NOT \seg3|seg[6]~6_combout\;

-- Location: IOOBUF_X89_Y0_N23
\addr_seg1[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg3|seg[0]~0_combout\,
	devoe => ww_devoe,
	o => \addr_seg1[0]~output_o\);

-- Location: IOOBUF_X65_Y0_N2
\addr_seg1[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg3|seg[1]~1_combout\,
	devoe => ww_devoe,
	o => \addr_seg1[1]~output_o\);

-- Location: IOOBUF_X65_Y0_N9
\addr_seg1[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg3|seg[2]~2_combout\,
	devoe => ww_devoe,
	o => \addr_seg1[2]~output_o\);

-- Location: IOOBUF_X89_Y0_N16
\addr_seg1[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg3|seg[3]~3_combout\,
	devoe => ww_devoe,
	o => \addr_seg1[3]~output_o\);

-- Location: IOOBUF_X67_Y0_N16
\addr_seg1[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg3|seg[4]~4_combout\,
	devoe => ww_devoe,
	o => \addr_seg1[4]~output_o\);

-- Location: IOOBUF_X67_Y0_N23
\addr_seg1[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg3|seg[5]~5_combout\,
	devoe => ww_devoe,
	o => \addr_seg1[5]~output_o\);

-- Location: IOOBUF_X74_Y0_N23
\addr_seg1[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg3|ALT_INV_seg[6]~6_combout\,
	devoe => ww_devoe,
	o => \addr_seg1[6]~output_o\);

-- Location: IOOBUF_X74_Y0_N16
\addr_seg2[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \addr[4]~input_o\,
	devoe => ww_devoe,
	o => \addr_seg2[0]~output_o\);

-- Location: IOOBUF_X67_Y0_N9
\addr_seg2[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \addr_seg2[1]~output_o\);

-- Location: IOOBUF_X62_Y0_N23
\addr_seg2[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \addr_seg2[2]~output_o\);

-- Location: IOOBUF_X62_Y0_N16
\addr_seg2[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \addr[4]~input_o\,
	devoe => ww_devoe,
	o => \addr_seg2[3]~output_o\);

-- Location: IOOBUF_X67_Y0_N2
\addr_seg2[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \addr[4]~input_o\,
	devoe => ww_devoe,
	o => \addr_seg2[4]~output_o\);

-- Location: IOOBUF_X69_Y0_N9
\addr_seg2[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \addr[4]~input_o\,
	devoe => ww_devoe,
	o => \addr_seg2[5]~output_o\);

-- Location: IOOBUF_X54_Y0_N23
\addr_seg2[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \addr_seg2[6]~output_o\);

-- Location: IOOBUF_X98_Y0_N23
\wdata_seg1[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg1|seg[0]~0_combout\,
	devoe => ww_devoe,
	o => \wdata_seg1[0]~output_o\);

-- Location: IOOBUF_X107_Y0_N9
\wdata_seg1[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg1|seg[1]~1_combout\,
	devoe => ww_devoe,
	o => \wdata_seg1[1]~output_o\);

-- Location: IOOBUF_X74_Y0_N9
\wdata_seg1[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg1|seg[2]~2_combout\,
	devoe => ww_devoe,
	o => \wdata_seg1[2]~output_o\);

-- Location: IOOBUF_X74_Y0_N2
\wdata_seg1[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg1|seg[3]~3_combout\,
	devoe => ww_devoe,
	o => \wdata_seg1[3]~output_o\);

-- Location: IOOBUF_X83_Y0_N23
\wdata_seg1[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg1|seg[4]~4_combout\,
	devoe => ww_devoe,
	o => \wdata_seg1[4]~output_o\);

-- Location: IOOBUF_X83_Y0_N16
\wdata_seg1[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg1|seg[5]~5_combout\,
	devoe => ww_devoe,
	o => \wdata_seg1[5]~output_o\);

-- Location: IOOBUF_X79_Y0_N23
\wdata_seg1[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg1|ALT_INV_seg[6]~6_combout\,
	devoe => ww_devoe,
	o => \wdata_seg1[6]~output_o\);

-- Location: IOOBUF_X85_Y0_N9
\wdata_seg2[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg2|seg[0]~0_combout\,
	devoe => ww_devoe,
	o => \wdata_seg2[0]~output_o\);

-- Location: IOOBUF_X87_Y0_N16
\wdata_seg2[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg2|seg[1]~1_combout\,
	devoe => ww_devoe,
	o => \wdata_seg2[1]~output_o\);

-- Location: IOOBUF_X98_Y0_N16
\wdata_seg2[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg2|seg[2]~2_combout\,
	devoe => ww_devoe,
	o => \wdata_seg2[2]~output_o\);

-- Location: IOOBUF_X72_Y0_N2
\wdata_seg2[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg2|seg[3]~3_combout\,
	devoe => ww_devoe,
	o => \wdata_seg2[3]~output_o\);

-- Location: IOOBUF_X72_Y0_N9
\wdata_seg2[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg2|seg[4]~4_combout\,
	devoe => ww_devoe,
	o => \wdata_seg2[4]~output_o\);

-- Location: IOOBUF_X79_Y0_N16
\wdata_seg2[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg2|seg[5]~5_combout\,
	devoe => ww_devoe,
	o => \wdata_seg2[5]~output_o\);

-- Location: IOOBUF_X69_Y0_N2
\wdata_seg2[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg2|ALT_INV_seg[6]~6_combout\,
	devoe => ww_devoe,
	o => \wdata_seg2[6]~output_o\);

-- Location: IOOBUF_X115_Y17_N9
\rdata_seg1[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg5|seg[0]~0_combout\,
	devoe => ww_devoe,
	o => \rdata_seg1[0]~output_o\);

-- Location: IOOBUF_X115_Y16_N2
\rdata_seg1[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg5|seg[1]~1_combout\,
	devoe => ww_devoe,
	o => \rdata_seg1[1]~output_o\);

-- Location: IOOBUF_X115_Y19_N9
\rdata_seg1[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg5|seg[2]~2_combout\,
	devoe => ww_devoe,
	o => \rdata_seg1[2]~output_o\);

-- Location: IOOBUF_X115_Y19_N2
\rdata_seg1[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg5|seg[3]~3_combout\,
	devoe => ww_devoe,
	o => \rdata_seg1[3]~output_o\);

-- Location: IOOBUF_X115_Y18_N2
\rdata_seg1[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg5|seg[4]~4_combout\,
	devoe => ww_devoe,
	o => \rdata_seg1[4]~output_o\);

-- Location: IOOBUF_X115_Y20_N2
\rdata_seg1[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg5|seg[5]~5_combout\,
	devoe => ww_devoe,
	o => \rdata_seg1[5]~output_o\);

-- Location: IOOBUF_X115_Y21_N16
\rdata_seg1[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg5|ALT_INV_seg[6]~6_combout\,
	devoe => ww_devoe,
	o => \rdata_seg1[6]~output_o\);

-- Location: IOOBUF_X115_Y25_N16
\rdata_seg2[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg6|seg[0]~0_combout\,
	devoe => ww_devoe,
	o => \rdata_seg2[0]~output_o\);

-- Location: IOOBUF_X115_Y29_N2
\rdata_seg2[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg6|seg[1]~1_combout\,
	devoe => ww_devoe,
	o => \rdata_seg2[1]~output_o\);

-- Location: IOOBUF_X100_Y0_N2
\rdata_seg2[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg6|seg[2]~2_combout\,
	devoe => ww_devoe,
	o => \rdata_seg2[2]~output_o\);

-- Location: IOOBUF_X111_Y0_N2
\rdata_seg2[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg6|seg[3]~3_combout\,
	devoe => ww_devoe,
	o => \rdata_seg2[3]~output_o\);

-- Location: IOOBUF_X105_Y0_N23
\rdata_seg2[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg6|seg[4]~4_combout\,
	devoe => ww_devoe,
	o => \rdata_seg2[4]~output_o\);

-- Location: IOOBUF_X105_Y0_N9
\rdata_seg2[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg6|seg[5]~5_combout\,
	devoe => ww_devoe,
	o => \rdata_seg2[5]~output_o\);

-- Location: IOOBUF_X105_Y0_N2
\rdata_seg2[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \seg6|ALT_INV_seg[6]~6_combout\,
	devoe => ww_devoe,
	o => \rdata_seg2[6]~output_o\);

-- Location: IOIBUF_X115_Y6_N15
\addr[2]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_addr(2),
	o => \addr[2]~input_o\);

-- Location: IOIBUF_X115_Y9_N22
\addr[0]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_addr(0),
	o => \addr[0]~input_o\);

-- Location: IOIBUF_X115_Y13_N1
\addr[3]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_addr(3),
	o => \addr[3]~input_o\);

-- Location: IOIBUF_X115_Y10_N8
\addr[1]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_addr(1),
	o => \addr[1]~input_o\);

-- Location: LCCOMB_X86_Y1_N0
\seg3|seg[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg3|seg[0]~0_combout\ = (\addr[2]~input_o\ & (!\addr[1]~input_o\ & (\addr[0]~input_o\ $ (!\addr[3]~input_o\)))) # (!\addr[2]~input_o\ & ((\addr[3]~input_o\ & ((\addr[1]~input_o\))) # (!\addr[3]~input_o\ & (\addr[0]~input_o\ & !\addr[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000010000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \addr[2]~input_o\,
	datab => \addr[0]~input_o\,
	datac => \addr[3]~input_o\,
	datad => \addr[1]~input_o\,
	combout => \seg3|seg[0]~0_combout\);

-- Location: LCCOMB_X86_Y1_N6
\seg3|seg[1]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg3|seg[1]~1_combout\ = (\addr[3]~input_o\ & ((\addr[0]~input_o\ & ((\addr[1]~input_o\))) # (!\addr[0]~input_o\ & (\addr[2]~input_o\)))) # (!\addr[3]~input_o\ & (\addr[2]~input_o\ & (\addr[0]~input_o\ $ (\addr[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001000101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \addr[2]~input_o\,
	datab => \addr[0]~input_o\,
	datac => \addr[3]~input_o\,
	datad => \addr[1]~input_o\,
	combout => \seg3|seg[1]~1_combout\);

-- Location: LCCOMB_X86_Y1_N20
\seg3|seg[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg3|seg[2]~2_combout\ = (\addr[2]~input_o\ & (\addr[3]~input_o\ & ((\addr[1]~input_o\) # (!\addr[0]~input_o\)))) # (!\addr[2]~input_o\ & (!\addr[0]~input_o\ & (!\addr[3]~input_o\ & \addr[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000100100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \addr[2]~input_o\,
	datab => \addr[0]~input_o\,
	datac => \addr[3]~input_o\,
	datad => \addr[1]~input_o\,
	combout => \seg3|seg[2]~2_combout\);

-- Location: LCCOMB_X86_Y1_N30
\seg3|seg[3]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg3|seg[3]~3_combout\ = (\addr[1]~input_o\ & ((\addr[2]~input_o\ & (\addr[0]~input_o\)) # (!\addr[2]~input_o\ & (!\addr[0]~input_o\ & \addr[3]~input_o\)))) # (!\addr[1]~input_o\ & (!\addr[3]~input_o\ & (\addr[2]~input_o\ $ (\addr[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001100000000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \addr[2]~input_o\,
	datab => \addr[0]~input_o\,
	datac => \addr[3]~input_o\,
	datad => \addr[1]~input_o\,
	combout => \seg3|seg[3]~3_combout\);

-- Location: LCCOMB_X86_Y1_N16
\seg3|seg[4]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg3|seg[4]~4_combout\ = (\addr[1]~input_o\ & (((\addr[0]~input_o\ & !\addr[3]~input_o\)))) # (!\addr[1]~input_o\ & ((\addr[2]~input_o\ & ((!\addr[3]~input_o\))) # (!\addr[2]~input_o\ & (\addr[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110001001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \addr[2]~input_o\,
	datab => \addr[0]~input_o\,
	datac => \addr[3]~input_o\,
	datad => \addr[1]~input_o\,
	combout => \seg3|seg[4]~4_combout\);

-- Location: LCCOMB_X86_Y1_N26
\seg3|seg[5]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg3|seg[5]~5_combout\ = (\addr[2]~input_o\ & (\addr[0]~input_o\ & (\addr[3]~input_o\ $ (\addr[1]~input_o\)))) # (!\addr[2]~input_o\ & (!\addr[3]~input_o\ & ((\addr[0]~input_o\) # (\addr[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110110000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \addr[2]~input_o\,
	datab => \addr[0]~input_o\,
	datac => \addr[3]~input_o\,
	datad => \addr[1]~input_o\,
	combout => \seg3|seg[5]~5_combout\);

-- Location: LCCOMB_X86_Y1_N24
\seg3|seg[6]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg3|seg[6]~6_combout\ = (\addr[0]~input_o\ & ((\addr[3]~input_o\) # (\addr[2]~input_o\ $ (\addr[1]~input_o\)))) # (!\addr[0]~input_o\ & ((\addr[1]~input_o\) # (\addr[2]~input_o\ $ (\addr[3]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011111011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \addr[2]~input_o\,
	datab => \addr[0]~input_o\,
	datac => \addr[3]~input_o\,
	datad => \addr[1]~input_o\,
	combout => \seg3|seg[6]~6_combout\);

-- Location: IOIBUF_X115_Y14_N8
\addr[4]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_addr(4),
	o => \addr[4]~input_o\);

-- Location: IOIBUF_X115_Y15_N8
\datain[1]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datain(1),
	o => \datain[1]~input_o\);

-- Location: IOIBUF_X115_Y14_N1
\datain[0]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datain(0),
	o => \datain[0]~input_o\);

-- Location: IOIBUF_X115_Y13_N8
\datain[2]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datain(2),
	o => \datain[2]~input_o\);

-- Location: IOIBUF_X115_Y18_N8
\datain[3]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datain(3),
	o => \datain[3]~input_o\);

-- Location: LCCOMB_X86_Y2_N12
\seg1|seg[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg1|seg[0]~0_combout\ = (\datain[1]~input_o\ & (((!\datain[2]~input_o\ & \datain[3]~input_o\)))) # (!\datain[1]~input_o\ & ((\datain[0]~input_o\ & (\datain[2]~input_o\ $ (!\datain[3]~input_o\))) # (!\datain[0]~input_o\ & (\datain[2]~input_o\ & 
-- !\datain[3]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100101000010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datain[1]~input_o\,
	datab => \datain[0]~input_o\,
	datac => \datain[2]~input_o\,
	datad => \datain[3]~input_o\,
	combout => \seg1|seg[0]~0_combout\);

-- Location: LCCOMB_X86_Y2_N26
\seg1|seg[1]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg1|seg[1]~1_combout\ = (\datain[1]~input_o\ & ((\datain[0]~input_o\ & ((\datain[3]~input_o\))) # (!\datain[0]~input_o\ & (\datain[2]~input_o\)))) # (!\datain[1]~input_o\ & (\datain[2]~input_o\ & (\datain[0]~input_o\ $ (\datain[3]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100001100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datain[1]~input_o\,
	datab => \datain[0]~input_o\,
	datac => \datain[2]~input_o\,
	datad => \datain[3]~input_o\,
	combout => \seg1|seg[1]~1_combout\);

-- Location: LCCOMB_X86_Y2_N16
\seg1|seg[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg1|seg[2]~2_combout\ = (\datain[2]~input_o\ & (\datain[3]~input_o\ & ((\datain[1]~input_o\) # (!\datain[0]~input_o\)))) # (!\datain[2]~input_o\ & (\datain[1]~input_o\ & (!\datain[0]~input_o\ & !\datain[3]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datain[1]~input_o\,
	datab => \datain[0]~input_o\,
	datac => \datain[2]~input_o\,
	datad => \datain[3]~input_o\,
	combout => \seg1|seg[2]~2_combout\);

-- Location: LCCOMB_X86_Y2_N22
\seg1|seg[3]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg1|seg[3]~3_combout\ = (\datain[1]~input_o\ & ((\datain[0]~input_o\ & (\datain[2]~input_o\)) # (!\datain[0]~input_o\ & (!\datain[2]~input_o\ & \datain[3]~input_o\)))) # (!\datain[1]~input_o\ & (!\datain[3]~input_o\ & (\datain[0]~input_o\ $ 
-- (\datain[2]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001010010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datain[1]~input_o\,
	datab => \datain[0]~input_o\,
	datac => \datain[2]~input_o\,
	datad => \datain[3]~input_o\,
	combout => \seg1|seg[3]~3_combout\);

-- Location: LCCOMB_X86_Y2_N4
\seg1|seg[4]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg1|seg[4]~4_combout\ = (\datain[1]~input_o\ & (\datain[0]~input_o\ & ((!\datain[3]~input_o\)))) # (!\datain[1]~input_o\ & ((\datain[2]~input_o\ & ((!\datain[3]~input_o\))) # (!\datain[2]~input_o\ & (\datain[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010011011100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datain[1]~input_o\,
	datab => \datain[0]~input_o\,
	datac => \datain[2]~input_o\,
	datad => \datain[3]~input_o\,
	combout => \seg1|seg[4]~4_combout\);

-- Location: LCCOMB_X86_Y2_N6
\seg1|seg[5]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg1|seg[5]~5_combout\ = (\datain[1]~input_o\ & (!\datain[3]~input_o\ & ((\datain[0]~input_o\) # (!\datain[2]~input_o\)))) # (!\datain[1]~input_o\ & (\datain[0]~input_o\ & (\datain[2]~input_o\ $ (!\datain[3]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000010001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datain[1]~input_o\,
	datab => \datain[0]~input_o\,
	datac => \datain[2]~input_o\,
	datad => \datain[3]~input_o\,
	combout => \seg1|seg[5]~5_combout\);

-- Location: LCCOMB_X86_Y2_N24
\seg1|seg[6]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg1|seg[6]~6_combout\ = (\datain[0]~input_o\ & ((\datain[3]~input_o\) # (\datain[1]~input_o\ $ (\datain[2]~input_o\)))) # (!\datain[0]~input_o\ & ((\datain[1]~input_o\) # (\datain[2]~input_o\ $ (\datain[3]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111101111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datain[1]~input_o\,
	datab => \datain[0]~input_o\,
	datac => \datain[2]~input_o\,
	datad => \datain[3]~input_o\,
	combout => \seg1|seg[6]~6_combout\);

-- Location: IOIBUF_X115_Y11_N8
\datain[4]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datain(4),
	o => \datain[4]~input_o\);

-- Location: IOIBUF_X115_Y10_N1
\datain[5]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datain(5),
	o => \datain[5]~input_o\);

-- Location: IOIBUF_X115_Y4_N22
\datain[7]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datain(7),
	o => \datain[7]~input_o\);

-- Location: IOIBUF_X115_Y15_N1
\datain[6]~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_datain(6),
	o => \datain[6]~input_o\);

-- Location: LCCOMB_X87_Y3_N24
\seg2|seg[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg2|seg[0]~0_combout\ = (\datain[5]~input_o\ & (((\datain[7]~input_o\ & !\datain[6]~input_o\)))) # (!\datain[5]~input_o\ & ((\datain[4]~input_o\ & (\datain[7]~input_o\ $ (!\datain[6]~input_o\))) # (!\datain[4]~input_o\ & (!\datain[7]~input_o\ & 
-- \datain[6]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000111000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datain[4]~input_o\,
	datab => \datain[5]~input_o\,
	datac => \datain[7]~input_o\,
	datad => \datain[6]~input_o\,
	combout => \seg2|seg[0]~0_combout\);

-- Location: LCCOMB_X87_Y3_N30
\seg2|seg[1]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg2|seg[1]~1_combout\ = (\datain[5]~input_o\ & ((\datain[4]~input_o\ & (\datain[7]~input_o\)) # (!\datain[4]~input_o\ & ((\datain[6]~input_o\))))) # (!\datain[5]~input_o\ & (\datain[6]~input_o\ & (\datain[4]~input_o\ $ (\datain[7]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101011010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datain[4]~input_o\,
	datab => \datain[5]~input_o\,
	datac => \datain[7]~input_o\,
	datad => \datain[6]~input_o\,
	combout => \seg2|seg[1]~1_combout\);

-- Location: LCCOMB_X87_Y3_N8
\seg2|seg[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg2|seg[2]~2_combout\ = (\datain[7]~input_o\ & (\datain[6]~input_o\ & ((\datain[5]~input_o\) # (!\datain[4]~input_o\)))) # (!\datain[7]~input_o\ & (!\datain[4]~input_o\ & (\datain[5]~input_o\ & !\datain[6]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datain[4]~input_o\,
	datab => \datain[5]~input_o\,
	datac => \datain[7]~input_o\,
	datad => \datain[6]~input_o\,
	combout => \seg2|seg[2]~2_combout\);

-- Location: LCCOMB_X87_Y3_N18
\seg2|seg[3]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg2|seg[3]~3_combout\ = (\datain[5]~input_o\ & ((\datain[4]~input_o\ & ((\datain[6]~input_o\))) # (!\datain[4]~input_o\ & (\datain[7]~input_o\ & !\datain[6]~input_o\)))) # (!\datain[5]~input_o\ & (!\datain[7]~input_o\ & (\datain[4]~input_o\ $ 
-- (\datain[6]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100101000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datain[4]~input_o\,
	datab => \datain[5]~input_o\,
	datac => \datain[7]~input_o\,
	datad => \datain[6]~input_o\,
	combout => \seg2|seg[3]~3_combout\);

-- Location: LCCOMB_X87_Y3_N28
\seg2|seg[4]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg2|seg[4]~4_combout\ = (\datain[5]~input_o\ & (\datain[4]~input_o\ & (!\datain[7]~input_o\))) # (!\datain[5]~input_o\ & ((\datain[6]~input_o\ & ((!\datain[7]~input_o\))) # (!\datain[6]~input_o\ & (\datain[4]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101100101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datain[4]~input_o\,
	datab => \datain[5]~input_o\,
	datac => \datain[7]~input_o\,
	datad => \datain[6]~input_o\,
	combout => \seg2|seg[4]~4_combout\);

-- Location: LCCOMB_X87_Y3_N6
\seg2|seg[5]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg2|seg[5]~5_combout\ = (\datain[4]~input_o\ & (\datain[7]~input_o\ $ (((\datain[5]~input_o\) # (!\datain[6]~input_o\))))) # (!\datain[4]~input_o\ & (\datain[5]~input_o\ & (!\datain[7]~input_o\ & !\datain[6]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010100000001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datain[4]~input_o\,
	datab => \datain[5]~input_o\,
	datac => \datain[7]~input_o\,
	datad => \datain[6]~input_o\,
	combout => \seg2|seg[5]~5_combout\);

-- Location: LCCOMB_X87_Y3_N20
\seg2|seg[6]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg2|seg[6]~6_combout\ = (\datain[4]~input_o\ & ((\datain[7]~input_o\) # (\datain[5]~input_o\ $ (\datain[6]~input_o\)))) # (!\datain[4]~input_o\ & ((\datain[5]~input_o\) # (\datain[7]~input_o\ $ (\datain[6]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110011111111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datain[4]~input_o\,
	datab => \datain[5]~input_o\,
	datac => \datain[7]~input_o\,
	datad => \datain[6]~input_o\,
	combout => \seg2|seg[6]~6_combout\);

-- Location: IOIBUF_X115_Y17_N1
\we_en~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_we_en,
	o => \we_en~input_o\);

-- Location: IOIBUF_X115_Y40_N8
\clk_key~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk_key,
	o => \clk_key~input_o\);

-- Location: M9K_X104_Y8_N0
\r1|altsyncram_component|auto_generated|ram_block1a0\ : cycloneive_ram_block
-- pragma translate_off
GENERIC MAP (
	data_interleave_offset_in_bits => 1,
	data_interleave_width_in_bits => 1,
	logical_ram_name => "ram_1p_ip:r1|altsyncram:altsyncram_component|altsyncram_g6p3:auto_generated|ALTSYNCRAM",
	operation_mode => "single_port",
	port_a_address_clear => "none",
	port_a_address_width => 5,
	port_a_byte_enable_clock => "none",
	port_a_data_out_clear => "none",
	port_a_data_out_clock => "clock0",
	port_a_data_width => 18,
	port_a_first_address => 0,
	port_a_first_bit_number => 0,
	port_a_last_address => 31,
	port_a_logical_ram_depth => 32,
	port_a_logical_ram_width => 8,
	port_a_read_during_write_mode => "new_data_with_nbe_read",
	port_b_address_width => 5,
	port_b_data_width => 18,
	ram_block_type => "M9K")
-- pragma translate_on
PORT MAP (
	portawe => \we_en~input_o\,
	portare => VCC,
	clk0 => \ALT_INV_clk_key~input_o\,
	portadatain => \r1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAIN_bus\,
	portaaddr => \r1|altsyncram_component|auto_generated|ram_block1a0_PORTAADDR_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	portadataout => \r1|altsyncram_component|auto_generated|ram_block1a0_PORTADATAOUT_bus\);

-- Location: LCCOMB_X114_Y16_N0
\seg5|seg[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg5|seg[0]~0_combout\ = (\r1|altsyncram_component|auto_generated|q_a\(3) & ((\r1|altsyncram_component|auto_generated|q_a\(1) & ((!\r1|altsyncram_component|auto_generated|q_a\(2)))) # (!\r1|altsyncram_component|auto_generated|q_a\(1) & 
-- (\r1|altsyncram_component|auto_generated|q_a\(0) & \r1|altsyncram_component|auto_generated|q_a\(2))))) # (!\r1|altsyncram_component|auto_generated|q_a\(3) & (!\r1|altsyncram_component|auto_generated|q_a\(1) & 
-- (\r1|altsyncram_component|auto_generated|q_a\(0) $ (\r1|altsyncram_component|auto_generated|q_a\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000110011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1|altsyncram_component|auto_generated|q_a\(3),
	datab => \r1|altsyncram_component|auto_generated|q_a\(1),
	datac => \r1|altsyncram_component|auto_generated|q_a\(0),
	datad => \r1|altsyncram_component|auto_generated|q_a\(2),
	combout => \seg5|seg[0]~0_combout\);

-- Location: LCCOMB_X114_Y16_N22
\seg5|seg[1]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg5|seg[1]~1_combout\ = (\r1|altsyncram_component|auto_generated|q_a\(3) & ((\r1|altsyncram_component|auto_generated|q_a\(0) & (\r1|altsyncram_component|auto_generated|q_a\(1))) # (!\r1|altsyncram_component|auto_generated|q_a\(0) & 
-- ((\r1|altsyncram_component|auto_generated|q_a\(2)))))) # (!\r1|altsyncram_component|auto_generated|q_a\(3) & (\r1|altsyncram_component|auto_generated|q_a\(2) & (\r1|altsyncram_component|auto_generated|q_a\(1) $ 
-- (\r1|altsyncram_component|auto_generated|q_a\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001111010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1|altsyncram_component|auto_generated|q_a\(3),
	datab => \r1|altsyncram_component|auto_generated|q_a\(1),
	datac => \r1|altsyncram_component|auto_generated|q_a\(0),
	datad => \r1|altsyncram_component|auto_generated|q_a\(2),
	combout => \seg5|seg[1]~1_combout\);

-- Location: LCCOMB_X114_Y16_N16
\seg5|seg[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg5|seg[2]~2_combout\ = (\r1|altsyncram_component|auto_generated|q_a\(3) & (\r1|altsyncram_component|auto_generated|q_a\(2) & ((\r1|altsyncram_component|auto_generated|q_a\(1)) # (!\r1|altsyncram_component|auto_generated|q_a\(0))))) # 
-- (!\r1|altsyncram_component|auto_generated|q_a\(3) & (\r1|altsyncram_component|auto_generated|q_a\(1) & (!\r1|altsyncram_component|auto_generated|q_a\(0) & !\r1|altsyncram_component|auto_generated|q_a\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1|altsyncram_component|auto_generated|q_a\(3),
	datab => \r1|altsyncram_component|auto_generated|q_a\(1),
	datac => \r1|altsyncram_component|auto_generated|q_a\(0),
	datad => \r1|altsyncram_component|auto_generated|q_a\(2),
	combout => \seg5|seg[2]~2_combout\);

-- Location: LCCOMB_X114_Y16_N18
\seg5|seg[3]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg5|seg[3]~3_combout\ = (\r1|altsyncram_component|auto_generated|q_a\(1) & ((\r1|altsyncram_component|auto_generated|q_a\(0) & ((\r1|altsyncram_component|auto_generated|q_a\(2)))) # (!\r1|altsyncram_component|auto_generated|q_a\(0) & 
-- (\r1|altsyncram_component|auto_generated|q_a\(3) & !\r1|altsyncram_component|auto_generated|q_a\(2))))) # (!\r1|altsyncram_component|auto_generated|q_a\(1) & (!\r1|altsyncram_component|auto_generated|q_a\(3) & 
-- (\r1|altsyncram_component|auto_generated|q_a\(0) $ (\r1|altsyncram_component|auto_generated|q_a\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000100011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1|altsyncram_component|auto_generated|q_a\(3),
	datab => \r1|altsyncram_component|auto_generated|q_a\(1),
	datac => \r1|altsyncram_component|auto_generated|q_a\(0),
	datad => \r1|altsyncram_component|auto_generated|q_a\(2),
	combout => \seg5|seg[3]~3_combout\);

-- Location: LCCOMB_X114_Y16_N24
\seg5|seg[4]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg5|seg[4]~4_combout\ = (\r1|altsyncram_component|auto_generated|q_a\(1) & (!\r1|altsyncram_component|auto_generated|q_a\(3) & (\r1|altsyncram_component|auto_generated|q_a\(0)))) # (!\r1|altsyncram_component|auto_generated|q_a\(1) & 
-- ((\r1|altsyncram_component|auto_generated|q_a\(2) & (!\r1|altsyncram_component|auto_generated|q_a\(3))) # (!\r1|altsyncram_component|auto_generated|q_a\(2) & ((\r1|altsyncram_component|auto_generated|q_a\(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000101110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1|altsyncram_component|auto_generated|q_a\(3),
	datab => \r1|altsyncram_component|auto_generated|q_a\(1),
	datac => \r1|altsyncram_component|auto_generated|q_a\(0),
	datad => \r1|altsyncram_component|auto_generated|q_a\(2),
	combout => \seg5|seg[4]~4_combout\);

-- Location: LCCOMB_X114_Y16_N10
\seg5|seg[5]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg5|seg[5]~5_combout\ = (\r1|altsyncram_component|auto_generated|q_a\(1) & (!\r1|altsyncram_component|auto_generated|q_a\(3) & ((\r1|altsyncram_component|auto_generated|q_a\(0)) # (!\r1|altsyncram_component|auto_generated|q_a\(2))))) # 
-- (!\r1|altsyncram_component|auto_generated|q_a\(1) & (\r1|altsyncram_component|auto_generated|q_a\(0) & (\r1|altsyncram_component|auto_generated|q_a\(3) $ (!\r1|altsyncram_component|auto_generated|q_a\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000001010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1|altsyncram_component|auto_generated|q_a\(3),
	datab => \r1|altsyncram_component|auto_generated|q_a\(1),
	datac => \r1|altsyncram_component|auto_generated|q_a\(0),
	datad => \r1|altsyncram_component|auto_generated|q_a\(2),
	combout => \seg5|seg[5]~5_combout\);

-- Location: LCCOMB_X114_Y16_N12
\seg5|seg[6]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg5|seg[6]~6_combout\ = (\r1|altsyncram_component|auto_generated|q_a\(0) & ((\r1|altsyncram_component|auto_generated|q_a\(3)) # (\r1|altsyncram_component|auto_generated|q_a\(1) $ (\r1|altsyncram_component|auto_generated|q_a\(2))))) # 
-- (!\r1|altsyncram_component|auto_generated|q_a\(0) & ((\r1|altsyncram_component|auto_generated|q_a\(1)) # (\r1|altsyncram_component|auto_generated|q_a\(3) $ (\r1|altsyncram_component|auto_generated|q_a\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011110111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1|altsyncram_component|auto_generated|q_a\(3),
	datab => \r1|altsyncram_component|auto_generated|q_a\(1),
	datac => \r1|altsyncram_component|auto_generated|q_a\(0),
	datad => \r1|altsyncram_component|auto_generated|q_a\(2),
	combout => \seg5|seg[6]~6_combout\);

-- Location: LCCOMB_X105_Y8_N0
\seg6|seg[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg6|seg[0]~0_combout\ = (\r1|altsyncram_component|auto_generated|q_a\(7) & ((\r1|altsyncram_component|auto_generated|q_a\(5) & ((!\r1|altsyncram_component|auto_generated|q_a\(6)))) # (!\r1|altsyncram_component|auto_generated|q_a\(5) & 
-- (\r1|altsyncram_component|auto_generated|q_a\(4) & \r1|altsyncram_component|auto_generated|q_a\(6))))) # (!\r1|altsyncram_component|auto_generated|q_a\(7) & (!\r1|altsyncram_component|auto_generated|q_a\(5) & 
-- (\r1|altsyncram_component|auto_generated|q_a\(4) $ (\r1|altsyncram_component|auto_generated|q_a\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000110011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1|altsyncram_component|auto_generated|q_a\(7),
	datab => \r1|altsyncram_component|auto_generated|q_a\(5),
	datac => \r1|altsyncram_component|auto_generated|q_a\(4),
	datad => \r1|altsyncram_component|auto_generated|q_a\(6),
	combout => \seg6|seg[0]~0_combout\);

-- Location: LCCOMB_X105_Y8_N26
\seg6|seg[1]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg6|seg[1]~1_combout\ = (\r1|altsyncram_component|auto_generated|q_a\(7) & ((\r1|altsyncram_component|auto_generated|q_a\(4) & (\r1|altsyncram_component|auto_generated|q_a\(5))) # (!\r1|altsyncram_component|auto_generated|q_a\(4) & 
-- ((\r1|altsyncram_component|auto_generated|q_a\(6)))))) # (!\r1|altsyncram_component|auto_generated|q_a\(7) & (\r1|altsyncram_component|auto_generated|q_a\(6) & (\r1|altsyncram_component|auto_generated|q_a\(5) $ 
-- (\r1|altsyncram_component|auto_generated|q_a\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001111010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1|altsyncram_component|auto_generated|q_a\(7),
	datab => \r1|altsyncram_component|auto_generated|q_a\(5),
	datac => \r1|altsyncram_component|auto_generated|q_a\(4),
	datad => \r1|altsyncram_component|auto_generated|q_a\(6),
	combout => \seg6|seg[1]~1_combout\);

-- Location: LCCOMB_X105_Y8_N12
\seg6|seg[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg6|seg[2]~2_combout\ = (\r1|altsyncram_component|auto_generated|q_a\(7) & (\r1|altsyncram_component|auto_generated|q_a\(6) & ((\r1|altsyncram_component|auto_generated|q_a\(5)) # (!\r1|altsyncram_component|auto_generated|q_a\(4))))) # 
-- (!\r1|altsyncram_component|auto_generated|q_a\(7) & (\r1|altsyncram_component|auto_generated|q_a\(5) & (!\r1|altsyncram_component|auto_generated|q_a\(4) & !\r1|altsyncram_component|auto_generated|q_a\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1|altsyncram_component|auto_generated|q_a\(7),
	datab => \r1|altsyncram_component|auto_generated|q_a\(5),
	datac => \r1|altsyncram_component|auto_generated|q_a\(4),
	datad => \r1|altsyncram_component|auto_generated|q_a\(6),
	combout => \seg6|seg[2]~2_combout\);

-- Location: LCCOMB_X105_Y8_N2
\seg6|seg[3]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg6|seg[3]~3_combout\ = (\r1|altsyncram_component|auto_generated|q_a\(5) & ((\r1|altsyncram_component|auto_generated|q_a\(4) & ((\r1|altsyncram_component|auto_generated|q_a\(6)))) # (!\r1|altsyncram_component|auto_generated|q_a\(4) & 
-- (\r1|altsyncram_component|auto_generated|q_a\(7) & !\r1|altsyncram_component|auto_generated|q_a\(6))))) # (!\r1|altsyncram_component|auto_generated|q_a\(5) & (!\r1|altsyncram_component|auto_generated|q_a\(7) & 
-- (\r1|altsyncram_component|auto_generated|q_a\(4) $ (\r1|altsyncram_component|auto_generated|q_a\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000100011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1|altsyncram_component|auto_generated|q_a\(7),
	datab => \r1|altsyncram_component|auto_generated|q_a\(5),
	datac => \r1|altsyncram_component|auto_generated|q_a\(4),
	datad => \r1|altsyncram_component|auto_generated|q_a\(6),
	combout => \seg6|seg[3]~3_combout\);

-- Location: LCCOMB_X105_Y8_N4
\seg6|seg[4]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg6|seg[4]~4_combout\ = (\r1|altsyncram_component|auto_generated|q_a\(5) & (!\r1|altsyncram_component|auto_generated|q_a\(7) & (\r1|altsyncram_component|auto_generated|q_a\(4)))) # (!\r1|altsyncram_component|auto_generated|q_a\(5) & 
-- ((\r1|altsyncram_component|auto_generated|q_a\(6) & (!\r1|altsyncram_component|auto_generated|q_a\(7))) # (!\r1|altsyncram_component|auto_generated|q_a\(6) & ((\r1|altsyncram_component|auto_generated|q_a\(4))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000101110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1|altsyncram_component|auto_generated|q_a\(7),
	datab => \r1|altsyncram_component|auto_generated|q_a\(5),
	datac => \r1|altsyncram_component|auto_generated|q_a\(4),
	datad => \r1|altsyncram_component|auto_generated|q_a\(6),
	combout => \seg6|seg[4]~4_combout\);

-- Location: LCCOMB_X105_Y8_N30
\seg6|seg[5]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg6|seg[5]~5_combout\ = (\r1|altsyncram_component|auto_generated|q_a\(5) & (!\r1|altsyncram_component|auto_generated|q_a\(7) & ((\r1|altsyncram_component|auto_generated|q_a\(4)) # (!\r1|altsyncram_component|auto_generated|q_a\(6))))) # 
-- (!\r1|altsyncram_component|auto_generated|q_a\(5) & (\r1|altsyncram_component|auto_generated|q_a\(4) & (\r1|altsyncram_component|auto_generated|q_a\(7) $ (!\r1|altsyncram_component|auto_generated|q_a\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000001010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1|altsyncram_component|auto_generated|q_a\(7),
	datab => \r1|altsyncram_component|auto_generated|q_a\(5),
	datac => \r1|altsyncram_component|auto_generated|q_a\(4),
	datad => \r1|altsyncram_component|auto_generated|q_a\(6),
	combout => \seg6|seg[5]~5_combout\);

-- Location: LCCOMB_X105_Y8_N28
\seg6|seg[6]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \seg6|seg[6]~6_combout\ = (\r1|altsyncram_component|auto_generated|q_a\(4) & ((\r1|altsyncram_component|auto_generated|q_a\(7)) # (\r1|altsyncram_component|auto_generated|q_a\(5) $ (\r1|altsyncram_component|auto_generated|q_a\(6))))) # 
-- (!\r1|altsyncram_component|auto_generated|q_a\(4) & ((\r1|altsyncram_component|auto_generated|q_a\(5)) # (\r1|altsyncram_component|auto_generated|q_a\(7) $ (\r1|altsyncram_component|auto_generated|q_a\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011110111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r1|altsyncram_component|auto_generated|q_a\(7),
	datab => \r1|altsyncram_component|auto_generated|q_a\(5),
	datac => \r1|altsyncram_component|auto_generated|q_a\(4),
	datad => \r1|altsyncram_component|auto_generated|q_a\(6),
	combout => \seg6|seg[6]~6_combout\);

ww_addr_seg1(0) <= \addr_seg1[0]~output_o\;

ww_addr_seg1(1) <= \addr_seg1[1]~output_o\;

ww_addr_seg1(2) <= \addr_seg1[2]~output_o\;

ww_addr_seg1(3) <= \addr_seg1[3]~output_o\;

ww_addr_seg1(4) <= \addr_seg1[4]~output_o\;

ww_addr_seg1(5) <= \addr_seg1[5]~output_o\;

ww_addr_seg1(6) <= \addr_seg1[6]~output_o\;

ww_addr_seg2(0) <= \addr_seg2[0]~output_o\;

ww_addr_seg2(1) <= \addr_seg2[1]~output_o\;

ww_addr_seg2(2) <= \addr_seg2[2]~output_o\;

ww_addr_seg2(3) <= \addr_seg2[3]~output_o\;

ww_addr_seg2(4) <= \addr_seg2[4]~output_o\;

ww_addr_seg2(5) <= \addr_seg2[5]~output_o\;

ww_addr_seg2(6) <= \addr_seg2[6]~output_o\;

ww_wdata_seg1(0) <= \wdata_seg1[0]~output_o\;

ww_wdata_seg1(1) <= \wdata_seg1[1]~output_o\;

ww_wdata_seg1(2) <= \wdata_seg1[2]~output_o\;

ww_wdata_seg1(3) <= \wdata_seg1[3]~output_o\;

ww_wdata_seg1(4) <= \wdata_seg1[4]~output_o\;

ww_wdata_seg1(5) <= \wdata_seg1[5]~output_o\;

ww_wdata_seg1(6) <= \wdata_seg1[6]~output_o\;

ww_wdata_seg2(0) <= \wdata_seg2[0]~output_o\;

ww_wdata_seg2(1) <= \wdata_seg2[1]~output_o\;

ww_wdata_seg2(2) <= \wdata_seg2[2]~output_o\;

ww_wdata_seg2(3) <= \wdata_seg2[3]~output_o\;

ww_wdata_seg2(4) <= \wdata_seg2[4]~output_o\;

ww_wdata_seg2(5) <= \wdata_seg2[5]~output_o\;

ww_wdata_seg2(6) <= \wdata_seg2[6]~output_o\;

ww_rdata_seg1(0) <= \rdata_seg1[0]~output_o\;

ww_rdata_seg1(1) <= \rdata_seg1[1]~output_o\;

ww_rdata_seg1(2) <= \rdata_seg1[2]~output_o\;

ww_rdata_seg1(3) <= \rdata_seg1[3]~output_o\;

ww_rdata_seg1(4) <= \rdata_seg1[4]~output_o\;

ww_rdata_seg1(5) <= \rdata_seg1[5]~output_o\;

ww_rdata_seg1(6) <= \rdata_seg1[6]~output_o\;

ww_rdata_seg2(0) <= \rdata_seg2[0]~output_o\;

ww_rdata_seg2(1) <= \rdata_seg2[1]~output_o\;

ww_rdata_seg2(2) <= \rdata_seg2[2]~output_o\;

ww_rdata_seg2(3) <= \rdata_seg2[3]~output_o\;

ww_rdata_seg2(4) <= \rdata_seg2[4]~output_o\;

ww_rdata_seg2(5) <= \rdata_seg2[5]~output_o\;

ww_rdata_seg2(6) <= \rdata_seg2[6]~output_o\;
END structure;


