library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
entity seg_sel is
	port(
		num:in std_logic_vector(3 downto 0);
		seg:out std_logic_vector(6 downto 0));
end seg_sel;
architecture behav of seg_sel is
begin
	seg<=	"1000000" when num="0000" else
			"1111001" when num="0001" else
			"0100100" when num="0010" else
			"0110000" when num="0011" else
			"0011001" when num="0100" else
			"0010010" when num="0101" else
			"0000010" when num="0110" else
			"1111000" when num="0111" else
			"0000000" when num="1000" else
			"0010000" when num="1001" else
			"0001001" when num="1010" else
			"0000011" when num="1011" else
			"1000110" when num="1100" else
			"0100001" when num="1101" else
			"0000110" when num="1110" else
			"0001110" when num="1111" else
			"0000000";
end behav;