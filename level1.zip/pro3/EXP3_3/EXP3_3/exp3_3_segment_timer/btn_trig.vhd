library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
entity btn_trig is
	port(
		clk:in std_logic;
		btn:in std_logic;
		trig:out std_logic);--返回值是trig
end btn_trig;
architecture behav of btn_trig is
signal btn_sync,btn_delay:std_logic;
begin
	process(clk)
	begin
		if clk'event and clk='1' then   --同步的
			btn_sync<=btn;
			btn_delay<=btn_sync;--有一个延迟，应该是避免误触，要按的时间长一点点，才都置为一？是吗，但是下面的trig<=(btn_delay xor btn_sync) and btn_sync;写出真值表是只有
			--delay=0，sync=1时才有trig=1
		end if;
	end process;
	trig<=(btn_delay xor btn_sync) and btn_sync;
end behav;