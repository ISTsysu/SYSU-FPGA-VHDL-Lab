create_clock -period 10 -name clk [get_ports clk]
derive_clock_uncertainty