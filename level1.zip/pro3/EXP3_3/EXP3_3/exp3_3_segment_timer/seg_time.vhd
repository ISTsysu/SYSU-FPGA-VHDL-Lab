library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
--sw0 为1使能
--sw1 为1，时钟    为0，闹钟
--key0 在时钟状态（sw1=1）切换位置
--key1 在闹钟状态（sw1=0）切换位置
--key2 确定
--key3 增加

--闹钟到达后，ledg0会亮起来一次

entity seg_time is
	port(
		clk:in std_logic;
		en:in std_logic;
		mode1:in std_logic;
		
		ct1_btn:in std_logic;--四个按钮输入
		ct2_btn:in std_logic;
		inc_btn:in std_logic;
		done_btn:in std_logic;
		
		led1,led2,led3,led4,led5,led6,led7,led8,led9,led10,led11,led12,led13,led14:out std_logic;
		led_flash:out std_logic;
		
		min_high:out std_logic_vector(6 downto 0);
		min_low:out std_logic_vector(6 downto 0);
		sec_high:out std_logic_vector(6 downto 0);
		sec_low:out std_logic_vector(6 downto 0);
		hour_high:out std_logic_vector(6 downto 0);
		hour_low:out std_logic_vector(6 downto 0)
		);
end seg_time;

architecture behav of seg_time is

--按钮触发调用生声明--调用子文件btn_trig
component btn_trig is
	port(
		clk:in std_logic;
		btn:in std_logic;
		trig:out std_logic);
end component btn_trig;

--调用子文件freq_divider，分频器，把系统时钟转换为秒的速度
component freq_divider is
	generic(
		COUNT_MAX:natural);
	port(
		clk_in:in std_logic;
		clk_out:out std_logic);
end component freq_divider;

--调用子文件，num转换为七段显示的seg
component seg_sel is
	port(
		num:in std_logic_vector(3 downto 0);
		seg:out std_logic_vector(6 downto 0));
end component seg_sel;


type STATES is (IDLE,INC,S0,S1,M0,M1,H0,H1,ST0,ST1,MT0,MT1,HT0,HT1);--定义状态
signal current_state,next_state:STATES;

signal ct1_trig,ct2_trig,inc_trig,done_trig:std_logic;
signal time_trig:std_logic;
signal blink_mask:std_logic_vector(6 downto 0);
signal clk1Hz,clk10Hz:std_logic;

-- ticktock 滴答
signal cnt_min_high:std_logic_vector(3 downto 0);
signal cnt_min_low:std_logic_vector(3 downto 0);
signal cnt_sec_high:std_logic_vector(3 downto 0);
signal cnt_sec_low:std_logic_vector(3 downto 0);
signal cnt_hour_high:std_logic_vector(3 downto 0);
signal cnt_hour_low:std_logic_vector(3 downto 0);

signal in_min_high:std_logic_vector(3 downto 0);
signal in_min_low:std_logic_vector(3 downto 0);
signal in_sec_high:std_logic_vector(3 downto 0);
signal in_sec_low:std_logic_vector(3 downto 0);
signal in_hour_high:std_logic_vector(3 downto 0);
signal in_hour_low:std_logic_vector(3 downto 0);

signal reg_min_high:std_logic_vector(6 downto 0);
signal reg_min_low:std_logic_vector(6 downto 0);
signal reg_sec_high:std_logic_vector(6 downto 0);
signal reg_sec_low:std_logic_vector(6 downto 0);
signal reg_hour_high:std_logic_vector(6 downto 0);
signal reg_hour_low:std_logic_vector(6 downto 0);
 
-- timer 计时器
signal in_tim_min_high:std_logic_vector(3 downto 0);
signal in_tim_min_low:std_logic_vector(3 downto 0);
signal in_tim_sec_high:std_logic_vector(3 downto 0);
signal in_tim_sec_low:std_logic_vector(3 downto 0);
signal in_tim_hour_high:std_logic_vector(3 downto 0);
signal in_tim_hour_low:std_logic_vector(3 downto 0);

signal reg_tim_min_high:std_logic_vector(6 downto 0);
signal reg_tim_min_low:std_logic_vector(6 downto 0);
signal reg_tim_sec_high:std_logic_vector(6 downto 0);
signal reg_tim_sec_low:std_logic_vector(6 downto 0);
signal reg_tim_hour_high:std_logic_vector(6 downto 0);
signal reg_tim_hour_low:std_logic_vector(6 downto 0);

begin
	-- button trig 按钮触发
	bt1:btn_trig port map(clk=>clk,btn=>ct1_btn,trig=>ct1_trig);
	bt2:btn_trig port map(clk=>clk,btn=>ct2_btn,trig=>ct2_trig);
	bt3:btn_trig port map(clk=>clk,btn=>inc_btn,trig=>inc_trig);
	bt4:btn_trig port map(clk=>clk,btn=>done_btn,trig=>done_trig);
	
	-- num 2 seg convert
	se1:seg_sel port map(num=>cnt_min_high,seg=>reg_min_high);
	se2:seg_sel port map(num=>cnt_min_low,seg=>reg_min_low);
	se3:seg_sel port map(num=>cnt_sec_high,seg=>reg_sec_high);
	se4:seg_sel port map(num=>cnt_sec_low,seg=>reg_sec_low);
	se5:seg_sel port map(num=>cnt_hour_high,seg=>reg_hour_high);
	se6:seg_sel port map(num=>cnt_hour_low,seg=>reg_hour_low);
	
----闹钟时间转换为7段码
	se7:seg_sel port map(num=>in_tim_min_high,seg=>reg_tim_min_high);
	se8:seg_sel port map(num=>in_tim_min_low,seg=>reg_tim_min_low);
	se9:seg_sel port map(num=>in_tim_sec_high,seg=>reg_tim_sec_high);
	se10:seg_sel port map(num=>in_tim_sec_low,seg=>reg_tim_sec_low);
	se11:seg_sel port map(num=>in_tim_hour_high,seg=>reg_tim_hour_high);
	se12:seg_sel port map(num=>in_tim_hour_low,seg=>reg_tim_hour_low);
	

	-- clk declaration
	t1:freq_divider generic map(COUNT_MAX=>25000000) port map(clk_in=>clk,clk_out=>clk1Hz);--这里COUNT_MAX赋值为25000000
	t2:freq_divider generic map(COUNT_MAX=>25000000) port map(clk_in=>clk,clk_out=>clk10Hz);
	
	-- state machine seq
	process(clk,next_state,en)
	begin
		if en='1' then
			if clk'event and clk='1' then
				current_state<=next_state;
			end if;
		else
			current_state<=IDLE;
		end if;
	end process;
	
	-- state machine com
	process(current_state,ct1_trig,ct2_trig,done_trig)
	begin
		case current_state is
			when IDLE=>
				if ct1_trig='1' then
					next_state<=INC;
				else
					next_state<=IDLE;
				end if;
			when INC=>
				if ct1_trig='1' then
					next_state<=S0;
				elsif ct2_trig='1' then
					next_state<=ST0;
				else
					next_state<=INC;
				end if;
			when S0=>
				if ct1_trig='1' then
					next_state<=S1;
				elsif done_trig='1' then
					next_state<=INC;
				else
					next_state<=S0;
				end if;
			when S1=>
				if ct1_trig='1' then
					next_state<=M0;
				elsif done_trig='1' then
					next_state<=INC;
				else
					next_state<=S1;
				end if;
			when M0=>
				if ct1_trig='1' then
					next_state<=M1;
				elsif done_trig='1' then
					next_state<=INC;
				else
					next_state<=M0;
				end if;
			when M1=>
				if ct1_trig='1' then
					next_state<=H0;
				elsif done_trig='1' then
					next_state<=INC;
				else
					next_state<=M1;
				end if;
				
			when H0=>
				if ct1_trig='1' then
					next_state<=H1;
				elsif done_trig='1' then
					next_state<=INC;
				else
					next_state<=H0;
				end if;
			when H1=>
				if ct1_trig='1' then
					next_state<=INC;
				elsif done_trig='1' then
					next_state<=INC;
				else
					next_state<=H1;
				end if;
				
				
			when ST0=>
				if ct2_trig='1' then
					next_state<=ST1;
				elsif done_trig='1' then
					next_state<=INC;
				else
					next_state<=ST0;
				end if;
			when ST1=>
				if ct2_trig='1' then
					next_state<=MT0;
				elsif done_trig='1' then
					next_state<=INC;
				else
					next_state<=ST1;
				end if;
			when MT0=>
				if ct2_trig='1' then
					next_state<=MT1;
				elsif done_trig='1' then
					next_state<=INC;
				else
					next_state<=MT0;
				end if;
			when MT1=>
				if ct2_trig='1' then
					next_state<=HT0;
				elsif done_trig='1' then
					next_state<=INC;
				else
					next_state<=MT1;
				end if;
				
			when HT0=>
				if ct2_trig='1' then
					next_state<=HT1;
				elsif done_trig='1' then
					next_state<=INC;
				else
					next_state<=HT0;
				end if;
			when HT1=>
				if ct2_trig='1' then
					next_state<=INC;
				elsif done_trig='1' then
					next_state<=INC;
				else
					next_state<=HT1;
				end if;
				
			when others=>null;
		end case;
	end process;
	
	-- in_sec_low
	process(clk,current_state,inc_trig,in_sec_low)
	begin
		if current_state=S0 then
			if clk'event and clk='1' then
				if inc_trig='1' then
					if in_sec_low="1001" then
						in_sec_low<="0000";
					else
						in_sec_low<=in_sec_low+"0001";
					end if;
				end if;
			end if;
		else
			in_sec_low<=cnt_sec_low;
		end if;
	end process;
	
	-- cnt_sec_low
	process(clk1Hz,current_state,en,cnt_sec_low)
	begin
		if en='1' then
			if current_state=INC then
				if clk1Hz'event and clk1Hz='1' then
					if cnt_sec_low="1001" then
						cnt_sec_low<="0000";
					else
						cnt_sec_low<=cnt_sec_low+"0001";
					end if;
				end if;
			elsif current_state=S0 then
				cnt_sec_low<=in_sec_low;
			else
				null;
			end if;
		else
			cnt_sec_low<="0000";
		end if;
	end process;

	-- in_sec_high
	process(clk,current_state,inc_trig,in_sec_high)
	begin
		if current_state=S1 then
			if clk'event and clk='1' then
				if inc_trig='1' then
					if in_sec_high="0101" then
						in_sec_high<="0000";
					else
						in_sec_high<=in_sec_high+"0001";
					end if;
				end if;
			end if;
		else
			in_sec_high<=cnt_sec_high;
		end if;
	end process;

	-- cnt_sec_high
	process(clk1Hz,current_state,en,cnt_sec_high,cnt_sec_low)
	begin
		if en='1' then
			if current_state=INC then
				if clk1Hz'event and clk1Hz='1' then
					if cnt_sec_low="1001" then
						if cnt_sec_high="0101" then
							cnt_sec_high<="0000";
						else
							cnt_sec_high<=cnt_sec_high+"0001";
						end if;
					end if;
				end if;
			elsif current_state=S1 then
				cnt_sec_high<=in_sec_high;
			else 
				null;
			end if;
		else
			cnt_sec_high<="0000";
		end if;
	end process;

	-- in_min_low
	process(clk,current_state,inc_trig,in_min_low)
	begin
		if current_state=M0 then
			if clk'event and clk='1' then
				if inc_trig='1' then
					if in_min_low="1001" then          --10
						in_min_low<="0000";
					else
						in_min_low<=in_min_low+"0001";
					end if;
				end if;
			end if;
		else
			in_min_low<=cnt_min_low;
		end if;
	end process;

	-- cnt_min_low
	process(clk1Hz,current_state,en,cnt_min_low,cnt_sec_high,cnt_sec_low)
	begin
		if en='1' then
			if current_state=INC then
				if clk1Hz'event and clk1Hz='1' then
					if cnt_sec_high="0101" and cnt_sec_low="1001" then
						if cnt_min_low="1001" then
							cnt_min_low<="0000";
						else
							cnt_min_low<=cnt_min_low+"0001";
						end if;
					end if;
				end if;
			elsif current_state=M0 then
				cnt_min_low<=in_min_low;
			else
				null;
			end if;
		else
			cnt_min_low<="0000";
		end if;
	end process;

	-- in_min_high
	process(clk,current_state,inc_trig,in_min_high)
	begin
		if current_state=M1 then
			if clk'event and clk='1' then
				if inc_trig='1' then
					if in_min_high="0101" then
						in_min_high<="0000";
					else
						in_min_high<=in_min_high+"0001";
					end if;
				end if;
			end if;
		else
			in_min_high<=cnt_min_high;
		end if;
	end process;

	-- cnt_min_high
	process(clk1Hz,current_state,en,cnt_min_high,cnt_min_low)
	begin
		if en='1' then
			if current_state=INC then
				if clk1Hz'event and clk1Hz='1' then
					if cnt_min_low="1001" and cnt_sec_high="0101" and cnt_sec_low="1001" then
						if cnt_min_high="0101" then       --6
							cnt_min_high<="0000";
						else
							cnt_min_high<=cnt_min_high+"0001";
						end if;
					end if;
				end if;
			elsif current_state=M1 then
				cnt_min_high<=in_min_high;
			else
				null;
			end if;
		else
			cnt_min_high<="0000";
		end if;
	end process;
	
	
	-- in_HOUR_low
	process(clk,current_state,inc_trig,in_hour_low)
	begin
		if current_state=H0 then
			if clk'event and clk='1' then
				if inc_trig='1' then
					if in_hour_low="1001" then          
						in_hour_low<="0000";
					else
						in_hour_low<=in_hour_low+"0001";
					end if;
				end if;
			end if;
		else
			in_hour_low<=cnt_hour_low;
		end if;
	end process;

	-- cnt_HOUR_low
	process(clk1Hz,current_state,en,cnt_min_high,cnt_min_low,cnt_hour_high,cnt_hour_low)
	begin
		if en='1' then
			if current_state=INC then
				if clk1Hz'event and clk1Hz='1' then
					if cnt_min_high="0101" and cnt_min_low="1001"then
						if cnt_hour_high="0010" and cnt_hour_low="0011" then
							cnt_hour_low<="0000";
						elsif (cnt_hour_high="0000" or cnt_hour_high="0001") and cnt_hour_low="1001" then
							cnt_hour_low<="0000";
						else 
							cnt_hour_low<=cnt_hour_low+"0001";
						end if;
					end if;
				end if;
			elsif current_state=H0 then
				cnt_hour_low<=in_hour_low;
			else
				null;
			end if;
		else
			cnt_hour_low<="0000";
		end if;
	end process;
	
	-- in_HOUR_high
	process(clk,current_state,inc_trig,in_hour_high)
	begin
		if current_state=H1 then
			if clk'event and clk='1' then
				if inc_trig='1' then
					if in_hour_high="0010" then
						in_hour_high<="0000";
					else
						in_hour_high<=in_hour_high+"0001";
					end if;
				end if;
			end if;
		else
			in_hour_high<=cnt_hour_high;
		end if;
	end process;

	-- cnt_HOUR_high
	process(clk1Hz,current_state,en,cnt_hour_high,cnt_hour_low)
	begin
		if en='1' then
			if current_state=INC then
				if clk1Hz'event and clk1Hz='1' then
					if cnt_hour_low="1001" and cnt_min_high="0101" and cnt_min_low="1001" then
						if cnt_hour_high="0010" then       --2
							cnt_hour_high<="0000";
						else
							cnt_hour_high<=cnt_hour_high+"0001";
						end if;
					end if;
				end if;
			elsif current_state=H1 then
				cnt_hour_high<=in_hour_high;
			else
				null;
			end if;
		else
			cnt_hour_high<="0000";
		end if;
	end process;
	
	

	-- in_tim_sec_low
	process(clk,current_state,inc_trig,in_tim_sec_low,en)
	begin
		if en='1' then
			if current_state=ST0 then
				if clk'event and clk='1' then
					if inc_trig='1' then
						if in_tim_sec_low="1001" then
							in_tim_sec_low<="0000";
						else
							in_tim_sec_low<=in_tim_sec_low+"0001";
						end if;
					end if;
				end if;
			end if;
		else
			in_tim_sec_low<="0001";
		end if;
	end process;
	
	-- in_tim_sec_high
	process(clk,current_state,inc_trig,in_tim_sec_high,en)
	begin
		if en='1' then
			if current_state=ST1 then
				if clk'event and clk='1' then
					if inc_trig='1' then
						if in_tim_sec_high="0101" then
							in_tim_sec_high<="0000";
						else
							in_tim_sec_high<=in_tim_sec_high+"0001";
						end if;
					end if;
				end if;
			end if;
		else
			in_tim_sec_high<="0001";
		end if;
	end process;

	-- in_tim_min_low
	process(clk,current_state,inc_trig,in_tim_min_low,en)
	begin
		if en='1' then
			if current_state=MT0 then
				if clk'event and clk='1' then
					if inc_trig='1' then
						if in_tim_min_low="1001" then
							in_tim_min_low<="0000";
						else
							in_tim_min_low<=in_tim_min_low+"0001";
						end if;
					end if;
				end if;
			end if;
		else
			in_tim_min_low<="0001";
		end if;
	end process;
	
	-- in_tim_min_high
	process(clk,current_state,inc_trig,in_tim_min_high,en)
	begin
		if en='1' then
			if current_state=MT1 then
				if clk'event and clk='1' then
					if inc_trig='1' then
						if in_tim_min_high="0101" then
							in_tim_min_high<="0000";
						else
							in_tim_min_high<=in_tim_min_high+"0001";
						end if;
					end if;
				end if;
			end if;
		else
			in_tim_min_high<="0001";
		end if;
	end process;
	
----------------------------------------------------	
	-- in_tim_hour_low
	process(clk,current_state,inc_trig,in_tim_hour_low,en)
	begin
		if en='1' then
			if current_state=HT0 then
				if clk'event and clk='1' then
					if inc_trig='1' then
						if in_tim_hour_low="1001" then
							in_tim_hour_low<="0000";
						else
							in_tim_hour_low<=in_tim_hour_low+"0001";
						end if;
					end if;
				end if;
			end if;
		else
			in_tim_hour_low<="0001";
		end if;
	end process;
	
	-- in_tim_hour_high
	process(clk,current_state,inc_trig,in_tim_hour_high,en)
	begin
		if en='1' then
			if current_state=HT1 then
				if clk'event and clk='1' then
					if inc_trig='1' then
						if in_tim_hour_high="0010" then
							in_tim_hour_high<="0000";
						else
							in_tim_hour_high<=in_tim_hour_high+"0001";
						end if;
					end if;
				end if;
			end if;
		else
			in_tim_hour_high<="0001";
		end if;
	end process;
		
	
	
	process(inc_trig,current_state,time_trig)
	begin
		if en='1' then
			if current_state=INC then
				if in_tim_hour_high=cnt_hour_high and in_tim_hour_low=cnt_hour_low and in_tim_min_high=cnt_min_high and in_tim_sec_high=cnt_sec_high and in_tim_min_low=cnt_min_low and in_tim_sec_low=cnt_sec_low then
					time_trig<='1';
				elsif inc_trig='1' then
					time_trig<='0';
				else
					time_trig<=time_trig;
				end if;
			else
				null;
			end if;
		else
			time_trig<='0';
		end if;
	end process;
	
	-- led state indicate
	led1<='1' when current_state=INC else '0';
	
	led2<='1' when current_state=S0 else '0';
	led3<='1' when current_state=S1 else '0';
	led4<='1' when current_state=M0 else '0';
	led5<='1' when current_state=M1 else '0';
	led6<='1' when current_state=H0 else '0';
	led7<='1' when current_state=H1 else '0';
	
	led8<='1' when current_state=ST0 else '0';
	led9<='1' when current_state=ST1 else '0';
	led10<='1' when current_state=MT0 else '0';
	led11<='1' when current_state=MT1 else '0';
	led12<='1' when current_state=HT0 else '0';
	led13<='1' when current_state=HT1 else '0';
	
	led14<=clk1Hz;
	
	-- seg output
	blink_mask<="1111111" when clk1Hz='1' else "0000000";
	led_flash<=clk10Hz when time_trig='1' else '0';

	min_high<=(blink_mask or reg_min_high) when  mode1='1' and current_state=M1 else reg_min_high when mode1 = '1' else (blink_mask or reg_tim_min_high) when current_state = MT1 else reg_tim_min_high;
	min_low<=(blink_mask or reg_min_low) when mode1='1' and  current_state=M0 else reg_min_low when mode1 = '1' else (blink_mask or reg_tim_min_low) when current_state=MT0 else reg_tim_min_low;
	sec_high<=(blink_mask or reg_sec_high) when mode1='1' and current_state=S1 else reg_sec_high when mode1 = '1' else (blink_mask or reg_tim_sec_high) when current_state=ST1 else reg_tim_sec_high;
	sec_low<=(blink_mask or reg_sec_low) when mode1='1' and current_state=S0 else reg_sec_low when mode1 = '1' else (blink_mask or reg_tim_sec_low) when current_state=ST0 else reg_tim_sec_low;
	hour_high<=(blink_mask or reg_hour_high) when mode1='1' and current_state=H1 else reg_hour_high when mode1 = '1' else (blink_mask or reg_tim_hour_high) when current_state=HT1 else reg_tim_hour_high;
	hour_low<=(blink_mask or reg_hour_low) when mode1='1' and current_state=H0 else reg_hour_low when mode1 = '1' else (blink_mask or reg_tim_hour_low) when current_state=HT0 else reg_tim_hour_low ;	

end behav;