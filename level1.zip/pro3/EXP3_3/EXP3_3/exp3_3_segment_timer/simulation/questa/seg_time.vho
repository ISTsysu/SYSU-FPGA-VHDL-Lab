-- Copyright (C) 2023  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details, at
-- https://fpgasoftware.intel.com/eula.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 23.1std.0 Build 991 11/28/2023 SC Lite Edition"

-- DATE "05/30/2025 15:39:23"

-- 
-- Device: Altera EP4CE115F29C7 Package FBGA780
-- 

-- 
-- This VHDL file should be used for Questa Intel FPGA (VHDL) only
-- 

LIBRARY CYCLONEIVE;
LIBRARY IEEE;
USE CYCLONEIVE.CYCLONEIVE_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	hard_block IS
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic
	);
END hard_block;

-- Design Ports Information
-- ~ALTERA_ASDO_DATA1~	=>  Location: PIN_F4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_FLASH_nCE_nCSO~	=>  Location: PIN_E2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_DCLK~	=>  Location: PIN_P3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_DATA0~	=>  Location: PIN_N7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_nCEO~	=>  Location: PIN_P28,	 I/O Standard: 2.5 V,	 Current Strength: 8mA


ARCHITECTURE structure OF hard_block IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL \~ALTERA_ASDO_DATA1~~padout\ : std_logic;
SIGNAL \~ALTERA_FLASH_nCE_nCSO~~padout\ : std_logic;
SIGNAL \~ALTERA_DATA0~~padout\ : std_logic;
SIGNAL \~ALTERA_ASDO_DATA1~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_FLASH_nCE_nCSO~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_DATA0~~ibuf_o\ : std_logic;

BEGIN

ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
END structure;


LIBRARY ALTERA;
LIBRARY CYCLONEIVE;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIVE.CYCLONEIVE_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	seg_time IS
    PORT (
	clk : IN std_logic;
	en : IN std_logic;
	mode1 : IN std_logic;
	ct1_btn : IN std_logic;
	ct2_btn : IN std_logic;
	inc_btn : IN std_logic;
	done_btn : IN std_logic;
	led1 : OUT std_logic;
	led2 : OUT std_logic;
	led3 : OUT std_logic;
	led4 : OUT std_logic;
	led5 : OUT std_logic;
	led6 : OUT std_logic;
	led7 : OUT std_logic;
	led8 : OUT std_logic;
	led9 : OUT std_logic;
	led10 : OUT std_logic;
	led11 : OUT std_logic;
	led12 : OUT std_logic;
	led13 : OUT std_logic;
	led14 : OUT std_logic;
	led_flash : OUT std_logic;
	min_high : OUT std_logic_vector(6 DOWNTO 0);
	min_low : OUT std_logic_vector(6 DOWNTO 0);
	sec_high : OUT std_logic_vector(6 DOWNTO 0);
	sec_low : OUT std_logic_vector(6 DOWNTO 0);
	hour_high : OUT std_logic_vector(6 DOWNTO 0);
	hour_low : OUT std_logic_vector(6 DOWNTO 0)
	);
END seg_time;

-- Design Ports Information
-- led1	=>  Location: PIN_G19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led2	=>  Location: PIN_F19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led3	=>  Location: PIN_E19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led4	=>  Location: PIN_F21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led5	=>  Location: PIN_F18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led6	=>  Location: PIN_E18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led7	=>  Location: PIN_J19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led8	=>  Location: PIN_H19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led9	=>  Location: PIN_J17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led10	=>  Location: PIN_G17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led11	=>  Location: PIN_J15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led12	=>  Location: PIN_H16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led13	=>  Location: PIN_J16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led14	=>  Location: PIN_H17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led_flash	=>  Location: PIN_E21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_high[0]	=>  Location: PIN_AD18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_high[1]	=>  Location: PIN_AC18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_high[2]	=>  Location: PIN_AB18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_high[3]	=>  Location: PIN_AH19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_high[4]	=>  Location: PIN_AG19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_high[5]	=>  Location: PIN_AF18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_high[6]	=>  Location: PIN_AH18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_low[0]	=>  Location: PIN_AB19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_low[1]	=>  Location: PIN_AA19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_low[2]	=>  Location: PIN_AG21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_low[3]	=>  Location: PIN_AH21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_low[4]	=>  Location: PIN_AE19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_low[5]	=>  Location: PIN_AF19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_low[6]	=>  Location: PIN_AE18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_high[0]	=>  Location: PIN_V21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_high[1]	=>  Location: PIN_U21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_high[2]	=>  Location: PIN_AB20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_high[3]	=>  Location: PIN_AA21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_high[4]	=>  Location: PIN_AD24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_high[5]	=>  Location: PIN_AF23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_high[6]	=>  Location: PIN_Y19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_low[0]	=>  Location: PIN_AA25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_low[1]	=>  Location: PIN_AA26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_low[2]	=>  Location: PIN_Y25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_low[3]	=>  Location: PIN_W26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_low[4]	=>  Location: PIN_Y26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_low[5]	=>  Location: PIN_W27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_low[6]	=>  Location: PIN_W28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hour_high[0]	=>  Location: PIN_AD17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hour_high[1]	=>  Location: PIN_AE17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hour_high[2]	=>  Location: PIN_AG17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hour_high[3]	=>  Location: PIN_AH17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hour_high[4]	=>  Location: PIN_AF17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hour_high[5]	=>  Location: PIN_AG18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hour_high[6]	=>  Location: PIN_AA14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hour_low[0]	=>  Location: PIN_AA17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hour_low[1]	=>  Location: PIN_AB16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hour_low[2]	=>  Location: PIN_AA16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hour_low[3]	=>  Location: PIN_AB17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hour_low[4]	=>  Location: PIN_AB15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hour_low[5]	=>  Location: PIN_AA15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- hour_low[6]	=>  Location: PIN_AC17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- mode1	=>  Location: PIN_AC28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk	=>  Location: PIN_Y2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- en	=>  Location: PIN_AB28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ct2_btn	=>  Location: PIN_M21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ct1_btn	=>  Location: PIN_M23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- done_btn	=>  Location: PIN_N21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- inc_btn	=>  Location: PIN_R24,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF seg_time IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk : std_logic;
SIGNAL ww_en : std_logic;
SIGNAL ww_mode1 : std_logic;
SIGNAL ww_ct1_btn : std_logic;
SIGNAL ww_ct2_btn : std_logic;
SIGNAL ww_inc_btn : std_logic;
SIGNAL ww_done_btn : std_logic;
SIGNAL ww_led1 : std_logic;
SIGNAL ww_led2 : std_logic;
SIGNAL ww_led3 : std_logic;
SIGNAL ww_led4 : std_logic;
SIGNAL ww_led5 : std_logic;
SIGNAL ww_led6 : std_logic;
SIGNAL ww_led7 : std_logic;
SIGNAL ww_led8 : std_logic;
SIGNAL ww_led9 : std_logic;
SIGNAL ww_led10 : std_logic;
SIGNAL ww_led11 : std_logic;
SIGNAL ww_led12 : std_logic;
SIGNAL ww_led13 : std_logic;
SIGNAL ww_led14 : std_logic;
SIGNAL ww_led_flash : std_logic;
SIGNAL ww_min_high : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_min_low : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_sec_high : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_sec_low : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_hour_high : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_hour_low : std_logic_vector(6 DOWNTO 0);
SIGNAL \clk~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \cnt_min_high[2]~0clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \led1~output_o\ : std_logic;
SIGNAL \led2~output_o\ : std_logic;
SIGNAL \led3~output_o\ : std_logic;
SIGNAL \led4~output_o\ : std_logic;
SIGNAL \led5~output_o\ : std_logic;
SIGNAL \led6~output_o\ : std_logic;
SIGNAL \led7~output_o\ : std_logic;
SIGNAL \led8~output_o\ : std_logic;
SIGNAL \led9~output_o\ : std_logic;
SIGNAL \led10~output_o\ : std_logic;
SIGNAL \led11~output_o\ : std_logic;
SIGNAL \led12~output_o\ : std_logic;
SIGNAL \led13~output_o\ : std_logic;
SIGNAL \led14~output_o\ : std_logic;
SIGNAL \led_flash~output_o\ : std_logic;
SIGNAL \min_high[0]~output_o\ : std_logic;
SIGNAL \min_high[1]~output_o\ : std_logic;
SIGNAL \min_high[2]~output_o\ : std_logic;
SIGNAL \min_high[3]~output_o\ : std_logic;
SIGNAL \min_high[4]~output_o\ : std_logic;
SIGNAL \min_high[5]~output_o\ : std_logic;
SIGNAL \min_high[6]~output_o\ : std_logic;
SIGNAL \min_low[0]~output_o\ : std_logic;
SIGNAL \min_low[1]~output_o\ : std_logic;
SIGNAL \min_low[2]~output_o\ : std_logic;
SIGNAL \min_low[3]~output_o\ : std_logic;
SIGNAL \min_low[4]~output_o\ : std_logic;
SIGNAL \min_low[5]~output_o\ : std_logic;
SIGNAL \min_low[6]~output_o\ : std_logic;
SIGNAL \sec_high[0]~output_o\ : std_logic;
SIGNAL \sec_high[1]~output_o\ : std_logic;
SIGNAL \sec_high[2]~output_o\ : std_logic;
SIGNAL \sec_high[3]~output_o\ : std_logic;
SIGNAL \sec_high[4]~output_o\ : std_logic;
SIGNAL \sec_high[5]~output_o\ : std_logic;
SIGNAL \sec_high[6]~output_o\ : std_logic;
SIGNAL \sec_low[0]~output_o\ : std_logic;
SIGNAL \sec_low[1]~output_o\ : std_logic;
SIGNAL \sec_low[2]~output_o\ : std_logic;
SIGNAL \sec_low[3]~output_o\ : std_logic;
SIGNAL \sec_low[4]~output_o\ : std_logic;
SIGNAL \sec_low[5]~output_o\ : std_logic;
SIGNAL \sec_low[6]~output_o\ : std_logic;
SIGNAL \hour_high[0]~output_o\ : std_logic;
SIGNAL \hour_high[1]~output_o\ : std_logic;
SIGNAL \hour_high[2]~output_o\ : std_logic;
SIGNAL \hour_high[3]~output_o\ : std_logic;
SIGNAL \hour_high[4]~output_o\ : std_logic;
SIGNAL \hour_high[5]~output_o\ : std_logic;
SIGNAL \hour_high[6]~output_o\ : std_logic;
SIGNAL \hour_low[0]~output_o\ : std_logic;
SIGNAL \hour_low[1]~output_o\ : std_logic;
SIGNAL \hour_low[2]~output_o\ : std_logic;
SIGNAL \hour_low[3]~output_o\ : std_logic;
SIGNAL \hour_low[4]~output_o\ : std_logic;
SIGNAL \hour_low[5]~output_o\ : std_logic;
SIGNAL \hour_low[6]~output_o\ : std_logic;
SIGNAL \clk~input_o\ : std_logic;
SIGNAL \clk~inputclkctrl_outclk\ : std_logic;
SIGNAL \done_btn~input_o\ : std_logic;
SIGNAL \bt4|btn_sync~q\ : std_logic;
SIGNAL \bt4|btn_delay~q\ : std_logic;
SIGNAL \bt4|trig~0_combout\ : std_logic;
SIGNAL \ct1_btn~input_o\ : std_logic;
SIGNAL \bt1|btn_sync~q\ : std_logic;
SIGNAL \bt1|btn_delay~q\ : std_logic;
SIGNAL \Selector1~0_combout\ : std_logic;
SIGNAL \en~input_o\ : std_logic;
SIGNAL \next_state~0_combout\ : std_logic;
SIGNAL \current_state.S0~q\ : std_logic;
SIGNAL \Selector2~0_combout\ : std_logic;
SIGNAL \current_state.S1~q\ : std_logic;
SIGNAL \Selector3~0_combout\ : std_logic;
SIGNAL \current_state.M0~q\ : std_logic;
SIGNAL \Selector4~0_combout\ : std_logic;
SIGNAL \current_state.M1~q\ : std_logic;
SIGNAL \Selector0~2_combout\ : std_logic;
SIGNAL \Selector5~0_combout\ : std_logic;
SIGNAL \current_state.H0~q\ : std_logic;
SIGNAL \Selector0~3_combout\ : std_logic;
SIGNAL \ct2_btn~input_o\ : std_logic;
SIGNAL \bt2|btn_sync~q\ : std_logic;
SIGNAL \bt2|btn_delay~q\ : std_logic;
SIGNAL \Selector7~0_combout\ : std_logic;
SIGNAL \next_state~1_combout\ : std_logic;
SIGNAL \bt2|trig~combout\ : std_logic;
SIGNAL \Selector7~1_combout\ : std_logic;
SIGNAL \current_state.ST0~q\ : std_logic;
SIGNAL \Selector8~0_combout\ : std_logic;
SIGNAL \current_state.ST1~q\ : std_logic;
SIGNAL \Selector9~0_combout\ : std_logic;
SIGNAL \current_state.MT0~q\ : std_logic;
SIGNAL \Selector10~0_combout\ : std_logic;
SIGNAL \current_state.MT1~q\ : std_logic;
SIGNAL \Selector11~0_combout\ : std_logic;
SIGNAL \current_state.HT0~q\ : std_logic;
SIGNAL \Selector0~4_combout\ : std_logic;
SIGNAL \Selector0~5_combout\ : std_logic;
SIGNAL \current_state.IDLE~0_combout\ : std_logic;
SIGNAL \current_state.IDLE~q\ : std_logic;
SIGNAL \bt1|trig~combout\ : std_logic;
SIGNAL \Selector0~0_combout\ : std_logic;
SIGNAL \Selector12~0_combout\ : std_logic;
SIGNAL \current_state.HT1~q\ : std_logic;
SIGNAL \Selector6~0_combout\ : std_logic;
SIGNAL \current_state.H1~q\ : std_logic;
SIGNAL \Selector0~1_combout\ : std_logic;
SIGNAL \Selector0~6_combout\ : std_logic;
SIGNAL \current_state.INC~q\ : std_logic;
SIGNAL \t1|toggle~0_combout\ : std_logic;
SIGNAL \t1|toggle~feeder_combout\ : std_logic;
SIGNAL \t1|Add0~0_combout\ : std_logic;
SIGNAL \t1|Add0~1\ : std_logic;
SIGNAL \t1|Add0~2_combout\ : std_logic;
SIGNAL \t1|Add0~3\ : std_logic;
SIGNAL \t1|Add0~4_combout\ : std_logic;
SIGNAL \t1|Add0~5\ : std_logic;
SIGNAL \t1|Add0~6_combout\ : std_logic;
SIGNAL \t1|Add0~7\ : std_logic;
SIGNAL \t1|Add0~8_combout\ : std_logic;
SIGNAL \t1|Add0~9\ : std_logic;
SIGNAL \t1|Add0~10_combout\ : std_logic;
SIGNAL \t1|Add0~11\ : std_logic;
SIGNAL \t1|Add0~12_combout\ : std_logic;
SIGNAL \t1|count~2_combout\ : std_logic;
SIGNAL \t1|Add0~13\ : std_logic;
SIGNAL \t1|Add0~14_combout\ : std_logic;
SIGNAL \t1|Add0~15\ : std_logic;
SIGNAL \t1|Add0~16_combout\ : std_logic;
SIGNAL \t1|Add0~17\ : std_logic;
SIGNAL \t1|Add0~18_combout\ : std_logic;
SIGNAL \t1|Add0~19\ : std_logic;
SIGNAL \t1|Add0~20_combout\ : std_logic;
SIGNAL \t1|Add0~21\ : std_logic;
SIGNAL \t1|Add0~22_combout\ : std_logic;
SIGNAL \t1|count~1_combout\ : std_logic;
SIGNAL \t1|Add0~23\ : std_logic;
SIGNAL \t1|Add0~24_combout\ : std_logic;
SIGNAL \t1|count~0_combout\ : std_logic;
SIGNAL \t1|Add0~25\ : std_logic;
SIGNAL \t1|Add0~26_combout\ : std_logic;
SIGNAL \t1|count~3_combout\ : std_logic;
SIGNAL \t1|Add0~27\ : std_logic;
SIGNAL \t1|Add0~28_combout\ : std_logic;
SIGNAL \t1|count~4_combout\ : std_logic;
SIGNAL \t1|Add0~29\ : std_logic;
SIGNAL \t1|Add0~30_combout\ : std_logic;
SIGNAL \t1|Add0~31\ : std_logic;
SIGNAL \t1|Add0~32_combout\ : std_logic;
SIGNAL \t1|count~5_combout\ : std_logic;
SIGNAL \t1|Add0~33\ : std_logic;
SIGNAL \t1|Add0~34_combout\ : std_logic;
SIGNAL \t1|Add0~35\ : std_logic;
SIGNAL \t1|Add0~36_combout\ : std_logic;
SIGNAL \t1|count~6_combout\ : std_logic;
SIGNAL \t1|Add0~37\ : std_logic;
SIGNAL \t1|Add0~38_combout\ : std_logic;
SIGNAL \t1|count~7_combout\ : std_logic;
SIGNAL \t1|Equal0~5_combout\ : std_logic;
SIGNAL \t1|Add0~39\ : std_logic;
SIGNAL \t1|Add0~40_combout\ : std_logic;
SIGNAL \t1|count~9_combout\ : std_logic;
SIGNAL \t1|Add0~41\ : std_logic;
SIGNAL \t1|Add0~42_combout\ : std_logic;
SIGNAL \t1|count~10_combout\ : std_logic;
SIGNAL \t1|Add0~43\ : std_logic;
SIGNAL \t1|Add0~44_combout\ : std_logic;
SIGNAL \t1|count~11_combout\ : std_logic;
SIGNAL \t1|Add0~45\ : std_logic;
SIGNAL \t1|Add0~46_combout\ : std_logic;
SIGNAL \t1|Equal0~6_combout\ : std_logic;
SIGNAL \t1|Equal0~1_combout\ : std_logic;
SIGNAL \t1|Equal0~2_combout\ : std_logic;
SIGNAL \t1|Equal0~0_combout\ : std_logic;
SIGNAL \t1|Equal0~3_combout\ : std_logic;
SIGNAL \t1|Equal0~4_combout\ : std_logic;
SIGNAL \t1|Add0~47\ : std_logic;
SIGNAL \t1|Add0~48_combout\ : std_logic;
SIGNAL \t1|count~8_combout\ : std_logic;
SIGNAL \t1|Equal0~7_combout\ : std_logic;
SIGNAL \t1|toggle~q\ : std_logic;
SIGNAL \cnt_min_high~33_combout\ : std_logic;
SIGNAL \cnt_min_high~30_combout\ : std_logic;
SIGNAL \cnt_sec_low[3]~28_combout\ : std_logic;
SIGNAL \cnt_min_high[3]~6_combout\ : std_logic;
SIGNAL \in_min_high[0]~13_combout\ : std_logic;
SIGNAL \in_min_high[0]~15_combout\ : std_logic;
SIGNAL \inc_btn~input_o\ : std_logic;
SIGNAL \bt3|btn_sync~q\ : std_logic;
SIGNAL \bt3|btn_delay~q\ : std_logic;
SIGNAL \bt3|trig~combout\ : std_logic;
SIGNAL \in_min_high[0]~_emulated_q\ : std_logic;
SIGNAL \in_min_high[0]~14_combout\ : std_logic;
SIGNAL \cnt_min_high~32_combout\ : std_logic;
SIGNAL \cnt_min_high[0]~16_combout\ : std_logic;
SIGNAL \cnt_min_high[0]~19_combout\ : std_logic;
SIGNAL \cnt_min_high[2]~0_combout\ : std_logic;
SIGNAL \cnt_min_high[2]~0clkctrl_outclk\ : std_logic;
SIGNAL \in_sec_low[0]~13_combout\ : std_logic;
SIGNAL \in_sec_low[0]~15_combout\ : std_logic;
SIGNAL \in_sec_low[0]~_emulated_q\ : std_logic;
SIGNAL \in_sec_low[0]~14_combout\ : std_logic;
SIGNAL \cnt_sec_low~31_combout\ : std_logic;
SIGNAL \cnt_sec_low[0]~16_combout\ : std_logic;
SIGNAL \cnt_sec_low[0]~19_combout\ : std_logic;
SIGNAL \cnt_sec_low[0]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_low[0]~18_combout\ : std_logic;
SIGNAL \cnt_sec_low[0]~17_combout\ : std_logic;
SIGNAL \cnt_sec_low~32_combout\ : std_logic;
SIGNAL \cnt_sec_low[1]~11_combout\ : std_logic;
SIGNAL \in_sec_low[2]~1_combout\ : std_logic;
SIGNAL \Add0~1_combout\ : std_logic;
SIGNAL \in_sec_low[2]~3_combout\ : std_logic;
SIGNAL \in_sec_low[2]~_emulated_q\ : std_logic;
SIGNAL \in_sec_low[2]~2_combout\ : std_logic;
SIGNAL \cnt_sec_low~30_combout\ : std_logic;
SIGNAL \cnt_sec_low[2]~1_combout\ : std_logic;
SIGNAL \cnt_sec_low[2]~4_combout\ : std_logic;
SIGNAL \cnt_sec_low[2]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_low[2]~3_combout\ : std_logic;
SIGNAL \cnt_sec_low[2]~2_combout\ : std_logic;
SIGNAL \se4|Equal15~0_combout\ : std_logic;
SIGNAL \cnt_sec_low[1]~14_combout\ : std_logic;
SIGNAL \cnt_sec_low[1]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_low[1]~13_combout\ : std_logic;
SIGNAL \cnt_sec_low[1]~12_combout\ : std_logic;
SIGNAL \in_sec_low[1]~9_combout\ : std_logic;
SIGNAL \Equal0~0_combout\ : std_logic;
SIGNAL \in_sec_low[1]~11_combout\ : std_logic;
SIGNAL \in_sec_low[1]~_emulated_q\ : std_logic;
SIGNAL \in_sec_low[1]~10_combout\ : std_logic;
SIGNAL \Add0~0_combout\ : std_logic;
SIGNAL \in_sec_low[3]~5_combout\ : std_logic;
SIGNAL \in_sec_low[3]~7_combout\ : std_logic;
SIGNAL \in_sec_low[3]~_emulated_q\ : std_logic;
SIGNAL \in_sec_low[3]~6_combout\ : std_logic;
SIGNAL \cnt_sec_low~29_combout\ : std_logic;
SIGNAL \Add1~0_combout\ : std_logic;
SIGNAL \cnt_sec_low[3]~6_combout\ : std_logic;
SIGNAL \cnt_sec_low[3]~9_combout\ : std_logic;
SIGNAL \cnt_sec_low[3]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_low[3]~8_combout\ : std_logic;
SIGNAL \cnt_sec_low[3]~7_combout\ : std_logic;
SIGNAL \se4|Equal15~1_combout\ : std_logic;
SIGNAL \in_min_low[0]~13_combout\ : std_logic;
SIGNAL \in_min_low[0]~15_combout\ : std_logic;
SIGNAL \in_min_low[0]~_emulated_q\ : std_logic;
SIGNAL \in_min_low[0]~14_combout\ : std_logic;
SIGNAL \cnt_min_low~29_combout\ : std_logic;
SIGNAL \cnt_min_low[0]~16_combout\ : std_logic;
SIGNAL \cnt_min_low[0]~19_combout\ : std_logic;
SIGNAL \in_sec_high[3]~5_combout\ : std_logic;
SIGNAL \cnt_sec_high~29_combout\ : std_logic;
SIGNAL \cnt_sec_high[0]~16_combout\ : std_logic;
SIGNAL \cnt_sec_high[0]~19_combout\ : std_logic;
SIGNAL \cnt_sec_high[0]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_high[0]~18_combout\ : std_logic;
SIGNAL \cnt_sec_high[0]~17_combout\ : std_logic;
SIGNAL \in_sec_high[0]~13_combout\ : std_logic;
SIGNAL \in_sec_high[0]~15_combout\ : std_logic;
SIGNAL \in_sec_high[0]~_emulated_q\ : std_logic;
SIGNAL \in_sec_high[0]~14_combout\ : std_logic;
SIGNAL \cnt_sec_high~32_combout\ : std_logic;
SIGNAL \cnt_sec_high[1]~11_combout\ : std_logic;
SIGNAL \cnt_sec_high[1]~14_combout\ : std_logic;
SIGNAL \cnt_sec_high[1]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_high[1]~13_combout\ : std_logic;
SIGNAL \cnt_sec_high[1]~12_combout\ : std_logic;
SIGNAL \in_sec_high[1]~9_combout\ : std_logic;
SIGNAL \cnt_sec_high~28_combout\ : std_logic;
SIGNAL \cnt_sec_high[2]~1_combout\ : std_logic;
SIGNAL \se3|seg[1]~5_combout\ : std_logic;
SIGNAL \cnt_sec_high[2]~4_combout\ : std_logic;
SIGNAL \cnt_sec_high[2]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_high[2]~3_combout\ : std_logic;
SIGNAL \cnt_sec_high[2]~2_combout\ : std_logic;
SIGNAL \in_sec_high[2]~1_combout\ : std_logic;
SIGNAL \in_sec_high[2]~3_combout\ : std_logic;
SIGNAL \in_sec_high[2]~_emulated_q\ : std_logic;
SIGNAL \in_sec_high[2]~2_combout\ : std_logic;
SIGNAL \Equal2~0_combout\ : std_logic;
SIGNAL \in_sec_high[1]~11_combout\ : std_logic;
SIGNAL \in_sec_high[1]~_emulated_q\ : std_logic;
SIGNAL \in_sec_high[1]~10_combout\ : std_logic;
SIGNAL \Add2~0_combout\ : std_logic;
SIGNAL \in_sec_high[3]~22_combout\ : std_logic;
SIGNAL \in_sec_high[3]~7_combout\ : std_logic;
SIGNAL \in_sec_high[3]~_emulated_q\ : std_logic;
SIGNAL \in_sec_high[3]~6_combout\ : std_logic;
SIGNAL \cnt_sec_high~31_combout\ : std_logic;
SIGNAL \cnt_sec_high[3]~6_combout\ : std_logic;
SIGNAL \cnt_sec_high[3]~30_combout\ : std_logic;
SIGNAL \cnt_sec_high[3]~9_combout\ : std_logic;
SIGNAL \cnt_sec_high[3]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_high[3]~8_combout\ : std_logic;
SIGNAL \cnt_sec_high[3]~7_combout\ : std_logic;
SIGNAL \se3|Equal15~0_combout\ : std_logic;
SIGNAL \process_7~0_combout\ : std_logic;
SIGNAL \cnt_min_low[0]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_low[0]~18_combout\ : std_logic;
SIGNAL \cnt_min_low[0]~17_combout\ : std_logic;
SIGNAL \cnt_min_low~31_combout\ : std_logic;
SIGNAL \cnt_min_low[1]~11_combout\ : std_logic;
SIGNAL \cnt_min_low[1]~14_combout\ : std_logic;
SIGNAL \cnt_min_low[1]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_low[1]~13_combout\ : std_logic;
SIGNAL \cnt_min_low[1]~12_combout\ : std_logic;
SIGNAL \in_min_low[1]~9_combout\ : std_logic;
SIGNAL \cnt_min_low~30_combout\ : std_logic;
SIGNAL \cnt_min_low[3]~6_combout\ : std_logic;
SIGNAL \Add5~0_combout\ : std_logic;
SIGNAL \cnt_min_low[3]~9_combout\ : std_logic;
SIGNAL \cnt_min_low[3]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_low[3]~8_combout\ : std_logic;
SIGNAL \cnt_min_low[3]~7_combout\ : std_logic;
SIGNAL \in_min_low[3]~5_combout\ : std_logic;
SIGNAL \Add4~1_combout\ : std_logic;
SIGNAL \in_min_low[3]~7_combout\ : std_logic;
SIGNAL \in_min_low[3]~_emulated_q\ : std_logic;
SIGNAL \in_min_low[3]~6_combout\ : std_logic;
SIGNAL \Equal4~0_combout\ : std_logic;
SIGNAL \in_min_low[1]~11_combout\ : std_logic;
SIGNAL \in_min_low[1]~_emulated_q\ : std_logic;
SIGNAL \in_min_low[1]~10_combout\ : std_logic;
SIGNAL \Add4~0_combout\ : std_logic;
SIGNAL \in_min_low[2]~1_combout\ : std_logic;
SIGNAL \in_min_low[2]~3_combout\ : std_logic;
SIGNAL \in_min_low[2]~_emulated_q\ : std_logic;
SIGNAL \in_min_low[2]~2_combout\ : std_logic;
SIGNAL \cnt_min_low~28_combout\ : std_logic;
SIGNAL \cnt_min_low[2]~1_combout\ : std_logic;
SIGNAL \se2|seg[1]~5_combout\ : std_logic;
SIGNAL \cnt_min_low[2]~4_combout\ : std_logic;
SIGNAL \cnt_min_low[2]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_low[2]~3_combout\ : std_logic;
SIGNAL \cnt_min_low[2]~2_combout\ : std_logic;
SIGNAL \se2|Equal15~0_combout\ : std_logic;
SIGNAL \process_9~0_combout\ : std_logic;
SIGNAL \cnt_min_high[0]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_high[0]~18_combout\ : std_logic;
SIGNAL \cnt_min_high[0]~17_combout\ : std_logic;
SIGNAL \se1|seg[1]~5_combout\ : std_logic;
SIGNAL \cnt_min_high[3]~29_combout\ : std_logic;
SIGNAL \cnt_min_high[3]~9_combout\ : std_logic;
SIGNAL \cnt_min_high[3]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_high[3]~8_combout\ : std_logic;
SIGNAL \cnt_min_high[3]~7_combout\ : std_logic;
SIGNAL \se1|Equal15~1_combout\ : std_logic;
SIGNAL \cnt_min_high[2]~1_combout\ : std_logic;
SIGNAL \cnt_min_high[2]~4_combout\ : std_logic;
SIGNAL \cnt_min_high[2]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_high[2]~3_combout\ : std_logic;
SIGNAL \cnt_min_high[2]~2_combout\ : std_logic;
SIGNAL \in_min_high[2]~1_combout\ : std_logic;
SIGNAL \Add6~0_combout\ : std_logic;
SIGNAL \in_min_high[2]~3_combout\ : std_logic;
SIGNAL \in_min_high[2]~_emulated_q\ : std_logic;
SIGNAL \in_min_high[2]~2_combout\ : std_logic;
SIGNAL \in_min_high[3]~22_combout\ : std_logic;
SIGNAL \in_min_high[3]~5_combout\ : std_logic;
SIGNAL \in_min_high[3]~7_combout\ : std_logic;
SIGNAL \in_min_high[3]~_emulated_q\ : std_logic;
SIGNAL \in_min_high[3]~6_combout\ : std_logic;
SIGNAL \Equal6~0_combout\ : std_logic;
SIGNAL \in_min_high[1]~9_combout\ : std_logic;
SIGNAL \in_min_high[1]~11_combout\ : std_logic;
SIGNAL \in_min_high[1]~_emulated_q\ : std_logic;
SIGNAL \in_min_high[1]~10_combout\ : std_logic;
SIGNAL \cnt_min_high~31_combout\ : std_logic;
SIGNAL \se1|Equal15~0_combout\ : std_logic;
SIGNAL \cnt_min_high[1]~11_combout\ : std_logic;
SIGNAL \cnt_min_high[1]~14_combout\ : std_logic;
SIGNAL \cnt_min_high[1]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_high[1]~13_combout\ : std_logic;
SIGNAL \cnt_min_high[1]~12_combout\ : std_logic;
SIGNAL \in_tim_min_high[0]~4_combout\ : std_logic;
SIGNAL \in_tim_min_high[0]~0_combout\ : std_logic;
SIGNAL \se7|seg[1]~3_combout\ : std_logic;
SIGNAL \in_tim_min_high[3]~1_combout\ : std_logic;
SIGNAL \in_tim_min_high~3_combout\ : std_logic;
SIGNAL \in_tim_min_high~2_combout\ : std_logic;
SIGNAL \process_20~5_combout\ : std_logic;
SIGNAL \in_tim_sec_high[0]~4_combout\ : std_logic;
SIGNAL \in_tim_sec_high[0]~0_combout\ : std_logic;
SIGNAL \se9|seg[1]~3_combout\ : std_logic;
SIGNAL \in_tim_sec_high[3]~1_combout\ : std_logic;
SIGNAL \in_tim_sec_high~3_combout\ : std_logic;
SIGNAL \in_tim_sec_high~2_combout\ : std_logic;
SIGNAL \process_20~7_combout\ : std_logic;
SIGNAL \process_20~8_combout\ : std_logic;
SIGNAL \process_20~6_combout\ : std_logic;
SIGNAL \process_20~9_combout\ : std_logic;
SIGNAL \in_tim_sec_low[0]~4_combout\ : std_logic;
SIGNAL \in_tim_sec_low[0]~1_combout\ : std_logic;
SIGNAL \in_tim_sec_low~2_combout\ : std_logic;
SIGNAL \in_tim_sec_low[2]~3_combout\ : std_logic;
SIGNAL \in_tim_sec_low~0_combout\ : std_logic;
SIGNAL \process_20~13_combout\ : std_logic;
SIGNAL \in_tim_min_low[0]~4_combout\ : std_logic;
SIGNAL \in_tim_min_low[0]~1_combout\ : std_logic;
SIGNAL \in_tim_min_low~0_combout\ : std_logic;
SIGNAL \in_tim_min_low~2_combout\ : std_logic;
SIGNAL \in_tim_min_low[2]~3_combout\ : std_logic;
SIGNAL \process_20~11_combout\ : std_logic;
SIGNAL \process_20~10_combout\ : std_logic;
SIGNAL \process_20~12_combout\ : std_logic;
SIGNAL \process_20~14_combout\ : std_logic;
SIGNAL \in_tim_hour_high~4_combout\ : std_logic;
SIGNAL \in_tim_hour_high[0]~3_combout\ : std_logic;
SIGNAL \in_tim_hour_high~2_combout\ : std_logic;
SIGNAL \in_tim_hour_high[2]~5_combout\ : std_logic;
SIGNAL \in_tim_hour_high[2]~0_combout\ : std_logic;
SIGNAL \in_tim_hour_high[3]~1_combout\ : std_logic;
SIGNAL \in_hour_high[2]~1_combout\ : std_logic;
SIGNAL \in_hour_high[3]~23_combout\ : std_logic;
SIGNAL \cnt_hour_high~31_combout\ : std_logic;
SIGNAL \cnt_hour_high[3]~6_combout\ : std_logic;
SIGNAL \cnt_hour_high~28_combout\ : std_logic;
SIGNAL \cnt_hour_high[1]~11_combout\ : std_logic;
SIGNAL \in_hour_high[0]~13_combout\ : std_logic;
SIGNAL \in_hour_high~22_combout\ : std_logic;
SIGNAL \in_hour_high[0]~15_combout\ : std_logic;
SIGNAL \in_hour_high[0]~_emulated_q\ : std_logic;
SIGNAL \in_hour_high[0]~14_combout\ : std_logic;
SIGNAL \cnt_hour_high~32_combout\ : std_logic;
SIGNAL \cnt_hour_high[0]~16_combout\ : std_logic;
SIGNAL \se5|Equal15~0_combout\ : std_logic;
SIGNAL \cnt_hour_high[0]~19_combout\ : std_logic;
SIGNAL \in_hour_low[1]~9_combout\ : std_logic;
SIGNAL \cnt_hour_low~28_combout\ : std_logic;
SIGNAL \in_hour_low[0]~13_combout\ : std_logic;
SIGNAL \in_hour_low[0]~15_combout\ : std_logic;
SIGNAL \in_hour_low[0]~_emulated_q\ : std_logic;
SIGNAL \in_hour_low[0]~14_combout\ : std_logic;
SIGNAL \cnt_hour_low~29_combout\ : std_logic;
SIGNAL \cnt_hour_low[0]~16_combout\ : std_logic;
SIGNAL \cnt_hour_low[0]~19_combout\ : std_logic;
SIGNAL \process_11~4_combout\ : std_logic;
SIGNAL \cnt_hour_low[0]~_emulated_q\ : std_logic;
SIGNAL \cnt_hour_low[0]~18_combout\ : std_logic;
SIGNAL \cnt_hour_low[0]~17_combout\ : std_logic;
SIGNAL \Add9~0_combout\ : std_logic;
SIGNAL \in_hour_low[3]~5_combout\ : std_logic;
SIGNAL \in_hour_low[3]~20_combout\ : std_logic;
SIGNAL \in_hour_low[3]~7_combout\ : std_logic;
SIGNAL \in_hour_low[3]~_emulated_q\ : std_logic;
SIGNAL \in_hour_low[3]~6_combout\ : std_logic;
SIGNAL \cnt_hour_low~30_combout\ : std_logic;
SIGNAL \process_11~1_combout\ : std_logic;
SIGNAL \Add9~1_combout\ : std_logic;
SIGNAL \cnt_hour_low[3]~6_combout\ : std_logic;
SIGNAL \cnt_hour_low[3]~9_combout\ : std_logic;
SIGNAL \cnt_hour_low[3]~_emulated_q\ : std_logic;
SIGNAL \cnt_hour_low[3]~8_combout\ : std_logic;
SIGNAL \cnt_hour_low[3]~7_combout\ : std_logic;
SIGNAL \process_11~2_combout\ : std_logic;
SIGNAL \process_11~3_combout\ : std_logic;
SIGNAL \cnt_hour_low[2]~1_combout\ : std_logic;
SIGNAL \cnt_hour_low[2]~4_combout\ : std_logic;
SIGNAL \cnt_hour_low[2]~_emulated_q\ : std_logic;
SIGNAL \cnt_hour_low[2]~3_combout\ : std_logic;
SIGNAL \cnt_hour_low[2]~2_combout\ : std_logic;
SIGNAL \in_hour_low[2]~1_combout\ : std_logic;
SIGNAL \Add8~0_combout\ : std_logic;
SIGNAL \in_hour_low[2]~3_combout\ : std_logic;
SIGNAL \in_hour_low[2]~_emulated_q\ : std_logic;
SIGNAL \in_hour_low[2]~2_combout\ : std_logic;
SIGNAL \Equal8~0_combout\ : std_logic;
SIGNAL \in_hour_low[1]~11_combout\ : std_logic;
SIGNAL \in_hour_low[1]~_emulated_q\ : std_logic;
SIGNAL \in_hour_low[1]~10_combout\ : std_logic;
SIGNAL \cnt_hour_low~31_combout\ : std_logic;
SIGNAL \Add9~2_combout\ : std_logic;
SIGNAL \cnt_hour_low[1]~11_combout\ : std_logic;
SIGNAL \cnt_hour_low[1]~14_combout\ : std_logic;
SIGNAL \cnt_hour_low[1]~_emulated_q\ : std_logic;
SIGNAL \cnt_hour_low[1]~13_combout\ : std_logic;
SIGNAL \cnt_hour_low[1]~12_combout\ : std_logic;
SIGNAL \process_11~0_combout\ : std_logic;
SIGNAL \process_13~0_combout\ : std_logic;
SIGNAL \cnt_hour_high[0]~_emulated_q\ : std_logic;
SIGNAL \cnt_hour_high[0]~18_combout\ : std_logic;
SIGNAL \cnt_hour_high[0]~17_combout\ : std_logic;
SIGNAL \se5|Equal15~1_combout\ : std_logic;
SIGNAL \cnt_hour_high[1]~14_combout\ : std_logic;
SIGNAL \cnt_hour_high[1]~_emulated_q\ : std_logic;
SIGNAL \cnt_hour_high[1]~13_combout\ : std_logic;
SIGNAL \cnt_hour_high[1]~12_combout\ : std_logic;
SIGNAL \se5|seg[1]~5_combout\ : std_logic;
SIGNAL \cnt_hour_high[3]~30_combout\ : std_logic;
SIGNAL \cnt_hour_high[3]~9_combout\ : std_logic;
SIGNAL \cnt_hour_high[3]~_emulated_q\ : std_logic;
SIGNAL \cnt_hour_high[3]~8_combout\ : std_logic;
SIGNAL \cnt_hour_high[3]~7_combout\ : std_logic;
SIGNAL \in_hour_high[3]~5_combout\ : std_logic;
SIGNAL \in_hour_high[3]~7_combout\ : std_logic;
SIGNAL \in_hour_high[3]~_emulated_q\ : std_logic;
SIGNAL \in_hour_high[3]~6_combout\ : std_logic;
SIGNAL \Equal14~0_combout\ : std_logic;
SIGNAL \in_hour_high[1]~9_combout\ : std_logic;
SIGNAL \in_hour_high[1]~11_combout\ : std_logic;
SIGNAL \in_hour_high[1]~_emulated_q\ : std_logic;
SIGNAL \in_hour_high[1]~10_combout\ : std_logic;
SIGNAL \Add10~0_combout\ : std_logic;
SIGNAL \in_hour_high[2]~3_combout\ : std_logic;
SIGNAL \in_hour_high[2]~_emulated_q\ : std_logic;
SIGNAL \in_hour_high[2]~2_combout\ : std_logic;
SIGNAL \cnt_hour_high~29_combout\ : std_logic;
SIGNAL \cnt_hour_high[2]~1_combout\ : std_logic;
SIGNAL \cnt_hour_high[2]~4_combout\ : std_logic;
SIGNAL \cnt_hour_high[2]~_emulated_q\ : std_logic;
SIGNAL \cnt_hour_high[2]~3_combout\ : std_logic;
SIGNAL \cnt_hour_high[2]~2_combout\ : std_logic;
SIGNAL \process_20~1_combout\ : std_logic;
SIGNAL \in_tim_hour_low[0]~4_combout\ : std_logic;
SIGNAL \in_tim_hour_low[0]~1_combout\ : std_logic;
SIGNAL \in_tim_hour_low~0_combout\ : std_logic;
SIGNAL \in_tim_hour_low~2_combout\ : std_logic;
SIGNAL \in_tim_hour_low[2]~3_combout\ : std_logic;
SIGNAL \process_20~3_combout\ : std_logic;
SIGNAL \process_20~2_combout\ : std_logic;
SIGNAL \process_20~0_combout\ : std_logic;
SIGNAL \process_20~4_combout\ : std_logic;
SIGNAL \process_20~15_combout\ : std_logic;
SIGNAL \time_trig~2_combout\ : std_logic;
SIGNAL \time_trig~combout\ : std_logic;
SIGNAL \t2|toggle~0_combout\ : std_logic;
SIGNAL \t2|toggle~q\ : std_logic;
SIGNAL \led_flash~0_combout\ : std_logic;
SIGNAL \mode1~input_o\ : std_logic;
SIGNAL \min_high~2_combout\ : std_logic;
SIGNAL \min_high~1_combout\ : std_logic;
SIGNAL \min_high~0_combout\ : std_logic;
SIGNAL \min_high~3_combout\ : std_logic;
SIGNAL \min_high~4_combout\ : std_logic;
SIGNAL \se1|seg[1]~0_combout\ : std_logic;
SIGNAL \min_high~5_combout\ : std_logic;
SIGNAL \min_high~6_combout\ : std_logic;
SIGNAL \se1|seg[2]~1_combout\ : std_logic;
SIGNAL \min_high~7_combout\ : std_logic;
SIGNAL \se1|seg[3]~2_combout\ : std_logic;
SIGNAL \se7|seg[3]~0_combout\ : std_logic;
SIGNAL \min_high~8_combout\ : std_logic;
SIGNAL \se1|seg[4]~3_combout\ : std_logic;
SIGNAL \se7|seg[4]~1_combout\ : std_logic;
SIGNAL \min_high~9_combout\ : std_logic;
SIGNAL \min_high~12_combout\ : std_logic;
SIGNAL \min_high~11_combout\ : std_logic;
SIGNAL \min_high~10_combout\ : std_logic;
SIGNAL \min_high~13_combout\ : std_logic;
SIGNAL \se1|seg[6]~4_combout\ : std_logic;
SIGNAL \se7|seg[6]~2_combout\ : std_logic;
SIGNAL \min_high~14_combout\ : std_logic;
SIGNAL \min_low~3_combout\ : std_logic;
SIGNAL \min_low~2_combout\ : std_logic;
SIGNAL \min_low~0_combout\ : std_logic;
SIGNAL \min_low~1_combout\ : std_logic;
SIGNAL \min_low~4_combout\ : std_logic;
SIGNAL \min_low~5_combout\ : std_logic;
SIGNAL \min_low~6_combout\ : std_logic;
SIGNAL \se2|seg[1]~0_combout\ : std_logic;
SIGNAL \min_low~7_combout\ : std_logic;
SIGNAL \min_low~8_combout\ : std_logic;
SIGNAL \se2|seg[2]~1_combout\ : std_logic;
SIGNAL \min_low~9_combout\ : std_logic;
SIGNAL \se2|seg[3]~2_combout\ : std_logic;
SIGNAL \se8|seg[3]~0_combout\ : std_logic;
SIGNAL \min_low~10_combout\ : std_logic;
SIGNAL \se8|seg[4]~1_combout\ : std_logic;
SIGNAL \se2|seg[4]~3_combout\ : std_logic;
SIGNAL \min_low~11_combout\ : std_logic;
SIGNAL \min_low~14_combout\ : std_logic;
SIGNAL \min_low~12_combout\ : std_logic;
SIGNAL \min_low~13_combout\ : std_logic;
SIGNAL \min_low~15_combout\ : std_logic;
SIGNAL \se2|seg[6]~4_combout\ : std_logic;
SIGNAL \se8|seg[6]~2_combout\ : std_logic;
SIGNAL \min_low~16_combout\ : std_logic;
SIGNAL \sec_high~2_combout\ : std_logic;
SIGNAL \sec_high~3_combout\ : std_logic;
SIGNAL \sec_high~0_combout\ : std_logic;
SIGNAL \sec_high~1_combout\ : std_logic;
SIGNAL \sec_high~4_combout\ : std_logic;
SIGNAL \se3|seg[1]~0_combout\ : std_logic;
SIGNAL \sec_high~5_combout\ : std_logic;
SIGNAL \sec_high~6_combout\ : std_logic;
SIGNAL \sec_high~7_combout\ : std_logic;
SIGNAL \se3|seg[2]~1_combout\ : std_logic;
SIGNAL \sec_high~8_combout\ : std_logic;
SIGNAL \sec_high~9_combout\ : std_logic;
SIGNAL \se9|seg[3]~0_combout\ : std_logic;
SIGNAL \se3|seg[3]~2_combout\ : std_logic;
SIGNAL \sec_high~10_combout\ : std_logic;
SIGNAL \se9|seg[4]~1_combout\ : std_logic;
SIGNAL \se3|seg[4]~3_combout\ : std_logic;
SIGNAL \sec_high~11_combout\ : std_logic;
SIGNAL \sec_high~14_combout\ : std_logic;
SIGNAL \sec_high~12_combout\ : std_logic;
SIGNAL \sec_high~13_combout\ : std_logic;
SIGNAL \sec_high~15_combout\ : std_logic;
SIGNAL \se9|seg[6]~2_combout\ : std_logic;
SIGNAL \se3|seg[6]~4_combout\ : std_logic;
SIGNAL \sec_high~16_combout\ : std_logic;
SIGNAL \sec_low~3_combout\ : std_logic;
SIGNAL \sec_low~4_combout\ : std_logic;
SIGNAL \sec_low~0_combout\ : std_logic;
SIGNAL \sec_low~1_combout\ : std_logic;
SIGNAL \sec_low~2_combout\ : std_logic;
SIGNAL \sec_low~5_combout\ : std_logic;
SIGNAL \sec_low~6_combout\ : std_logic;
SIGNAL \se4|seg[1]~0_combout\ : std_logic;
SIGNAL \sec_low~7_combout\ : std_logic;
SIGNAL \sec_low~8_combout\ : std_logic;
SIGNAL \sec_low~9_combout\ : std_logic;
SIGNAL \se4|seg[2]~1_combout\ : std_logic;
SIGNAL \sec_low~10_combout\ : std_logic;
SIGNAL \se4|seg[3]~2_combout\ : std_logic;
SIGNAL \se10|seg[3]~0_combout\ : std_logic;
SIGNAL \sec_low~11_combout\ : std_logic;
SIGNAL \se10|seg[4]~1_combout\ : std_logic;
SIGNAL \se4|seg[4]~3_combout\ : std_logic;
SIGNAL \sec_low~12_combout\ : std_logic;
SIGNAL \sec_low~13_combout\ : std_logic;
SIGNAL \sec_low~14_combout\ : std_logic;
SIGNAL \sec_low~15_combout\ : std_logic;
SIGNAL \sec_low~16_combout\ : std_logic;
SIGNAL \se10|seg[6]~2_combout\ : std_logic;
SIGNAL \se4|seg[6]~4_combout\ : std_logic;
SIGNAL \sec_low~17_combout\ : std_logic;
SIGNAL \hour_high~5_combout\ : std_logic;
SIGNAL \hour_high~6_combout\ : std_logic;
SIGNAL \hour_high~4_combout\ : std_logic;
SIGNAL \hour_high~20_combout\ : std_logic;
SIGNAL \hour_high~7_combout\ : std_logic;
SIGNAL \se5|seg[1]~0_combout\ : std_logic;
SIGNAL \hour_high~8_combout\ : std_logic;
SIGNAL \hour_high~9_combout\ : std_logic;
SIGNAL \hour_high~10_combout\ : std_logic;
SIGNAL \se5|seg[2]~1_combout\ : std_logic;
SIGNAL \hour_high~11_combout\ : std_logic;
SIGNAL \hour_high~12_combout\ : std_logic;
SIGNAL \se11|seg[3]~0_combout\ : std_logic;
SIGNAL \se5|seg[3]~2_combout\ : std_logic;
SIGNAL \hour_high~13_combout\ : std_logic;
SIGNAL \se5|seg[4]~3_combout\ : std_logic;
SIGNAL \se11|seg[4]~1_combout\ : std_logic;
SIGNAL \hour_high~14_combout\ : std_logic;
SIGNAL \hour_high~15_combout\ : std_logic;
SIGNAL \hour_high~16_combout\ : std_logic;
SIGNAL \hour_high~17_combout\ : std_logic;
SIGNAL \hour_high~18_combout\ : std_logic;
SIGNAL \se5|seg[6]~4_combout\ : std_logic;
SIGNAL \se11|seg[6]~2_combout\ : std_logic;
SIGNAL \hour_high~19_combout\ : std_logic;
SIGNAL \hour_low~3_combout\ : std_logic;
SIGNAL \hour_low~0_combout\ : std_logic;
SIGNAL \hour_low~1_combout\ : std_logic;
SIGNAL \hour_low~2_combout\ : std_logic;
SIGNAL \hour_low~4_combout\ : std_logic;
SIGNAL \hour_low~6_combout\ : std_logic;
SIGNAL \se6|seg[1]~0_combout\ : std_logic;
SIGNAL \hour_low~5_combout\ : std_logic;
SIGNAL \hour_low~7_combout\ : std_logic;
SIGNAL \se6|seg[2]~1_combout\ : std_logic;
SIGNAL \hour_low~8_combout\ : std_logic;
SIGNAL \hour_low~9_combout\ : std_logic;
SIGNAL \se12|seg[3]~0_combout\ : std_logic;
SIGNAL \se6|seg[3]~2_combout\ : std_logic;
SIGNAL \hour_low~10_combout\ : std_logic;
SIGNAL \se6|seg[4]~3_combout\ : std_logic;
SIGNAL \se12|seg[4]~1_combout\ : std_logic;
SIGNAL \hour_low~11_combout\ : std_logic;
SIGNAL \hour_low~12_combout\ : std_logic;
SIGNAL \hour_low~13_combout\ : std_logic;
SIGNAL \hour_low~14_combout\ : std_logic;
SIGNAL \hour_low~15_combout\ : std_logic;
SIGNAL \se6|seg[6]~4_combout\ : std_logic;
SIGNAL \se12|seg[6]~2_combout\ : std_logic;
SIGNAL \hour_low~16_combout\ : std_logic;
SIGNAL in_tim_min_high : std_logic_vector(3 DOWNTO 0);
SIGNAL in_tim_min_low : std_logic_vector(3 DOWNTO 0);
SIGNAL in_tim_sec_high : std_logic_vector(3 DOWNTO 0);
SIGNAL \t1|count\ : std_logic_vector(24 DOWNTO 0);
SIGNAL in_tim_sec_low : std_logic_vector(3 DOWNTO 0);
SIGNAL in_tim_hour_high : std_logic_vector(3 DOWNTO 0);
SIGNAL in_tim_hour_low : std_logic_vector(3 DOWNTO 0);
SIGNAL \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\ : std_logic;

COMPONENT hard_block
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic);
END COMPONENT;

BEGIN

ww_clk <= clk;
ww_en <= en;
ww_mode1 <= mode1;
ww_ct1_btn <= ct1_btn;
ww_ct2_btn <= ct2_btn;
ww_inc_btn <= inc_btn;
ww_done_btn <= done_btn;
led1 <= ww_led1;
led2 <= ww_led2;
led3 <= ww_led3;
led4 <= ww_led4;
led5 <= ww_led5;
led6 <= ww_led6;
led7 <= ww_led7;
led8 <= ww_led8;
led9 <= ww_led9;
led10 <= ww_led10;
led11 <= ww_led11;
led12 <= ww_led12;
led13 <= ww_led13;
led14 <= ww_led14;
led_flash <= ww_led_flash;
min_high <= ww_min_high;
min_low <= ww_min_low;
sec_high <= ww_sec_high;
sec_low <= ww_sec_low;
hour_high <= ww_hour_high;
hour_low <= ww_hour_low;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\clk~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk~input_o\);

\cnt_min_high[2]~0clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \cnt_min_high[2]~0_combout\);
\ALT_INV_cnt_min_high[2]~0clkctrl_outclk\ <= NOT \cnt_min_high[2]~0clkctrl_outclk\;
auto_generated_inst : hard_block
PORT MAP (
	devoe => ww_devoe,
	devclrn => ww_devclrn,
	devpor => ww_devpor);

-- Location: IOOBUF_X69_Y73_N16
\led1~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.INC~q\,
	devoe => ww_devoe,
	o => \led1~output_o\);

-- Location: IOOBUF_X94_Y73_N2
\led2~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.S0~q\,
	devoe => ww_devoe,
	o => \led2~output_o\);

-- Location: IOOBUF_X94_Y73_N9
\led3~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.S1~q\,
	devoe => ww_devoe,
	o => \led3~output_o\);

-- Location: IOOBUF_X107_Y73_N16
\led4~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.M0~q\,
	devoe => ww_devoe,
	o => \led4~output_o\);

-- Location: IOOBUF_X87_Y73_N16
\led5~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.M1~q\,
	devoe => ww_devoe,
	o => \led5~output_o\);

-- Location: IOOBUF_X87_Y73_N9
\led6~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.H0~q\,
	devoe => ww_devoe,
	o => \led6~output_o\);

-- Location: IOOBUF_X72_Y73_N9
\led7~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.H1~q\,
	devoe => ww_devoe,
	o => \led7~output_o\);

-- Location: IOOBUF_X72_Y73_N2
\led8~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.ST0~q\,
	devoe => ww_devoe,
	o => \led8~output_o\);

-- Location: IOOBUF_X69_Y73_N2
\led9~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.ST1~q\,
	devoe => ww_devoe,
	o => \led9~output_o\);

-- Location: IOOBUF_X83_Y73_N23
\led10~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.MT0~q\,
	devoe => ww_devoe,
	o => \led10~output_o\);

-- Location: IOOBUF_X60_Y73_N23
\led11~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.MT1~q\,
	devoe => ww_devoe,
	o => \led11~output_o\);

-- Location: IOOBUF_X65_Y73_N23
\led12~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.HT0~q\,
	devoe => ww_devoe,
	o => \led12~output_o\);

-- Location: IOOBUF_X65_Y73_N16
\led13~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.HT1~q\,
	devoe => ww_devoe,
	o => \led13~output_o\);

-- Location: IOOBUF_X67_Y73_N9
\led14~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \t1|toggle~q\,
	devoe => ww_devoe,
	o => \led14~output_o\);

-- Location: IOOBUF_X107_Y73_N9
\led_flash~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \led_flash~0_combout\,
	devoe => ww_devoe,
	o => \led_flash~output_o\);

-- Location: IOOBUF_X85_Y0_N9
\min_high[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_high~3_combout\,
	devoe => ww_devoe,
	o => \min_high[0]~output_o\);

-- Location: IOOBUF_X87_Y0_N16
\min_high[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_high~5_combout\,
	devoe => ww_devoe,
	o => \min_high[1]~output_o\);

-- Location: IOOBUF_X98_Y0_N16
\min_high[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_high~7_combout\,
	devoe => ww_devoe,
	o => \min_high[2]~output_o\);

-- Location: IOOBUF_X72_Y0_N2
\min_high[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_high~8_combout\,
	devoe => ww_devoe,
	o => \min_high[3]~output_o\);

-- Location: IOOBUF_X72_Y0_N9
\min_high[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_high~9_combout\,
	devoe => ww_devoe,
	o => \min_high[4]~output_o\);

-- Location: IOOBUF_X79_Y0_N16
\min_high[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_high~13_combout\,
	devoe => ww_devoe,
	o => \min_high[5]~output_o\);

-- Location: IOOBUF_X69_Y0_N2
\min_high[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_high~14_combout\,
	devoe => ww_devoe,
	o => \min_high[6]~output_o\);

-- Location: IOOBUF_X98_Y0_N23
\min_low[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_low~4_combout\,
	devoe => ww_devoe,
	o => \min_low[0]~output_o\);

-- Location: IOOBUF_X107_Y0_N9
\min_low[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_low~7_combout\,
	devoe => ww_devoe,
	o => \min_low[1]~output_o\);

-- Location: IOOBUF_X74_Y0_N9
\min_low[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_low~9_combout\,
	devoe => ww_devoe,
	o => \min_low[2]~output_o\);

-- Location: IOOBUF_X74_Y0_N2
\min_low[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_low~10_combout\,
	devoe => ww_devoe,
	o => \min_low[3]~output_o\);

-- Location: IOOBUF_X83_Y0_N23
\min_low[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_low~11_combout\,
	devoe => ww_devoe,
	o => \min_low[4]~output_o\);

-- Location: IOOBUF_X83_Y0_N16
\min_low[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_low~15_combout\,
	devoe => ww_devoe,
	o => \min_low[5]~output_o\);

-- Location: IOOBUF_X79_Y0_N23
\min_low[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_low~16_combout\,
	devoe => ww_devoe,
	o => \min_low[6]~output_o\);

-- Location: IOOBUF_X115_Y25_N16
\sec_high[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_high~4_combout\,
	devoe => ww_devoe,
	o => \sec_high[0]~output_o\);

-- Location: IOOBUF_X115_Y29_N2
\sec_high[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_high~7_combout\,
	devoe => ww_devoe,
	o => \sec_high[1]~output_o\);

-- Location: IOOBUF_X100_Y0_N2
\sec_high[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_high~9_combout\,
	devoe => ww_devoe,
	o => \sec_high[2]~output_o\);

-- Location: IOOBUF_X111_Y0_N2
\sec_high[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_high~10_combout\,
	devoe => ww_devoe,
	o => \sec_high[3]~output_o\);

-- Location: IOOBUF_X105_Y0_N23
\sec_high[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_high~11_combout\,
	devoe => ww_devoe,
	o => \sec_high[4]~output_o\);

-- Location: IOOBUF_X105_Y0_N9
\sec_high[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_high~15_combout\,
	devoe => ww_devoe,
	o => \sec_high[5]~output_o\);

-- Location: IOOBUF_X105_Y0_N2
\sec_high[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_high~16_combout\,
	devoe => ww_devoe,
	o => \sec_high[6]~output_o\);

-- Location: IOOBUF_X115_Y17_N9
\sec_low[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_low~5_combout\,
	devoe => ww_devoe,
	o => \sec_low[0]~output_o\);

-- Location: IOOBUF_X115_Y16_N2
\sec_low[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_low~8_combout\,
	devoe => ww_devoe,
	o => \sec_low[1]~output_o\);

-- Location: IOOBUF_X115_Y19_N9
\sec_low[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_low~10_combout\,
	devoe => ww_devoe,
	o => \sec_low[2]~output_o\);

-- Location: IOOBUF_X115_Y19_N2
\sec_low[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_low~11_combout\,
	devoe => ww_devoe,
	o => \sec_low[3]~output_o\);

-- Location: IOOBUF_X115_Y18_N2
\sec_low[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_low~12_combout\,
	devoe => ww_devoe,
	o => \sec_low[4]~output_o\);

-- Location: IOOBUF_X115_Y20_N2
\sec_low[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_low~16_combout\,
	devoe => ww_devoe,
	o => \sec_low[5]~output_o\);

-- Location: IOOBUF_X115_Y21_N16
\sec_low[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_low~17_combout\,
	devoe => ww_devoe,
	o => \sec_low[6]~output_o\);

-- Location: IOOBUF_X74_Y0_N16
\hour_high[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hour_high~7_combout\,
	devoe => ww_devoe,
	o => \hour_high[0]~output_o\);

-- Location: IOOBUF_X67_Y0_N9
\hour_high[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hour_high~10_combout\,
	devoe => ww_devoe,
	o => \hour_high[1]~output_o\);

-- Location: IOOBUF_X62_Y0_N23
\hour_high[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hour_high~12_combout\,
	devoe => ww_devoe,
	o => \hour_high[2]~output_o\);

-- Location: IOOBUF_X62_Y0_N16
\hour_high[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hour_high~13_combout\,
	devoe => ww_devoe,
	o => \hour_high[3]~output_o\);

-- Location: IOOBUF_X67_Y0_N2
\hour_high[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hour_high~14_combout\,
	devoe => ww_devoe,
	o => \hour_high[4]~output_o\);

-- Location: IOOBUF_X69_Y0_N9
\hour_high[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hour_high~18_combout\,
	devoe => ww_devoe,
	o => \hour_high[5]~output_o\);

-- Location: IOOBUF_X54_Y0_N23
\hour_high[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hour_high~19_combout\,
	devoe => ww_devoe,
	o => \hour_high[6]~output_o\);

-- Location: IOOBUF_X89_Y0_N23
\hour_low[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hour_low~4_combout\,
	devoe => ww_devoe,
	o => \hour_low[0]~output_o\);

-- Location: IOOBUF_X65_Y0_N2
\hour_low[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hour_low~7_combout\,
	devoe => ww_devoe,
	o => \hour_low[1]~output_o\);

-- Location: IOOBUF_X65_Y0_N9
\hour_low[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hour_low~9_combout\,
	devoe => ww_devoe,
	o => \hour_low[2]~output_o\);

-- Location: IOOBUF_X89_Y0_N16
\hour_low[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hour_low~10_combout\,
	devoe => ww_devoe,
	o => \hour_low[3]~output_o\);

-- Location: IOOBUF_X67_Y0_N16
\hour_low[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hour_low~11_combout\,
	devoe => ww_devoe,
	o => \hour_low[4]~output_o\);

-- Location: IOOBUF_X67_Y0_N23
\hour_low[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hour_low~15_combout\,
	devoe => ww_devoe,
	o => \hour_low[5]~output_o\);

-- Location: IOOBUF_X74_Y0_N23
\hour_low[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \hour_low~16_combout\,
	devoe => ww_devoe,
	o => \hour_low[6]~output_o\);

-- Location: IOIBUF_X0_Y36_N15
\clk~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk,
	o => \clk~input_o\);

-- Location: CLKCTRL_G4
\clk~inputclkctrl\ : cycloneive_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk~inputclkctrl_outclk\);

-- Location: IOIBUF_X115_Y42_N15
\done_btn~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_done_btn,
	o => \done_btn~input_o\);

-- Location: FF_X36_Y35_N21
\bt4|btn_sync\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \done_btn~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt4|btn_sync~q\);

-- Location: FF_X34_Y36_N25
\bt4|btn_delay\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \bt4|btn_sync~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt4|btn_delay~q\);

-- Location: LCCOMB_X34_Y36_N28
\bt4|trig~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \bt4|trig~0_combout\ = (\bt4|btn_sync~q\ & !\bt4|btn_delay~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \bt4|btn_sync~q\,
	datad => \bt4|btn_delay~q\,
	combout => \bt4|trig~0_combout\);

-- Location: IOIBUF_X115_Y40_N8
\ct1_btn~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_ct1_btn,
	o => \ct1_btn~input_o\);

-- Location: FF_X34_Y36_N31
\bt1|btn_sync\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \ct1_btn~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt1|btn_sync~q\);

-- Location: FF_X34_Y36_N3
\bt1|btn_delay\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \bt1|btn_sync~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt1|btn_delay~q\);

-- Location: LCCOMB_X33_Y35_N14
\Selector1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector1~0_combout\ = (\bt1|btn_sync~q\ & (\current_state.INC~q\ & !\bt1|btn_delay~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt1|btn_sync~q\,
	datac => \current_state.INC~q\,
	datad => \bt1|btn_delay~q\,
	combout => \Selector1~0_combout\);

-- Location: IOIBUF_X115_Y17_N1
\en~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_en,
	o => \en~input_o\);

-- Location: LCCOMB_X34_Y36_N24
\next_state~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \next_state~0_combout\ = (\bt1|btn_delay~q\ & (\bt4|btn_sync~q\ & (!\bt4|btn_delay~q\))) # (!\bt1|btn_delay~q\ & ((\bt1|btn_sync~q\) # ((\bt4|btn_sync~q\ & !\bt4|btn_delay~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110100001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt1|btn_delay~q\,
	datab => \bt4|btn_sync~q\,
	datac => \bt4|btn_delay~q\,
	datad => \bt1|btn_sync~q\,
	combout => \next_state~0_combout\);

-- Location: FF_X33_Y35_N15
\current_state.S0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \Selector1~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.S0~q\);

-- Location: LCCOMB_X34_Y36_N0
\Selector2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector2~0_combout\ = (\bt1|btn_sync~q\ & (!\bt1|btn_delay~q\ & \current_state.S0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt1|btn_sync~q\,
	datac => \bt1|btn_delay~q\,
	datad => \current_state.S0~q\,
	combout => \Selector2~0_combout\);

-- Location: FF_X34_Y36_N1
\current_state.S1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \Selector2~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.S1~q\);

-- Location: LCCOMB_X34_Y36_N10
\Selector3~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector3~0_combout\ = (!\bt1|btn_delay~q\ & (\current_state.S1~q\ & \bt1|btn_sync~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt1|btn_delay~q\,
	datab => \current_state.S1~q\,
	datad => \bt1|btn_sync~q\,
	combout => \Selector3~0_combout\);

-- Location: FF_X34_Y36_N11
\current_state.M0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \Selector3~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.M0~q\);

-- Location: LCCOMB_X33_Y35_N30
\Selector4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector4~0_combout\ = (\bt1|btn_sync~q\ & (\current_state.M0~q\ & !\bt1|btn_delay~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt1|btn_sync~q\,
	datab => \current_state.M0~q\,
	datad => \bt1|btn_delay~q\,
	combout => \Selector4~0_combout\);

-- Location: FF_X33_Y35_N31
\current_state.M1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \Selector4~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.M1~q\);

-- Location: LCCOMB_X34_Y36_N18
\Selector0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~2_combout\ = (\current_state.S0~q\) # ((\current_state.M1~q\) # ((\current_state.S1~q\) # (\current_state.M0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.S0~q\,
	datab => \current_state.M1~q\,
	datac => \current_state.S1~q\,
	datad => \current_state.M0~q\,
	combout => \Selector0~2_combout\);

-- Location: LCCOMB_X33_Y35_N6
\Selector5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector5~0_combout\ = (\bt1|btn_sync~q\ & (\current_state.M1~q\ & !\bt1|btn_delay~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \bt1|btn_sync~q\,
	datac => \current_state.M1~q\,
	datad => \bt1|btn_delay~q\,
	combout => \Selector5~0_combout\);

-- Location: FF_X33_Y35_N7
\current_state.H0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \Selector5~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.H0~q\);

-- Location: LCCOMB_X34_Y36_N30
\Selector0~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~3_combout\ = (\bt1|btn_delay~q\ & ((\Selector0~2_combout\) # ((\current_state.H0~q\)))) # (!\bt1|btn_delay~q\ & (!\bt1|btn_sync~q\ & ((\Selector0~2_combout\) # (\current_state.H0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt1|btn_delay~q\,
	datab => \Selector0~2_combout\,
	datac => \bt1|btn_sync~q\,
	datad => \current_state.H0~q\,
	combout => \Selector0~3_combout\);

-- Location: IOIBUF_X115_Y53_N15
\ct2_btn~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_ct2_btn,
	o => \ct2_btn~input_o\);

-- Location: FF_X36_Y35_N5
\bt2|btn_sync\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \ct2_btn~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt2|btn_sync~q\);

-- Location: FF_X36_Y35_N13
\bt2|btn_delay\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \bt2|btn_sync~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt2|btn_delay~q\);

-- Location: LCCOMB_X34_Y36_N4
\Selector7~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector7~0_combout\ = (\current_state.INC~q\ & ((\bt1|btn_delay~q\) # (!\bt1|btn_sync~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt1|btn_delay~q\,
	datac => \current_state.INC~q\,
	datad => \bt1|btn_sync~q\,
	combout => \Selector7~0_combout\);

-- Location: LCCOMB_X36_Y35_N20
\next_state~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \next_state~1_combout\ = (\bt4|btn_delay~q\ & (\bt2|btn_sync~q\ & ((!\bt2|btn_delay~q\)))) # (!\bt4|btn_delay~q\ & ((\bt4|btn_sync~q\) # ((\bt2|btn_sync~q\ & !\bt2|btn_delay~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000011011100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt4|btn_delay~q\,
	datab => \bt2|btn_sync~q\,
	datac => \bt4|btn_sync~q\,
	datad => \bt2|btn_delay~q\,
	combout => \next_state~1_combout\);

-- Location: LCCOMB_X36_Y35_N4
\bt2|trig\ : cycloneive_lcell_comb
-- Equation(s):
-- \bt2|trig~combout\ = (\bt2|btn_delay~q\) # (!\bt2|btn_sync~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \bt2|btn_sync~q\,
	datad => \bt2|btn_delay~q\,
	combout => \bt2|trig~combout\);

-- Location: LCCOMB_X36_Y35_N14
\Selector7~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector7~1_combout\ = (\Selector7~0_combout\ & (((!\next_state~1_combout\ & \current_state.ST0~q\)) # (!\bt2|trig~combout\))) # (!\Selector7~0_combout\ & (!\next_state~1_combout\ & (\current_state.ST0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000010111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector7~0_combout\,
	datab => \next_state~1_combout\,
	datac => \current_state.ST0~q\,
	datad => \bt2|trig~combout\,
	combout => \Selector7~1_combout\);

-- Location: FF_X36_Y35_N15
\current_state.ST0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \Selector7~1_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.ST0~q\);

-- Location: LCCOMB_X36_Y35_N2
\Selector8~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector8~0_combout\ = (\bt2|btn_sync~q\ & (\current_state.ST0~q\ & !\bt2|btn_delay~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \bt2|btn_sync~q\,
	datac => \current_state.ST0~q\,
	datad => \bt2|btn_delay~q\,
	combout => \Selector8~0_combout\);

-- Location: FF_X36_Y35_N3
\current_state.ST1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \Selector8~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.ST1~q\);

-- Location: LCCOMB_X36_Y35_N6
\Selector9~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector9~0_combout\ = (\current_state.ST1~q\ & (\bt2|btn_sync~q\ & !\bt2|btn_delay~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \current_state.ST1~q\,
	datac => \bt2|btn_sync~q\,
	datad => \bt2|btn_delay~q\,
	combout => \Selector9~0_combout\);

-- Location: FF_X36_Y35_N7
\current_state.MT0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \Selector9~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.MT0~q\);

-- Location: LCCOMB_X36_Y35_N30
\Selector10~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector10~0_combout\ = (!\bt2|btn_delay~q\ & (\bt2|btn_sync~q\ & \current_state.MT0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt2|btn_delay~q\,
	datac => \bt2|btn_sync~q\,
	datad => \current_state.MT0~q\,
	combout => \Selector10~0_combout\);

-- Location: FF_X36_Y35_N31
\current_state.MT1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \Selector10~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.MT1~q\);

-- Location: LCCOMB_X36_Y35_N24
\Selector11~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector11~0_combout\ = (\bt2|btn_sync~q\ & (\current_state.MT1~q\ & !\bt2|btn_delay~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \bt2|btn_sync~q\,
	datac => \current_state.MT1~q\,
	datad => \bt2|btn_delay~q\,
	combout => \Selector11~0_combout\);

-- Location: FF_X36_Y35_N25
\current_state.HT0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \Selector11~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.HT0~q\);

-- Location: LCCOMB_X36_Y35_N10
\Selector0~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~4_combout\ = (\current_state.MT1~q\) # ((\current_state.ST1~q\) # ((\current_state.ST0~q\) # (\current_state.MT0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.MT1~q\,
	datab => \current_state.ST1~q\,
	datac => \current_state.ST0~q\,
	datad => \current_state.MT0~q\,
	combout => \Selector0~4_combout\);

-- Location: LCCOMB_X36_Y35_N22
\Selector0~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~5_combout\ = (\Selector0~3_combout\) # ((\bt2|trig~combout\ & ((\current_state.HT0~q\) # (\Selector0~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector0~3_combout\,
	datab => \current_state.HT0~q\,
	datac => \bt2|trig~combout\,
	datad => \Selector0~4_combout\,
	combout => \Selector0~5_combout\);

-- Location: LCCOMB_X34_Y36_N16
\current_state.IDLE~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \current_state.IDLE~0_combout\ = (\current_state.IDLE~q\) # ((!\bt1|btn_delay~q\ & \bt1|btn_sync~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt1|btn_delay~q\,
	datac => \current_state.IDLE~q\,
	datad => \bt1|btn_sync~q\,
	combout => \current_state.IDLE~0_combout\);

-- Location: FF_X34_Y36_N17
\current_state.IDLE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \current_state.IDLE~0_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.IDLE~q\);

-- Location: LCCOMB_X34_Y36_N2
\bt1|trig\ : cycloneive_lcell_comb
-- Equation(s):
-- \bt1|trig~combout\ = (\bt1|btn_delay~q\) # (!\bt1|btn_sync~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010111110101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt1|btn_sync~q\,
	datac => \bt1|btn_delay~q\,
	combout => \bt1|trig~combout\);

-- Location: LCCOMB_X34_Y36_N14
\Selector0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~0_combout\ = (\bt1|trig~combout\ & (\bt2|trig~combout\ & ((\current_state.INC~q\)))) # (!\bt1|trig~combout\ & (((!\current_state.IDLE~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt2|trig~combout\,
	datab => \current_state.IDLE~q\,
	datac => \current_state.INC~q\,
	datad => \bt1|trig~combout\,
	combout => \Selector0~0_combout\);

-- Location: LCCOMB_X36_Y35_N28
\Selector12~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector12~0_combout\ = (\current_state.HT0~q\ & (\bt2|btn_sync~q\ & !\bt2|btn_delay~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \current_state.HT0~q\,
	datac => \bt2|btn_sync~q\,
	datad => \bt2|btn_delay~q\,
	combout => \Selector12~0_combout\);

-- Location: FF_X36_Y35_N29
\current_state.HT1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \Selector12~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.HT1~q\);

-- Location: LCCOMB_X33_Y35_N20
\Selector6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector6~0_combout\ = (\current_state.H0~q\ & (\bt1|btn_sync~q\ & !\bt1|btn_delay~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.H0~q\,
	datab => \bt1|btn_sync~q\,
	datad => \bt1|btn_delay~q\,
	combout => \Selector6~0_combout\);

-- Location: FF_X33_Y35_N21
\current_state.H1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \Selector6~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.H1~q\);

-- Location: LCCOMB_X36_Y35_N16
\Selector0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~1_combout\ = (\next_state~0_combout\ & ((\current_state.H1~q\) # ((\current_state.HT1~q\ & \next_state~1_combout\)))) # (!\next_state~0_combout\ & (\current_state.HT1~q\ & ((\next_state~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \next_state~0_combout\,
	datab => \current_state.HT1~q\,
	datac => \current_state.H1~q\,
	datad => \next_state~1_combout\,
	combout => \Selector0~1_combout\);

-- Location: LCCOMB_X34_Y34_N4
\Selector0~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~6_combout\ = (\Selector0~0_combout\) # ((\Selector0~1_combout\) # ((\bt4|trig~0_combout\ & \Selector0~5_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt4|trig~0_combout\,
	datab => \Selector0~5_combout\,
	datac => \Selector0~0_combout\,
	datad => \Selector0~1_combout\,
	combout => \Selector0~6_combout\);

-- Location: FF_X34_Y34_N5
\current_state.INC\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \Selector0~6_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.INC~q\);

-- Location: LCCOMB_X38_Y33_N28
\t1|toggle~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|toggle~0_combout\ = !\t1|toggle~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \t1|toggle~q\,
	combout => \t1|toggle~0_combout\);

-- Location: LCCOMB_X38_Y33_N26
\t1|toggle~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|toggle~feeder_combout\ = \t1|toggle~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \t1|toggle~0_combout\,
	combout => \t1|toggle~feeder_combout\);

-- Location: LCCOMB_X39_Y34_N8
\t1|Add0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~0_combout\ = \t1|count\(0) $ (VCC)
-- \t1|Add0~1\ = CARRY(\t1|count\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(0),
	datad => VCC,
	combout => \t1|Add0~0_combout\,
	cout => \t1|Add0~1\);

-- Location: FF_X39_Y34_N9
\t1|count[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(0));

-- Location: LCCOMB_X39_Y34_N10
\t1|Add0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~2_combout\ = (\t1|count\(1) & (!\t1|Add0~1\)) # (!\t1|count\(1) & ((\t1|Add0~1\) # (GND)))
-- \t1|Add0~3\ = CARRY((!\t1|Add0~1\) # (!\t1|count\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(1),
	datad => VCC,
	cin => \t1|Add0~1\,
	combout => \t1|Add0~2_combout\,
	cout => \t1|Add0~3\);

-- Location: FF_X39_Y34_N11
\t1|count[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(1));

-- Location: LCCOMB_X39_Y34_N12
\t1|Add0~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~4_combout\ = (\t1|count\(2) & (\t1|Add0~3\ $ (GND))) # (!\t1|count\(2) & (!\t1|Add0~3\ & VCC))
-- \t1|Add0~5\ = CARRY((\t1|count\(2) & !\t1|Add0~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(2),
	datad => VCC,
	cin => \t1|Add0~3\,
	combout => \t1|Add0~4_combout\,
	cout => \t1|Add0~5\);

-- Location: FF_X39_Y34_N13
\t1|count[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(2));

-- Location: LCCOMB_X39_Y34_N14
\t1|Add0~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~6_combout\ = (\t1|count\(3) & (!\t1|Add0~5\)) # (!\t1|count\(3) & ((\t1|Add0~5\) # (GND)))
-- \t1|Add0~7\ = CARRY((!\t1|Add0~5\) # (!\t1|count\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(3),
	datad => VCC,
	cin => \t1|Add0~5\,
	combout => \t1|Add0~6_combout\,
	cout => \t1|Add0~7\);

-- Location: FF_X39_Y34_N15
\t1|count[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(3));

-- Location: LCCOMB_X39_Y34_N16
\t1|Add0~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~8_combout\ = (\t1|count\(4) & (\t1|Add0~7\ $ (GND))) # (!\t1|count\(4) & (!\t1|Add0~7\ & VCC))
-- \t1|Add0~9\ = CARRY((\t1|count\(4) & !\t1|Add0~7\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(4),
	datad => VCC,
	cin => \t1|Add0~7\,
	combout => \t1|Add0~8_combout\,
	cout => \t1|Add0~9\);

-- Location: FF_X39_Y34_N17
\t1|count[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(4));

-- Location: LCCOMB_X39_Y34_N18
\t1|Add0~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~10_combout\ = (\t1|count\(5) & (!\t1|Add0~9\)) # (!\t1|count\(5) & ((\t1|Add0~9\) # (GND)))
-- \t1|Add0~11\ = CARRY((!\t1|Add0~9\) # (!\t1|count\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(5),
	datad => VCC,
	cin => \t1|Add0~9\,
	combout => \t1|Add0~10_combout\,
	cout => \t1|Add0~11\);

-- Location: FF_X39_Y34_N19
\t1|count[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~10_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(5));

-- Location: LCCOMB_X39_Y34_N20
\t1|Add0~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~12_combout\ = (\t1|count\(6) & (\t1|Add0~11\ $ (GND))) # (!\t1|count\(6) & (!\t1|Add0~11\ & VCC))
-- \t1|Add0~13\ = CARRY((\t1|count\(6) & !\t1|Add0~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(6),
	datad => VCC,
	cin => \t1|Add0~11\,
	combout => \t1|Add0~12_combout\,
	cout => \t1|Add0~13\);

-- Location: LCCOMB_X39_Y34_N2
\t1|count~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~2_combout\ = (!\t1|Equal0~7_combout\ & \t1|Add0~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \t1|Equal0~7_combout\,
	datad => \t1|Add0~12_combout\,
	combout => \t1|count~2_combout\);

-- Location: FF_X39_Y34_N3
\t1|count[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(6));

-- Location: LCCOMB_X39_Y34_N22
\t1|Add0~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~14_combout\ = (\t1|count\(7) & (!\t1|Add0~13\)) # (!\t1|count\(7) & ((\t1|Add0~13\) # (GND)))
-- \t1|Add0~15\ = CARRY((!\t1|Add0~13\) # (!\t1|count\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(7),
	datad => VCC,
	cin => \t1|Add0~13\,
	combout => \t1|Add0~14_combout\,
	cout => \t1|Add0~15\);

-- Location: FF_X39_Y34_N23
\t1|count[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~14_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(7));

-- Location: LCCOMB_X39_Y34_N24
\t1|Add0~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~16_combout\ = (\t1|count\(8) & (\t1|Add0~15\ $ (GND))) # (!\t1|count\(8) & (!\t1|Add0~15\ & VCC))
-- \t1|Add0~17\ = CARRY((\t1|count\(8) & !\t1|Add0~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(8),
	datad => VCC,
	cin => \t1|Add0~15\,
	combout => \t1|Add0~16_combout\,
	cout => \t1|Add0~17\);

-- Location: FF_X39_Y34_N25
\t1|count[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~16_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(8));

-- Location: LCCOMB_X39_Y34_N26
\t1|Add0~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~18_combout\ = (\t1|count\(9) & (!\t1|Add0~17\)) # (!\t1|count\(9) & ((\t1|Add0~17\) # (GND)))
-- \t1|Add0~19\ = CARRY((!\t1|Add0~17\) # (!\t1|count\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(9),
	datad => VCC,
	cin => \t1|Add0~17\,
	combout => \t1|Add0~18_combout\,
	cout => \t1|Add0~19\);

-- Location: FF_X39_Y34_N27
\t1|count[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~18_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(9));

-- Location: LCCOMB_X39_Y34_N28
\t1|Add0~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~20_combout\ = (\t1|count\(10) & (\t1|Add0~19\ $ (GND))) # (!\t1|count\(10) & (!\t1|Add0~19\ & VCC))
-- \t1|Add0~21\ = CARRY((\t1|count\(10) & !\t1|Add0~19\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(10),
	datad => VCC,
	cin => \t1|Add0~19\,
	combout => \t1|Add0~20_combout\,
	cout => \t1|Add0~21\);

-- Location: FF_X39_Y34_N29
\t1|count[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(10));

-- Location: LCCOMB_X39_Y34_N30
\t1|Add0~22\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~22_combout\ = (\t1|count\(11) & (!\t1|Add0~21\)) # (!\t1|count\(11) & ((\t1|Add0~21\) # (GND)))
-- \t1|Add0~23\ = CARRY((!\t1|Add0~21\) # (!\t1|count\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(11),
	datad => VCC,
	cin => \t1|Add0~21\,
	combout => \t1|Add0~22_combout\,
	cout => \t1|Add0~23\);

-- Location: LCCOMB_X39_Y34_N0
\t1|count~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~1_combout\ = (!\t1|Equal0~7_combout\ & \t1|Add0~22_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|Equal0~7_combout\,
	datac => \t1|Add0~22_combout\,
	combout => \t1|count~1_combout\);

-- Location: FF_X39_Y34_N1
\t1|count[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(11));

-- Location: LCCOMB_X39_Y33_N0
\t1|Add0~24\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~24_combout\ = (\t1|count\(12) & (\t1|Add0~23\ $ (GND))) # (!\t1|count\(12) & (!\t1|Add0~23\ & VCC))
-- \t1|Add0~25\ = CARRY((\t1|count\(12) & !\t1|Add0~23\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(12),
	datad => VCC,
	cin => \t1|Add0~23\,
	combout => \t1|Add0~24_combout\,
	cout => \t1|Add0~25\);

-- Location: LCCOMB_X38_Y33_N16
\t1|count~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~0_combout\ = (\t1|Add0~24_combout\ & !\t1|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \t1|Add0~24_combout\,
	datad => \t1|Equal0~7_combout\,
	combout => \t1|count~0_combout\);

-- Location: FF_X38_Y33_N17
\t1|count[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(12));

-- Location: LCCOMB_X39_Y33_N2
\t1|Add0~26\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~26_combout\ = (\t1|count\(13) & (!\t1|Add0~25\)) # (!\t1|count\(13) & ((\t1|Add0~25\) # (GND)))
-- \t1|Add0~27\ = CARRY((!\t1|Add0~25\) # (!\t1|count\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(13),
	datad => VCC,
	cin => \t1|Add0~25\,
	combout => \t1|Add0~26_combout\,
	cout => \t1|Add0~27\);

-- Location: LCCOMB_X39_Y33_N26
\t1|count~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~3_combout\ = (!\t1|Equal0~7_combout\ & \t1|Add0~26_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|Equal0~7_combout\,
	datad => \t1|Add0~26_combout\,
	combout => \t1|count~3_combout\);

-- Location: FF_X39_Y33_N27
\t1|count[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(13));

-- Location: LCCOMB_X39_Y33_N4
\t1|Add0~28\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~28_combout\ = (\t1|count\(14) & (\t1|Add0~27\ $ (GND))) # (!\t1|count\(14) & (!\t1|Add0~27\ & VCC))
-- \t1|Add0~29\ = CARRY((\t1|count\(14) & !\t1|Add0~27\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(14),
	datad => VCC,
	cin => \t1|Add0~27\,
	combout => \t1|Add0~28_combout\,
	cout => \t1|Add0~29\);

-- Location: LCCOMB_X39_Y33_N28
\t1|count~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~4_combout\ = (\t1|Add0~28_combout\ & !\t1|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \t1|Add0~28_combout\,
	datad => \t1|Equal0~7_combout\,
	combout => \t1|count~4_combout\);

-- Location: FF_X39_Y33_N29
\t1|count[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(14));

-- Location: LCCOMB_X39_Y33_N6
\t1|Add0~30\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~30_combout\ = (\t1|count\(15) & (!\t1|Add0~29\)) # (!\t1|count\(15) & ((\t1|Add0~29\) # (GND)))
-- \t1|Add0~31\ = CARRY((!\t1|Add0~29\) # (!\t1|count\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(15),
	datad => VCC,
	cin => \t1|Add0~29\,
	combout => \t1|Add0~30_combout\,
	cout => \t1|Add0~31\);

-- Location: FF_X39_Y33_N7
\t1|count[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~30_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(15));

-- Location: LCCOMB_X39_Y33_N8
\t1|Add0~32\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~32_combout\ = (\t1|count\(16) & (\t1|Add0~31\ $ (GND))) # (!\t1|count\(16) & (!\t1|Add0~31\ & VCC))
-- \t1|Add0~33\ = CARRY((\t1|count\(16) & !\t1|Add0~31\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(16),
	datad => VCC,
	cin => \t1|Add0~31\,
	combout => \t1|Add0~32_combout\,
	cout => \t1|Add0~33\);

-- Location: LCCOMB_X38_Y33_N8
\t1|count~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~5_combout\ = (\t1|Add0~32_combout\ & !\t1|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \t1|Add0~32_combout\,
	datad => \t1|Equal0~7_combout\,
	combout => \t1|count~5_combout\);

-- Location: FF_X38_Y33_N9
\t1|count[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(16));

-- Location: LCCOMB_X39_Y33_N10
\t1|Add0~34\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~34_combout\ = (\t1|count\(17) & (!\t1|Add0~33\)) # (!\t1|count\(17) & ((\t1|Add0~33\) # (GND)))
-- \t1|Add0~35\ = CARRY((!\t1|Add0~33\) # (!\t1|count\(17)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(17),
	datad => VCC,
	cin => \t1|Add0~33\,
	combout => \t1|Add0~34_combout\,
	cout => \t1|Add0~35\);

-- Location: FF_X39_Y33_N11
\t1|count[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~34_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(17));

-- Location: LCCOMB_X39_Y33_N12
\t1|Add0~36\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~36_combout\ = (\t1|count\(18) & (\t1|Add0~35\ $ (GND))) # (!\t1|count\(18) & (!\t1|Add0~35\ & VCC))
-- \t1|Add0~37\ = CARRY((\t1|count\(18) & !\t1|Add0~35\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(18),
	datad => VCC,
	cin => \t1|Add0~35\,
	combout => \t1|Add0~36_combout\,
	cout => \t1|Add0~37\);

-- Location: LCCOMB_X38_Y33_N18
\t1|count~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~6_combout\ = (\t1|Add0~36_combout\ & !\t1|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \t1|Add0~36_combout\,
	datad => \t1|Equal0~7_combout\,
	combout => \t1|count~6_combout\);

-- Location: FF_X38_Y33_N19
\t1|count[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(18));

-- Location: LCCOMB_X39_Y33_N14
\t1|Add0~38\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~38_combout\ = (\t1|count\(19) & (!\t1|Add0~37\)) # (!\t1|count\(19) & ((\t1|Add0~37\) # (GND)))
-- \t1|Add0~39\ = CARRY((!\t1|Add0~37\) # (!\t1|count\(19)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(19),
	datad => VCC,
	cin => \t1|Add0~37\,
	combout => \t1|Add0~38_combout\,
	cout => \t1|Add0~39\);

-- Location: LCCOMB_X38_Y33_N10
\t1|count~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~7_combout\ = (\t1|Add0~38_combout\ & !\t1|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \t1|Add0~38_combout\,
	datad => \t1|Equal0~7_combout\,
	combout => \t1|count~7_combout\);

-- Location: FF_X38_Y33_N11
\t1|count[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(19));

-- Location: LCCOMB_X38_Y33_N22
\t1|Equal0~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~5_combout\ = (\t1|count\(19) & (\t1|count\(18) & (!\t1|count\(17) & \t1|count\(16))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(19),
	datab => \t1|count\(18),
	datac => \t1|count\(17),
	datad => \t1|count\(16),
	combout => \t1|Equal0~5_combout\);

-- Location: LCCOMB_X39_Y33_N16
\t1|Add0~40\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~40_combout\ = (\t1|count\(20) & (\t1|Add0~39\ $ (GND))) # (!\t1|count\(20) & (!\t1|Add0~39\ & VCC))
-- \t1|Add0~41\ = CARRY((\t1|count\(20) & !\t1|Add0~39\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(20),
	datad => VCC,
	cin => \t1|Add0~39\,
	combout => \t1|Add0~40_combout\,
	cout => \t1|Add0~41\);

-- Location: LCCOMB_X38_Y33_N14
\t1|count~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~9_combout\ = (!\t1|Equal0~7_combout\ & \t1|Add0~40_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|Equal0~7_combout\,
	datad => \t1|Add0~40_combout\,
	combout => \t1|count~9_combout\);

-- Location: FF_X38_Y33_N15
\t1|count[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~9_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(20));

-- Location: LCCOMB_X39_Y33_N18
\t1|Add0~42\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~42_combout\ = (\t1|count\(21) & (!\t1|Add0~41\)) # (!\t1|count\(21) & ((\t1|Add0~41\) # (GND)))
-- \t1|Add0~43\ = CARRY((!\t1|Add0~41\) # (!\t1|count\(21)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(21),
	datad => VCC,
	cin => \t1|Add0~41\,
	combout => \t1|Add0~42_combout\,
	cout => \t1|Add0~43\);

-- Location: LCCOMB_X38_Y33_N6
\t1|count~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~10_combout\ = (!\t1|Equal0~7_combout\ & \t1|Add0~42_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|Equal0~7_combout\,
	datad => \t1|Add0~42_combout\,
	combout => \t1|count~10_combout\);

-- Location: FF_X38_Y33_N7
\t1|count[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~10_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(21));

-- Location: LCCOMB_X39_Y33_N20
\t1|Add0~44\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~44_combout\ = (\t1|count\(22) & (\t1|Add0~43\ $ (GND))) # (!\t1|count\(22) & (!\t1|Add0~43\ & VCC))
-- \t1|Add0~45\ = CARRY((\t1|count\(22) & !\t1|Add0~43\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(22),
	datad => VCC,
	cin => \t1|Add0~43\,
	combout => \t1|Add0~44_combout\,
	cout => \t1|Add0~45\);

-- Location: LCCOMB_X38_Y33_N24
\t1|count~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~11_combout\ = (\t1|Add0~44_combout\ & !\t1|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \t1|Add0~44_combout\,
	datad => \t1|Equal0~7_combout\,
	combout => \t1|count~11_combout\);

-- Location: FF_X38_Y33_N25
\t1|count[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~11_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(22));

-- Location: LCCOMB_X39_Y33_N22
\t1|Add0~46\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~46_combout\ = (\t1|count\(23) & (!\t1|Add0~45\)) # (!\t1|count\(23) & ((\t1|Add0~45\) # (GND)))
-- \t1|Add0~47\ = CARRY((!\t1|Add0~45\) # (!\t1|count\(23)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(23),
	datad => VCC,
	cin => \t1|Add0~45\,
	combout => \t1|Add0~46_combout\,
	cout => \t1|Add0~47\);

-- Location: FF_X39_Y33_N23
\t1|count[23]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~46_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(23));

-- Location: LCCOMB_X38_Y33_N20
\t1|Equal0~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~6_combout\ = (\t1|count\(21) & (\t1|count\(22) & (\t1|count\(20) & !\t1|count\(23))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(21),
	datab => \t1|count\(22),
	datac => \t1|count\(20),
	datad => \t1|count\(23),
	combout => \t1|Equal0~6_combout\);

-- Location: LCCOMB_X39_Y34_N4
\t1|Equal0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~1_combout\ = (!\t1|count\(8) & (\t1|count\(5) & (!\t1|count\(7) & !\t1|count\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(8),
	datab => \t1|count\(5),
	datac => \t1|count\(7),
	datad => \t1|count\(6),
	combout => \t1|Equal0~1_combout\);

-- Location: LCCOMB_X39_Y34_N6
\t1|Equal0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~2_combout\ = (\t1|count\(2) & (\t1|count\(4) & (\t1|count\(3) & \t1|count\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(2),
	datab => \t1|count\(4),
	datac => \t1|count\(3),
	datad => \t1|count\(1),
	combout => \t1|Equal0~2_combout\);

-- Location: LCCOMB_X38_Y33_N30
\t1|Equal0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~0_combout\ = (\t1|count\(11) & (!\t1|count\(10) & (!\t1|count\(9) & \t1|count\(12))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(11),
	datab => \t1|count\(10),
	datac => \t1|count\(9),
	datad => \t1|count\(12),
	combout => \t1|Equal0~0_combout\);

-- Location: LCCOMB_X39_Y33_N30
\t1|Equal0~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~3_combout\ = (\t1|count\(13) & (\t1|count\(14) & (\t1|count\(0) & !\t1|count\(15))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(13),
	datab => \t1|count\(14),
	datac => \t1|count\(0),
	datad => \t1|count\(15),
	combout => \t1|Equal0~3_combout\);

-- Location: LCCOMB_X38_Y33_N4
\t1|Equal0~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~4_combout\ = (\t1|Equal0~1_combout\ & (\t1|Equal0~2_combout\ & (\t1|Equal0~0_combout\ & \t1|Equal0~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|Equal0~1_combout\,
	datab => \t1|Equal0~2_combout\,
	datac => \t1|Equal0~0_combout\,
	datad => \t1|Equal0~3_combout\,
	combout => \t1|Equal0~4_combout\);

-- Location: LCCOMB_X39_Y33_N24
\t1|Add0~48\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~48_combout\ = \t1|Add0~47\ $ (!\t1|count\(24))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \t1|count\(24),
	cin => \t1|Add0~47\,
	combout => \t1|Add0~48_combout\);

-- Location: LCCOMB_X38_Y33_N12
\t1|count~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~8_combout\ = (!\t1|Equal0~7_combout\ & \t1|Add0~48_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|Equal0~7_combout\,
	datac => \t1|Add0~48_combout\,
	combout => \t1|count~8_combout\);

-- Location: FF_X38_Y33_N13
\t1|count[24]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(24));

-- Location: LCCOMB_X38_Y33_N2
\t1|Equal0~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~7_combout\ = (\t1|Equal0~5_combout\ & (\t1|Equal0~6_combout\ & (\t1|Equal0~4_combout\ & \t1|count\(24))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|Equal0~5_combout\,
	datab => \t1|Equal0~6_combout\,
	datac => \t1|Equal0~4_combout\,
	datad => \t1|count\(24),
	combout => \t1|Equal0~7_combout\);

-- Location: FF_X38_Y33_N27
\t1|toggle\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \t1|toggle~feeder_combout\,
	ena => \t1|Equal0~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|toggle~q\);

-- Location: LCCOMB_X29_Y33_N6
\cnt_min_high~33\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high~33_combout\ = (\current_state.M1~q\ & (\in_min_high[2]~2_combout\)) # (!\current_state.M1~q\ & ((\cnt_min_high[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_min_high[2]~2_combout\,
	datac => \cnt_min_high[2]~2_combout\,
	datad => \current_state.M1~q\,
	combout => \cnt_min_high~33_combout\);

-- Location: LCCOMB_X29_Y33_N20
\cnt_min_high~30\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high~30_combout\ = (\current_state.M1~q\ & (\in_min_high[3]~6_combout\)) # (!\current_state.M1~q\ & ((\cnt_min_high[3]~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_min_high[3]~6_combout\,
	datac => \cnt_min_high[3]~7_combout\,
	datad => \current_state.M1~q\,
	combout => \cnt_min_high~30_combout\);

-- Location: LCCOMB_X35_Y33_N14
\cnt_sec_low[3]~28\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[3]~28_combout\ = (\en~input_o\ & !\current_state.INC~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \en~input_o\,
	datad => \current_state.INC~q\,
	combout => \cnt_sec_low[3]~28_combout\);

-- Location: LCCOMB_X35_Y30_N16
\cnt_min_high[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[3]~6_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high~30_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_high[3]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_min_high[3]~6_combout\,
	datac => \cnt_min_high~30_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_high[3]~6_combout\);

-- Location: LCCOMB_X33_Y34_N14
\in_min_high[0]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[0]~13_combout\ = (\current_state.M1~q\ & (\in_min_high[0]~13_combout\)) # (!\current_state.M1~q\ & ((\cnt_min_high[0]~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_min_high[0]~13_combout\,
	datac => \current_state.M1~q\,
	datad => \cnt_min_high[0]~17_combout\,
	combout => \in_min_high[0]~13_combout\);

-- Location: LCCOMB_X33_Y34_N2
\in_min_high[0]~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[0]~15_combout\ = \in_min_high[0]~14_combout\ $ (!\in_min_high[0]~13_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001111000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_min_high[0]~14_combout\,
	datac => \in_min_high[0]~13_combout\,
	combout => \in_min_high[0]~15_combout\);

-- Location: IOIBUF_X115_Y35_N22
\inc_btn~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_inc_btn,
	o => \inc_btn~input_o\);

-- Location: FF_X33_Y34_N7
\bt3|btn_sync\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	asdata => \inc_btn~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt3|btn_sync~q\);

-- Location: FF_X34_Y34_N21
\bt3|btn_delay\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	asdata => \bt3|btn_sync~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt3|btn_delay~q\);

-- Location: LCCOMB_X33_Y34_N16
\bt3|trig\ : cycloneive_lcell_comb
-- Equation(s):
-- \bt3|trig~combout\ = (!\bt3|btn_delay~q\ & \bt3|btn_sync~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt3|btn_delay~q\,
	datad => \bt3|btn_sync~q\,
	combout => \bt3|trig~combout\);

-- Location: FF_X33_Y34_N3
\in_min_high[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_high[0]~15_combout\,
	clrn => \current_state.M1~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_high[0]~_emulated_q\);

-- Location: LCCOMB_X33_Y34_N4
\in_min_high[0]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[0]~14_combout\ = (\current_state.M1~q\ & ((\in_min_high[0]~13_combout\ $ (\in_min_high[0]~_emulated_q\)))) # (!\current_state.M1~q\ & (\cnt_min_high[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.M1~q\,
	datab => \cnt_min_high[0]~17_combout\,
	datac => \in_min_high[0]~13_combout\,
	datad => \in_min_high[0]~_emulated_q\,
	combout => \in_min_high[0]~14_combout\);

-- Location: LCCOMB_X33_Y34_N30
\cnt_min_high~32\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high~32_combout\ = (\current_state.M1~q\ & (\in_min_high[0]~14_combout\)) # (!\current_state.M1~q\ & ((\cnt_min_high[0]~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_min_high[0]~14_combout\,
	datac => \current_state.M1~q\,
	datad => \cnt_min_high[0]~17_combout\,
	combout => \cnt_min_high~32_combout\);

-- Location: LCCOMB_X35_Y33_N10
\cnt_min_high[0]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[0]~16_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high~32_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_high[0]~16_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[0]~16_combout\,
	datab => \en~input_o\,
	datac => \cnt_min_high~32_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_high[0]~16_combout\);

-- Location: LCCOMB_X35_Y33_N8
\cnt_min_high[0]~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[0]~19_combout\ = \cnt_min_high[0]~17_combout\ $ (!\cnt_min_high[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[0]~16_combout\,
	combout => \cnt_min_high[0]~19_combout\);

-- Location: LCCOMB_X33_Y33_N30
\cnt_min_high[2]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[2]~0_combout\ = (\cnt_sec_low[3]~28_combout\) # (!\en~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[3]~28_combout\,
	datad => \en~input_o\,
	combout => \cnt_min_high[2]~0_combout\);

-- Location: CLKCTRL_G3
\cnt_min_high[2]~0clkctrl\ : cycloneive_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \cnt_min_high[2]~0clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \cnt_min_high[2]~0clkctrl_outclk\);

-- Location: LCCOMB_X32_Y32_N16
\in_sec_low[0]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[0]~13_combout\ = (\current_state.S0~q\ & ((\in_sec_low[0]~13_combout\))) # (!\current_state.S0~q\ & (\cnt_sec_low[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_low[0]~17_combout\,
	datac => \current_state.S0~q\,
	datad => \in_sec_low[0]~13_combout\,
	combout => \in_sec_low[0]~13_combout\);

-- Location: LCCOMB_X32_Y32_N26
\in_sec_low[0]~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[0]~15_combout\ = \in_sec_low[0]~13_combout\ $ (!\in_sec_low[0]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001111000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_sec_low[0]~13_combout\,
	datac => \in_sec_low[0]~14_combout\,
	combout => \in_sec_low[0]~15_combout\);

-- Location: FF_X32_Y32_N27
\in_sec_low[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_low[0]~15_combout\,
	clrn => \current_state.S0~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_low[0]~_emulated_q\);

-- Location: LCCOMB_X32_Y32_N30
\in_sec_low[0]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[0]~14_combout\ = (\current_state.S0~q\ & ((\in_sec_low[0]~_emulated_q\ $ (\in_sec_low[0]~13_combout\)))) # (!\current_state.S0~q\ & (\cnt_sec_low[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010111011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[0]~17_combout\,
	datab => \current_state.S0~q\,
	datac => \in_sec_low[0]~_emulated_q\,
	datad => \in_sec_low[0]~13_combout\,
	combout => \in_sec_low[0]~14_combout\);

-- Location: LCCOMB_X38_Y31_N16
\cnt_sec_low~31\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low~31_combout\ = (\current_state.S0~q\ & ((\in_sec_low[0]~14_combout\))) # (!\current_state.S0~q\ & (\cnt_sec_low[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_low[0]~17_combout\,
	datac => \in_sec_low[0]~14_combout\,
	datad => \current_state.S0~q\,
	combout => \cnt_sec_low~31_combout\);

-- Location: LCCOMB_X38_Y31_N28
\cnt_sec_low[0]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[0]~16_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low~31_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low[0]~16_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low~31_combout\,
	datab => \cnt_sec_low[0]~16_combout\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \en~input_o\,
	combout => \cnt_sec_low[0]~16_combout\);

-- Location: LCCOMB_X38_Y31_N4
\cnt_sec_low[0]~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[0]~19_combout\ = \cnt_sec_low[0]~16_combout\ $ (!\cnt_sec_low[0]~17_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_low[0]~16_combout\,
	datad => \cnt_sec_low[0]~17_combout\,
	combout => \cnt_sec_low[0]~19_combout\);

-- Location: FF_X38_Y31_N13
\cnt_sec_low[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_low[0]~19_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_low[0]~_emulated_q\);

-- Location: LCCOMB_X38_Y31_N12
\cnt_sec_low[0]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[0]~18_combout\ = \cnt_sec_low[0]~_emulated_q\ $ (\cnt_sec_low[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_low[0]~_emulated_q\,
	datad => \cnt_sec_low[0]~16_combout\,
	combout => \cnt_sec_low[0]~18_combout\);

-- Location: LCCOMB_X38_Y31_N24
\cnt_sec_low[0]~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[0]~17_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low~31_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low[0]~18_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_sec_low~31_combout\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_sec_low[0]~18_combout\,
	combout => \cnt_sec_low[0]~17_combout\);

-- Location: LCCOMB_X38_Y31_N30
\cnt_sec_low~32\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low~32_combout\ = (\current_state.S0~q\ & ((\in_sec_low[1]~10_combout\))) # (!\current_state.S0~q\ & (\cnt_sec_low[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_low[1]~12_combout\,
	datac => \in_sec_low[1]~10_combout\,
	datad => \current_state.S0~q\,
	combout => \cnt_sec_low~32_combout\);

-- Location: LCCOMB_X38_Y31_N6
\cnt_sec_low[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[1]~11_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low~32_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low[1]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[1]~11_combout\,
	datab => \cnt_sec_low~32_combout\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \en~input_o\,
	combout => \cnt_sec_low[1]~11_combout\);

-- Location: LCCOMB_X32_Y32_N12
\in_sec_low[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[2]~1_combout\ = (\current_state.S0~q\ & ((\in_sec_low[2]~1_combout\))) # (!\current_state.S0~q\ & (\cnt_sec_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_low[2]~2_combout\,
	datac => \current_state.S0~q\,
	datad => \in_sec_low[2]~1_combout\,
	combout => \in_sec_low[2]~1_combout\);

-- Location: LCCOMB_X32_Y32_N14
\Add0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add0~1_combout\ = (\in_sec_low[1]~10_combout\ & \in_sec_low[0]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \in_sec_low[1]~10_combout\,
	datad => \in_sec_low[0]~14_combout\,
	combout => \Add0~1_combout\);

-- Location: LCCOMB_X32_Y32_N0
\in_sec_low[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[2]~3_combout\ = \in_sec_low[2]~1_combout\ $ (\in_sec_low[2]~2_combout\ $ (((\Add0~1_combout\ & \bt3|trig~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001010101101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_low[2]~1_combout\,
	datab => \Add0~1_combout\,
	datac => \bt3|trig~combout\,
	datad => \in_sec_low[2]~2_combout\,
	combout => \in_sec_low[2]~3_combout\);

-- Location: FF_X32_Y32_N1
\in_sec_low[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_low[2]~3_combout\,
	clrn => \current_state.S0~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_low[2]~_emulated_q\);

-- Location: LCCOMB_X32_Y32_N24
\in_sec_low[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[2]~2_combout\ = (\current_state.S0~q\ & ((\in_sec_low[2]~_emulated_q\ $ (\in_sec_low[2]~1_combout\)))) # (!\current_state.S0~q\ & (\cnt_sec_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[2]~2_combout\,
	datab => \in_sec_low[2]~_emulated_q\,
	datac => \current_state.S0~q\,
	datad => \in_sec_low[2]~1_combout\,
	combout => \in_sec_low[2]~2_combout\);

-- Location: LCCOMB_X38_Y31_N18
\cnt_sec_low~30\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low~30_combout\ = (\current_state.S0~q\ & ((\in_sec_low[2]~2_combout\))) # (!\current_state.S0~q\ & (\cnt_sec_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[2]~2_combout\,
	datac => \in_sec_low[2]~2_combout\,
	datad => \current_state.S0~q\,
	combout => \cnt_sec_low~30_combout\);

-- Location: LCCOMB_X38_Y31_N10
\cnt_sec_low[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[2]~1_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low~30_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low[2]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[2]~1_combout\,
	datab => \cnt_sec_low~30_combout\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \en~input_o\,
	combout => \cnt_sec_low[2]~1_combout\);

-- Location: LCCOMB_X38_Y31_N8
\cnt_sec_low[2]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[2]~4_combout\ = \cnt_sec_low[2]~1_combout\ $ (\cnt_sec_low[2]~2_combout\ $ (((\cnt_sec_low[1]~12_combout\ & \cnt_sec_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011001011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[2]~1_combout\,
	datab => \cnt_sec_low[1]~12_combout\,
	datac => \cnt_sec_low[2]~2_combout\,
	datad => \cnt_sec_low[0]~17_combout\,
	combout => \cnt_sec_low[2]~4_combout\);

-- Location: FF_X38_Y31_N21
\cnt_sec_low[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_low[2]~4_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_low[2]~_emulated_q\);

-- Location: LCCOMB_X38_Y31_N20
\cnt_sec_low[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[2]~3_combout\ = \cnt_sec_low[2]~_emulated_q\ $ (\cnt_sec_low[2]~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_low[2]~_emulated_q\,
	datad => \cnt_sec_low[2]~1_combout\,
	combout => \cnt_sec_low[2]~3_combout\);

-- Location: LCCOMB_X38_Y31_N26
\cnt_sec_low[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[2]~2_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low~30_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low[2]~3_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_sec_low~30_combout\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_sec_low[2]~3_combout\,
	combout => \cnt_sec_low[2]~2_combout\);

-- Location: LCCOMB_X36_Y32_N0
\se4|Equal15~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se4|Equal15~0_combout\ = (\cnt_sec_low[3]~7_combout\ & !\cnt_sec_low[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_low[3]~7_combout\,
	datad => \cnt_sec_low[2]~2_combout\,
	combout => \se4|Equal15~0_combout\);

-- Location: LCCOMB_X38_Y31_N22
\cnt_sec_low[1]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[1]~14_combout\ = \cnt_sec_low[1]~11_combout\ $ (((\cnt_sec_low[0]~17_combout\ & (!\cnt_sec_low[1]~12_combout\ & !\se4|Equal15~0_combout\)) # (!\cnt_sec_low[0]~17_combout\ & (\cnt_sec_low[1]~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001101010010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[1]~11_combout\,
	datab => \cnt_sec_low[0]~17_combout\,
	datac => \cnt_sec_low[1]~12_combout\,
	datad => \se4|Equal15~0_combout\,
	combout => \cnt_sec_low[1]~14_combout\);

-- Location: FF_X38_Y31_N3
\cnt_sec_low[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_low[1]~14_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_low[1]~_emulated_q\);

-- Location: LCCOMB_X38_Y31_N2
\cnt_sec_low[1]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[1]~13_combout\ = \cnt_sec_low[1]~_emulated_q\ $ (\cnt_sec_low[1]~11_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_low[1]~_emulated_q\,
	datad => \cnt_sec_low[1]~11_combout\,
	combout => \cnt_sec_low[1]~13_combout\);

-- Location: LCCOMB_X38_Y31_N0
\cnt_sec_low[1]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[1]~12_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low~32_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low[1]~13_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low~32_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_sec_low[1]~13_combout\,
	combout => \cnt_sec_low[1]~12_combout\);

-- Location: LCCOMB_X32_Y32_N4
\in_sec_low[1]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[1]~9_combout\ = (\current_state.S0~q\ & ((\in_sec_low[1]~9_combout\))) # (!\current_state.S0~q\ & (\cnt_sec_low[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[1]~12_combout\,
	datab => \in_sec_low[1]~9_combout\,
	datac => \current_state.S0~q\,
	combout => \in_sec_low[1]~9_combout\);

-- Location: LCCOMB_X32_Y32_N6
\Equal0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Equal0~0_combout\ = (\in_sec_low[0]~14_combout\ & (\in_sec_low[3]~6_combout\ & (!\in_sec_low[1]~10_combout\ & !\in_sec_low[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_low[0]~14_combout\,
	datab => \in_sec_low[3]~6_combout\,
	datac => \in_sec_low[1]~10_combout\,
	datad => \in_sec_low[2]~2_combout\,
	combout => \Equal0~0_combout\);

-- Location: LCCOMB_X32_Y32_N28
\in_sec_low[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[1]~11_combout\ = \in_sec_low[1]~9_combout\ $ (((!\Equal0~0_combout\ & (\in_sec_low[0]~14_combout\ $ (\in_sec_low[1]~10_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110100010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_low[0]~14_combout\,
	datab => \Equal0~0_combout\,
	datac => \in_sec_low[1]~10_combout\,
	datad => \in_sec_low[1]~9_combout\,
	combout => \in_sec_low[1]~11_combout\);

-- Location: FF_X32_Y32_N29
\in_sec_low[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_low[1]~11_combout\,
	clrn => \current_state.S0~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_low[1]~_emulated_q\);

-- Location: LCCOMB_X32_Y32_N22
\in_sec_low[1]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[1]~10_combout\ = (\current_state.S0~q\ & ((\in_sec_low[1]~9_combout\ $ (\in_sec_low[1]~_emulated_q\)))) # (!\current_state.S0~q\ & (\cnt_sec_low[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[1]~12_combout\,
	datab => \in_sec_low[1]~9_combout\,
	datac => \current_state.S0~q\,
	datad => \in_sec_low[1]~_emulated_q\,
	combout => \in_sec_low[1]~10_combout\);

-- Location: LCCOMB_X32_Y32_N2
\Add0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add0~0_combout\ = (\in_sec_low[0]~14_combout\ & (\in_sec_low[1]~10_combout\ & \in_sec_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_low[0]~14_combout\,
	datac => \in_sec_low[1]~10_combout\,
	datad => \in_sec_low[2]~2_combout\,
	combout => \Add0~0_combout\);

-- Location: LCCOMB_X32_Y32_N20
\in_sec_low[3]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[3]~5_combout\ = (\current_state.S0~q\ & ((\in_sec_low[3]~5_combout\))) # (!\current_state.S0~q\ & (\cnt_sec_low[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[3]~7_combout\,
	datab => \in_sec_low[3]~5_combout\,
	datac => \current_state.S0~q\,
	combout => \in_sec_low[3]~5_combout\);

-- Location: LCCOMB_X32_Y32_N8
\in_sec_low[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[3]~7_combout\ = \in_sec_low[3]~5_combout\ $ (((!\Equal0~0_combout\ & (\Add0~0_combout\ $ (\in_sec_low[3]~6_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110100010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Add0~0_combout\,
	datab => \Equal0~0_combout\,
	datac => \in_sec_low[3]~6_combout\,
	datad => \in_sec_low[3]~5_combout\,
	combout => \in_sec_low[3]~7_combout\);

-- Location: FF_X32_Y32_N9
\in_sec_low[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_low[3]~7_combout\,
	clrn => \current_state.S0~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_low[3]~_emulated_q\);

-- Location: LCCOMB_X32_Y32_N10
\in_sec_low[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[3]~6_combout\ = (\current_state.S0~q\ & ((\in_sec_low[3]~_emulated_q\ $ (\in_sec_low[3]~5_combout\)))) # (!\current_state.S0~q\ & (\cnt_sec_low[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[3]~7_combout\,
	datab => \in_sec_low[3]~_emulated_q\,
	datac => \current_state.S0~q\,
	datad => \in_sec_low[3]~5_combout\,
	combout => \in_sec_low[3]~6_combout\);

-- Location: LCCOMB_X32_Y32_N18
\cnt_sec_low~29\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low~29_combout\ = (\current_state.S0~q\ & ((\in_sec_low[3]~6_combout\))) # (!\current_state.S0~q\ & (\cnt_sec_low[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_low[3]~7_combout\,
	datac => \current_state.S0~q\,
	datad => \in_sec_low[3]~6_combout\,
	combout => \cnt_sec_low~29_combout\);

-- Location: LCCOMB_X38_Y31_N14
\Add1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add1~0_combout\ = (\cnt_sec_low[2]~2_combout\ & (\cnt_sec_low[1]~12_combout\ & \cnt_sec_low[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[2]~2_combout\,
	datac => \cnt_sec_low[1]~12_combout\,
	datad => \cnt_sec_low[0]~17_combout\,
	combout => \Add1~0_combout\);

-- Location: LCCOMB_X35_Y30_N20
\cnt_sec_low[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[3]~6_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low~29_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low[3]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_sec_low[3]~6_combout\,
	datac => \cnt_sec_low~29_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_sec_low[3]~6_combout\);

-- Location: LCCOMB_X35_Y30_N6
\cnt_sec_low[3]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[3]~9_combout\ = \cnt_sec_low[3]~6_combout\ $ (((!\se4|Equal15~1_combout\ & (\Add1~0_combout\ $ (\cnt_sec_low[3]~7_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110100010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Add1~0_combout\,
	datab => \se4|Equal15~1_combout\,
	datac => \cnt_sec_low[3]~7_combout\,
	datad => \cnt_sec_low[3]~6_combout\,
	combout => \cnt_sec_low[3]~9_combout\);

-- Location: FF_X35_Y30_N5
\cnt_sec_low[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_low[3]~9_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_low[3]~_emulated_q\);

-- Location: LCCOMB_X35_Y30_N4
\cnt_sec_low[3]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[3]~8_combout\ = \cnt_sec_low[3]~_emulated_q\ $ (\cnt_sec_low[3]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_low[3]~_emulated_q\,
	datad => \cnt_sec_low[3]~6_combout\,
	combout => \cnt_sec_low[3]~8_combout\);

-- Location: LCCOMB_X35_Y30_N18
\cnt_sec_low[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[3]~7_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low~29_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low[3]~8_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low~29_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~8_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_sec_low[3]~7_combout\);

-- Location: LCCOMB_X36_Y32_N20
\se4|Equal15~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se4|Equal15~1_combout\ = (\cnt_sec_low[0]~17_combout\ & (\cnt_sec_low[3]~7_combout\ & (!\cnt_sec_low[1]~12_combout\ & !\cnt_sec_low[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[0]~17_combout\,
	datab => \cnt_sec_low[3]~7_combout\,
	datac => \cnt_sec_low[1]~12_combout\,
	datad => \cnt_sec_low[2]~2_combout\,
	combout => \se4|Equal15~1_combout\);

-- Location: LCCOMB_X31_Y36_N14
\in_min_low[0]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[0]~13_combout\ = (\current_state.M0~q\ & ((\in_min_low[0]~13_combout\))) # (!\current_state.M0~q\ & (\cnt_min_low[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~17_combout\,
	datab => \in_min_low[0]~13_combout\,
	datad => \current_state.M0~q\,
	combout => \in_min_low[0]~13_combout\);

-- Location: LCCOMB_X31_Y36_N24
\in_min_low[0]~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[0]~15_combout\ = \in_min_low[0]~13_combout\ $ (!\in_min_low[0]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001111000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_min_low[0]~13_combout\,
	datac => \in_min_low[0]~14_combout\,
	combout => \in_min_low[0]~15_combout\);

-- Location: FF_X31_Y36_N25
\in_min_low[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_low[0]~15_combout\,
	clrn => \current_state.M0~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_low[0]~_emulated_q\);

-- Location: LCCOMB_X31_Y36_N30
\in_min_low[0]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[0]~14_combout\ = (\current_state.M0~q\ & ((\in_min_low[0]~13_combout\ $ (\in_min_low[0]~_emulated_q\)))) # (!\current_state.M0~q\ & (\cnt_min_low[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010111011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~17_combout\,
	datab => \current_state.M0~q\,
	datac => \in_min_low[0]~13_combout\,
	datad => \in_min_low[0]~_emulated_q\,
	combout => \in_min_low[0]~14_combout\);

-- Location: LCCOMB_X31_Y36_N16
\cnt_min_low~29\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low~29_combout\ = (\current_state.M0~q\ & (\in_min_low[0]~14_combout\)) # (!\current_state.M0~q\ & ((\cnt_min_low[0]~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[0]~14_combout\,
	datac => \cnt_min_low[0]~17_combout\,
	datad => \current_state.M0~q\,
	combout => \cnt_min_low~29_combout\);

-- Location: LCCOMB_X40_Y33_N12
\cnt_min_low[0]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[0]~16_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low~29_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_low[0]~16_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~16_combout\,
	datab => \en~input_o\,
	datac => \cnt_min_low~29_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_low[0]~16_combout\);

-- Location: LCCOMB_X40_Y33_N10
\cnt_min_low[0]~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[0]~19_combout\ = \cnt_min_low[0]~17_combout\ $ (!\cnt_min_low[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_low[0]~17_combout\,
	datad => \cnt_min_low[0]~16_combout\,
	combout => \cnt_min_low[0]~19_combout\);

-- Location: LCCOMB_X33_Y36_N8
\in_sec_high[3]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[3]~5_combout\ = (\current_state.S1~q\ & ((\in_sec_high[3]~5_combout\))) # (!\current_state.S1~q\ & (\cnt_sec_high[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[3]~7_combout\,
	datab => \current_state.S1~q\,
	datac => \in_sec_high[3]~5_combout\,
	combout => \in_sec_high[3]~5_combout\);

-- Location: LCCOMB_X34_Y36_N20
\cnt_sec_high~29\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high~29_combout\ = (\current_state.S1~q\ & (\in_sec_high[0]~14_combout\)) # (!\current_state.S1~q\ & ((\cnt_sec_high[0]~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_high[0]~14_combout\,
	datac => \cnt_sec_high[0]~17_combout\,
	datad => \current_state.S1~q\,
	combout => \cnt_sec_high~29_combout\);

-- Location: LCCOMB_X35_Y33_N2
\cnt_sec_high[0]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[0]~16_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high~29_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high[0]~16_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_sec_high[0]~16_combout\,
	datac => \cnt_sec_high~29_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_sec_high[0]~16_combout\);

-- Location: LCCOMB_X35_Y33_N28
\cnt_sec_high[0]~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[0]~19_combout\ = \cnt_sec_high[0]~17_combout\ $ (!\cnt_sec_high[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_high[0]~17_combout\,
	datad => \cnt_sec_high[0]~16_combout\,
	combout => \cnt_sec_high[0]~19_combout\);

-- Location: FF_X35_Y33_N21
\cnt_sec_high[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_high[0]~19_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \se4|Equal15~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_high[0]~_emulated_q\);

-- Location: LCCOMB_X35_Y33_N20
\cnt_sec_high[0]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[0]~18_combout\ = \cnt_sec_high[0]~_emulated_q\ $ (\cnt_sec_high[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_high[0]~_emulated_q\,
	datad => \cnt_sec_high[0]~16_combout\,
	combout => \cnt_sec_high[0]~18_combout\);

-- Location: LCCOMB_X35_Y33_N26
\cnt_sec_high[0]~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[0]~17_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high~29_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high[0]~18_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high~29_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_sec_high[0]~18_combout\,
	combout => \cnt_sec_high[0]~17_combout\);

-- Location: LCCOMB_X31_Y36_N26
\in_sec_high[0]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[0]~13_combout\ = (\current_state.S1~q\ & ((\in_sec_high[0]~13_combout\))) # (!\current_state.S1~q\ & (\cnt_sec_high[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[0]~17_combout\,
	datac => \current_state.S1~q\,
	datad => \in_sec_high[0]~13_combout\,
	combout => \in_sec_high[0]~13_combout\);

-- Location: LCCOMB_X31_Y36_N18
\in_sec_high[0]~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[0]~15_combout\ = \in_sec_high[0]~13_combout\ $ (!\in_sec_high[0]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \in_sec_high[0]~13_combout\,
	datad => \in_sec_high[0]~14_combout\,
	combout => \in_sec_high[0]~15_combout\);

-- Location: FF_X31_Y36_N19
\in_sec_high[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_high[0]~15_combout\,
	clrn => \current_state.S1~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_high[0]~_emulated_q\);

-- Location: LCCOMB_X31_Y36_N28
\in_sec_high[0]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[0]~14_combout\ = (\current_state.S1~q\ & ((\in_sec_high[0]~13_combout\ $ (\in_sec_high[0]~_emulated_q\)))) # (!\current_state.S1~q\ & (\cnt_sec_high[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010111011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[0]~17_combout\,
	datab => \current_state.S1~q\,
	datac => \in_sec_high[0]~13_combout\,
	datad => \in_sec_high[0]~_emulated_q\,
	combout => \in_sec_high[0]~14_combout\);

-- Location: LCCOMB_X34_Y36_N12
\cnt_sec_high~32\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high~32_combout\ = (\current_state.S1~q\ & ((\in_sec_high[1]~10_combout\))) # (!\current_state.S1~q\ & (\cnt_sec_high[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_high[1]~12_combout\,
	datac => \in_sec_high[1]~10_combout\,
	datad => \current_state.S1~q\,
	combout => \cnt_sec_high~32_combout\);

-- Location: LCCOMB_X33_Y33_N18
\cnt_sec_high[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[1]~11_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high~32_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high[1]~11_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high~32_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_sec_high[1]~11_combout\,
	combout => \cnt_sec_high[1]~11_combout\);

-- Location: LCCOMB_X33_Y33_N8
\cnt_sec_high[1]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[1]~14_combout\ = \cnt_sec_high[1]~11_combout\ $ (((!\se3|Equal15~0_combout\ & (\cnt_sec_high[0]~17_combout\ $ (\cnt_sec_high[1]~12_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110100010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[0]~17_combout\,
	datab => \se3|Equal15~0_combout\,
	datac => \cnt_sec_high[1]~12_combout\,
	datad => \cnt_sec_high[1]~11_combout\,
	combout => \cnt_sec_high[1]~14_combout\);

-- Location: FF_X33_Y33_N13
\cnt_sec_high[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_high[1]~14_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \se4|Equal15~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_high[1]~_emulated_q\);

-- Location: LCCOMB_X33_Y33_N12
\cnt_sec_high[1]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[1]~13_combout\ = \cnt_sec_high[1]~_emulated_q\ $ (\cnt_sec_high[1]~11_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_high[1]~_emulated_q\,
	datad => \cnt_sec_high[1]~11_combout\,
	combout => \cnt_sec_high[1]~13_combout\);

-- Location: LCCOMB_X33_Y33_N26
\cnt_sec_high[1]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[1]~12_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high~32_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high[1]~13_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_sec_high~32_combout\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_sec_high[1]~13_combout\,
	combout => \cnt_sec_high[1]~12_combout\);

-- Location: LCCOMB_X33_Y36_N22
\in_sec_high[1]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[1]~9_combout\ = (\current_state.S1~q\ & (\in_sec_high[1]~9_combout\)) # (!\current_state.S1~q\ & ((\cnt_sec_high[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100010111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_high[1]~9_combout\,
	datab => \current_state.S1~q\,
	datac => \cnt_sec_high[1]~12_combout\,
	combout => \in_sec_high[1]~9_combout\);

-- Location: LCCOMB_X34_Y36_N8
\cnt_sec_high~28\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high~28_combout\ = (\current_state.S1~q\ & ((\in_sec_high[2]~2_combout\))) # (!\current_state.S1~q\ & (\cnt_sec_high[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_high[2]~2_combout\,
	datac => \in_sec_high[2]~2_combout\,
	datad => \current_state.S1~q\,
	combout => \cnt_sec_high~28_combout\);

-- Location: LCCOMB_X33_Y33_N6
\cnt_sec_high[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[2]~1_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high~28_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high[2]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[2]~1_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_high~28_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_sec_high[2]~1_combout\);

-- Location: LCCOMB_X33_Y33_N0
\se3|seg[1]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \se3|seg[1]~5_combout\ = (\cnt_sec_high[1]~12_combout\ & \cnt_sec_high[0]~17_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_high[1]~12_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \se3|seg[1]~5_combout\);

-- Location: LCCOMB_X33_Y33_N4
\cnt_sec_high[2]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[2]~4_combout\ = \cnt_sec_high[2]~1_combout\ $ (((!\se3|Equal15~0_combout\ & (\se3|seg[1]~5_combout\ $ (\cnt_sec_high[2]~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[2]~1_combout\,
	datab => \se3|seg[1]~5_combout\,
	datac => \cnt_sec_high[2]~2_combout\,
	datad => \se3|Equal15~0_combout\,
	combout => \cnt_sec_high[2]~4_combout\);

-- Location: FF_X33_Y33_N21
\cnt_sec_high[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_high[2]~4_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \se4|Equal15~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_high[2]~_emulated_q\);

-- Location: LCCOMB_X33_Y33_N20
\cnt_sec_high[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[2]~3_combout\ = \cnt_sec_high[2]~_emulated_q\ $ (\cnt_sec_high[2]~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_high[2]~_emulated_q\,
	datad => \cnt_sec_high[2]~1_combout\,
	combout => \cnt_sec_high[2]~3_combout\);

-- Location: LCCOMB_X33_Y33_N10
\cnt_sec_high[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[2]~2_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high~28_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high[2]~3_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_sec_high~28_combout\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_sec_high[2]~3_combout\,
	combout => \cnt_sec_high[2]~2_combout\);

-- Location: LCCOMB_X33_Y36_N20
\in_sec_high[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[2]~1_combout\ = (\current_state.S1~q\ & ((\in_sec_high[2]~1_combout\))) # (!\current_state.S1~q\ & (\cnt_sec_high[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[2]~2_combout\,
	datab => \in_sec_high[2]~1_combout\,
	datac => \current_state.S1~q\,
	combout => \in_sec_high[2]~1_combout\);

-- Location: LCCOMB_X33_Y36_N14
\in_sec_high[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[2]~3_combout\ = \in_sec_high[2]~1_combout\ $ (((!\Equal2~0_combout\ & (\in_sec_high[2]~2_combout\ $ (\Add2~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_high[2]~2_combout\,
	datab => \in_sec_high[2]~1_combout\,
	datac => \Add2~0_combout\,
	datad => \Equal2~0_combout\,
	combout => \in_sec_high[2]~3_combout\);

-- Location: FF_X33_Y36_N15
\in_sec_high[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_high[2]~3_combout\,
	clrn => \current_state.S1~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_high[2]~_emulated_q\);

-- Location: LCCOMB_X33_Y36_N16
\in_sec_high[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[2]~2_combout\ = (\current_state.S1~q\ & ((\in_sec_high[2]~_emulated_q\ $ (\in_sec_high[2]~1_combout\)))) # (!\current_state.S1~q\ & (\cnt_sec_high[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[2]~2_combout\,
	datab => \in_sec_high[2]~_emulated_q\,
	datac => \current_state.S1~q\,
	datad => \in_sec_high[2]~1_combout\,
	combout => \in_sec_high[2]~2_combout\);

-- Location: LCCOMB_X33_Y36_N12
\Equal2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Equal2~0_combout\ = (!\in_sec_high[1]~10_combout\ & (\in_sec_high[0]~14_combout\ & (!\in_sec_high[3]~6_combout\ & \in_sec_high[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_high[1]~10_combout\,
	datab => \in_sec_high[0]~14_combout\,
	datac => \in_sec_high[3]~6_combout\,
	datad => \in_sec_high[2]~2_combout\,
	combout => \Equal2~0_combout\);

-- Location: LCCOMB_X33_Y36_N4
\in_sec_high[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[1]~11_combout\ = \in_sec_high[1]~9_combout\ $ (((!\Equal2~0_combout\ & (\in_sec_high[0]~14_combout\ $ (\in_sec_high[1]~10_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100110011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_high[1]~9_combout\,
	datab => \Equal2~0_combout\,
	datac => \in_sec_high[0]~14_combout\,
	datad => \in_sec_high[1]~10_combout\,
	combout => \in_sec_high[1]~11_combout\);

-- Location: FF_X33_Y36_N5
\in_sec_high[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_high[1]~11_combout\,
	clrn => \current_state.S1~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_high[1]~_emulated_q\);

-- Location: LCCOMB_X33_Y36_N26
\in_sec_high[1]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[1]~10_combout\ = (\current_state.S1~q\ & ((\in_sec_high[1]~9_combout\ $ (\in_sec_high[1]~_emulated_q\)))) # (!\current_state.S1~q\ & (\cnt_sec_high[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010111011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[1]~12_combout\,
	datab => \current_state.S1~q\,
	datac => \in_sec_high[1]~9_combout\,
	datad => \in_sec_high[1]~_emulated_q\,
	combout => \in_sec_high[1]~10_combout\);

-- Location: LCCOMB_X33_Y36_N18
\Add2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add2~0_combout\ = (\in_sec_high[0]~14_combout\ & \in_sec_high[1]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \in_sec_high[0]~14_combout\,
	datad => \in_sec_high[1]~10_combout\,
	combout => \Add2~0_combout\);

-- Location: LCCOMB_X33_Y36_N10
\in_sec_high[3]~22\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[3]~22_combout\ = (!\bt3|btn_delay~q\ & (\in_sec_high[2]~2_combout\ & \bt3|btn_sync~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \bt3|btn_delay~q\,
	datac => \in_sec_high[2]~2_combout\,
	datad => \bt3|btn_sync~q\,
	combout => \in_sec_high[3]~22_combout\);

-- Location: LCCOMB_X33_Y36_N30
\in_sec_high[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[3]~7_combout\ = \in_sec_high[3]~6_combout\ $ (\in_sec_high[3]~5_combout\ $ (((\Add2~0_combout\ & \in_sec_high[3]~22_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011001100110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_high[3]~6_combout\,
	datab => \in_sec_high[3]~5_combout\,
	datac => \Add2~0_combout\,
	datad => \in_sec_high[3]~22_combout\,
	combout => \in_sec_high[3]~7_combout\);

-- Location: FF_X33_Y36_N31
\in_sec_high[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_high[3]~7_combout\,
	clrn => \current_state.S1~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_high[3]~_emulated_q\);

-- Location: LCCOMB_X33_Y36_N28
\in_sec_high[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[3]~6_combout\ = (\current_state.S1~q\ & ((\in_sec_high[3]~_emulated_q\ $ (\in_sec_high[3]~5_combout\)))) # (!\current_state.S1~q\ & (\cnt_sec_high[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010111011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[3]~7_combout\,
	datab => \current_state.S1~q\,
	datac => \in_sec_high[3]~_emulated_q\,
	datad => \in_sec_high[3]~5_combout\,
	combout => \in_sec_high[3]~6_combout\);

-- Location: LCCOMB_X33_Y36_N6
\cnt_sec_high~31\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high~31_combout\ = (\current_state.S1~q\ & ((\in_sec_high[3]~6_combout\))) # (!\current_state.S1~q\ & (\cnt_sec_high[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[3]~7_combout\,
	datab => \in_sec_high[3]~6_combout\,
	datac => \current_state.S1~q\,
	combout => \cnt_sec_high~31_combout\);

-- Location: LCCOMB_X33_Y33_N16
\cnt_sec_high[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[3]~6_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high~31_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high[3]~6_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high~31_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_sec_high[3]~6_combout\,
	combout => \cnt_sec_high[3]~6_combout\);

-- Location: LCCOMB_X33_Y33_N24
\cnt_sec_high[3]~30\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[3]~30_combout\ = \cnt_sec_high[3]~7_combout\ $ (((\se4|Equal15~1_combout\ & (\cnt_sec_high[2]~2_combout\ & \se3|seg[1]~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[3]~7_combout\,
	datab => \se4|Equal15~1_combout\,
	datac => \cnt_sec_high[2]~2_combout\,
	datad => \se3|seg[1]~5_combout\,
	combout => \cnt_sec_high[3]~30_combout\);

-- Location: LCCOMB_X33_Y33_N14
\cnt_sec_high[3]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[3]~9_combout\ = \cnt_sec_high[3]~6_combout\ $ (\cnt_sec_high[3]~30_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_high[3]~6_combout\,
	datad => \cnt_sec_high[3]~30_combout\,
	combout => \cnt_sec_high[3]~9_combout\);

-- Location: FF_X33_Y33_N29
\cnt_sec_high[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_high[3]~9_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_high[3]~_emulated_q\);

-- Location: LCCOMB_X33_Y33_N28
\cnt_sec_high[3]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[3]~8_combout\ = \cnt_sec_high[3]~_emulated_q\ $ (\cnt_sec_high[3]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_high[3]~_emulated_q\,
	datad => \cnt_sec_high[3]~6_combout\,
	combout => \cnt_sec_high[3]~8_combout\);

-- Location: LCCOMB_X33_Y33_N2
\cnt_sec_high[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[3]~7_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high~31_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high[3]~8_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_sec_high~31_combout\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_sec_high[3]~8_combout\,
	combout => \cnt_sec_high[3]~7_combout\);

-- Location: LCCOMB_X33_Y33_N22
\se3|Equal15~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se3|Equal15~0_combout\ = (!\cnt_sec_high[3]~7_combout\ & (\cnt_sec_high[2]~2_combout\ & (!\cnt_sec_high[1]~12_combout\ & \cnt_sec_high[0]~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[3]~7_combout\,
	datab => \cnt_sec_high[2]~2_combout\,
	datac => \cnt_sec_high[1]~12_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \se3|Equal15~0_combout\);

-- Location: LCCOMB_X36_Y33_N24
\process_7~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_7~0_combout\ = (\se4|Equal15~1_combout\ & \se3|Equal15~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se4|Equal15~1_combout\,
	datad => \se3|Equal15~0_combout\,
	combout => \process_7~0_combout\);

-- Location: FF_X40_Y33_N23
\cnt_min_low[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_low[0]~19_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_7~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_low[0]~_emulated_q\);

-- Location: LCCOMB_X40_Y33_N22
\cnt_min_low[0]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[0]~18_combout\ = \cnt_min_low[0]~_emulated_q\ $ (\cnt_min_low[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_low[0]~_emulated_q\,
	datad => \cnt_min_low[0]~16_combout\,
	combout => \cnt_min_low[0]~18_combout\);

-- Location: LCCOMB_X40_Y33_N6
\cnt_min_low[0]~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[0]~17_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_low~29_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low[0]~18_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low~29_combout\,
	datab => \en~input_o\,
	datac => \cnt_min_low[0]~18_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_low[0]~17_combout\);

-- Location: LCCOMB_X33_Y37_N12
\cnt_min_low~31\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low~31_combout\ = (\current_state.M0~q\ & (\in_min_low[1]~10_combout\)) # (!\current_state.M0~q\ & ((\cnt_min_low[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_min_low[1]~10_combout\,
	datac => \cnt_min_low[1]~12_combout\,
	datad => \current_state.M0~q\,
	combout => \cnt_min_low~31_combout\);

-- Location: LCCOMB_X40_Y33_N0
\cnt_min_low[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[1]~11_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low~31_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_low[1]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_min_low[1]~11_combout\,
	datac => \cnt_min_low~31_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_low[1]~11_combout\);

-- Location: LCCOMB_X40_Y33_N28
\cnt_min_low[1]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[1]~14_combout\ = \cnt_min_low[1]~11_combout\ $ (((!\se2|Equal15~0_combout\ & (\cnt_min_low[0]~17_combout\ $ (\cnt_min_low[1]~12_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101100010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se2|Equal15~0_combout\,
	datab => \cnt_min_low[0]~17_combout\,
	datac => \cnt_min_low[1]~12_combout\,
	datad => \cnt_min_low[1]~11_combout\,
	combout => \cnt_min_low[1]~14_combout\);

-- Location: FF_X40_Y33_N27
\cnt_min_low[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_low[1]~14_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_7~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_low[1]~_emulated_q\);

-- Location: LCCOMB_X40_Y33_N26
\cnt_min_low[1]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[1]~13_combout\ = \cnt_min_low[1]~_emulated_q\ $ (\cnt_min_low[1]~11_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_low[1]~_emulated_q\,
	datad => \cnt_min_low[1]~11_combout\,
	combout => \cnt_min_low[1]~13_combout\);

-- Location: LCCOMB_X40_Y33_N16
\cnt_min_low[1]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[1]~12_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_low~31_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low[1]~13_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low~31_combout\,
	datab => \en~input_o\,
	datac => \cnt_min_low[1]~13_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_low[1]~12_combout\);

-- Location: LCCOMB_X33_Y37_N8
\in_min_low[1]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[1]~9_combout\ = (\current_state.M0~q\ & ((\in_min_low[1]~9_combout\))) # (!\current_state.M0~q\ & (\cnt_min_low[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_min_low[1]~12_combout\,
	datac => \in_min_low[1]~9_combout\,
	datad => \current_state.M0~q\,
	combout => \in_min_low[1]~9_combout\);

-- Location: LCCOMB_X33_Y37_N22
\cnt_min_low~30\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low~30_combout\ = (\current_state.M0~q\ & (\in_min_low[3]~6_combout\)) # (!\current_state.M0~q\ & ((\cnt_min_low[3]~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[3]~6_combout\,
	datac => \cnt_min_low[3]~7_combout\,
	datad => \current_state.M0~q\,
	combout => \cnt_min_low~30_combout\);

-- Location: LCCOMB_X40_Y33_N24
\cnt_min_low[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[3]~6_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low~30_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_low[3]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_min_low[3]~6_combout\,
	datac => \cnt_min_low~30_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_low[3]~6_combout\);

-- Location: LCCOMB_X40_Y33_N8
\Add5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add5~0_combout\ = (\cnt_min_low[2]~2_combout\ & (\cnt_min_low[0]~17_combout\ & \cnt_min_low[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[2]~2_combout\,
	datab => \cnt_min_low[0]~17_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \Add5~0_combout\);

-- Location: LCCOMB_X40_Y33_N20
\cnt_min_low[3]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[3]~9_combout\ = \cnt_min_low[3]~6_combout\ $ (((!\se2|Equal15~0_combout\ & (\cnt_min_low[3]~7_combout\ $ (\Add5~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100110100110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[3]~6_combout\,
	datab => \cnt_min_low[3]~7_combout\,
	datac => \se2|Equal15~0_combout\,
	datad => \Add5~0_combout\,
	combout => \cnt_min_low[3]~9_combout\);

-- Location: FF_X40_Y33_N5
\cnt_min_low[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_low[3]~9_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_7~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_low[3]~_emulated_q\);

-- Location: LCCOMB_X40_Y33_N4
\cnt_min_low[3]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[3]~8_combout\ = \cnt_min_low[3]~_emulated_q\ $ (\cnt_min_low[3]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_low[3]~_emulated_q\,
	datad => \cnt_min_low[3]~6_combout\,
	combout => \cnt_min_low[3]~8_combout\);

-- Location: LCCOMB_X40_Y33_N14
\cnt_min_low[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[3]~7_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_low~30_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low[3]~8_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low~30_combout\,
	datab => \en~input_o\,
	datac => \cnt_min_low[3]~8_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_low[3]~7_combout\);

-- Location: LCCOMB_X33_Y37_N20
\in_min_low[3]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[3]~5_combout\ = (\current_state.M0~q\ & (\in_min_low[3]~5_combout\)) # (!\current_state.M0~q\ & ((\cnt_min_low[3]~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_min_low[3]~5_combout\,
	datac => \cnt_min_low[3]~7_combout\,
	datad => \current_state.M0~q\,
	combout => \in_min_low[3]~5_combout\);

-- Location: LCCOMB_X33_Y37_N14
\Add4~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add4~1_combout\ = (\in_min_low[2]~2_combout\ & (\in_min_low[0]~14_combout\ & \in_min_low[1]~10_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[2]~2_combout\,
	datac => \in_min_low[0]~14_combout\,
	datad => \in_min_low[1]~10_combout\,
	combout => \Add4~1_combout\);

-- Location: LCCOMB_X33_Y37_N4
\in_min_low[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[3]~7_combout\ = \in_min_low[3]~5_combout\ $ (((!\Equal4~0_combout\ & (\in_min_low[3]~6_combout\ $ (\Add4~1_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[3]~6_combout\,
	datab => \in_min_low[3]~5_combout\,
	datac => \Add4~1_combout\,
	datad => \Equal4~0_combout\,
	combout => \in_min_low[3]~7_combout\);

-- Location: FF_X33_Y37_N5
\in_min_low[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_low[3]~7_combout\,
	clrn => \current_state.M0~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_low[3]~_emulated_q\);

-- Location: LCCOMB_X33_Y37_N26
\in_min_low[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[3]~6_combout\ = (\current_state.M0~q\ & ((\in_min_low[3]~_emulated_q\ $ (\in_min_low[3]~5_combout\)))) # (!\current_state.M0~q\ & (\cnt_min_low[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[3]~7_combout\,
	datab => \in_min_low[3]~_emulated_q\,
	datac => \current_state.M0~q\,
	datad => \in_min_low[3]~5_combout\,
	combout => \in_min_low[3]~6_combout\);

-- Location: LCCOMB_X33_Y37_N16
\Equal4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Equal4~0_combout\ = (\in_min_low[0]~14_combout\ & (!\in_min_low[1]~10_combout\ & (!\in_min_low[2]~2_combout\ & \in_min_low[3]~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[0]~14_combout\,
	datab => \in_min_low[1]~10_combout\,
	datac => \in_min_low[2]~2_combout\,
	datad => \in_min_low[3]~6_combout\,
	combout => \Equal4~0_combout\);

-- Location: LCCOMB_X33_Y37_N24
\in_min_low[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[1]~11_combout\ = \in_min_low[1]~9_combout\ $ (((!\Equal4~0_combout\ & (\in_min_low[1]~10_combout\ $ (\in_min_low[0]~14_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[1]~9_combout\,
	datab => \in_min_low[1]~10_combout\,
	datac => \in_min_low[0]~14_combout\,
	datad => \Equal4~0_combout\,
	combout => \in_min_low[1]~11_combout\);

-- Location: FF_X33_Y37_N25
\in_min_low[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_low[1]~11_combout\,
	clrn => \current_state.M0~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_low[1]~_emulated_q\);

-- Location: LCCOMB_X33_Y37_N18
\in_min_low[1]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[1]~10_combout\ = (\current_state.M0~q\ & ((\in_min_low[1]~9_combout\ $ (\in_min_low[1]~_emulated_q\)))) # (!\current_state.M0~q\ & (\cnt_min_low[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010111011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[1]~12_combout\,
	datab => \current_state.M0~q\,
	datac => \in_min_low[1]~9_combout\,
	datad => \in_min_low[1]~_emulated_q\,
	combout => \in_min_low[1]~10_combout\);

-- Location: LCCOMB_X33_Y37_N10
\Add4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add4~0_combout\ = (\in_min_low[0]~14_combout\ & \in_min_low[1]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \in_min_low[0]~14_combout\,
	datad => \in_min_low[1]~10_combout\,
	combout => \Add4~0_combout\);

-- Location: LCCOMB_X33_Y37_N28
\in_min_low[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[2]~1_combout\ = (\current_state.M0~q\ & ((\in_min_low[2]~1_combout\))) # (!\current_state.M0~q\ & (\cnt_min_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[2]~2_combout\,
	datab => \in_min_low[2]~1_combout\,
	datad => \current_state.M0~q\,
	combout => \in_min_low[2]~1_combout\);

-- Location: LCCOMB_X33_Y37_N2
\in_min_low[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[2]~3_combout\ = \in_min_low[2]~2_combout\ $ (\in_min_low[2]~1_combout\ $ (((\bt3|trig~combout\ & \Add4~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001010101101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[2]~2_combout\,
	datab => \bt3|trig~combout\,
	datac => \Add4~0_combout\,
	datad => \in_min_low[2]~1_combout\,
	combout => \in_min_low[2]~3_combout\);

-- Location: FF_X33_Y37_N3
\in_min_low[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_low[2]~3_combout\,
	clrn => \current_state.M0~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_low[2]~_emulated_q\);

-- Location: LCCOMB_X33_Y37_N30
\in_min_low[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[2]~2_combout\ = (\current_state.M0~q\ & ((\in_min_low[2]~_emulated_q\ $ (\in_min_low[2]~1_combout\)))) # (!\current_state.M0~q\ & (\cnt_min_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[2]~2_combout\,
	datab => \in_min_low[2]~_emulated_q\,
	datac => \current_state.M0~q\,
	datad => \in_min_low[2]~1_combout\,
	combout => \in_min_low[2]~2_combout\);

-- Location: LCCOMB_X33_Y37_N6
\cnt_min_low~28\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low~28_combout\ = (\current_state.M0~q\ & ((\in_min_low[2]~2_combout\))) # (!\current_state.M0~q\ & (\cnt_min_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[2]~2_combout\,
	datac => \in_min_low[2]~2_combout\,
	datad => \current_state.M0~q\,
	combout => \cnt_min_low~28_combout\);

-- Location: LCCOMB_X34_Y33_N28
\cnt_min_low[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[2]~1_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low~28_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_low[2]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_min_low[2]~1_combout\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_min_low~28_combout\,
	combout => \cnt_min_low[2]~1_combout\);

-- Location: LCCOMB_X34_Y33_N18
\se2|seg[1]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \se2|seg[1]~5_combout\ = (\cnt_min_low[0]~17_combout\ & \cnt_min_low[1]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~17_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \se2|seg[1]~5_combout\);

-- Location: LCCOMB_X34_Y33_N22
\cnt_min_low[2]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[2]~4_combout\ = \cnt_min_low[2]~2_combout\ $ (\cnt_min_low[2]~1_combout\ $ (((\process_7~0_combout\ & \se2|seg[1]~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011001100110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[2]~2_combout\,
	datab => \cnt_min_low[2]~1_combout\,
	datac => \process_7~0_combout\,
	datad => \se2|seg[1]~5_combout\,
	combout => \cnt_min_low[2]~4_combout\);

-- Location: FF_X34_Y33_N21
\cnt_min_low[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_low[2]~4_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_low[2]~_emulated_q\);

-- Location: LCCOMB_X34_Y33_N20
\cnt_min_low[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[2]~3_combout\ = \cnt_min_low[2]~_emulated_q\ $ (\cnt_min_low[2]~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_low[2]~_emulated_q\,
	datad => \cnt_min_low[2]~1_combout\,
	combout => \cnt_min_low[2]~3_combout\);

-- Location: LCCOMB_X34_Y33_N4
\cnt_min_low[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[2]~2_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_low~28_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low[2]~3_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_min_low~28_combout\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_min_low[2]~3_combout\,
	combout => \cnt_min_low[2]~2_combout\);

-- Location: LCCOMB_X40_Y32_N28
\se2|Equal15~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se2|Equal15~0_combout\ = (\cnt_min_low[0]~17_combout\ & (!\cnt_min_low[2]~2_combout\ & (\cnt_min_low[3]~7_combout\ & !\cnt_min_low[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~17_combout\,
	datab => \cnt_min_low[2]~2_combout\,
	datac => \cnt_min_low[3]~7_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \se2|Equal15~0_combout\);

-- Location: LCCOMB_X35_Y33_N4
\process_9~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_9~0_combout\ = (\se4|Equal15~1_combout\ & (\se2|Equal15~0_combout\ & \se3|Equal15~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se4|Equal15~1_combout\,
	datac => \se2|Equal15~0_combout\,
	datad => \se3|Equal15~0_combout\,
	combout => \process_9~0_combout\);

-- Location: FF_X35_Y33_N13
\cnt_min_high[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_high[0]~19_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_9~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_high[0]~_emulated_q\);

-- Location: LCCOMB_X35_Y33_N12
\cnt_min_high[0]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[0]~18_combout\ = \cnt_min_high[0]~_emulated_q\ $ (\cnt_min_high[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_high[0]~_emulated_q\,
	datad => \cnt_min_high[0]~16_combout\,
	combout => \cnt_min_high[0]~18_combout\);

-- Location: LCCOMB_X35_Y33_N22
\cnt_min_high[0]~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[0]~17_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_high~32_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high[0]~18_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high~32_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_min_high[0]~18_combout\,
	combout => \cnt_min_high[0]~17_combout\);

-- Location: LCCOMB_X35_Y30_N26
\se1|seg[1]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \se1|seg[1]~5_combout\ = (\cnt_min_high[0]~17_combout\ & \cnt_min_high[1]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[1]~12_combout\,
	combout => \se1|seg[1]~5_combout\);

-- Location: LCCOMB_X35_Y30_N24
\cnt_min_high[3]~29\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[3]~29_combout\ = \cnt_min_high[3]~7_combout\ $ (((\se1|seg[1]~5_combout\ & (\cnt_min_high[2]~2_combout\ & \process_9~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se1|seg[1]~5_combout\,
	datab => \cnt_min_high[2]~2_combout\,
	datac => \process_9~0_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \cnt_min_high[3]~29_combout\);

-- Location: LCCOMB_X35_Y30_N22
\cnt_min_high[3]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[3]~9_combout\ = \cnt_min_high[3]~6_combout\ $ (\cnt_min_high[3]~29_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_min_high[3]~6_combout\,
	datad => \cnt_min_high[3]~29_combout\,
	combout => \cnt_min_high[3]~9_combout\);

-- Location: FF_X35_Y30_N9
\cnt_min_high[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_high[3]~9_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_high[3]~_emulated_q\);

-- Location: LCCOMB_X35_Y30_N8
\cnt_min_high[3]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[3]~8_combout\ = \cnt_min_high[3]~_emulated_q\ $ (\cnt_min_high[3]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_high[3]~_emulated_q\,
	datad => \cnt_min_high[3]~6_combout\,
	combout => \cnt_min_high[3]~8_combout\);

-- Location: LCCOMB_X35_Y30_N0
\cnt_min_high[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[3]~7_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_high~30_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high[3]~8_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_min_high~30_combout\,
	datac => \cnt_min_high[3]~8_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_high[3]~7_combout\);

-- Location: LCCOMB_X35_Y30_N12
\se1|Equal15~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se1|Equal15~1_combout\ = (!\cnt_min_high[3]~7_combout\ & (\cnt_min_high[2]~2_combout\ & (\cnt_min_high[0]~17_combout\ & !\cnt_min_high[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[3]~7_combout\,
	datab => \cnt_min_high[2]~2_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[1]~12_combout\,
	combout => \se1|Equal15~1_combout\);

-- Location: LCCOMB_X35_Y30_N28
\cnt_min_high[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[2]~1_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high~33_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_high[2]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~1_combout\,
	datab => \en~input_o\,
	datac => \cnt_min_high~33_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_high[2]~1_combout\);

-- Location: LCCOMB_X35_Y30_N30
\cnt_min_high[2]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[2]~4_combout\ = \cnt_min_high[2]~1_combout\ $ (((!\se1|Equal15~1_combout\ & (\cnt_min_high[2]~2_combout\ $ (\se1|seg[1]~5_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101100010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se1|Equal15~1_combout\,
	datab => \cnt_min_high[2]~2_combout\,
	datac => \se1|seg[1]~5_combout\,
	datad => \cnt_min_high[2]~1_combout\,
	combout => \cnt_min_high[2]~4_combout\);

-- Location: FF_X35_Y30_N15
\cnt_min_high[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_high[2]~4_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_9~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_high[2]~_emulated_q\);

-- Location: LCCOMB_X35_Y30_N14
\cnt_min_high[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[2]~3_combout\ = \cnt_min_high[2]~_emulated_q\ $ (\cnt_min_high[2]~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_high[2]~_emulated_q\,
	datad => \cnt_min_high[2]~1_combout\,
	combout => \cnt_min_high[2]~3_combout\);

-- Location: LCCOMB_X35_Y30_N10
\cnt_min_high[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[2]~2_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_high~33_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high[2]~3_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_min_high~33_combout\,
	datac => \cnt_min_high[2]~3_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_high[2]~2_combout\);

-- Location: LCCOMB_X29_Y33_N30
\in_min_high[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[2]~1_combout\ = (\current_state.M1~q\ & (\in_min_high[2]~1_combout\)) # (!\current_state.M1~q\ & ((\cnt_min_high[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[2]~1_combout\,
	datab => \cnt_min_high[2]~2_combout\,
	datad => \current_state.M1~q\,
	combout => \in_min_high[2]~1_combout\);

-- Location: LCCOMB_X29_Y33_N14
\Add6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add6~0_combout\ = (\in_min_high[0]~14_combout\ & \in_min_high[1]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \in_min_high[0]~14_combout\,
	datad => \in_min_high[1]~10_combout\,
	combout => \Add6~0_combout\);

-- Location: LCCOMB_X29_Y33_N12
\in_min_high[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[2]~3_combout\ = \in_min_high[2]~1_combout\ $ (((!\Equal6~0_combout\ & (\Add6~0_combout\ $ (\in_min_high[2]~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100110100110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[2]~1_combout\,
	datab => \Add6~0_combout\,
	datac => \Equal6~0_combout\,
	datad => \in_min_high[2]~2_combout\,
	combout => \in_min_high[2]~3_combout\);

-- Location: FF_X29_Y33_N13
\in_min_high[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_high[2]~3_combout\,
	clrn => \current_state.M1~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_high[2]~_emulated_q\);

-- Location: LCCOMB_X29_Y33_N18
\in_min_high[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[2]~2_combout\ = (\current_state.M1~q\ & (\in_min_high[2]~1_combout\ $ (((\in_min_high[2]~_emulated_q\))))) # (!\current_state.M1~q\ & (((\cnt_min_high[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[2]~1_combout\,
	datab => \cnt_min_high[2]~2_combout\,
	datac => \current_state.M1~q\,
	datad => \in_min_high[2]~_emulated_q\,
	combout => \in_min_high[2]~2_combout\);

-- Location: LCCOMB_X29_Y33_N22
\in_min_high[3]~22\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[3]~22_combout\ = (\in_min_high[2]~2_combout\ & (\bt3|btn_sync~q\ & !\bt3|btn_delay~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_min_high[2]~2_combout\,
	datac => \bt3|btn_sync~q\,
	datad => \bt3|btn_delay~q\,
	combout => \in_min_high[3]~22_combout\);

-- Location: LCCOMB_X29_Y33_N2
\in_min_high[3]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[3]~5_combout\ = (\current_state.M1~q\ & ((\in_min_high[3]~5_combout\))) # (!\current_state.M1~q\ & (\cnt_min_high[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_min_high[3]~7_combout\,
	datac => \current_state.M1~q\,
	datad => \in_min_high[3]~5_combout\,
	combout => \in_min_high[3]~5_combout\);

-- Location: LCCOMB_X29_Y33_N26
\in_min_high[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[3]~7_combout\ = \in_min_high[3]~5_combout\ $ (\in_min_high[3]~6_combout\ $ (((\in_min_high[3]~22_combout\ & \Add6~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000011101111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[3]~22_combout\,
	datab => \Add6~0_combout\,
	datac => \in_min_high[3]~5_combout\,
	datad => \in_min_high[3]~6_combout\,
	combout => \in_min_high[3]~7_combout\);

-- Location: FF_X29_Y33_N27
\in_min_high[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_high[3]~7_combout\,
	clrn => \current_state.M1~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_high[3]~_emulated_q\);

-- Location: LCCOMB_X29_Y33_N0
\in_min_high[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[3]~6_combout\ = (\current_state.M1~q\ & (\in_min_high[3]~_emulated_q\ $ (((\in_min_high[3]~5_combout\))))) # (!\current_state.M1~q\ & (((\cnt_min_high[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[3]~_emulated_q\,
	datab => \cnt_min_high[3]~7_combout\,
	datac => \current_state.M1~q\,
	datad => \in_min_high[3]~5_combout\,
	combout => \in_min_high[3]~6_combout\);

-- Location: LCCOMB_X29_Y33_N4
\Equal6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Equal6~0_combout\ = (!\in_min_high[1]~10_combout\ & (!\in_min_high[3]~6_combout\ & (\in_min_high[0]~14_combout\ & \in_min_high[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[1]~10_combout\,
	datab => \in_min_high[3]~6_combout\,
	datac => \in_min_high[0]~14_combout\,
	datad => \in_min_high[2]~2_combout\,
	combout => \Equal6~0_combout\);

-- Location: LCCOMB_X29_Y33_N16
\in_min_high[1]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[1]~9_combout\ = (\current_state.M1~q\ & (\in_min_high[1]~9_combout\)) # (!\current_state.M1~q\ & ((\cnt_min_high[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_min_high[1]~9_combout\,
	datac => \cnt_min_high[1]~12_combout\,
	datad => \current_state.M1~q\,
	combout => \in_min_high[1]~9_combout\);

-- Location: LCCOMB_X29_Y33_N8
\in_min_high[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[1]~11_combout\ = \in_min_high[1]~9_combout\ $ (((!\Equal6~0_combout\ & (\in_min_high[1]~10_combout\ $ (\in_min_high[0]~14_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110100010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[1]~10_combout\,
	datab => \Equal6~0_combout\,
	datac => \in_min_high[0]~14_combout\,
	datad => \in_min_high[1]~9_combout\,
	combout => \in_min_high[1]~11_combout\);

-- Location: FF_X29_Y33_N9
\in_min_high[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_high[1]~11_combout\,
	clrn => \current_state.M1~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_high[1]~_emulated_q\);

-- Location: LCCOMB_X29_Y33_N28
\in_min_high[1]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[1]~10_combout\ = (\current_state.M1~q\ & ((\in_min_high[1]~_emulated_q\ $ (\in_min_high[1]~9_combout\)))) # (!\current_state.M1~q\ & (\cnt_min_high[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.M1~q\,
	datab => \cnt_min_high[1]~12_combout\,
	datac => \in_min_high[1]~_emulated_q\,
	datad => \in_min_high[1]~9_combout\,
	combout => \in_min_high[1]~10_combout\);

-- Location: LCCOMB_X29_Y33_N24
\cnt_min_high~31\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high~31_combout\ = (\current_state.M1~q\ & ((\in_min_high[1]~10_combout\))) # (!\current_state.M1~q\ & (\cnt_min_high[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_min_high[1]~12_combout\,
	datac => \in_min_high[1]~10_combout\,
	datad => \current_state.M1~q\,
	combout => \cnt_min_high~31_combout\);

-- Location: LCCOMB_X35_Y33_N18
\se1|Equal15~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se1|Equal15~0_combout\ = (\cnt_min_high[2]~2_combout\ & !\cnt_min_high[3]~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~2_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \se1|Equal15~0_combout\);

-- Location: LCCOMB_X35_Y33_N16
\cnt_min_high[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[1]~11_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high~31_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_high[1]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_min_high[1]~11_combout\,
	datac => \cnt_min_high~31_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_high[1]~11_combout\);

-- Location: LCCOMB_X35_Y33_N30
\cnt_min_high[1]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[1]~14_combout\ = \cnt_min_high[1]~11_combout\ $ (((\cnt_min_high[0]~17_combout\ & (!\se1|Equal15~0_combout\ & !\cnt_min_high[1]~12_combout\)) # (!\cnt_min_high[0]~17_combout\ & ((\cnt_min_high[1]~12_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110101010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[0]~17_combout\,
	datab => \se1|Equal15~0_combout\,
	datac => \cnt_min_high[1]~12_combout\,
	datad => \cnt_min_high[1]~11_combout\,
	combout => \cnt_min_high[1]~14_combout\);

-- Location: FF_X35_Y33_N25
\cnt_min_high[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_high[1]~14_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_9~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_high[1]~_emulated_q\);

-- Location: LCCOMB_X35_Y33_N24
\cnt_min_high[1]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[1]~13_combout\ = \cnt_min_high[1]~_emulated_q\ $ (\cnt_min_high[1]~11_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_high[1]~_emulated_q\,
	datad => \cnt_min_high[1]~11_combout\,
	combout => \cnt_min_high[1]~13_combout\);

-- Location: LCCOMB_X35_Y33_N6
\cnt_min_high[1]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[1]~12_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_high~31_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high[1]~13_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high~31_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_min_high[1]~13_combout\,
	combout => \cnt_min_high[1]~12_combout\);

-- Location: LCCOMB_X34_Y31_N26
\in_tim_min_high[0]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_high[0]~4_combout\ = !in_tim_min_high(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => in_tim_min_high(0),
	combout => \in_tim_min_high[0]~4_combout\);

-- Location: LCCOMB_X33_Y34_N8
\in_tim_min_high[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_high[0]~0_combout\ = (\current_state.MT1~q\ & (!\bt3|btn_delay~q\ & \bt3|btn_sync~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \current_state.MT1~q\,
	datac => \bt3|btn_delay~q\,
	datad => \bt3|btn_sync~q\,
	combout => \in_tim_min_high[0]~0_combout\);

-- Location: FF_X34_Y31_N27
\in_tim_min_high[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_min_high[0]~4_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_min_high[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_high(0));

-- Location: LCCOMB_X34_Y31_N6
\se7|seg[1]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se7|seg[1]~3_combout\ = (!in_tim_min_high(0) & in_tim_min_high(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => in_tim_min_high(0),
	datad => in_tim_min_high(1),
	combout => \se7|seg[1]~3_combout\);

-- Location: LCCOMB_X34_Y31_N10
\in_tim_min_high[3]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_high[3]~1_combout\ = in_tim_min_high(3) $ (((\se7|seg[1]~3_combout\ & (\in_tim_min_high[0]~0_combout\ & in_tim_min_high(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se7|seg[1]~3_combout\,
	datab => \in_tim_min_high[0]~0_combout\,
	datac => in_tim_min_high(3),
	datad => in_tim_min_high(2),
	combout => \in_tim_min_high[3]~1_combout\);

-- Location: FF_X34_Y31_N11
\in_tim_min_high[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_min_high[3]~1_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_high(3));

-- Location: LCCOMB_X34_Y31_N8
\in_tim_min_high~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_high~3_combout\ = (in_tim_min_high(1) & ((in_tim_min_high(2) $ (!in_tim_min_high(0))))) # (!in_tim_min_high(1) & (in_tim_min_high(2) & ((in_tim_min_high(3)) # (in_tim_min_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(1),
	datab => in_tim_min_high(3),
	datac => in_tim_min_high(2),
	datad => in_tim_min_high(0),
	combout => \in_tim_min_high~3_combout\);

-- Location: FF_X34_Y31_N9
\in_tim_min_high[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_min_high~3_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_min_high[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_high(2));

-- Location: LCCOMB_X34_Y31_N16
\in_tim_min_high~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_high~2_combout\ = (in_tim_min_high(1) & (((in_tim_min_high(0))))) # (!in_tim_min_high(1) & (!in_tim_min_high(0) & ((in_tim_min_high(3)) # (!in_tim_min_high(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(2),
	datab => in_tim_min_high(3),
	datac => in_tim_min_high(1),
	datad => in_tim_min_high(0),
	combout => \in_tim_min_high~2_combout\);

-- Location: FF_X34_Y31_N17
\in_tim_min_high[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_min_high~2_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_min_high[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_high(1));

-- Location: LCCOMB_X34_Y31_N22
\process_20~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~5_combout\ = (\cnt_min_high[1]~12_combout\ & (in_tim_min_high(1) & (\cnt_min_high[0]~17_combout\ $ (in_tim_min_high(0))))) # (!\cnt_min_high[1]~12_combout\ & (!in_tim_min_high(1) & (\cnt_min_high[0]~17_combout\ $ (in_tim_min_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010100000010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[1]~12_combout\,
	datab => \cnt_min_high[0]~17_combout\,
	datac => in_tim_min_high(0),
	datad => in_tim_min_high(1),
	combout => \process_20~5_combout\);

-- Location: LCCOMB_X32_Y36_N24
\in_tim_sec_high[0]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_high[0]~4_combout\ = !in_tim_sec_high(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => in_tim_sec_high(0),
	combout => \in_tim_sec_high[0]~4_combout\);

-- Location: LCCOMB_X36_Y35_N0
\in_tim_sec_high[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_high[0]~0_combout\ = (\bt3|btn_sync~q\ & (!\bt3|btn_delay~q\ & \current_state.ST1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt3|btn_sync~q\,
	datab => \bt3|btn_delay~q\,
	datad => \current_state.ST1~q\,
	combout => \in_tim_sec_high[0]~0_combout\);

-- Location: FF_X32_Y36_N25
\in_tim_sec_high[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_high[0]~4_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_sec_high[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_high(0));

-- Location: LCCOMB_X32_Y36_N12
\se9|seg[1]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se9|seg[1]~3_combout\ = (!in_tim_sec_high(0) & in_tim_sec_high(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => in_tim_sec_high(0),
	datac => in_tim_sec_high(1),
	combout => \se9|seg[1]~3_combout\);

-- Location: LCCOMB_X32_Y36_N6
\in_tim_sec_high[3]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_high[3]~1_combout\ = in_tim_sec_high(3) $ (((\se9|seg[1]~3_combout\ & (\in_tim_sec_high[0]~0_combout\ & in_tim_sec_high(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se9|seg[1]~3_combout\,
	datab => \in_tim_sec_high[0]~0_combout\,
	datac => in_tim_sec_high(3),
	datad => in_tim_sec_high(2),
	combout => \in_tim_sec_high[3]~1_combout\);

-- Location: FF_X32_Y36_N7
\in_tim_sec_high[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_high[3]~1_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_high(3));

-- Location: LCCOMB_X32_Y36_N22
\in_tim_sec_high~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_high~3_combout\ = (in_tim_sec_high(1) & (in_tim_sec_high(0) $ ((!in_tim_sec_high(2))))) # (!in_tim_sec_high(1) & (in_tim_sec_high(2) & ((in_tim_sec_high(0)) # (in_tim_sec_high(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101001011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(1),
	datab => in_tim_sec_high(0),
	datac => in_tim_sec_high(2),
	datad => in_tim_sec_high(3),
	combout => \in_tim_sec_high~3_combout\);

-- Location: FF_X32_Y36_N23
\in_tim_sec_high[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_high~3_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_sec_high[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_high(2));

-- Location: LCCOMB_X32_Y36_N26
\in_tim_sec_high~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_high~2_combout\ = (in_tim_sec_high(0) & (((in_tim_sec_high(1))))) # (!in_tim_sec_high(0) & (!in_tim_sec_high(1) & ((in_tim_sec_high(3)) # (!in_tim_sec_high(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001111000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => in_tim_sec_high(0),
	datac => in_tim_sec_high(1),
	datad => in_tim_sec_high(3),
	combout => \in_tim_sec_high~2_combout\);

-- Location: FF_X32_Y36_N27
\in_tim_sec_high[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_high~2_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_sec_high[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_high(1));

-- Location: LCCOMB_X32_Y36_N30
\process_20~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~7_combout\ = (\cnt_sec_high[0]~17_combout\ & (!in_tim_sec_high(0) & (in_tim_sec_high(1) $ (!\cnt_sec_high[1]~12_combout\)))) # (!\cnt_sec_high[0]~17_combout\ & (in_tim_sec_high(0) & (in_tim_sec_high(1) $ (!\cnt_sec_high[1]~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000000000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[0]~17_combout\,
	datab => in_tim_sec_high(0),
	datac => in_tim_sec_high(1),
	datad => \cnt_sec_high[1]~12_combout\,
	combout => \process_20~7_combout\);

-- Location: LCCOMB_X32_Y36_N16
\process_20~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~8_combout\ = (in_tim_sec_high(3) & (\cnt_sec_high[3]~7_combout\ & (in_tim_sec_high(2) $ (!\cnt_sec_high[2]~2_combout\)))) # (!in_tim_sec_high(3) & (!\cnt_sec_high[3]~7_combout\ & (in_tim_sec_high(2) $ (!\cnt_sec_high[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001001000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(3),
	datab => in_tim_sec_high(2),
	datac => \cnt_sec_high[2]~2_combout\,
	datad => \cnt_sec_high[3]~7_combout\,
	combout => \process_20~8_combout\);

-- Location: LCCOMB_X34_Y31_N28
\process_20~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~6_combout\ = (in_tim_min_high(3) & (\cnt_min_high[3]~7_combout\ & (in_tim_min_high(2) $ (!\cnt_min_high[2]~2_combout\)))) # (!in_tim_min_high(3) & (!\cnt_min_high[3]~7_combout\ & (in_tim_min_high(2) $ (!\cnt_min_high[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001000000001001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(3),
	datab => \cnt_min_high[3]~7_combout\,
	datac => in_tim_min_high(2),
	datad => \cnt_min_high[2]~2_combout\,
	combout => \process_20~6_combout\);

-- Location: LCCOMB_X34_Y31_N4
\process_20~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~9_combout\ = (\process_20~5_combout\ & (\process_20~7_combout\ & (\process_20~8_combout\ & \process_20~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_20~5_combout\,
	datab => \process_20~7_combout\,
	datac => \process_20~8_combout\,
	datad => \process_20~6_combout\,
	combout => \process_20~9_combout\);

-- Location: LCCOMB_X39_Y32_N16
\in_tim_sec_low[0]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_low[0]~4_combout\ = !in_tim_sec_low(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => in_tim_sec_low(0),
	combout => \in_tim_sec_low[0]~4_combout\);

-- Location: LCCOMB_X39_Y32_N22
\in_tim_sec_low[0]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_low[0]~1_combout\ = (!\bt3|btn_delay~q\ & (\bt3|btn_sync~q\ & \current_state.ST0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \bt3|btn_delay~q\,
	datac => \bt3|btn_sync~q\,
	datad => \current_state.ST0~q\,
	combout => \in_tim_sec_low[0]~1_combout\);

-- Location: FF_X39_Y32_N17
\in_tim_sec_low[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_low[0]~4_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_sec_low[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_low(0));

-- Location: LCCOMB_X39_Y32_N0
\in_tim_sec_low~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_low~2_combout\ = (in_tim_sec_low(0) & (((in_tim_sec_low(1))))) # (!in_tim_sec_low(0) & (!in_tim_sec_low(1) & ((in_tim_sec_low(2)) # (!in_tim_sec_low(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001111000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(3),
	datab => in_tim_sec_low(0),
	datac => in_tim_sec_low(1),
	datad => in_tim_sec_low(2),
	combout => \in_tim_sec_low~2_combout\);

-- Location: FF_X39_Y32_N1
\in_tim_sec_low[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_low~2_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_sec_low[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_low(1));

-- Location: LCCOMB_X39_Y32_N6
\in_tim_sec_low[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_low[2]~3_combout\ = in_tim_sec_low(2) $ (((in_tim_sec_low(1) & (\in_tim_sec_low[0]~1_combout\ & !in_tim_sec_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(1),
	datab => \in_tim_sec_low[0]~1_combout\,
	datac => in_tim_sec_low(2),
	datad => in_tim_sec_low(0),
	combout => \in_tim_sec_low[2]~3_combout\);

-- Location: FF_X39_Y32_N7
\in_tim_sec_low[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_low[2]~3_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_low(2));

-- Location: LCCOMB_X39_Y32_N8
\in_tim_sec_low~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_low~0_combout\ = (in_tim_sec_low(2) & (in_tim_sec_low(3) $ (((!in_tim_sec_low(0) & in_tim_sec_low(1)))))) # (!in_tim_sec_low(2) & (in_tim_sec_low(3) & ((in_tim_sec_low(0)) # (in_tim_sec_low(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101001011100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(2),
	datab => in_tim_sec_low(0),
	datac => in_tim_sec_low(3),
	datad => in_tim_sec_low(1),
	combout => \in_tim_sec_low~0_combout\);

-- Location: FF_X39_Y32_N9
\in_tim_sec_low[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_low~0_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_sec_low[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_low(3));

-- Location: LCCOMB_X39_Y32_N12
\process_20~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~13_combout\ = (\cnt_sec_low[3]~7_combout\ & (in_tim_sec_low(3) & (\cnt_sec_low[2]~2_combout\ $ (!in_tim_sec_low(2))))) # (!\cnt_sec_low[3]~7_combout\ & (!in_tim_sec_low(3) & (\cnt_sec_low[2]~2_combout\ $ (!in_tim_sec_low(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001000000001001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[3]~7_combout\,
	datab => in_tim_sec_low(3),
	datac => \cnt_sec_low[2]~2_combout\,
	datad => in_tim_sec_low(2),
	combout => \process_20~13_combout\);

-- Location: LCCOMB_X41_Y33_N4
\in_tim_min_low[0]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_low[0]~4_combout\ = !in_tim_min_low(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => in_tim_min_low(0),
	combout => \in_tim_min_low[0]~4_combout\);

-- Location: LCCOMB_X41_Y33_N14
\in_tim_min_low[0]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_low[0]~1_combout\ = (\bt3|btn_sync~q\ & (\current_state.MT0~q\ & !\bt3|btn_delay~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt3|btn_sync~q\,
	datac => \current_state.MT0~q\,
	datad => \bt3|btn_delay~q\,
	combout => \in_tim_min_low[0]~1_combout\);

-- Location: FF_X41_Y33_N5
\in_tim_min_low[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_min_low[0]~4_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_min_low[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_low(0));

-- Location: LCCOMB_X41_Y33_N26
\in_tim_min_low~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_low~0_combout\ = (in_tim_min_low(2) & (in_tim_min_low(3) $ (((in_tim_min_low(1) & !in_tim_min_low(0)))))) # (!in_tim_min_low(2) & (in_tim_min_low(3) & ((in_tim_min_low(1)) # (in_tim_min_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(2),
	datab => in_tim_min_low(1),
	datac => in_tim_min_low(3),
	datad => in_tim_min_low(0),
	combout => \in_tim_min_low~0_combout\);

-- Location: FF_X41_Y33_N27
\in_tim_min_low[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_min_low~0_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_min_low[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_low(3));

-- Location: LCCOMB_X41_Y33_N0
\in_tim_min_low~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_low~2_combout\ = (in_tim_min_low(1) & (((in_tim_min_low(0))))) # (!in_tim_min_low(1) & (!in_tim_min_low(0) & ((in_tim_min_low(2)) # (!in_tim_min_low(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(2),
	datab => in_tim_min_low(3),
	datac => in_tim_min_low(1),
	datad => in_tim_min_low(0),
	combout => \in_tim_min_low~2_combout\);

-- Location: FF_X41_Y33_N1
\in_tim_min_low[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_min_low~2_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_min_low[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_low(1));

-- Location: LCCOMB_X41_Y33_N6
\in_tim_min_low[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_low[2]~3_combout\ = in_tim_min_low(2) $ (((in_tim_min_low(1) & (\in_tim_min_low[0]~1_combout\ & !in_tim_min_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(1),
	datab => \in_tim_min_low[0]~1_combout\,
	datac => in_tim_min_low(2),
	datad => in_tim_min_low(0),
	combout => \in_tim_min_low[2]~3_combout\);

-- Location: FF_X41_Y33_N7
\in_tim_min_low[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_min_low[2]~3_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_low(2));

-- Location: LCCOMB_X40_Y33_N30
\process_20~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~11_combout\ = (in_tim_min_low(2) & (\cnt_min_low[2]~2_combout\ & (\cnt_min_low[3]~7_combout\ $ (!in_tim_min_low(3))))) # (!in_tim_min_low(2) & (!\cnt_min_low[2]~2_combout\ & (\cnt_min_low[3]~7_combout\ $ (!in_tim_min_low(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000010000100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(2),
	datab => \cnt_min_low[3]~7_combout\,
	datac => \cnt_min_low[2]~2_combout\,
	datad => in_tim_min_low(3),
	combout => \process_20~11_combout\);

-- Location: LCCOMB_X41_Y33_N30
\process_20~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~10_combout\ = (\cnt_min_low[1]~12_combout\ & (in_tim_min_low(1) & (in_tim_min_low(0) $ (\cnt_min_low[0]~17_combout\)))) # (!\cnt_min_low[1]~12_combout\ & (!in_tim_min_low(1) & (in_tim_min_low(0) $ (\cnt_min_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010100000010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[1]~12_combout\,
	datab => in_tim_min_low(0),
	datac => \cnt_min_low[0]~17_combout\,
	datad => in_tim_min_low(1),
	combout => \process_20~10_combout\);

-- Location: LCCOMB_X39_Y32_N2
\process_20~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~12_combout\ = (\cnt_sec_low[1]~12_combout\ & (in_tim_sec_low(1) & (in_tim_sec_low(0) $ (\cnt_sec_low[0]~17_combout\)))) # (!\cnt_sec_low[1]~12_combout\ & (!in_tim_sec_low(1) & (in_tim_sec_low(0) $ (\cnt_sec_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010100000010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[1]~12_combout\,
	datab => in_tim_sec_low(0),
	datac => \cnt_sec_low[0]~17_combout\,
	datad => in_tim_sec_low(1),
	combout => \process_20~12_combout\);

-- Location: LCCOMB_X39_Y32_N14
\process_20~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~14_combout\ = (\process_20~13_combout\ & (\process_20~11_combout\ & (\process_20~10_combout\ & \process_20~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_20~13_combout\,
	datab => \process_20~11_combout\,
	datac => \process_20~10_combout\,
	datad => \process_20~12_combout\,
	combout => \process_20~14_combout\);

-- Location: LCCOMB_X35_Y34_N26
\in_tim_hour_high~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_hour_high~4_combout\ = ((!in_tim_hour_high(2) & (!in_tim_hour_high(3) & in_tim_hour_high(1)))) # (!in_tim_hour_high(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_high(2),
	datab => in_tim_hour_high(3),
	datac => in_tim_hour_high(0),
	datad => in_tim_hour_high(1),
	combout => \in_tim_hour_high~4_combout\);

-- Location: LCCOMB_X34_Y34_N6
\in_tim_hour_high[0]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_hour_high[0]~3_combout\ = (\bt3|btn_sync~q\ & (\current_state.HT1~q\ & !\bt3|btn_delay~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \bt3|btn_sync~q\,
	datac => \current_state.HT1~q\,
	datad => \bt3|btn_delay~q\,
	combout => \in_tim_hour_high[0]~3_combout\);

-- Location: FF_X35_Y34_N27
\in_tim_hour_high[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_hour_high~4_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_hour_high[0]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_hour_high(0));

-- Location: LCCOMB_X35_Y34_N12
\in_tim_hour_high~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_hour_high~2_combout\ = (in_tim_hour_high(1) & (in_tim_hour_high(0) & ((in_tim_hour_high(2)) # (in_tim_hour_high(3))))) # (!in_tim_hour_high(1) & (((!in_tim_hour_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_high(2),
	datab => in_tim_hour_high(3),
	datac => in_tim_hour_high(1),
	datad => in_tim_hour_high(0),
	combout => \in_tim_hour_high~2_combout\);

-- Location: FF_X35_Y34_N13
\in_tim_hour_high[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_hour_high~2_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_hour_high[0]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_hour_high(1));

-- Location: LCCOMB_X34_Y34_N8
\in_tim_hour_high[2]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_hour_high[2]~5_combout\ = in_tim_hour_high(2) $ (((in_tim_hour_high(1) & (!in_tim_hour_high(0) & \in_tim_hour_high[0]~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101001011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_high(1),
	datab => in_tim_hour_high(0),
	datac => in_tim_hour_high(2),
	datad => \in_tim_hour_high[0]~3_combout\,
	combout => \in_tim_hour_high[2]~5_combout\);

-- Location: FF_X34_Y34_N9
\in_tim_hour_high[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_hour_high[2]~5_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_hour_high(2));

-- Location: LCCOMB_X34_Y34_N0
\in_tim_hour_high[2]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_hour_high[2]~0_combout\ = (\bt3|trig~combout\ & (!in_tim_hour_high(0) & (\current_state.HT1~q\ & in_tim_hour_high(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt3|trig~combout\,
	datab => in_tim_hour_high(0),
	datac => \current_state.HT1~q\,
	datad => in_tim_hour_high(1),
	combout => \in_tim_hour_high[2]~0_combout\);

-- Location: LCCOMB_X34_Y34_N30
\in_tim_hour_high[3]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_hour_high[3]~1_combout\ = in_tim_hour_high(3) $ (((in_tim_hour_high(2) & \in_tim_hour_high[2]~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => in_tim_hour_high(2),
	datac => in_tim_hour_high(3),
	datad => \in_tim_hour_high[2]~0_combout\,
	combout => \in_tim_hour_high[3]~1_combout\);

-- Location: FF_X34_Y34_N31
\in_tim_hour_high[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_hour_high[3]~1_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_hour_high(3));

-- Location: LCCOMB_X29_Y34_N26
\in_hour_high[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_high[2]~1_combout\ = (\current_state.H1~q\ & ((\in_hour_high[2]~1_combout\))) # (!\current_state.H1~q\ & (\cnt_hour_high[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[2]~2_combout\,
	datac => \in_hour_high[2]~1_combout\,
	datad => \current_state.H1~q\,
	combout => \in_hour_high[2]~1_combout\);

-- Location: LCCOMB_X29_Y33_N10
\in_hour_high[3]~23\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_high[3]~23_combout\ = (\bt3|btn_sync~q\ & (\in_hour_high[2]~2_combout\ & !\bt3|btn_delay~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt3|btn_sync~q\,
	datac => \in_hour_high[2]~2_combout\,
	datad => \bt3|btn_delay~q\,
	combout => \in_hour_high[3]~23_combout\);

-- Location: LCCOMB_X34_Y33_N30
\cnt_hour_high~31\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high~31_combout\ = (\current_state.H1~q\ & ((\in_hour_high[3]~6_combout\))) # (!\current_state.H1~q\ & (\cnt_hour_high[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_hour_high[3]~7_combout\,
	datac => \in_hour_high[3]~6_combout\,
	datad => \current_state.H1~q\,
	combout => \cnt_hour_high~31_combout\);

-- Location: LCCOMB_X34_Y33_N12
\cnt_hour_high[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[3]~6_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_hour_high~31_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_high[3]~6_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high~31_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_hour_high[3]~6_combout\,
	combout => \cnt_hour_high[3]~6_combout\);

-- Location: LCCOMB_X29_Y34_N18
\cnt_hour_high~28\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high~28_combout\ = (\current_state.H1~q\ & ((\in_hour_high[1]~10_combout\))) # (!\current_state.H1~q\ & (\cnt_hour_high[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[1]~12_combout\,
	datac => \in_hour_high[1]~10_combout\,
	datad => \current_state.H1~q\,
	combout => \cnt_hour_high~28_combout\);

-- Location: LCCOMB_X36_Y33_N12
\cnt_hour_high[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[1]~11_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_hour_high~28_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_high[1]~11_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high~28_combout\,
	datab => \en~input_o\,
	datac => \cnt_hour_high[1]~11_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_hour_high[1]~11_combout\);

-- Location: LCCOMB_X29_Y34_N4
\in_hour_high[0]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_high[0]~13_combout\ = (\current_state.H1~q\ & ((\in_hour_high[0]~13_combout\))) # (!\current_state.H1~q\ & (\cnt_hour_high[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[0]~17_combout\,
	datac => \in_hour_high[0]~13_combout\,
	datad => \current_state.H1~q\,
	combout => \in_hour_high[0]~13_combout\);

-- Location: LCCOMB_X29_Y34_N10
\in_hour_high~22\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_high~22_combout\ = (\in_hour_high[0]~14_combout\) # ((!\in_hour_high[3]~6_combout\ & (!\in_hour_high[2]~2_combout\ & \in_hour_high[1]~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_hour_high[3]~6_combout\,
	datab => \in_hour_high[2]~2_combout\,
	datac => \in_hour_high[1]~10_combout\,
	datad => \in_hour_high[0]~14_combout\,
	combout => \in_hour_high~22_combout\);

-- Location: LCCOMB_X29_Y34_N16
\in_hour_high[0]~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_high[0]~15_combout\ = \in_hour_high[0]~13_combout\ $ (!\in_hour_high~22_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_hour_high[0]~13_combout\,
	datad => \in_hour_high~22_combout\,
	combout => \in_hour_high[0]~15_combout\);

-- Location: FF_X29_Y34_N17
\in_hour_high[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_hour_high[0]~15_combout\,
	clrn => \current_state.H1~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_hour_high[0]~_emulated_q\);

-- Location: LCCOMB_X29_Y34_N0
\in_hour_high[0]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_high[0]~14_combout\ = (\current_state.H1~q\ & ((\in_hour_high[0]~_emulated_q\ $ (\in_hour_high[0]~13_combout\)))) # (!\current_state.H1~q\ & (\cnt_hour_high[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[0]~17_combout\,
	datab => \in_hour_high[0]~_emulated_q\,
	datac => \in_hour_high[0]~13_combout\,
	datad => \current_state.H1~q\,
	combout => \in_hour_high[0]~14_combout\);

-- Location: LCCOMB_X33_Y34_N0
\cnt_hour_high~32\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high~32_combout\ = (\current_state.H1~q\ & ((\in_hour_high[0]~14_combout\))) # (!\current_state.H1~q\ & (\cnt_hour_high[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[0]~17_combout\,
	datac => \in_hour_high[0]~14_combout\,
	datad => \current_state.H1~q\,
	combout => \cnt_hour_high~32_combout\);

-- Location: LCCOMB_X36_Y33_N10
\cnt_hour_high[0]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[0]~16_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_high~32_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_hour_high[0]~16_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[0]~16_combout\,
	datab => \en~input_o\,
	datac => \cnt_hour_high~32_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_hour_high[0]~16_combout\);

-- Location: LCCOMB_X36_Y33_N18
\se5|Equal15~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se5|Equal15~0_combout\ = (!\cnt_hour_high[2]~2_combout\ & \cnt_hour_high[1]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_hour_high[2]~2_combout\,
	datac => \cnt_hour_high[1]~12_combout\,
	combout => \se5|Equal15~0_combout\);

-- Location: LCCOMB_X36_Y33_N26
\cnt_hour_high[0]~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[0]~19_combout\ = \cnt_hour_high[0]~16_combout\ $ (((!\cnt_hour_high[0]~17_combout\ & ((\cnt_hour_high[3]~7_combout\) # (!\se5|Equal15~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001101010011001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[0]~16_combout\,
	datab => \cnt_hour_high[0]~17_combout\,
	datac => \cnt_hour_high[3]~7_combout\,
	datad => \se5|Equal15~0_combout\,
	combout => \cnt_hour_high[0]~19_combout\);

-- Location: LCCOMB_X29_Y35_N14
\in_hour_low[1]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_low[1]~9_combout\ = (\current_state.H0~q\ & ((\in_hour_low[1]~9_combout\))) # (!\current_state.H0~q\ & (\cnt_hour_low[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[1]~12_combout\,
	datab => \in_hour_low[1]~9_combout\,
	datad => \current_state.H0~q\,
	combout => \in_hour_low[1]~9_combout\);

-- Location: LCCOMB_X33_Y35_N24
\cnt_hour_low~28\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low~28_combout\ = (\current_state.H0~q\ & ((\in_hour_low[2]~2_combout\))) # (!\current_state.H0~q\ & (\cnt_hour_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_hour_low[2]~2_combout\,
	datac => \in_hour_low[2]~2_combout\,
	datad => \current_state.H0~q\,
	combout => \cnt_hour_low~28_combout\);

-- Location: LCCOMB_X29_Y35_N28
\in_hour_low[0]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_low[0]~13_combout\ = (\current_state.H0~q\ & ((\in_hour_low[0]~13_combout\))) # (!\current_state.H0~q\ & (\cnt_hour_low[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_hour_low[0]~17_combout\,
	datac => \current_state.H0~q\,
	datad => \in_hour_low[0]~13_combout\,
	combout => \in_hour_low[0]~13_combout\);

-- Location: LCCOMB_X29_Y35_N22
\in_hour_low[0]~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_low[0]~15_combout\ = \in_hour_low[0]~13_combout\ $ (!\in_hour_low[0]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_hour_low[0]~13_combout\,
	datad => \in_hour_low[0]~14_combout\,
	combout => \in_hour_low[0]~15_combout\);

-- Location: FF_X29_Y35_N23
\in_hour_low[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_hour_low[0]~15_combout\,
	clrn => \current_state.H0~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_hour_low[0]~_emulated_q\);

-- Location: LCCOMB_X29_Y35_N24
\in_hour_low[0]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_low[0]~14_combout\ = (\current_state.H0~q\ & (\in_hour_low[0]~_emulated_q\ $ (((\in_hour_low[0]~13_combout\))))) # (!\current_state.H0~q\ & (((\cnt_hour_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_hour_low[0]~_emulated_q\,
	datab => \cnt_hour_low[0]~17_combout\,
	datac => \current_state.H0~q\,
	datad => \in_hour_low[0]~13_combout\,
	combout => \in_hour_low[0]~14_combout\);

-- Location: LCCOMB_X32_Y35_N4
\cnt_hour_low~29\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low~29_combout\ = (\current_state.H0~q\ & ((\in_hour_low[0]~14_combout\))) # (!\current_state.H0~q\ & (\cnt_hour_low[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[0]~17_combout\,
	datac => \in_hour_low[0]~14_combout\,
	datad => \current_state.H0~q\,
	combout => \cnt_hour_low~29_combout\);

-- Location: LCCOMB_X34_Y32_N2
\cnt_hour_low[0]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[0]~16_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_low~29_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_hour_low[0]~16_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_hour_low[0]~16_combout\,
	datac => \cnt_hour_low~29_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_hour_low[0]~16_combout\);

-- Location: LCCOMB_X33_Y32_N26
\cnt_hour_low[0]~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[0]~19_combout\ = \cnt_hour_low[0]~17_combout\ $ (!\cnt_hour_low[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001111000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_hour_low[0]~17_combout\,
	datac => \cnt_hour_low[0]~16_combout\,
	combout => \cnt_hour_low[0]~19_combout\);

-- Location: LCCOMB_X35_Y31_N10
\process_11~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_11~4_combout\ = (\se1|Equal15~1_combout\ & \se2|Equal15~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \se1|Equal15~1_combout\,
	datac => \se2|Equal15~0_combout\,
	combout => \process_11~4_combout\);

-- Location: FF_X34_Y32_N9
\cnt_hour_low[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_hour_low[0]~19_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_11~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_hour_low[0]~_emulated_q\);

-- Location: LCCOMB_X34_Y32_N8
\cnt_hour_low[0]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[0]~18_combout\ = \cnt_hour_low[0]~_emulated_q\ $ (\cnt_hour_low[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_hour_low[0]~_emulated_q\,
	datad => \cnt_hour_low[0]~16_combout\,
	combout => \cnt_hour_low[0]~18_combout\);

-- Location: LCCOMB_X34_Y32_N14
\cnt_hour_low[0]~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[0]~17_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_hour_low~29_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_low[0]~18_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_hour_low~29_combout\,
	datac => \cnt_hour_low[0]~18_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_hour_low[0]~17_combout\);

-- Location: LCCOMB_X33_Y32_N8
\Add9~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add9~0_combout\ = \cnt_hour_low[2]~2_combout\ $ (((\cnt_hour_low[0]~17_combout\ & \cnt_hour_low[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_hour_low[0]~17_combout\,
	datac => \cnt_hour_low[1]~12_combout\,
	datad => \cnt_hour_low[2]~2_combout\,
	combout => \Add9~0_combout\);

-- Location: LCCOMB_X29_Y35_N6
\in_hour_low[3]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_low[3]~5_combout\ = (\current_state.H0~q\ & ((\in_hour_low[3]~5_combout\))) # (!\current_state.H0~q\ & (\cnt_hour_low[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[3]~7_combout\,
	datac => \current_state.H0~q\,
	datad => \in_hour_low[3]~5_combout\,
	combout => \in_hour_low[3]~5_combout\);

-- Location: LCCOMB_X29_Y35_N16
\in_hour_low[3]~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_low[3]~20_combout\ = (\in_hour_low[0]~14_combout\ & (\in_hour_low[2]~2_combout\ $ (!\in_hour_low[1]~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_hour_low[2]~2_combout\,
	datac => \in_hour_low[1]~10_combout\,
	datad => \in_hour_low[0]~14_combout\,
	combout => \in_hour_low[3]~20_combout\);

-- Location: LCCOMB_X29_Y35_N0
\in_hour_low[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_low[3]~7_combout\ = \in_hour_low[3]~5_combout\ $ (((\in_hour_low[3]~6_combout\ & ((!\in_hour_low[3]~20_combout\))) # (!\in_hour_low[3]~6_combout\ & (\in_hour_low[1]~10_combout\ & \in_hour_low[3]~20_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010011001011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_hour_low[3]~5_combout\,
	datab => \in_hour_low[1]~10_combout\,
	datac => \in_hour_low[3]~6_combout\,
	datad => \in_hour_low[3]~20_combout\,
	combout => \in_hour_low[3]~7_combout\);

-- Location: FF_X29_Y35_N1
\in_hour_low[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_hour_low[3]~7_combout\,
	clrn => \current_state.H0~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_hour_low[3]~_emulated_q\);

-- Location: LCCOMB_X29_Y35_N30
\in_hour_low[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_low[3]~6_combout\ = (\current_state.H0~q\ & ((\in_hour_low[3]~_emulated_q\ $ (\in_hour_low[3]~5_combout\)))) # (!\current_state.H0~q\ & (\cnt_hour_low[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[3]~7_combout\,
	datab => \in_hour_low[3]~_emulated_q\,
	datac => \current_state.H0~q\,
	datad => \in_hour_low[3]~5_combout\,
	combout => \in_hour_low[3]~6_combout\);

-- Location: LCCOMB_X32_Y35_N6
\cnt_hour_low~30\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low~30_combout\ = (\current_state.H0~q\ & (\in_hour_low[3]~6_combout\)) # (!\current_state.H0~q\ & ((\cnt_hour_low[3]~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_hour_low[3]~6_combout\,
	datac => \cnt_hour_low[3]~7_combout\,
	datad => \current_state.H0~q\,
	combout => \cnt_hour_low~30_combout\);

-- Location: LCCOMB_X34_Y34_N28
\process_11~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_11~1_combout\ = (\process_11~0_combout\ & (!\cnt_hour_high[1]~12_combout\ & (!\cnt_hour_high[3]~7_combout\ & !\cnt_hour_high[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_11~0_combout\,
	datab => \cnt_hour_high[1]~12_combout\,
	datac => \cnt_hour_high[3]~7_combout\,
	datad => \cnt_hour_high[2]~2_combout\,
	combout => \process_11~1_combout\);

-- Location: LCCOMB_X35_Y31_N28
\Add9~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add9~1_combout\ = \cnt_hour_low[3]~7_combout\ $ (((\cnt_hour_low[1]~12_combout\ & (\cnt_hour_low[0]~17_combout\ & \cnt_hour_low[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[1]~12_combout\,
	datab => \cnt_hour_low[0]~17_combout\,
	datac => \cnt_hour_low[3]~7_combout\,
	datad => \cnt_hour_low[2]~2_combout\,
	combout => \Add9~1_combout\);

-- Location: LCCOMB_X34_Y32_N24
\cnt_hour_low[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[3]~6_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_low~30_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_hour_low[3]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_hour_low[3]~6_combout\,
	datac => \cnt_hour_low~30_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_hour_low[3]~6_combout\);

-- Location: LCCOMB_X34_Y32_N12
\cnt_hour_low[3]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[3]~9_combout\ = \cnt_hour_low[3]~6_combout\ $ (((!\process_11~1_combout\ & (!\process_11~3_combout\ & \Add9~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_11~1_combout\,
	datab => \process_11~3_combout\,
	datac => \Add9~1_combout\,
	datad => \cnt_hour_low[3]~6_combout\,
	combout => \cnt_hour_low[3]~9_combout\);

-- Location: FF_X34_Y32_N5
\cnt_hour_low[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_hour_low[3]~9_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_11~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_hour_low[3]~_emulated_q\);

-- Location: LCCOMB_X34_Y32_N4
\cnt_hour_low[3]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[3]~8_combout\ = \cnt_hour_low[3]~_emulated_q\ $ (\cnt_hour_low[3]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_hour_low[3]~_emulated_q\,
	datad => \cnt_hour_low[3]~6_combout\,
	combout => \cnt_hour_low[3]~8_combout\);

-- Location: LCCOMB_X34_Y32_N18
\cnt_hour_low[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[3]~7_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_hour_low~30_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_low[3]~8_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low~30_combout\,
	datab => \en~input_o\,
	datac => \cnt_hour_low[3]~8_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_hour_low[3]~7_combout\);

-- Location: LCCOMB_X35_Y31_N24
\process_11~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_11~2_combout\ = (\cnt_hour_low[1]~12_combout\ & (\cnt_hour_low[0]~17_combout\ & (!\cnt_hour_low[3]~7_combout\ & !\cnt_hour_low[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[1]~12_combout\,
	datab => \cnt_hour_low[0]~17_combout\,
	datac => \cnt_hour_low[3]~7_combout\,
	datad => \cnt_hour_low[2]~2_combout\,
	combout => \process_11~2_combout\);

-- Location: LCCOMB_X36_Y33_N20
\process_11~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_11~3_combout\ = (\process_11~2_combout\ & (!\cnt_hour_high[0]~17_combout\ & (!\cnt_hour_high[3]~7_combout\ & \se5|Equal15~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_11~2_combout\,
	datab => \cnt_hour_high[0]~17_combout\,
	datac => \cnt_hour_high[3]~7_combout\,
	datad => \se5|Equal15~0_combout\,
	combout => \process_11~3_combout\);

-- Location: LCCOMB_X34_Y32_N28
\cnt_hour_low[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[2]~1_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_low~28_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_hour_low[2]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_hour_low[2]~1_combout\,
	datac => \cnt_hour_low~28_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_hour_low[2]~1_combout\);

-- Location: LCCOMB_X34_Y32_N10
\cnt_hour_low[2]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[2]~4_combout\ = \cnt_hour_low[2]~1_combout\ $ (((\Add9~0_combout\ & (!\process_11~3_combout\ & !\process_11~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Add9~0_combout\,
	datab => \process_11~3_combout\,
	datac => \process_11~1_combout\,
	datad => \cnt_hour_low[2]~1_combout\,
	combout => \cnt_hour_low[2]~4_combout\);

-- Location: FF_X34_Y32_N23
\cnt_hour_low[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_hour_low[2]~4_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_11~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_hour_low[2]~_emulated_q\);

-- Location: LCCOMB_X34_Y32_N22
\cnt_hour_low[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[2]~3_combout\ = \cnt_hour_low[2]~_emulated_q\ $ (\cnt_hour_low[2]~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_hour_low[2]~_emulated_q\,
	datad => \cnt_hour_low[2]~1_combout\,
	combout => \cnt_hour_low[2]~3_combout\);

-- Location: LCCOMB_X34_Y32_N16
\cnt_hour_low[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[2]~2_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_hour_low~28_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_low[2]~3_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low~28_combout\,
	datab => \en~input_o\,
	datac => \cnt_hour_low[2]~3_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_hour_low[2]~2_combout\);

-- Location: LCCOMB_X29_Y35_N4
\in_hour_low[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_low[2]~1_combout\ = (\current_state.H0~q\ & ((\in_hour_low[2]~1_combout\))) # (!\current_state.H0~q\ & (\cnt_hour_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_hour_low[2]~2_combout\,
	datac => \in_hour_low[2]~1_combout\,
	datad => \current_state.H0~q\,
	combout => \in_hour_low[2]~1_combout\);

-- Location: LCCOMB_X29_Y35_N26
\Add8~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add8~0_combout\ = (\in_hour_low[1]~10_combout\ & \in_hour_low[0]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \in_hour_low[1]~10_combout\,
	datad => \in_hour_low[0]~14_combout\,
	combout => \Add8~0_combout\);

-- Location: LCCOMB_X29_Y35_N12
\in_hour_low[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_low[2]~3_combout\ = \in_hour_low[2]~1_combout\ $ (\in_hour_low[2]~2_combout\ $ (((\Add8~0_combout\ & \bt3|trig~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000011101111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Add8~0_combout\,
	datab => \bt3|trig~combout\,
	datac => \in_hour_low[2]~1_combout\,
	datad => \in_hour_low[2]~2_combout\,
	combout => \in_hour_low[2]~3_combout\);

-- Location: FF_X29_Y35_N13
\in_hour_low[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_hour_low[2]~3_combout\,
	clrn => \current_state.H0~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_hour_low[2]~_emulated_q\);

-- Location: LCCOMB_X29_Y35_N20
\in_hour_low[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_low[2]~2_combout\ = (\current_state.H0~q\ & ((\in_hour_low[2]~1_combout\ $ (\in_hour_low[2]~_emulated_q\)))) # (!\current_state.H0~q\ & (\cnt_hour_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[2]~2_combout\,
	datab => \in_hour_low[2]~1_combout\,
	datac => \current_state.H0~q\,
	datad => \in_hour_low[2]~_emulated_q\,
	combout => \in_hour_low[2]~2_combout\);

-- Location: LCCOMB_X29_Y35_N18
\Equal8~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Equal8~0_combout\ = (!\in_hour_low[2]~2_combout\ & (!\in_hour_low[1]~10_combout\ & (\in_hour_low[3]~6_combout\ & \in_hour_low[0]~14_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_hour_low[2]~2_combout\,
	datab => \in_hour_low[1]~10_combout\,
	datac => \in_hour_low[3]~6_combout\,
	datad => \in_hour_low[0]~14_combout\,
	combout => \Equal8~0_combout\);

-- Location: LCCOMB_X29_Y35_N2
\in_hour_low[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_low[1]~11_combout\ = \in_hour_low[1]~9_combout\ $ (((!\Equal8~0_combout\ & (\in_hour_low[1]~10_combout\ $ (\in_hour_low[0]~14_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100110011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_hour_low[1]~9_combout\,
	datab => \Equal8~0_combout\,
	datac => \in_hour_low[1]~10_combout\,
	datad => \in_hour_low[0]~14_combout\,
	combout => \in_hour_low[1]~11_combout\);

-- Location: FF_X29_Y35_N3
\in_hour_low[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_hour_low[1]~11_combout\,
	clrn => \current_state.H0~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_hour_low[1]~_emulated_q\);

-- Location: LCCOMB_X29_Y35_N8
\in_hour_low[1]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_low[1]~10_combout\ = (\current_state.H0~q\ & ((\in_hour_low[1]~9_combout\ $ (\in_hour_low[1]~_emulated_q\)))) # (!\current_state.H0~q\ & (\cnt_hour_low[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[1]~12_combout\,
	datab => \in_hour_low[1]~9_combout\,
	datac => \current_state.H0~q\,
	datad => \in_hour_low[1]~_emulated_q\,
	combout => \in_hour_low[1]~10_combout\);

-- Location: LCCOMB_X29_Y35_N10
\cnt_hour_low~31\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low~31_combout\ = (\current_state.H0~q\ & ((\in_hour_low[1]~10_combout\))) # (!\current_state.H0~q\ & (\cnt_hour_low[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[1]~12_combout\,
	datac => \in_hour_low[1]~10_combout\,
	datad => \current_state.H0~q\,
	combout => \cnt_hour_low~31_combout\);

-- Location: LCCOMB_X34_Y32_N30
\Add9~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add9~2_combout\ = \cnt_hour_low[1]~12_combout\ $ (\cnt_hour_low[0]~17_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[1]~12_combout\,
	datad => \cnt_hour_low[0]~17_combout\,
	combout => \Add9~2_combout\);

-- Location: LCCOMB_X34_Y32_N20
\cnt_hour_low[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[1]~11_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_hour_low~31_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_low[1]~11_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low~31_combout\,
	datab => \en~input_o\,
	datac => \cnt_hour_low[1]~11_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_hour_low[1]~11_combout\);

-- Location: LCCOMB_X34_Y32_N0
\cnt_hour_low[1]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[1]~14_combout\ = \cnt_hour_low[1]~11_combout\ $ (((\Add9~2_combout\ & (!\process_11~3_combout\ & !\process_11~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Add9~2_combout\,
	datab => \process_11~3_combout\,
	datac => \process_11~1_combout\,
	datad => \cnt_hour_low[1]~11_combout\,
	combout => \cnt_hour_low[1]~14_combout\);

-- Location: FF_X34_Y32_N27
\cnt_hour_low[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_hour_low[1]~14_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_11~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_hour_low[1]~_emulated_q\);

-- Location: LCCOMB_X34_Y32_N26
\cnt_hour_low[1]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[1]~13_combout\ = \cnt_hour_low[1]~_emulated_q\ $ (\cnt_hour_low[1]~11_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_hour_low[1]~_emulated_q\,
	datad => \cnt_hour_low[1]~11_combout\,
	combout => \cnt_hour_low[1]~13_combout\);

-- Location: LCCOMB_X34_Y32_N6
\cnt_hour_low[1]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_low[1]~12_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_hour_low~31_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_low[1]~13_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low~31_combout\,
	datab => \en~input_o\,
	datac => \cnt_hour_low[1]~13_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_hour_low[1]~12_combout\);

-- Location: LCCOMB_X35_Y31_N4
\process_11~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_11~0_combout\ = (!\cnt_hour_low[1]~12_combout\ & (\cnt_hour_low[0]~17_combout\ & (\cnt_hour_low[3]~7_combout\ & !\cnt_hour_low[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[1]~12_combout\,
	datab => \cnt_hour_low[0]~17_combout\,
	datac => \cnt_hour_low[3]~7_combout\,
	datad => \cnt_hour_low[2]~2_combout\,
	combout => \process_11~0_combout\);

-- Location: LCCOMB_X35_Y31_N6
\process_13~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_13~0_combout\ = (\se2|Equal15~0_combout\ & (\se1|Equal15~1_combout\ & \process_11~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se2|Equal15~0_combout\,
	datab => \se1|Equal15~1_combout\,
	datac => \process_11~0_combout\,
	combout => \process_13~0_combout\);

-- Location: FF_X36_Y33_N5
\cnt_hour_high[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_hour_high[0]~19_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_13~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_hour_high[0]~_emulated_q\);

-- Location: LCCOMB_X36_Y33_N4
\cnt_hour_high[0]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[0]~18_combout\ = \cnt_hour_high[0]~_emulated_q\ $ (\cnt_hour_high[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_hour_high[0]~_emulated_q\,
	datad => \cnt_hour_high[0]~16_combout\,
	combout => \cnt_hour_high[0]~18_combout\);

-- Location: LCCOMB_X36_Y33_N0
\cnt_hour_high[0]~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[0]~17_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_hour_high~32_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_high[0]~18_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high~32_combout\,
	datab => \en~input_o\,
	datac => \cnt_hour_high[0]~18_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_hour_high[0]~17_combout\);

-- Location: LCCOMB_X36_Y33_N28
\se5|Equal15~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se5|Equal15~1_combout\ = (\cnt_hour_high[1]~12_combout\ & (!\cnt_hour_high[0]~17_combout\ & (!\cnt_hour_high[3]~7_combout\ & !\cnt_hour_high[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[1]~12_combout\,
	datab => \cnt_hour_high[0]~17_combout\,
	datac => \cnt_hour_high[3]~7_combout\,
	datad => \cnt_hour_high[2]~2_combout\,
	combout => \se5|Equal15~1_combout\);

-- Location: LCCOMB_X36_Y33_N14
\cnt_hour_high[1]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[1]~14_combout\ = \cnt_hour_high[1]~11_combout\ $ (((!\se5|Equal15~1_combout\ & (\cnt_hour_high[0]~17_combout\ $ (\cnt_hour_high[1]~12_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[1]~11_combout\,
	datab => \cnt_hour_high[0]~17_combout\,
	datac => \cnt_hour_high[1]~12_combout\,
	datad => \se5|Equal15~1_combout\,
	combout => \cnt_hour_high[1]~14_combout\);

-- Location: FF_X36_Y33_N23
\cnt_hour_high[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_hour_high[1]~14_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_13~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_hour_high[1]~_emulated_q\);

-- Location: LCCOMB_X36_Y33_N22
\cnt_hour_high[1]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[1]~13_combout\ = \cnt_hour_high[1]~_emulated_q\ $ (\cnt_hour_high[1]~11_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_hour_high[1]~_emulated_q\,
	datad => \cnt_hour_high[1]~11_combout\,
	combout => \cnt_hour_high[1]~13_combout\);

-- Location: LCCOMB_X35_Y33_N0
\cnt_hour_high[1]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[1]~12_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_hour_high~28_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_high[1]~13_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high~28_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_hour_high[1]~13_combout\,
	combout => \cnt_hour_high[1]~12_combout\);

-- Location: LCCOMB_X36_Y33_N30
\se5|seg[1]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \se5|seg[1]~5_combout\ = (\cnt_hour_high[1]~12_combout\ & \cnt_hour_high[0]~17_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_hour_high[1]~12_combout\,
	datad => \cnt_hour_high[0]~17_combout\,
	combout => \se5|seg[1]~5_combout\);

-- Location: LCCOMB_X34_Y33_N10
\cnt_hour_high[3]~30\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[3]~30_combout\ = \cnt_hour_high[3]~7_combout\ $ (((\se5|seg[1]~5_combout\ & (\cnt_hour_high[2]~2_combout\ & \process_13~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se5|seg[1]~5_combout\,
	datab => \cnt_hour_high[3]~7_combout\,
	datac => \cnt_hour_high[2]~2_combout\,
	datad => \process_13~0_combout\,
	combout => \cnt_hour_high[3]~30_combout\);

-- Location: LCCOMB_X34_Y33_N8
\cnt_hour_high[3]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[3]~9_combout\ = \cnt_hour_high[3]~6_combout\ $ (\cnt_hour_high[3]~30_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[3]~6_combout\,
	datad => \cnt_hour_high[3]~30_combout\,
	combout => \cnt_hour_high[3]~9_combout\);

-- Location: FF_X34_Y33_N3
\cnt_hour_high[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_hour_high[3]~9_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_hour_high[3]~_emulated_q\);

-- Location: LCCOMB_X34_Y33_N2
\cnt_hour_high[3]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[3]~8_combout\ = \cnt_hour_high[3]~_emulated_q\ $ (\cnt_hour_high[3]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_hour_high[3]~_emulated_q\,
	datad => \cnt_hour_high[3]~6_combout\,
	combout => \cnt_hour_high[3]~8_combout\);

-- Location: LCCOMB_X34_Y33_N16
\cnt_hour_high[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[3]~7_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_hour_high~31_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_high[3]~8_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high~31_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_hour_high[3]~8_combout\,
	combout => \cnt_hour_high[3]~7_combout\);

-- Location: LCCOMB_X29_Y34_N6
\in_hour_high[3]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_high[3]~5_combout\ = (\current_state.H1~q\ & (\in_hour_high[3]~5_combout\)) # (!\current_state.H1~q\ & ((\cnt_hour_high[3]~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_hour_high[3]~5_combout\,
	datab => \cnt_hour_high[3]~7_combout\,
	datad => \current_state.H1~q\,
	combout => \in_hour_high[3]~5_combout\);

-- Location: LCCOMB_X29_Y34_N30
\in_hour_high[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_high[3]~7_combout\ = \in_hour_high[3]~6_combout\ $ (\in_hour_high[3]~5_combout\ $ (((\in_hour_high[3]~23_combout\ & \Add10~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001010101101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_hour_high[3]~6_combout\,
	datab => \in_hour_high[3]~23_combout\,
	datac => \Add10~0_combout\,
	datad => \in_hour_high[3]~5_combout\,
	combout => \in_hour_high[3]~7_combout\);

-- Location: FF_X29_Y34_N31
\in_hour_high[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_hour_high[3]~7_combout\,
	clrn => \current_state.H1~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_hour_high[3]~_emulated_q\);

-- Location: LCCOMB_X29_Y34_N2
\in_hour_high[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_high[3]~6_combout\ = (\current_state.H1~q\ & (\in_hour_high[3]~_emulated_q\ $ (((\in_hour_high[3]~5_combout\))))) # (!\current_state.H1~q\ & (((\cnt_hour_high[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_hour_high[3]~_emulated_q\,
	datab => \cnt_hour_high[3]~7_combout\,
	datac => \current_state.H1~q\,
	datad => \in_hour_high[3]~5_combout\,
	combout => \in_hour_high[3]~6_combout\);

-- Location: LCCOMB_X29_Y34_N28
\Equal14~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Equal14~0_combout\ = (!\in_hour_high[3]~6_combout\ & (!\in_hour_high[2]~2_combout\ & (\in_hour_high[1]~10_combout\ & !\in_hour_high[0]~14_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_hour_high[3]~6_combout\,
	datab => \in_hour_high[2]~2_combout\,
	datac => \in_hour_high[1]~10_combout\,
	datad => \in_hour_high[0]~14_combout\,
	combout => \Equal14~0_combout\);

-- Location: LCCOMB_X29_Y34_N20
\in_hour_high[1]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_high[1]~9_combout\ = (\current_state.H1~q\ & (\in_hour_high[1]~9_combout\)) # (!\current_state.H1~q\ & ((\cnt_hour_high[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_hour_high[1]~9_combout\,
	datac => \cnt_hour_high[1]~12_combout\,
	datad => \current_state.H1~q\,
	combout => \in_hour_high[1]~9_combout\);

-- Location: LCCOMB_X29_Y34_N22
\in_hour_high[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_high[1]~11_combout\ = \in_hour_high[1]~9_combout\ $ (((!\Equal14~0_combout\ & (\in_hour_high[1]~10_combout\ $ (\in_hour_high[0]~14_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100100110011100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Equal14~0_combout\,
	datab => \in_hour_high[1]~9_combout\,
	datac => \in_hour_high[1]~10_combout\,
	datad => \in_hour_high[0]~14_combout\,
	combout => \in_hour_high[1]~11_combout\);

-- Location: FF_X29_Y34_N23
\in_hour_high[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_hour_high[1]~11_combout\,
	clrn => \current_state.H1~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_hour_high[1]~_emulated_q\);

-- Location: LCCOMB_X29_Y34_N12
\in_hour_high[1]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_high[1]~10_combout\ = (\current_state.H1~q\ & (\in_hour_high[1]~_emulated_q\ $ (((\in_hour_high[1]~9_combout\))))) # (!\current_state.H1~q\ & (((\cnt_hour_high[1]~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_hour_high[1]~_emulated_q\,
	datab => \cnt_hour_high[1]~12_combout\,
	datac => \current_state.H1~q\,
	datad => \in_hour_high[1]~9_combout\,
	combout => \in_hour_high[1]~10_combout\);

-- Location: LCCOMB_X29_Y34_N14
\Add10~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add10~0_combout\ = (\in_hour_high[1]~10_combout\ & \in_hour_high[0]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \in_hour_high[1]~10_combout\,
	datad => \in_hour_high[0]~14_combout\,
	combout => \Add10~0_combout\);

-- Location: LCCOMB_X29_Y34_N8
\in_hour_high[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_high[2]~3_combout\ = \in_hour_high[2]~1_combout\ $ (\in_hour_high[2]~2_combout\ $ (((\bt3|trig~combout\ & \Add10~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011001100110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_hour_high[2]~1_combout\,
	datab => \in_hour_high[2]~2_combout\,
	datac => \bt3|trig~combout\,
	datad => \Add10~0_combout\,
	combout => \in_hour_high[2]~3_combout\);

-- Location: FF_X29_Y34_N9
\in_hour_high[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_hour_high[2]~3_combout\,
	clrn => \current_state.H1~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_hour_high[2]~_emulated_q\);

-- Location: LCCOMB_X29_Y34_N24
\in_hour_high[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_hour_high[2]~2_combout\ = (\current_state.H1~q\ & (\in_hour_high[2]~1_combout\ $ (((\in_hour_high[2]~_emulated_q\))))) # (!\current_state.H1~q\ & (((\cnt_hour_high[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_hour_high[2]~1_combout\,
	datab => \cnt_hour_high[2]~2_combout\,
	datac => \in_hour_high[2]~_emulated_q\,
	datad => \current_state.H1~q\,
	combout => \in_hour_high[2]~2_combout\);

-- Location: LCCOMB_X34_Y33_N14
\cnt_hour_high~29\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high~29_combout\ = (\current_state.H1~q\ & (\in_hour_high[2]~2_combout\)) # (!\current_state.H1~q\ & ((\cnt_hour_high[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_hour_high[2]~2_combout\,
	datab => \cnt_hour_high[2]~2_combout\,
	datad => \current_state.H1~q\,
	combout => \cnt_hour_high~29_combout\);

-- Location: LCCOMB_X34_Y33_N24
\cnt_hour_high[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[2]~1_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_high~29_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_hour_high[2]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_hour_high[2]~1_combout\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_hour_high~29_combout\,
	combout => \cnt_hour_high[2]~1_combout\);

-- Location: LCCOMB_X34_Y33_N26
\cnt_hour_high[2]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[2]~4_combout\ = \cnt_hour_high[2]~1_combout\ $ (\cnt_hour_high[2]~2_combout\ $ (((\se5|seg[1]~5_combout\ & \process_13~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se5|seg[1]~5_combout\,
	datab => \cnt_hour_high[2]~1_combout\,
	datac => \cnt_hour_high[2]~2_combout\,
	datad => \process_13~0_combout\,
	combout => \cnt_hour_high[2]~4_combout\);

-- Location: FF_X34_Y33_N7
\cnt_hour_high[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_hour_high[2]~4_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_hour_high[2]~_emulated_q\);

-- Location: LCCOMB_X34_Y33_N6
\cnt_hour_high[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[2]~3_combout\ = \cnt_hour_high[2]~_emulated_q\ $ (\cnt_hour_high[2]~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_hour_high[2]~_emulated_q\,
	datad => \cnt_hour_high[2]~1_combout\,
	combout => \cnt_hour_high[2]~3_combout\);

-- Location: LCCOMB_X34_Y33_N0
\cnt_hour_high[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_hour_high[2]~2_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_hour_high~29_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_hour_high[2]~3_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_hour_high~29_combout\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_hour_high[2]~3_combout\,
	combout => \cnt_hour_high[2]~2_combout\);

-- Location: LCCOMB_X34_Y34_N12
\process_20~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~1_combout\ = (in_tim_hour_high(3) & (\cnt_hour_high[3]~7_combout\ & (\cnt_hour_high[2]~2_combout\ $ (!in_tim_hour_high(2))))) # (!in_tim_hour_high(3) & (!\cnt_hour_high[3]~7_combout\ & (\cnt_hour_high[2]~2_combout\ $ (!in_tim_hour_high(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001001000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_high(3),
	datab => \cnt_hour_high[2]~2_combout\,
	datac => in_tim_hour_high(2),
	datad => \cnt_hour_high[3]~7_combout\,
	combout => \process_20~1_combout\);

-- Location: LCCOMB_X35_Y32_N26
\in_tim_hour_low[0]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_hour_low[0]~4_combout\ = !in_tim_hour_low(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => in_tim_hour_low(0),
	combout => \in_tim_hour_low[0]~4_combout\);

-- Location: LCCOMB_X36_Y35_N12
\in_tim_hour_low[0]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_hour_low[0]~1_combout\ = (\bt3|btn_sync~q\ & (!\bt3|btn_delay~q\ & \current_state.HT0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt3|btn_sync~q\,
	datab => \bt3|btn_delay~q\,
	datad => \current_state.HT0~q\,
	combout => \in_tim_hour_low[0]~1_combout\);

-- Location: FF_X35_Y32_N27
\in_tim_hour_low[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_hour_low[0]~4_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_hour_low[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_hour_low(0));

-- Location: LCCOMB_X35_Y32_N28
\in_tim_hour_low~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_hour_low~0_combout\ = (in_tim_hour_low(2) & (in_tim_hour_low(3) $ (((in_tim_hour_low(1) & !in_tim_hour_low(0)))))) # (!in_tim_hour_low(2) & (in_tim_hour_low(3) & ((in_tim_hour_low(1)) # (in_tim_hour_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_low(2),
	datab => in_tim_hour_low(1),
	datac => in_tim_hour_low(3),
	datad => in_tim_hour_low(0),
	combout => \in_tim_hour_low~0_combout\);

-- Location: FF_X35_Y32_N29
\in_tim_hour_low[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_hour_low~0_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_hour_low[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_hour_low(3));

-- Location: LCCOMB_X35_Y32_N2
\in_tim_hour_low~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_hour_low~2_combout\ = (in_tim_hour_low(1) & (((in_tim_hour_low(0))))) # (!in_tim_hour_low(1) & (!in_tim_hour_low(0) & ((in_tim_hour_low(2)) # (!in_tim_hour_low(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_low(3),
	datab => in_tim_hour_low(2),
	datac => in_tim_hour_low(1),
	datad => in_tim_hour_low(0),
	combout => \in_tim_hour_low~2_combout\);

-- Location: FF_X35_Y32_N3
\in_tim_hour_low[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_hour_low~2_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_hour_low[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_hour_low(1));

-- Location: LCCOMB_X35_Y32_N10
\in_tim_hour_low[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_hour_low[2]~3_combout\ = in_tim_hour_low(2) $ (((in_tim_hour_low(1) & (\in_tim_hour_low[0]~1_combout\ & !in_tim_hour_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_low(1),
	datab => \in_tim_hour_low[0]~1_combout\,
	datac => in_tim_hour_low(2),
	datad => in_tim_hour_low(0),
	combout => \in_tim_hour_low[2]~3_combout\);

-- Location: FF_X35_Y32_N11
\in_tim_hour_low[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_hour_low[2]~3_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_hour_low(2));

-- Location: LCCOMB_X35_Y32_N24
\process_20~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~3_combout\ = (in_tim_hour_low(2) & (\cnt_hour_low[2]~2_combout\ & (\cnt_hour_low[3]~7_combout\ $ (!in_tim_hour_low(3))))) # (!in_tim_hour_low(2) & (!\cnt_hour_low[2]~2_combout\ & (\cnt_hour_low[3]~7_combout\ $ (!in_tim_hour_low(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000010000100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_low(2),
	datab => \cnt_hour_low[3]~7_combout\,
	datac => \cnt_hour_low[2]~2_combout\,
	datad => in_tim_hour_low(3),
	combout => \process_20~3_combout\);

-- Location: LCCOMB_X35_Y32_N14
\process_20~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~2_combout\ = (\cnt_hour_low[0]~17_combout\ & (!in_tim_hour_low(0) & (\cnt_hour_low[1]~12_combout\ $ (!in_tim_hour_low(1))))) # (!\cnt_hour_low[0]~17_combout\ & (in_tim_hour_low(0) & (\cnt_hour_low[1]~12_combout\ $ (!in_tim_hour_low(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100100000010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[0]~17_combout\,
	datab => \cnt_hour_low[1]~12_combout\,
	datac => in_tim_hour_low(0),
	datad => in_tim_hour_low(1),
	combout => \process_20~2_combout\);

-- Location: LCCOMB_X35_Y34_N8
\process_20~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~0_combout\ = (\cnt_hour_high[0]~17_combout\ & (!in_tim_hour_high(0) & (\cnt_hour_high[1]~12_combout\ $ (!in_tim_hour_high(1))))) # (!\cnt_hour_high[0]~17_combout\ & (in_tim_hour_high(0) & (\cnt_hour_high[1]~12_combout\ $ 
-- (!in_tim_hour_high(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100100000010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[0]~17_combout\,
	datab => \cnt_hour_high[1]~12_combout\,
	datac => in_tim_hour_high(0),
	datad => in_tim_hour_high(1),
	combout => \process_20~0_combout\);

-- Location: LCCOMB_X35_Y32_N12
\process_20~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~4_combout\ = (\process_20~1_combout\ & (\process_20~3_combout\ & (\process_20~2_combout\ & \process_20~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_20~1_combout\,
	datab => \process_20~3_combout\,
	datac => \process_20~2_combout\,
	datad => \process_20~0_combout\,
	combout => \process_20~4_combout\);

-- Location: LCCOMB_X35_Y32_N8
\process_20~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_20~15_combout\ = (\process_20~9_combout\ & (\process_20~14_combout\ & \process_20~4_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \process_20~9_combout\,
	datac => \process_20~14_combout\,
	datad => \process_20~4_combout\,
	combout => \process_20~15_combout\);

-- Location: LCCOMB_X34_Y34_N16
\time_trig~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \time_trig~2_combout\ = (\current_state.INC~q\ & ((\process_20~15_combout\) # ((\bt3|btn_sync~q\ & !\bt3|btn_delay~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt3|btn_sync~q\,
	datab => \process_20~15_combout\,
	datac => \current_state.INC~q\,
	datad => \bt3|btn_delay~q\,
	combout => \time_trig~2_combout\);

-- Location: LCCOMB_X34_Y34_N26
time_trig : cycloneive_lcell_comb
-- Equation(s):
-- \time_trig~combout\ = (\en~input_o\ & ((\time_trig~2_combout\ & (\process_20~15_combout\)) # (!\time_trig~2_combout\ & ((\time_trig~combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \process_20~15_combout\,
	datac => \time_trig~combout\,
	datad => \time_trig~2_combout\,
	combout => \time_trig~combout\);

-- Location: LCCOMB_X39_Y36_N0
\t2|toggle~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \t2|toggle~0_combout\ = !\t2|toggle~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \t2|toggle~q\,
	combout => \t2|toggle~0_combout\);

-- Location: FF_X39_Y36_N1
\t2|toggle\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t2|toggle~0_combout\,
	ena => \t1|Equal0~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t2|toggle~q\);

-- Location: LCCOMB_X42_Y36_N24
\led_flash~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \led_flash~0_combout\ = (\time_trig~combout\ & \t2|toggle~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \time_trig~combout\,
	datad => \t2|toggle~q\,
	combout => \led_flash~0_combout\);

-- Location: IOIBUF_X115_Y14_N1
\mode1~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_mode1,
	o => \mode1~input_o\);

-- Location: LCCOMB_X33_Y31_N0
\min_high~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~2_combout\ = (\cnt_min_high[2]~2_combout\ & (!\cnt_min_high[1]~12_combout\ & (\cnt_min_high[0]~17_combout\ $ (!\cnt_min_high[3]~7_combout\)))) # (!\cnt_min_high[2]~2_combout\ & ((\cnt_min_high[1]~12_combout\ & ((\cnt_min_high[3]~7_combout\))) # 
-- (!\cnt_min_high[1]~12_combout\ & (\cnt_min_high[0]~17_combout\ & !\cnt_min_high[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110010000010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~2_combout\,
	datab => \cnt_min_high[1]~12_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \min_high~2_combout\);

-- Location: LCCOMB_X33_Y34_N18
\min_high~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~1_combout\ = (\t1|toggle~q\ & ((\mode1~input_o\ & (\current_state.M1~q\)) # (!\mode1~input_o\ & ((\current_state.MT1~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.M1~q\,
	datab => \current_state.MT1~q\,
	datac => \t1|toggle~q\,
	datad => \mode1~input_o\,
	combout => \min_high~1_combout\);

-- Location: LCCOMB_X34_Y31_N14
\min_high~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~0_combout\ = (in_tim_min_high(3) & ((in_tim_min_high(2) & (!in_tim_min_high(0) & !in_tim_min_high(1))) # (!in_tim_min_high(2) & ((in_tim_min_high(1)))))) # (!in_tim_min_high(3) & (!in_tim_min_high(1) & (in_tim_min_high(0) $ 
-- (!in_tim_min_high(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110001100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(0),
	datab => in_tim_min_high(3),
	datac => in_tim_min_high(2),
	datad => in_tim_min_high(1),
	combout => \min_high~0_combout\);

-- Location: LCCOMB_X33_Y31_N26
\min_high~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~3_combout\ = (\min_high~1_combout\) # ((\mode1~input_o\ & (\min_high~2_combout\)) # (!\mode1~input_o\ & ((\min_high~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \min_high~2_combout\,
	datac => \min_high~1_combout\,
	datad => \min_high~0_combout\,
	combout => \min_high~3_combout\);

-- Location: LCCOMB_X34_Y31_N20
\min_high~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~4_combout\ = (in_tim_min_high(3) & ((in_tim_min_high(0) & (in_tim_min_high(2))) # (!in_tim_min_high(0) & ((in_tim_min_high(1)))))) # (!in_tim_min_high(3) & (in_tim_min_high(2) & (in_tim_min_high(0) $ (!in_tim_min_high(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(2),
	datab => in_tim_min_high(3),
	datac => in_tim_min_high(0),
	datad => in_tim_min_high(1),
	combout => \min_high~4_combout\);

-- Location: LCCOMB_X33_Y31_N20
\se1|seg[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se1|seg[1]~0_combout\ = (\cnt_min_high[1]~12_combout\ & ((\cnt_min_high[0]~17_combout\ & ((\cnt_min_high[3]~7_combout\))) # (!\cnt_min_high[0]~17_combout\ & (\cnt_min_high[2]~2_combout\)))) # (!\cnt_min_high[1]~12_combout\ & (\cnt_min_high[2]~2_combout\ 
-- & (\cnt_min_high[0]~17_combout\ $ (\cnt_min_high[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~2_combout\,
	datab => \cnt_min_high[1]~12_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \se1|seg[1]~0_combout\);

-- Location: LCCOMB_X33_Y31_N30
\min_high~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~5_combout\ = (\min_high~1_combout\) # ((\mode1~input_o\ & ((\se1|seg[1]~0_combout\))) # (!\mode1~input_o\ & (\min_high~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011011100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \min_high~1_combout\,
	datac => \min_high~4_combout\,
	datad => \se1|seg[1]~0_combout\,
	combout => \min_high~5_combout\);

-- Location: LCCOMB_X34_Y31_N12
\min_high~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~6_combout\ = (in_tim_min_high(3) & (in_tim_min_high(2) & ((in_tim_min_high(0)) # (in_tim_min_high(1))))) # (!in_tim_min_high(3) & (in_tim_min_high(0) & (!in_tim_min_high(2) & in_tim_min_high(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(0),
	datab => in_tim_min_high(3),
	datac => in_tim_min_high(2),
	datad => in_tim_min_high(1),
	combout => \min_high~6_combout\);

-- Location: LCCOMB_X33_Y31_N24
\se1|seg[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se1|seg[2]~1_combout\ = (\cnt_min_high[2]~2_combout\ & (\cnt_min_high[3]~7_combout\ & ((\cnt_min_high[1]~12_combout\) # (!\cnt_min_high[0]~17_combout\)))) # (!\cnt_min_high[2]~2_combout\ & (\cnt_min_high[1]~12_combout\ & (!\cnt_min_high[0]~17_combout\ & 
-- !\cnt_min_high[3]~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~2_combout\,
	datab => \cnt_min_high[1]~12_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \se1|seg[2]~1_combout\);

-- Location: LCCOMB_X33_Y31_N10
\min_high~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~7_combout\ = (\min_high~1_combout\) # ((\mode1~input_o\ & ((\se1|seg[2]~1_combout\))) # (!\mode1~input_o\ & (\min_high~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011011100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \min_high~1_combout\,
	datac => \min_high~6_combout\,
	datad => \se1|seg[2]~1_combout\,
	combout => \min_high~7_combout\);

-- Location: LCCOMB_X33_Y31_N4
\se1|seg[3]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se1|seg[3]~2_combout\ = (\cnt_min_high[1]~12_combout\ & ((\cnt_min_high[2]~2_combout\ & (\cnt_min_high[0]~17_combout\)) # (!\cnt_min_high[2]~2_combout\ & (!\cnt_min_high[0]~17_combout\ & \cnt_min_high[3]~7_combout\)))) # (!\cnt_min_high[1]~12_combout\ & 
-- (!\cnt_min_high[3]~7_combout\ & (\cnt_min_high[2]~2_combout\ $ (\cnt_min_high[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000010010010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~2_combout\,
	datab => \cnt_min_high[1]~12_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \se1|seg[3]~2_combout\);

-- Location: LCCOMB_X34_Y31_N24
\se7|seg[3]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se7|seg[3]~0_combout\ = (in_tim_min_high(1) & ((in_tim_min_high(2) & ((!in_tim_min_high(0)))) # (!in_tim_min_high(2) & (in_tim_min_high(3) & in_tim_min_high(0))))) # (!in_tim_min_high(1) & (!in_tim_min_high(3) & (in_tim_min_high(2) $ 
-- (!in_tim_min_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100101000100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(2),
	datab => in_tim_min_high(3),
	datac => in_tim_min_high(0),
	datad => in_tim_min_high(1),
	combout => \se7|seg[3]~0_combout\);

-- Location: LCCOMB_X33_Y31_N14
\min_high~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~8_combout\ = (\min_high~1_combout\) # ((\mode1~input_o\ & (\se1|seg[3]~2_combout\)) # (!\mode1~input_o\ & ((\se7|seg[3]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110111101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \min_high~1_combout\,
	datac => \se1|seg[3]~2_combout\,
	datad => \se7|seg[3]~0_combout\,
	combout => \min_high~8_combout\);

-- Location: LCCOMB_X33_Y31_N16
\se1|seg[4]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se1|seg[4]~3_combout\ = (\cnt_min_high[1]~12_combout\ & (((\cnt_min_high[0]~17_combout\ & !\cnt_min_high[3]~7_combout\)))) # (!\cnt_min_high[1]~12_combout\ & ((\cnt_min_high[2]~2_combout\ & ((!\cnt_min_high[3]~7_combout\))) # 
-- (!\cnt_min_high[2]~2_combout\ & (\cnt_min_high[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000011110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~2_combout\,
	datab => \cnt_min_high[1]~12_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \se1|seg[4]~3_combout\);

-- Location: LCCOMB_X34_Y31_N18
\se7|seg[4]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se7|seg[4]~1_combout\ = (in_tim_min_high(1) & (!in_tim_min_high(0) & (!in_tim_min_high(3)))) # (!in_tim_min_high(1) & ((in_tim_min_high(2) & ((!in_tim_min_high(3)))) # (!in_tim_min_high(2) & (!in_tim_min_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000100110101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(0),
	datab => in_tim_min_high(3),
	datac => in_tim_min_high(2),
	datad => in_tim_min_high(1),
	combout => \se7|seg[4]~1_combout\);

-- Location: LCCOMB_X33_Y31_N2
\min_high~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~9_combout\ = (\min_high~1_combout\) # ((\mode1~input_o\ & (\se1|seg[4]~3_combout\)) # (!\mode1~input_o\ & ((\se7|seg[4]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \se1|seg[4]~3_combout\,
	datac => \min_high~1_combout\,
	datad => \se7|seg[4]~1_combout\,
	combout => \min_high~9_combout\);

-- Location: LCCOMB_X33_Y34_N12
\min_high~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~12_combout\ = (\t1|toggle~q\ & ((\mode1~input_o\ & (\current_state.M1~q\)) # (!\mode1~input_o\ & ((\current_state.MT1~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.M1~q\,
	datab => \current_state.MT1~q\,
	datac => \t1|toggle~q\,
	datad => \mode1~input_o\,
	combout => \min_high~12_combout\);

-- Location: LCCOMB_X34_Y31_N30
\min_high~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~11_combout\ = (in_tim_min_high(2) & ((in_tim_min_high(0)) # (in_tim_min_high(3) $ (!in_tim_min_high(1))))) # (!in_tim_min_high(2) & ((in_tim_min_high(3)) # ((in_tim_min_high(0) & !in_tim_min_high(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110011110110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(2),
	datab => in_tim_min_high(3),
	datac => in_tim_min_high(0),
	datad => in_tim_min_high(1),
	combout => \min_high~11_combout\);

-- Location: LCCOMB_X33_Y31_N12
\min_high~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~10_combout\ = (\cnt_min_high[2]~2_combout\ & (\cnt_min_high[0]~17_combout\ & (\cnt_min_high[1]~12_combout\ $ (\cnt_min_high[3]~7_combout\)))) # (!\cnt_min_high[2]~2_combout\ & (!\cnt_min_high[3]~7_combout\ & ((\cnt_min_high[1]~12_combout\) # 
-- (\cnt_min_high[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000011010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~2_combout\,
	datab => \cnt_min_high[1]~12_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \min_high~10_combout\);

-- Location: LCCOMB_X33_Y31_N22
\min_high~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~13_combout\ = (\min_high~12_combout\) # ((\mode1~input_o\ & ((\min_high~10_combout\))) # (!\mode1~input_o\ & (!\min_high~11_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \min_high~12_combout\,
	datac => \min_high~11_combout\,
	datad => \min_high~10_combout\,
	combout => \min_high~13_combout\);

-- Location: LCCOMB_X33_Y31_N8
\se1|seg[6]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \se1|seg[6]~4_combout\ = (\cnt_min_high[0]~17_combout\ & ((\cnt_min_high[3]~7_combout\) # (\cnt_min_high[2]~2_combout\ $ (\cnt_min_high[1]~12_combout\)))) # (!\cnt_min_high[0]~17_combout\ & ((\cnt_min_high[1]~12_combout\) # (\cnt_min_high[2]~2_combout\ $ 
-- (\cnt_min_high[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110101101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~2_combout\,
	datab => \cnt_min_high[1]~12_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \se1|seg[6]~4_combout\);

-- Location: LCCOMB_X34_Y31_N2
\se7|seg[6]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se7|seg[6]~2_combout\ = (in_tim_min_high(0) & ((in_tim_min_high(1)) # (in_tim_min_high(2) $ (in_tim_min_high(3))))) # (!in_tim_min_high(0) & ((in_tim_min_high(3)) # (in_tim_min_high(2) $ (in_tim_min_high(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110101101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(2),
	datab => in_tim_min_high(3),
	datac => in_tim_min_high(0),
	datad => in_tim_min_high(1),
	combout => \se7|seg[6]~2_combout\);

-- Location: LCCOMB_X33_Y31_N18
\min_high~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~14_combout\ = (\min_high~1_combout\) # ((\mode1~input_o\ & (!\se1|seg[6]~4_combout\)) # (!\mode1~input_o\ & ((!\se7|seg[6]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111011011111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \min_high~1_combout\,
	datac => \se1|seg[6]~4_combout\,
	datad => \se7|seg[6]~2_combout\,
	combout => \min_high~14_combout\);

-- Location: LCCOMB_X40_Y32_N24
\min_low~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~3_combout\ = (\cnt_min_low[2]~2_combout\ & (!\cnt_min_low[1]~12_combout\ & (\cnt_min_low[0]~17_combout\ $ (!\cnt_min_low[3]~7_combout\)))) # (!\cnt_min_low[2]~2_combout\ & ((\cnt_min_low[3]~7_combout\ & ((\cnt_min_low[1]~12_combout\))) # 
-- (!\cnt_min_low[3]~7_combout\ & (\cnt_min_low[0]~17_combout\ & !\cnt_min_low[1]~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000010000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~17_combout\,
	datab => \cnt_min_low[2]~2_combout\,
	datac => \cnt_min_low[3]~7_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \min_low~3_combout\);

-- Location: LCCOMB_X36_Y35_N8
\min_low~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~2_combout\ = (\t1|toggle~q\ & (\mode1~input_o\ & \current_state.M0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|toggle~q\,
	datac => \mode1~input_o\,
	datad => \current_state.M0~q\,
	combout => \min_low~2_combout\);

-- Location: LCCOMB_X41_Y33_N20
\min_low~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~0_combout\ = (in_tim_min_low(2) & ((in_tim_min_low(1)) # (in_tim_min_low(3) $ (!in_tim_min_low(0))))) # (!in_tim_min_low(2) & ((in_tim_min_low(1) & (!in_tim_min_low(3))) # (!in_tim_min_low(1) & ((in_tim_min_low(3)) # (in_tim_min_low(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011110110011110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(2),
	datab => in_tim_min_low(1),
	datac => in_tim_min_low(3),
	datad => in_tim_min_low(0),
	combout => \min_low~0_combout\);

-- Location: LCCOMB_X41_Y33_N28
\min_low~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~1_combout\ = (!\mode1~input_o\ & (((\current_state.MT0~q\ & \t1|toggle~q\)) # (!\min_low~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.MT0~q\,
	datab => \t1|toggle~q\,
	datac => \mode1~input_o\,
	datad => \min_low~0_combout\,
	combout => \min_low~1_combout\);

-- Location: LCCOMB_X40_Y32_N10
\min_low~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~4_combout\ = (\min_low~2_combout\) # ((\min_low~1_combout\) # ((\mode1~input_o\ & \min_low~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \min_low~3_combout\,
	datac => \min_low~2_combout\,
	datad => \min_low~1_combout\,
	combout => \min_low~4_combout\);

-- Location: LCCOMB_X36_Y35_N26
\min_low~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~5_combout\ = (\t1|toggle~q\ & ((\mode1~input_o\ & ((\current_state.M0~q\))) # (!\mode1~input_o\ & (\current_state.MT0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100100000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.MT0~q\,
	datab => \t1|toggle~q\,
	datac => \mode1~input_o\,
	datad => \current_state.M0~q\,
	combout => \min_low~5_combout\);

-- Location: LCCOMB_X41_Y33_N24
\min_low~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~6_combout\ = (in_tim_min_low(3) & ((in_tim_min_low(0) & (in_tim_min_low(2))) # (!in_tim_min_low(0) & ((in_tim_min_low(1)))))) # (!in_tim_min_low(3) & (in_tim_min_low(2) & (in_tim_min_low(0) $ (!in_tim_min_low(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100010000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(2),
	datab => in_tim_min_low(0),
	datac => in_tim_min_low(3),
	datad => in_tim_min_low(1),
	combout => \min_low~6_combout\);

-- Location: LCCOMB_X40_Y32_N12
\se2|seg[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se2|seg[1]~0_combout\ = (\cnt_min_low[3]~7_combout\ & ((\cnt_min_low[0]~17_combout\ & ((\cnt_min_low[1]~12_combout\))) # (!\cnt_min_low[0]~17_combout\ & (\cnt_min_low[2]~2_combout\)))) # (!\cnt_min_low[3]~7_combout\ & (\cnt_min_low[2]~2_combout\ & 
-- (\cnt_min_low[0]~17_combout\ $ (\cnt_min_low[1]~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110010001001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~17_combout\,
	datab => \cnt_min_low[2]~2_combout\,
	datac => \cnt_min_low[3]~7_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \se2|seg[1]~0_combout\);

-- Location: LCCOMB_X41_Y32_N8
\min_low~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~7_combout\ = (\min_low~5_combout\) # ((\mode1~input_o\ & ((\se2|seg[1]~0_combout\))) # (!\mode1~input_o\ & (\min_low~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111010111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \min_low~5_combout\,
	datab => \mode1~input_o\,
	datac => \min_low~6_combout\,
	datad => \se2|seg[1]~0_combout\,
	combout => \min_low~7_combout\);

-- Location: LCCOMB_X41_Y33_N8
\min_low~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~8_combout\ = (in_tim_min_low(2) & (in_tim_min_low(3) & ((in_tim_min_low(0)) # (in_tim_min_low(1))))) # (!in_tim_min_low(2) & (in_tim_min_low(0) & (!in_tim_min_low(3) & in_tim_min_low(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(2),
	datab => in_tim_min_low(0),
	datac => in_tim_min_low(3),
	datad => in_tim_min_low(1),
	combout => \min_low~8_combout\);

-- Location: LCCOMB_X40_Y33_N18
\se2|seg[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se2|seg[2]~1_combout\ = (\cnt_min_low[2]~2_combout\ & (\cnt_min_low[3]~7_combout\ & ((\cnt_min_low[1]~12_combout\) # (!\cnt_min_low[0]~17_combout\)))) # (!\cnt_min_low[2]~2_combout\ & (!\cnt_min_low[0]~17_combout\ & (\cnt_min_low[1]~12_combout\ & 
-- !\cnt_min_low[3]~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[2]~2_combout\,
	datab => \cnt_min_low[0]~17_combout\,
	datac => \cnt_min_low[1]~12_combout\,
	datad => \cnt_min_low[3]~7_combout\,
	combout => \se2|seg[2]~1_combout\);

-- Location: LCCOMB_X41_Y33_N2
\min_low~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~9_combout\ = (\min_low~5_combout\) # ((\mode1~input_o\ & ((\se2|seg[2]~1_combout\))) # (!\mode1~input_o\ & (\min_low~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111010101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \min_low~5_combout\,
	datab => \min_low~8_combout\,
	datac => \mode1~input_o\,
	datad => \se2|seg[2]~1_combout\,
	combout => \min_low~9_combout\);

-- Location: LCCOMB_X40_Y32_N14
\se2|seg[3]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se2|seg[3]~2_combout\ = (\cnt_min_low[1]~12_combout\ & ((\cnt_min_low[0]~17_combout\ & (\cnt_min_low[2]~2_combout\)) # (!\cnt_min_low[0]~17_combout\ & (!\cnt_min_low[2]~2_combout\ & \cnt_min_low[3]~7_combout\)))) # (!\cnt_min_low[1]~12_combout\ & 
-- (!\cnt_min_low[3]~7_combout\ & (\cnt_min_low[0]~17_combout\ $ (\cnt_min_low[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001100000000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~17_combout\,
	datab => \cnt_min_low[2]~2_combout\,
	datac => \cnt_min_low[3]~7_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \se2|seg[3]~2_combout\);

-- Location: LCCOMB_X41_Y33_N16
\se8|seg[3]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se8|seg[3]~0_combout\ = (in_tim_min_low(1) & ((in_tim_min_low(2) & (!in_tim_min_low(0))) # (!in_tim_min_low(2) & (in_tim_min_low(0) & in_tim_min_low(3))))) # (!in_tim_min_low(1) & (!in_tim_min_low(3) & (in_tim_min_low(2) $ (!in_tim_min_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110001000001001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(2),
	datab => in_tim_min_low(0),
	datac => in_tim_min_low(3),
	datad => in_tim_min_low(1),
	combout => \se8|seg[3]~0_combout\);

-- Location: LCCOMB_X41_Y32_N26
\min_low~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~10_combout\ = (\min_low~5_combout\) # ((\mode1~input_o\ & (\se2|seg[3]~2_combout\)) # (!\mode1~input_o\ & ((\se8|seg[3]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se2|seg[3]~2_combout\,
	datab => \mode1~input_o\,
	datac => \min_low~5_combout\,
	datad => \se8|seg[3]~0_combout\,
	combout => \min_low~10_combout\);

-- Location: LCCOMB_X41_Y33_N12
\se8|seg[4]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se8|seg[4]~1_combout\ = (in_tim_min_low(1) & (((!in_tim_min_low(0) & !in_tim_min_low(3))))) # (!in_tim_min_low(1) & ((in_tim_min_low(2) & ((!in_tim_min_low(3)))) # (!in_tim_min_low(2) & (!in_tim_min_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100011011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(2),
	datab => in_tim_min_low(0),
	datac => in_tim_min_low(3),
	datad => in_tim_min_low(1),
	combout => \se8|seg[4]~1_combout\);

-- Location: LCCOMB_X40_Y32_N8
\se2|seg[4]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se2|seg[4]~3_combout\ = (\cnt_min_low[1]~12_combout\ & (\cnt_min_low[0]~17_combout\ & ((!\cnt_min_low[3]~7_combout\)))) # (!\cnt_min_low[1]~12_combout\ & ((\cnt_min_low[2]~2_combout\ & ((!\cnt_min_low[3]~7_combout\))) # (!\cnt_min_low[2]~2_combout\ & 
-- (\cnt_min_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~17_combout\,
	datab => \cnt_min_low[2]~2_combout\,
	datac => \cnt_min_low[3]~7_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \se2|seg[4]~3_combout\);

-- Location: LCCOMB_X40_Y32_N26
\min_low~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~11_combout\ = (\min_low~5_combout\) # ((\mode1~input_o\ & ((\se2|seg[4]~3_combout\))) # (!\mode1~input_o\ & (\se8|seg[4]~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011011100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \min_low~5_combout\,
	datac => \se8|seg[4]~1_combout\,
	datad => \se2|seg[4]~3_combout\,
	combout => \min_low~11_combout\);

-- Location: LCCOMB_X40_Y32_N20
\min_low~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~14_combout\ = (\cnt_min_low[0]~17_combout\ & (\cnt_min_low[3]~7_combout\ $ (((\cnt_min_low[1]~12_combout\) # (!\cnt_min_low[2]~2_combout\))))) # (!\cnt_min_low[0]~17_combout\ & (!\cnt_min_low[2]~2_combout\ & (!\cnt_min_low[3]~7_combout\ & 
-- \cnt_min_low[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101110000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~17_combout\,
	datab => \cnt_min_low[2]~2_combout\,
	datac => \cnt_min_low[3]~7_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \min_low~14_combout\);

-- Location: LCCOMB_X41_Y33_N10
\min_low~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~12_combout\ = (in_tim_min_low(2) & (!in_tim_min_low(0) & (in_tim_min_low(3) $ (in_tim_min_low(1))))) # (!in_tim_min_low(2) & (!in_tim_min_low(3) & ((in_tim_min_low(1)) # (!in_tim_min_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000011100100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(2),
	datab => in_tim_min_low(0),
	datac => in_tim_min_low(3),
	datad => in_tim_min_low(1),
	combout => \min_low~12_combout\);

-- Location: LCCOMB_X41_Y33_N22
\min_low~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~13_combout\ = (!\mode1~input_o\ & ((\min_low~12_combout\) # ((\current_state.MT0~q\ & \t1|toggle~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.MT0~q\,
	datab => \t1|toggle~q\,
	datac => \mode1~input_o\,
	datad => \min_low~12_combout\,
	combout => \min_low~13_combout\);

-- Location: LCCOMB_X40_Y32_N6
\min_low~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~15_combout\ = (\min_low~2_combout\) # ((\min_low~13_combout\) # ((\mode1~input_o\ & \min_low~14_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \min_low~14_combout\,
	datac => \min_low~2_combout\,
	datad => \min_low~13_combout\,
	combout => \min_low~15_combout\);

-- Location: LCCOMB_X40_Y32_N16
\se2|seg[6]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \se2|seg[6]~4_combout\ = (\cnt_min_low[0]~17_combout\ & ((\cnt_min_low[3]~7_combout\) # (\cnt_min_low[2]~2_combout\ $ (\cnt_min_low[1]~12_combout\)))) # (!\cnt_min_low[0]~17_combout\ & ((\cnt_min_low[1]~12_combout\) # (\cnt_min_low[2]~2_combout\ $ 
-- (\cnt_min_low[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011110111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~17_combout\,
	datab => \cnt_min_low[2]~2_combout\,
	datac => \cnt_min_low[3]~7_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \se2|seg[6]~4_combout\);

-- Location: LCCOMB_X41_Y33_N18
\se8|seg[6]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se8|seg[6]~2_combout\ = (in_tim_min_low(0) & ((in_tim_min_low(1)) # (in_tim_min_low(2) $ (in_tim_min_low(3))))) # (!in_tim_min_low(0) & ((in_tim_min_low(3)) # (in_tim_min_low(2) $ (in_tim_min_low(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101111011110110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(2),
	datab => in_tim_min_low(1),
	datac => in_tim_min_low(3),
	datad => in_tim_min_low(0),
	combout => \se8|seg[6]~2_combout\);

-- Location: LCCOMB_X41_Y32_N20
\min_low~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~16_combout\ = (\min_low~5_combout\) # ((\mode1~input_o\ & (!\se2|seg[6]~4_combout\)) # (!\mode1~input_o\ & ((!\se8|seg[6]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111010111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \min_low~5_combout\,
	datab => \mode1~input_o\,
	datac => \se2|seg[6]~4_combout\,
	datad => \se8|seg[6]~2_combout\,
	combout => \min_low~16_combout\);

-- Location: LCCOMB_X33_Y35_N4
\sec_high~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~2_combout\ = (\mode1~input_o\ & (\t1|toggle~q\ & \current_state.S1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \t1|toggle~q\,
	datad => \current_state.S1~q\,
	combout => \sec_high~2_combout\);

-- Location: LCCOMB_X34_Y36_N6
\sec_high~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~3_combout\ = (\cnt_sec_high[3]~7_combout\ & ((\cnt_sec_high[1]~12_combout\ & (!\cnt_sec_high[2]~2_combout\)) # (!\cnt_sec_high[1]~12_combout\ & (\cnt_sec_high[2]~2_combout\ & \cnt_sec_high[0]~17_combout\)))) # (!\cnt_sec_high[3]~7_combout\ & 
-- (!\cnt_sec_high[1]~12_combout\ & (\cnt_sec_high[2]~2_combout\ $ (\cnt_sec_high[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010100100011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[3]~7_combout\,
	datab => \cnt_sec_high[1]~12_combout\,
	datac => \cnt_sec_high[2]~2_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \sec_high~3_combout\);

-- Location: LCCOMB_X32_Y36_N10
\sec_high~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~0_combout\ = (in_tim_sec_high(2) & ((in_tim_sec_high(1)) # (in_tim_sec_high(3) $ (!in_tim_sec_high(0))))) # (!in_tim_sec_high(2) & ((in_tim_sec_high(3) & ((!in_tim_sec_high(1)))) # (!in_tim_sec_high(3) & ((in_tim_sec_high(0)) # 
-- (in_tim_sec_high(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => in_tim_sec_high(3),
	datac => in_tim_sec_high(0),
	datad => in_tim_sec_high(1),
	combout => \sec_high~0_combout\);

-- Location: LCCOMB_X33_Y35_N0
\sec_high~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~1_combout\ = (!\mode1~input_o\ & (((\t1|toggle~q\ & \current_state.ST1~q\)) # (!\sec_high~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000001010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \t1|toggle~q\,
	datac => \current_state.ST1~q\,
	datad => \sec_high~0_combout\,
	combout => \sec_high~1_combout\);

-- Location: LCCOMB_X33_Y35_N8
\sec_high~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~4_combout\ = (\sec_high~2_combout\) # ((\sec_high~1_combout\) # ((\mode1~input_o\ & \sec_high~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \sec_high~2_combout\,
	datac => \sec_high~3_combout\,
	datad => \sec_high~1_combout\,
	combout => \sec_high~4_combout\);

-- Location: LCCOMB_X32_Y34_N8
\se3|seg[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se3|seg[1]~0_combout\ = (\cnt_sec_high[3]~7_combout\ & ((\cnt_sec_high[0]~17_combout\ & ((\cnt_sec_high[1]~12_combout\))) # (!\cnt_sec_high[0]~17_combout\ & (\cnt_sec_high[2]~2_combout\)))) # (!\cnt_sec_high[3]~7_combout\ & (\cnt_sec_high[2]~2_combout\ & 
-- (\cnt_sec_high[1]~12_combout\ $ (\cnt_sec_high[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010011001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[3]~7_combout\,
	datab => \cnt_sec_high[2]~2_combout\,
	datac => \cnt_sec_high[1]~12_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \se3|seg[1]~0_combout\);

-- Location: LCCOMB_X33_Y35_N22
\sec_high~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~5_combout\ = (\t1|toggle~q\ & ((\mode1~input_o\ & ((\current_state.S1~q\))) # (!\mode1~input_o\ & (\current_state.ST1~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \current_state.ST1~q\,
	datac => \t1|toggle~q\,
	datad => \current_state.S1~q\,
	combout => \sec_high~5_combout\);

-- Location: LCCOMB_X32_Y36_N4
\sec_high~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~6_combout\ = (in_tim_sec_high(3) & ((in_tim_sec_high(0) & (in_tim_sec_high(2))) # (!in_tim_sec_high(0) & ((in_tim_sec_high(1)))))) # (!in_tim_sec_high(3) & (in_tim_sec_high(2) & (in_tim_sec_high(0) $ (!in_tim_sec_high(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => in_tim_sec_high(3),
	datac => in_tim_sec_high(0),
	datad => in_tim_sec_high(1),
	combout => \sec_high~6_combout\);

-- Location: LCCOMB_X33_Y34_N20
\sec_high~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~7_combout\ = (\sec_high~5_combout\) # ((\mode1~input_o\ & (\se3|seg[1]~0_combout\)) # (!\mode1~input_o\ & ((\sec_high~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se3|seg[1]~0_combout\,
	datab => \mode1~input_o\,
	datac => \sec_high~5_combout\,
	datad => \sec_high~6_combout\,
	combout => \sec_high~7_combout\);

-- Location: LCCOMB_X32_Y35_N8
\se3|seg[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se3|seg[2]~1_combout\ = (\cnt_sec_high[3]~7_combout\ & (\cnt_sec_high[2]~2_combout\ & ((\cnt_sec_high[1]~12_combout\) # (!\cnt_sec_high[0]~17_combout\)))) # (!\cnt_sec_high[3]~7_combout\ & (\cnt_sec_high[1]~12_combout\ & (!\cnt_sec_high[2]~2_combout\ & 
-- !\cnt_sec_high[0]~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000010100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[3]~7_combout\,
	datab => \cnt_sec_high[1]~12_combout\,
	datac => \cnt_sec_high[2]~2_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \se3|seg[2]~1_combout\);

-- Location: LCCOMB_X32_Y36_N28
\sec_high~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~8_combout\ = (in_tim_sec_high(2) & (in_tim_sec_high(3) & ((in_tim_sec_high(0)) # (in_tim_sec_high(1))))) # (!in_tim_sec_high(2) & (!in_tim_sec_high(3) & (in_tim_sec_high(0) & in_tim_sec_high(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001100010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => in_tim_sec_high(3),
	datac => in_tim_sec_high(0),
	datad => in_tim_sec_high(1),
	combout => \sec_high~8_combout\);

-- Location: LCCOMB_X33_Y35_N18
\sec_high~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~9_combout\ = (\sec_high~5_combout\) # ((\mode1~input_o\ & (\se3|seg[2]~1_combout\)) # (!\mode1~input_o\ & ((\sec_high~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se3|seg[2]~1_combout\,
	datab => \sec_high~5_combout\,
	datac => \mode1~input_o\,
	datad => \sec_high~8_combout\,
	combout => \sec_high~9_combout\);

-- Location: LCCOMB_X32_Y36_N14
\se9|seg[3]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se9|seg[3]~0_combout\ = (in_tim_sec_high(1) & ((in_tim_sec_high(2) & ((!in_tim_sec_high(0)))) # (!in_tim_sec_high(2) & (in_tim_sec_high(3) & in_tim_sec_high(0))))) # (!in_tim_sec_high(1) & (!in_tim_sec_high(3) & (in_tim_sec_high(2) $ 
-- (!in_tim_sec_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100101000100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => in_tim_sec_high(3),
	datac => in_tim_sec_high(0),
	datad => in_tim_sec_high(1),
	combout => \se9|seg[3]~0_combout\);

-- Location: LCCOMB_X33_Y35_N12
\se3|seg[3]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se3|seg[3]~2_combout\ = (\cnt_sec_high[1]~12_combout\ & ((\cnt_sec_high[0]~17_combout\ & ((\cnt_sec_high[2]~2_combout\))) # (!\cnt_sec_high[0]~17_combout\ & (\cnt_sec_high[3]~7_combout\ & !\cnt_sec_high[2]~2_combout\)))) # (!\cnt_sec_high[1]~12_combout\ 
-- & (!\cnt_sec_high[3]~7_combout\ & (\cnt_sec_high[0]~17_combout\ $ (\cnt_sec_high[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100101000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[0]~17_combout\,
	datab => \cnt_sec_high[1]~12_combout\,
	datac => \cnt_sec_high[3]~7_combout\,
	datad => \cnt_sec_high[2]~2_combout\,
	combout => \se3|seg[3]~2_combout\);

-- Location: LCCOMB_X33_Y35_N2
\sec_high~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~10_combout\ = (\sec_high~5_combout\) # ((\mode1~input_o\ & ((\se3|seg[3]~2_combout\))) # (!\mode1~input_o\ & (\se9|seg[3]~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se9|seg[3]~0_combout\,
	datab => \sec_high~5_combout\,
	datac => \mode1~input_o\,
	datad => \se3|seg[3]~2_combout\,
	combout => \sec_high~10_combout\);

-- Location: LCCOMB_X32_Y36_N20
\se9|seg[4]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se9|seg[4]~1_combout\ = (in_tim_sec_high(1) & (((!in_tim_sec_high(3) & !in_tim_sec_high(0))))) # (!in_tim_sec_high(1) & ((in_tim_sec_high(2) & (!in_tim_sec_high(3))) # (!in_tim_sec_high(2) & ((!in_tim_sec_high(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100100111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => in_tim_sec_high(3),
	datac => in_tim_sec_high(0),
	datad => in_tim_sec_high(1),
	combout => \se9|seg[4]~1_combout\);

-- Location: LCCOMB_X32_Y35_N10
\se3|seg[4]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se3|seg[4]~3_combout\ = (\cnt_sec_high[1]~12_combout\ & (!\cnt_sec_high[3]~7_combout\ & ((\cnt_sec_high[0]~17_combout\)))) # (!\cnt_sec_high[1]~12_combout\ & ((\cnt_sec_high[2]~2_combout\ & (!\cnt_sec_high[3]~7_combout\)) # (!\cnt_sec_high[2]~2_combout\ 
-- & ((\cnt_sec_high[0]~17_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101011100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[3]~7_combout\,
	datab => \cnt_sec_high[1]~12_combout\,
	datac => \cnt_sec_high[2]~2_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \se3|seg[4]~3_combout\);

-- Location: LCCOMB_X33_Y35_N26
\sec_high~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~11_combout\ = (\sec_high~5_combout\) # ((\mode1~input_o\ & ((\se3|seg[4]~3_combout\))) # (!\mode1~input_o\ & (\se9|seg[4]~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se9|seg[4]~1_combout\,
	datab => \sec_high~5_combout\,
	datac => \mode1~input_o\,
	datad => \se3|seg[4]~3_combout\,
	combout => \sec_high~11_combout\);

-- Location: LCCOMB_X33_Y35_N10
\sec_high~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~14_combout\ = (\cnt_sec_high[0]~17_combout\ & (\cnt_sec_high[3]~7_combout\ $ (((\cnt_sec_high[1]~12_combout\) # (!\cnt_sec_high[2]~2_combout\))))) # (!\cnt_sec_high[0]~17_combout\ & (\cnt_sec_high[1]~12_combout\ & (!\cnt_sec_high[3]~7_combout\ & 
-- !\cnt_sec_high[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010100000001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[0]~17_combout\,
	datab => \cnt_sec_high[1]~12_combout\,
	datac => \cnt_sec_high[3]~7_combout\,
	datad => \cnt_sec_high[2]~2_combout\,
	combout => \sec_high~14_combout\);

-- Location: LCCOMB_X32_Y36_N18
\sec_high~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~12_combout\ = (in_tim_sec_high(2) & (!in_tim_sec_high(0) & (in_tim_sec_high(3) $ (in_tim_sec_high(1))))) # (!in_tim_sec_high(2) & (!in_tim_sec_high(3) & ((in_tim_sec_high(1)) # (!in_tim_sec_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001001100001001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => in_tim_sec_high(3),
	datac => in_tim_sec_high(0),
	datad => in_tim_sec_high(1),
	combout => \sec_high~12_combout\);

-- Location: LCCOMB_X33_Y35_N28
\sec_high~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~13_combout\ = (!\mode1~input_o\ & ((\sec_high~12_combout\) # ((\t1|toggle~q\ & \current_state.ST1~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010101000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \t1|toggle~q\,
	datac => \current_state.ST1~q\,
	datad => \sec_high~12_combout\,
	combout => \sec_high~13_combout\);

-- Location: LCCOMB_X33_Y35_N16
\sec_high~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~15_combout\ = (\sec_high~2_combout\) # ((\sec_high~13_combout\) # ((\sec_high~14_combout\ & \mode1~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sec_high~14_combout\,
	datab => \mode1~input_o\,
	datac => \sec_high~2_combout\,
	datad => \sec_high~13_combout\,
	combout => \sec_high~15_combout\);

-- Location: LCCOMB_X32_Y36_N8
\se9|seg[6]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se9|seg[6]~2_combout\ = (in_tim_sec_high(0) & ((in_tim_sec_high(1)) # (in_tim_sec_high(2) $ (in_tim_sec_high(3))))) # (!in_tim_sec_high(0) & ((in_tim_sec_high(3)) # (in_tim_sec_high(2) $ (in_tim_sec_high(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110101101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => in_tim_sec_high(3),
	datac => in_tim_sec_high(0),
	datad => in_tim_sec_high(1),
	combout => \se9|seg[6]~2_combout\);

-- Location: LCCOMB_X34_Y36_N26
\se3|seg[6]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \se3|seg[6]~4_combout\ = (\cnt_sec_high[0]~17_combout\ & ((\cnt_sec_high[3]~7_combout\) # (\cnt_sec_high[1]~12_combout\ $ (\cnt_sec_high[2]~2_combout\)))) # (!\cnt_sec_high[0]~17_combout\ & ((\cnt_sec_high[1]~12_combout\) # (\cnt_sec_high[3]~7_combout\ $ 
-- (\cnt_sec_high[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111011011110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[3]~7_combout\,
	datab => \cnt_sec_high[1]~12_combout\,
	datac => \cnt_sec_high[2]~2_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \se3|seg[6]~4_combout\);

-- Location: LCCOMB_X33_Y34_N28
\sec_high~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~16_combout\ = (\sec_high~5_combout\) # ((\mode1~input_o\ & ((!\se3|seg[6]~4_combout\))) # (!\mode1~input_o\ & (!\se9|seg[6]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000111111101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se9|seg[6]~2_combout\,
	datab => \mode1~input_o\,
	datac => \sec_high~5_combout\,
	datad => \se3|seg[6]~4_combout\,
	combout => \sec_high~16_combout\);

-- Location: LCCOMB_X39_Y32_N30
\sec_low~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~3_combout\ = (in_tim_sec_low(2) & ((in_tim_sec_low(1)) # (in_tim_sec_low(0) $ (!in_tim_sec_low(3))))) # (!in_tim_sec_low(2) & ((in_tim_sec_low(1) & ((!in_tim_sec_low(3)))) # (!in_tim_sec_low(1) & ((in_tim_sec_low(0)) # (in_tim_sec_low(3))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110111110110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(2),
	datab => in_tim_sec_low(0),
	datac => in_tim_sec_low(1),
	datad => in_tim_sec_low(3),
	combout => \sec_low~3_combout\);

-- Location: LCCOMB_X39_Y32_N10
\sec_low~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~4_combout\ = ((\current_state.ST0~q\ & \t1|toggle~q\)) # (!\sec_low~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.ST0~q\,
	datac => \sec_low~3_combout\,
	datad => \t1|toggle~q\,
	combout => \sec_low~4_combout\);

-- Location: LCCOMB_X39_Y32_N24
\sec_low~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~0_combout\ = (\mode1~input_o\ & (\current_state.S0~q\ & \t1|toggle~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datac => \current_state.S0~q\,
	datad => \t1|toggle~q\,
	combout => \sec_low~0_combout\);

-- Location: LCCOMB_X36_Y32_N18
\sec_low~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~1_combout\ = (\cnt_sec_low[3]~7_combout\ & (\cnt_sec_low[0]~17_combout\ & (!\cnt_sec_low[1]~12_combout\ & \cnt_sec_low[2]~2_combout\))) # (!\cnt_sec_low[3]~7_combout\ & (\cnt_sec_low[0]~17_combout\ $ (((\cnt_sec_low[2]~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001100100100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[0]~17_combout\,
	datab => \cnt_sec_low[3]~7_combout\,
	datac => \cnt_sec_low[1]~12_combout\,
	datad => \cnt_sec_low[2]~2_combout\,
	combout => \sec_low~1_combout\);

-- Location: LCCOMB_X36_Y32_N28
\sec_low~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~2_combout\ = (\mode1~input_o\ & ((\cnt_sec_low[1]~12_combout\ & ((\se4|Equal15~0_combout\))) # (!\cnt_sec_low[1]~12_combout\ & (\sec_low~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \sec_low~1_combout\,
	datac => \cnt_sec_low[1]~12_combout\,
	datad => \se4|Equal15~0_combout\,
	combout => \sec_low~2_combout\);

-- Location: LCCOMB_X39_Y32_N20
\sec_low~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~5_combout\ = (\sec_low~0_combout\) # ((\sec_low~2_combout\) # ((\sec_low~4_combout\ & !\mode1~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sec_low~4_combout\,
	datab => \mode1~input_o\,
	datac => \sec_low~0_combout\,
	datad => \sec_low~2_combout\,
	combout => \sec_low~5_combout\);

-- Location: LCCOMB_X39_Y32_N26
\sec_low~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~6_combout\ = (\t1|toggle~q\ & ((\mode1~input_o\ & ((\current_state.S0~q\))) # (!\mode1~input_o\ & (\current_state.ST0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.ST0~q\,
	datab => \current_state.S0~q\,
	datac => \mode1~input_o\,
	datad => \t1|toggle~q\,
	combout => \sec_low~6_combout\);

-- Location: LCCOMB_X41_Y32_N30
\se4|seg[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se4|seg[1]~0_combout\ = (\cnt_sec_low[1]~12_combout\ & ((\cnt_sec_low[0]~17_combout\ & (\cnt_sec_low[3]~7_combout\)) # (!\cnt_sec_low[0]~17_combout\ & ((\cnt_sec_low[2]~2_combout\))))) # (!\cnt_sec_low[1]~12_combout\ & (\cnt_sec_low[2]~2_combout\ & 
-- (\cnt_sec_low[3]~7_combout\ $ (\cnt_sec_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001111010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[1]~12_combout\,
	datab => \cnt_sec_low[3]~7_combout\,
	datac => \cnt_sec_low[0]~17_combout\,
	datad => \cnt_sec_low[2]~2_combout\,
	combout => \se4|seg[1]~0_combout\);

-- Location: LCCOMB_X40_Y32_N2
\sec_low~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~7_combout\ = (in_tim_sec_low(3) & ((in_tim_sec_low(0) & ((in_tim_sec_low(2)))) # (!in_tim_sec_low(0) & (in_tim_sec_low(1))))) # (!in_tim_sec_low(3) & (in_tim_sec_low(2) & (in_tim_sec_low(1) $ (!in_tim_sec_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(3),
	datab => in_tim_sec_low(1),
	datac => in_tim_sec_low(2),
	datad => in_tim_sec_low(0),
	combout => \sec_low~7_combout\);

-- Location: LCCOMB_X41_Y32_N0
\sec_low~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~8_combout\ = (\sec_low~6_combout\) # ((\mode1~input_o\ & (\se4|seg[1]~0_combout\)) # (!\mode1~input_o\ & ((\sec_low~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101111101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sec_low~6_combout\,
	datab => \mode1~input_o\,
	datac => \se4|seg[1]~0_combout\,
	datad => \sec_low~7_combout\,
	combout => \sec_low~8_combout\);

-- Location: LCCOMB_X40_Y32_N4
\sec_low~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~9_combout\ = (in_tim_sec_low(3) & (in_tim_sec_low(2) & ((in_tim_sec_low(1)) # (in_tim_sec_low(0))))) # (!in_tim_sec_low(3) & (in_tim_sec_low(1) & (!in_tim_sec_low(2) & in_tim_sec_low(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(3),
	datab => in_tim_sec_low(1),
	datac => in_tim_sec_low(2),
	datad => in_tim_sec_low(0),
	combout => \sec_low~9_combout\);

-- Location: LCCOMB_X41_Y32_N10
\se4|seg[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se4|seg[2]~1_combout\ = (\cnt_sec_low[3]~7_combout\ & (\cnt_sec_low[2]~2_combout\ & ((\cnt_sec_low[1]~12_combout\) # (!\cnt_sec_low[0]~17_combout\)))) # (!\cnt_sec_low[3]~7_combout\ & (\cnt_sec_low[1]~12_combout\ & (!\cnt_sec_low[0]~17_combout\ & 
-- !\cnt_sec_low[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[1]~12_combout\,
	datab => \cnt_sec_low[3]~7_combout\,
	datac => \cnt_sec_low[0]~17_combout\,
	datad => \cnt_sec_low[2]~2_combout\,
	combout => \se4|seg[2]~1_combout\);

-- Location: LCCOMB_X41_Y32_N12
\sec_low~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~10_combout\ = (\sec_low~6_combout\) # ((\mode1~input_o\ & ((\se4|seg[2]~1_combout\))) # (!\mode1~input_o\ & (\sec_low~9_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111010111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sec_low~6_combout\,
	datab => \mode1~input_o\,
	datac => \sec_low~9_combout\,
	datad => \se4|seg[2]~1_combout\,
	combout => \sec_low~10_combout\);

-- Location: LCCOMB_X41_Y32_N6
\se4|seg[3]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se4|seg[3]~2_combout\ = (\cnt_sec_low[1]~12_combout\ & ((\cnt_sec_low[0]~17_combout\ & ((\cnt_sec_low[2]~2_combout\))) # (!\cnt_sec_low[0]~17_combout\ & (\cnt_sec_low[3]~7_combout\ & !\cnt_sec_low[2]~2_combout\)))) # (!\cnt_sec_low[1]~12_combout\ & 
-- (!\cnt_sec_low[3]~7_combout\ & (\cnt_sec_low[0]~17_combout\ $ (\cnt_sec_low[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000100011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[1]~12_combout\,
	datab => \cnt_sec_low[3]~7_combout\,
	datac => \cnt_sec_low[0]~17_combout\,
	datad => \cnt_sec_low[2]~2_combout\,
	combout => \se4|seg[3]~2_combout\);

-- Location: LCCOMB_X40_Y32_N22
\se10|seg[3]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se10|seg[3]~0_combout\ = (in_tim_sec_low(1) & ((in_tim_sec_low(2) & ((!in_tim_sec_low(0)))) # (!in_tim_sec_low(2) & (in_tim_sec_low(3) & in_tim_sec_low(0))))) # (!in_tim_sec_low(1) & (!in_tim_sec_low(3) & (in_tim_sec_low(2) $ (!in_tim_sec_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001100011000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(3),
	datab => in_tim_sec_low(1),
	datac => in_tim_sec_low(2),
	datad => in_tim_sec_low(0),
	combout => \se10|seg[3]~0_combout\);

-- Location: LCCOMB_X41_Y32_N24
\sec_low~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~11_combout\ = (\sec_low~6_combout\) # ((\mode1~input_o\ & (\se4|seg[3]~2_combout\)) # (!\mode1~input_o\ & ((\se10|seg[3]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se4|seg[3]~2_combout\,
	datab => \mode1~input_o\,
	datac => \sec_low~6_combout\,
	datad => \se10|seg[3]~0_combout\,
	combout => \sec_low~11_combout\);

-- Location: LCCOMB_X39_Y32_N28
\se10|seg[4]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se10|seg[4]~1_combout\ = (in_tim_sec_low(1) & (((!in_tim_sec_low(0) & !in_tim_sec_low(3))))) # (!in_tim_sec_low(1) & ((in_tim_sec_low(2) & ((!in_tim_sec_low(3)))) # (!in_tim_sec_low(2) & (!in_tim_sec_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100111011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(2),
	datab => in_tim_sec_low(0),
	datac => in_tim_sec_low(1),
	datad => in_tim_sec_low(3),
	combout => \se10|seg[4]~1_combout\);

-- Location: LCCOMB_X41_Y32_N18
\se4|seg[4]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se4|seg[4]~3_combout\ = (\cnt_sec_low[1]~12_combout\ & (!\cnt_sec_low[3]~7_combout\ & (\cnt_sec_low[0]~17_combout\))) # (!\cnt_sec_low[1]~12_combout\ & ((\cnt_sec_low[2]~2_combout\ & (!\cnt_sec_low[3]~7_combout\)) # (!\cnt_sec_low[2]~2_combout\ & 
-- ((\cnt_sec_low[0]~17_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000101110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[1]~12_combout\,
	datab => \cnt_sec_low[3]~7_combout\,
	datac => \cnt_sec_low[0]~17_combout\,
	datad => \cnt_sec_low[2]~2_combout\,
	combout => \se4|seg[4]~3_combout\);

-- Location: LCCOMB_X41_Y32_N28
\sec_low~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~12_combout\ = (\sec_low~6_combout\) # ((\mode1~input_o\ & ((\se4|seg[4]~3_combout\))) # (!\mode1~input_o\ & (\se10|seg[4]~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se10|seg[4]~1_combout\,
	datab => \mode1~input_o\,
	datac => \sec_low~6_combout\,
	datad => \se4|seg[4]~3_combout\,
	combout => \sec_low~12_combout\);

-- Location: LCCOMB_X39_Y32_N4
\sec_low~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~13_combout\ = (in_tim_sec_low(2) & (!in_tim_sec_low(0) & (in_tim_sec_low(1) $ (in_tim_sec_low(3))))) # (!in_tim_sec_low(2) & (!in_tim_sec_low(3) & ((in_tim_sec_low(1)) # (!in_tim_sec_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001001110001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(2),
	datab => in_tim_sec_low(0),
	datac => in_tim_sec_low(1),
	datad => in_tim_sec_low(3),
	combout => \sec_low~13_combout\);

-- Location: LCCOMB_X39_Y32_N18
\sec_low~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~14_combout\ = (!\mode1~input_o\ & ((\sec_low~13_combout\) # ((\current_state.ST0~q\ & \t1|toggle~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.ST0~q\,
	datab => \mode1~input_o\,
	datac => \sec_low~13_combout\,
	datad => \t1|toggle~q\,
	combout => \sec_low~14_combout\);

-- Location: LCCOMB_X41_Y32_N22
\sec_low~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~15_combout\ = (\cnt_sec_low[1]~12_combout\ & (!\cnt_sec_low[3]~7_combout\ & ((\cnt_sec_low[0]~17_combout\) # (!\cnt_sec_low[2]~2_combout\)))) # (!\cnt_sec_low[1]~12_combout\ & (\cnt_sec_low[0]~17_combout\ & (\cnt_sec_low[3]~7_combout\ $ 
-- (!\cnt_sec_low[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000000110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[1]~12_combout\,
	datab => \cnt_sec_low[3]~7_combout\,
	datac => \cnt_sec_low[0]~17_combout\,
	datad => \cnt_sec_low[2]~2_combout\,
	combout => \sec_low~15_combout\);

-- Location: LCCOMB_X40_Y32_N0
\sec_low~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~16_combout\ = (\sec_low~14_combout\) # ((\sec_low~0_combout\) # ((\mode1~input_o\ & \sec_low~15_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \sec_low~14_combout\,
	datac => \sec_low~0_combout\,
	datad => \sec_low~15_combout\,
	combout => \sec_low~16_combout\);

-- Location: LCCOMB_X40_Y32_N18
\se10|seg[6]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se10|seg[6]~2_combout\ = (in_tim_sec_low(0) & ((in_tim_sec_low(1)) # (in_tim_sec_low(3) $ (in_tim_sec_low(2))))) # (!in_tim_sec_low(0) & ((in_tim_sec_low(3)) # (in_tim_sec_low(1) $ (in_tim_sec_low(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101111010111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(3),
	datab => in_tim_sec_low(1),
	datac => in_tim_sec_low(2),
	datad => in_tim_sec_low(0),
	combout => \se10|seg[6]~2_combout\);

-- Location: LCCOMB_X41_Y32_N16
\se4|seg[6]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \se4|seg[6]~4_combout\ = (\cnt_sec_low[0]~17_combout\ & ((\cnt_sec_low[3]~7_combout\) # (\cnt_sec_low[1]~12_combout\ $ (\cnt_sec_low[2]~2_combout\)))) # (!\cnt_sec_low[0]~17_combout\ & ((\cnt_sec_low[1]~12_combout\) # (\cnt_sec_low[3]~7_combout\ $ 
-- (\cnt_sec_low[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101101111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[1]~12_combout\,
	datab => \cnt_sec_low[3]~7_combout\,
	datac => \cnt_sec_low[0]~17_combout\,
	datad => \cnt_sec_low[2]~2_combout\,
	combout => \se4|seg[6]~4_combout\);

-- Location: LCCOMB_X41_Y32_N2
\sec_low~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~17_combout\ = (\sec_low~6_combout\) # ((\mode1~input_o\ & ((!\se4|seg[6]~4_combout\))) # (!\mode1~input_o\ & (!\se10|seg[6]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000111111101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se10|seg[6]~2_combout\,
	datab => \mode1~input_o\,
	datac => \sec_low~6_combout\,
	datad => \se4|seg[6]~4_combout\,
	combout => \sec_low~17_combout\);

-- Location: LCCOMB_X34_Y34_N18
\hour_high~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~5_combout\ = (in_tim_hour_high(3) & ((in_tim_hour_high(2) & ((in_tim_hour_high(1)) # (in_tim_hour_high(0)))) # (!in_tim_hour_high(2) & (!in_tim_hour_high(1))))) # (!in_tim_hour_high(3) & ((in_tim_hour_high(1)) # (in_tim_hour_high(2) $ 
-- (in_tim_hour_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101101111010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_high(3),
	datab => in_tim_hour_high(2),
	datac => in_tim_hour_high(1),
	datad => in_tim_hour_high(0),
	combout => \hour_high~5_combout\);

-- Location: LCCOMB_X33_Y34_N6
\hour_high~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~6_combout\ = ((\t1|toggle~q\ & \current_state.HT1~q\)) # (!\hour_high~5_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datab => \current_state.HT1~q\,
	datad => \hour_high~5_combout\,
	combout => \hour_high~6_combout\);

-- Location: LCCOMB_X33_Y34_N24
\hour_high~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~4_combout\ = (\t1|toggle~q\ & (\mode1~input_o\ & \current_state.H1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datab => \mode1~input_o\,
	datad => \current_state.H1~q\,
	combout => \hour_high~4_combout\);

-- Location: LCCOMB_X34_Y34_N24
\hour_high~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~20_combout\ = (\cnt_hour_high[2]~2_combout\ & (!\cnt_hour_high[1]~12_combout\ & (\cnt_hour_high[0]~17_combout\ $ (!\cnt_hour_high[3]~7_combout\)))) # (!\cnt_hour_high[2]~2_combout\ & ((\cnt_hour_high[3]~7_combout\ & 
-- ((\cnt_hour_high[1]~12_combout\))) # (!\cnt_hour_high[3]~7_combout\ & (\cnt_hour_high[0]~17_combout\ & !\cnt_hour_high[1]~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000010000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[0]~17_combout\,
	datab => \cnt_hour_high[2]~2_combout\,
	datac => \cnt_hour_high[3]~7_combout\,
	datad => \cnt_hour_high[1]~12_combout\,
	combout => \hour_high~20_combout\);

-- Location: LCCOMB_X33_Y34_N22
\hour_high~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~7_combout\ = (\hour_high~4_combout\) # ((\mode1~input_o\ & ((\hour_high~20_combout\))) # (!\mode1~input_o\ & (\hour_high~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hour_high~6_combout\,
	datab => \hour_high~4_combout\,
	datac => \hour_high~20_combout\,
	datad => \mode1~input_o\,
	combout => \hour_high~7_combout\);

-- Location: LCCOMB_X35_Y34_N22
\se5|seg[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se5|seg[1]~0_combout\ = (\cnt_hour_high[1]~12_combout\ & ((\cnt_hour_high[0]~17_combout\ & (\cnt_hour_high[3]~7_combout\)) # (!\cnt_hour_high[0]~17_combout\ & ((\cnt_hour_high[2]~2_combout\))))) # (!\cnt_hour_high[1]~12_combout\ & 
-- (\cnt_hour_high[2]~2_combout\ & (\cnt_hour_high[0]~17_combout\ $ (\cnt_hour_high[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101011010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[0]~17_combout\,
	datab => \cnt_hour_high[1]~12_combout\,
	datac => \cnt_hour_high[3]~7_combout\,
	datad => \cnt_hour_high[2]~2_combout\,
	combout => \se5|seg[1]~0_combout\);

-- Location: LCCOMB_X36_Y35_N18
\hour_high~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~8_combout\ = (\t1|toggle~q\ & ((\mode1~input_o\ & (\current_state.H1~q\)) # (!\mode1~input_o\ & ((\current_state.HT1~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.H1~q\,
	datab => \t1|toggle~q\,
	datac => \mode1~input_o\,
	datad => \current_state.HT1~q\,
	combout => \hour_high~8_combout\);

-- Location: LCCOMB_X35_Y34_N24
\hour_high~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~9_combout\ = (in_tim_hour_high(3) & ((in_tim_hour_high(0) & (in_tim_hour_high(2))) # (!in_tim_hour_high(0) & ((in_tim_hour_high(1)))))) # (!in_tim_hour_high(3) & (in_tim_hour_high(2) & (in_tim_hour_high(0) $ (!in_tim_hour_high(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100010000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_high(2),
	datab => in_tim_hour_high(0),
	datac => in_tim_hour_high(3),
	datad => in_tim_hour_high(1),
	combout => \hour_high~9_combout\);

-- Location: LCCOMB_X35_Y34_N16
\hour_high~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~10_combout\ = (\hour_high~8_combout\) # ((\mode1~input_o\ & (\se5|seg[1]~0_combout\)) # (!\mode1~input_o\ & ((\hour_high~9_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se5|seg[1]~0_combout\,
	datab => \hour_high~8_combout\,
	datac => \mode1~input_o\,
	datad => \hour_high~9_combout\,
	combout => \hour_high~10_combout\);

-- Location: LCCOMB_X34_Y34_N14
\se5|seg[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se5|seg[2]~1_combout\ = (\cnt_hour_high[2]~2_combout\ & (\cnt_hour_high[3]~7_combout\ & ((\cnt_hour_high[1]~12_combout\) # (!\cnt_hour_high[0]~17_combout\)))) # (!\cnt_hour_high[2]~2_combout\ & (!\cnt_hour_high[0]~17_combout\ & 
-- (!\cnt_hour_high[3]~7_combout\ & \cnt_hour_high[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000101000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[0]~17_combout\,
	datab => \cnt_hour_high[2]~2_combout\,
	datac => \cnt_hour_high[3]~7_combout\,
	datad => \cnt_hour_high[1]~12_combout\,
	combout => \se5|seg[2]~1_combout\);

-- Location: LCCOMB_X35_Y34_N20
\hour_high~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~11_combout\ = (in_tim_hour_high(2) & (in_tim_hour_high(3) & ((in_tim_hour_high(0)) # (in_tim_hour_high(1))))) # (!in_tim_hour_high(2) & (in_tim_hour_high(0) & (!in_tim_hour_high(3) & in_tim_hour_high(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_high(2),
	datab => in_tim_hour_high(0),
	datac => in_tim_hour_high(3),
	datad => in_tim_hour_high(1),
	combout => \hour_high~11_combout\);

-- Location: LCCOMB_X35_Y34_N30
\hour_high~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~12_combout\ = (\hour_high~8_combout\) # ((\mode1~input_o\ & (\se5|seg[2]~1_combout\)) # (!\mode1~input_o\ & ((\hour_high~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se5|seg[2]~1_combout\,
	datab => \hour_high~8_combout\,
	datac => \mode1~input_o\,
	datad => \hour_high~11_combout\,
	combout => \hour_high~12_combout\);

-- Location: LCCOMB_X34_Y34_N10
\se11|seg[3]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se11|seg[3]~0_combout\ = (in_tim_hour_high(1) & ((in_tim_hour_high(2) & ((!in_tim_hour_high(0)))) # (!in_tim_hour_high(2) & (in_tim_hour_high(3) & in_tim_hour_high(0))))) # (!in_tim_hour_high(1) & (!in_tim_hour_high(3) & (in_tim_hour_high(2) $ 
-- (!in_tim_hour_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010010011000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_high(3),
	datab => in_tim_hour_high(2),
	datac => in_tim_hour_high(1),
	datad => in_tim_hour_high(0),
	combout => \se11|seg[3]~0_combout\);

-- Location: LCCOMB_X35_Y34_N0
\se5|seg[3]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se5|seg[3]~2_combout\ = (\cnt_hour_high[1]~12_combout\ & ((\cnt_hour_high[0]~17_combout\ & ((\cnt_hour_high[2]~2_combout\))) # (!\cnt_hour_high[0]~17_combout\ & (\cnt_hour_high[3]~7_combout\ & !\cnt_hour_high[2]~2_combout\)))) # 
-- (!\cnt_hour_high[1]~12_combout\ & (!\cnt_hour_high[3]~7_combout\ & (\cnt_hour_high[0]~17_combout\ $ (\cnt_hour_high[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100101000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[0]~17_combout\,
	datab => \cnt_hour_high[1]~12_combout\,
	datac => \cnt_hour_high[3]~7_combout\,
	datad => \cnt_hour_high[2]~2_combout\,
	combout => \se5|seg[3]~2_combout\);

-- Location: LCCOMB_X35_Y34_N2
\hour_high~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~13_combout\ = (\hour_high~8_combout\) # ((\mode1~input_o\ & ((\se5|seg[3]~2_combout\))) # (!\mode1~input_o\ & (\se11|seg[3]~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se11|seg[3]~0_combout\,
	datab => \hour_high~8_combout\,
	datac => \mode1~input_o\,
	datad => \se5|seg[3]~2_combout\,
	combout => \hour_high~13_combout\);

-- Location: LCCOMB_X35_Y34_N14
\se5|seg[4]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se5|seg[4]~3_combout\ = (\cnt_hour_high[1]~12_combout\ & (\cnt_hour_high[0]~17_combout\ & (!\cnt_hour_high[3]~7_combout\))) # (!\cnt_hour_high[1]~12_combout\ & ((\cnt_hour_high[2]~2_combout\ & ((!\cnt_hour_high[3]~7_combout\))) # 
-- (!\cnt_hour_high[2]~2_combout\ & (\cnt_hour_high[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101100101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[0]~17_combout\,
	datab => \cnt_hour_high[1]~12_combout\,
	datac => \cnt_hour_high[3]~7_combout\,
	datad => \cnt_hour_high[2]~2_combout\,
	combout => \se5|seg[4]~3_combout\);

-- Location: LCCOMB_X35_Y34_N10
\se11|seg[4]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se11|seg[4]~1_combout\ = (in_tim_hour_high(1) & (((!in_tim_hour_high(0) & !in_tim_hour_high(3))))) # (!in_tim_hour_high(1) & ((in_tim_hour_high(2) & ((!in_tim_hour_high(3)))) # (!in_tim_hour_high(2) & (!in_tim_hour_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100011011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_high(2),
	datab => in_tim_hour_high(0),
	datac => in_tim_hour_high(3),
	datad => in_tim_hour_high(1),
	combout => \se11|seg[4]~1_combout\);

-- Location: LCCOMB_X35_Y34_N18
\hour_high~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~14_combout\ = (\hour_high~8_combout\) # ((\mode1~input_o\ & (\se5|seg[4]~3_combout\)) # (!\mode1~input_o\ & ((\se11|seg[4]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se5|seg[4]~3_combout\,
	datab => \hour_high~8_combout\,
	datac => \mode1~input_o\,
	datad => \se11|seg[4]~1_combout\,
	combout => \hour_high~14_combout\);

-- Location: LCCOMB_X34_Y34_N2
\hour_high~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~15_combout\ = (in_tim_hour_high(2) & (!in_tim_hour_high(0) & (in_tim_hour_high(3) $ (in_tim_hour_high(1))))) # (!in_tim_hour_high(2) & (!in_tim_hour_high(3) & ((in_tim_hour_high(1)) # (!in_tim_hour_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000001011001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_high(3),
	datab => in_tim_hour_high(2),
	datac => in_tim_hour_high(1),
	datad => in_tim_hour_high(0),
	combout => \hour_high~15_combout\);

-- Location: LCCOMB_X33_Y34_N10
\hour_high~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~16_combout\ = (!\mode1~input_o\ & ((\hour_high~15_combout\) # ((\t1|toggle~q\ & \current_state.HT1~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datab => \mode1~input_o\,
	datac => \current_state.HT1~q\,
	datad => \hour_high~15_combout\,
	combout => \hour_high~16_combout\);

-- Location: LCCOMB_X34_Y34_N22
\hour_high~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~17_combout\ = (\cnt_hour_high[0]~17_combout\ & (\cnt_hour_high[3]~7_combout\ $ (((\cnt_hour_high[1]~12_combout\) # (!\cnt_hour_high[2]~2_combout\))))) # (!\cnt_hour_high[0]~17_combout\ & (!\cnt_hour_high[2]~2_combout\ & 
-- (!\cnt_hour_high[3]~7_combout\ & \cnt_hour_high[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101110000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[0]~17_combout\,
	datab => \cnt_hour_high[2]~2_combout\,
	datac => \cnt_hour_high[3]~7_combout\,
	datad => \cnt_hour_high[1]~12_combout\,
	combout => \hour_high~17_combout\);

-- Location: LCCOMB_X33_Y34_N26
\hour_high~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~18_combout\ = (\hour_high~16_combout\) # ((\hour_high~4_combout\) # ((\mode1~input_o\ & \hour_high~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hour_high~16_combout\,
	datab => \mode1~input_o\,
	datac => \hour_high~17_combout\,
	datad => \hour_high~4_combout\,
	combout => \hour_high~18_combout\);

-- Location: LCCOMB_X35_Y34_N4
\se5|seg[6]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \se5|seg[6]~4_combout\ = (\cnt_hour_high[0]~17_combout\ & ((\cnt_hour_high[3]~7_combout\) # (\cnt_hour_high[1]~12_combout\ $ (\cnt_hour_high[2]~2_combout\)))) # (!\cnt_hour_high[0]~17_combout\ & ((\cnt_hour_high[1]~12_combout\) # 
-- (\cnt_hour_high[3]~7_combout\ $ (\cnt_hour_high[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110011111111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_high[0]~17_combout\,
	datab => \cnt_hour_high[1]~12_combout\,
	datac => \cnt_hour_high[3]~7_combout\,
	datad => \cnt_hour_high[2]~2_combout\,
	combout => \se5|seg[6]~4_combout\);

-- Location: LCCOMB_X35_Y34_N28
\se11|seg[6]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se11|seg[6]~2_combout\ = (in_tim_hour_high(0) & ((in_tim_hour_high(1)) # (in_tim_hour_high(2) $ (in_tim_hour_high(3))))) # (!in_tim_hour_high(0) & ((in_tim_hour_high(3)) # (in_tim_hour_high(2) $ (in_tim_hour_high(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110101111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_high(2),
	datab => in_tim_hour_high(0),
	datac => in_tim_hour_high(3),
	datad => in_tim_hour_high(1),
	combout => \se11|seg[6]~2_combout\);

-- Location: LCCOMB_X35_Y34_N6
\hour_high~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_high~19_combout\ = (\hour_high~8_combout\) # ((\mode1~input_o\ & (!\se5|seg[6]~4_combout\)) # (!\mode1~input_o\ & ((!\se11|seg[6]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110011011111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se5|seg[6]~4_combout\,
	datab => \hour_high~8_combout\,
	datac => \mode1~input_o\,
	datad => \se11|seg[6]~2_combout\,
	combout => \hour_high~19_combout\);

-- Location: LCCOMB_X35_Y31_N0
\hour_low~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~3_combout\ = (\cnt_hour_low[1]~12_combout\ & (((\cnt_hour_low[3]~7_combout\ & !\cnt_hour_low[2]~2_combout\)))) # (!\cnt_hour_low[1]~12_combout\ & ((\cnt_hour_low[0]~17_combout\ & (\cnt_hour_low[3]~7_combout\ $ (!\cnt_hour_low[2]~2_combout\))) # 
-- (!\cnt_hour_low[0]~17_combout\ & (!\cnt_hour_low[3]~7_combout\ & \cnt_hour_low[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000110100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[1]~12_combout\,
	datab => \cnt_hour_low[0]~17_combout\,
	datac => \cnt_hour_low[3]~7_combout\,
	datad => \cnt_hour_low[2]~2_combout\,
	combout => \hour_low~3_combout\);

-- Location: LCCOMB_X35_Y32_N30
\hour_low~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~0_combout\ = (in_tim_hour_low(3) & ((in_tim_hour_low(2) & ((in_tim_hour_low(0)) # (in_tim_hour_low(1)))) # (!in_tim_hour_low(2) & ((!in_tim_hour_low(1)))))) # (!in_tim_hour_low(3) & ((in_tim_hour_low(1)) # (in_tim_hour_low(2) $ 
-- (in_tim_hour_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110110110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_low(3),
	datab => in_tim_hour_low(2),
	datac => in_tim_hour_low(0),
	datad => in_tim_hour_low(1),
	combout => \hour_low~0_combout\);

-- Location: LCCOMB_X36_Y32_N30
\hour_low~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~1_combout\ = (!\mode1~input_o\ & (((\current_state.HT0~q\ & \t1|toggle~q\)) # (!\hour_low~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.HT0~q\,
	datab => \t1|toggle~q\,
	datac => \mode1~input_o\,
	datad => \hour_low~0_combout\,
	combout => \hour_low~1_combout\);

-- Location: LCCOMB_X36_Y32_N24
\hour_low~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~2_combout\ = (\t1|toggle~q\ & (\mode1~input_o\ & \current_state.H0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|toggle~q\,
	datac => \mode1~input_o\,
	datad => \current_state.H0~q\,
	combout => \hour_low~2_combout\);

-- Location: LCCOMB_X36_Y32_N2
\hour_low~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~4_combout\ = (\hour_low~1_combout\) # ((\hour_low~2_combout\) # ((\mode1~input_o\ & \hour_low~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \mode1~input_o\,
	datab => \hour_low~3_combout\,
	datac => \hour_low~1_combout\,
	datad => \hour_low~2_combout\,
	combout => \hour_low~4_combout\);

-- Location: LCCOMB_X35_Y32_N6
\hour_low~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~6_combout\ = (in_tim_hour_low(3) & ((in_tim_hour_low(0) & (in_tim_hour_low(2))) # (!in_tim_hour_low(0) & ((in_tim_hour_low(1)))))) # (!in_tim_hour_low(3) & (in_tim_hour_low(2) & (in_tim_hour_low(0) $ (!in_tim_hour_low(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101010000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_low(3),
	datab => in_tim_hour_low(2),
	datac => in_tim_hour_low(0),
	datad => in_tim_hour_low(1),
	combout => \hour_low~6_combout\);

-- Location: LCCOMB_X35_Y32_N20
\se6|seg[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se6|seg[1]~0_combout\ = (\cnt_hour_low[1]~12_combout\ & ((\cnt_hour_low[0]~17_combout\ & ((\cnt_hour_low[3]~7_combout\))) # (!\cnt_hour_low[0]~17_combout\ & (\cnt_hour_low[2]~2_combout\)))) # (!\cnt_hour_low[1]~12_combout\ & (\cnt_hour_low[2]~2_combout\ 
-- & (\cnt_hour_low[0]~17_combout\ $ (\cnt_hour_low[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001000101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[2]~2_combout\,
	datab => \cnt_hour_low[0]~17_combout\,
	datac => \cnt_hour_low[1]~12_combout\,
	datad => \cnt_hour_low[3]~7_combout\,
	combout => \se6|seg[1]~0_combout\);

-- Location: LCCOMB_X36_Y32_N12
\hour_low~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~5_combout\ = (\t1|toggle~q\ & ((\mode1~input_o\ & ((\current_state.H0~q\))) # (!\mode1~input_o\ & (\current_state.HT0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100100000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.HT0~q\,
	datab => \t1|toggle~q\,
	datac => \mode1~input_o\,
	datad => \current_state.H0~q\,
	combout => \hour_low~5_combout\);

-- Location: LCCOMB_X36_Y32_N6
\hour_low~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~7_combout\ = (\hour_low~5_combout\) # ((\mode1~input_o\ & ((\se6|seg[1]~0_combout\))) # (!\mode1~input_o\ & (\hour_low~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hour_low~6_combout\,
	datab => \se6|seg[1]~0_combout\,
	datac => \mode1~input_o\,
	datad => \hour_low~5_combout\,
	combout => \hour_low~7_combout\);

-- Location: LCCOMB_X35_Y31_N2
\se6|seg[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se6|seg[2]~1_combout\ = (\cnt_hour_low[3]~7_combout\ & (\cnt_hour_low[2]~2_combout\ & ((\cnt_hour_low[1]~12_combout\) # (!\cnt_hour_low[0]~17_combout\)))) # (!\cnt_hour_low[3]~7_combout\ & (\cnt_hour_low[1]~12_combout\ & (!\cnt_hour_low[0]~17_combout\ & 
-- !\cnt_hour_low[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[1]~12_combout\,
	datab => \cnt_hour_low[0]~17_combout\,
	datac => \cnt_hour_low[3]~7_combout\,
	datad => \cnt_hour_low[2]~2_combout\,
	combout => \se6|seg[2]~1_combout\);

-- Location: LCCOMB_X35_Y32_N18
\hour_low~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~8_combout\ = (in_tim_hour_low(3) & (in_tim_hour_low(2) & ((in_tim_hour_low(0)) # (in_tim_hour_low(1))))) # (!in_tim_hour_low(3) & (!in_tim_hour_low(2) & (in_tim_hour_low(0) & in_tim_hour_low(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001100010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_low(3),
	datab => in_tim_hour_low(2),
	datac => in_tim_hour_low(0),
	datad => in_tim_hour_low(1),
	combout => \hour_low~8_combout\);

-- Location: LCCOMB_X36_Y32_N16
\hour_low~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~9_combout\ = (\hour_low~5_combout\) # ((\mode1~input_o\ & (\se6|seg[2]~1_combout\)) # (!\mode1~input_o\ & ((\hour_low~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se6|seg[2]~1_combout\,
	datab => \hour_low~8_combout\,
	datac => \mode1~input_o\,
	datad => \hour_low~5_combout\,
	combout => \hour_low~9_combout\);

-- Location: LCCOMB_X35_Y32_N0
\se12|seg[3]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se12|seg[3]~0_combout\ = (in_tim_hour_low(1) & ((in_tim_hour_low(2) & ((!in_tim_hour_low(0)))) # (!in_tim_hour_low(2) & (in_tim_hour_low(3) & in_tim_hour_low(0))))) # (!in_tim_hour_low(1) & (!in_tim_hour_low(3) & (in_tim_hour_low(2) $ 
-- (!in_tim_hour_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010110001000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_low(3),
	datab => in_tim_hour_low(2),
	datac => in_tim_hour_low(0),
	datad => in_tim_hour_low(1),
	combout => \se12|seg[3]~0_combout\);

-- Location: LCCOMB_X35_Y31_N12
\se6|seg[3]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se6|seg[3]~2_combout\ = (\cnt_hour_low[1]~12_combout\ & ((\cnt_hour_low[0]~17_combout\ & ((\cnt_hour_low[2]~2_combout\))) # (!\cnt_hour_low[0]~17_combout\ & (\cnt_hour_low[3]~7_combout\ & !\cnt_hour_low[2]~2_combout\)))) # (!\cnt_hour_low[1]~12_combout\ 
-- & (!\cnt_hour_low[3]~7_combout\ & (\cnt_hour_low[0]~17_combout\ $ (\cnt_hour_low[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100100100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[1]~12_combout\,
	datab => \cnt_hour_low[0]~17_combout\,
	datac => \cnt_hour_low[3]~7_combout\,
	datad => \cnt_hour_low[2]~2_combout\,
	combout => \se6|seg[3]~2_combout\);

-- Location: LCCOMB_X36_Y32_N26
\hour_low~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~10_combout\ = (\hour_low~5_combout\) # ((\mode1~input_o\ & ((\se6|seg[3]~2_combout\))) # (!\mode1~input_o\ & (\se12|seg[3]~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se12|seg[3]~0_combout\,
	datab => \se6|seg[3]~2_combout\,
	datac => \mode1~input_o\,
	datad => \hour_low~5_combout\,
	combout => \hour_low~10_combout\);

-- Location: LCCOMB_X35_Y31_N14
\se6|seg[4]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se6|seg[4]~3_combout\ = (\cnt_hour_low[1]~12_combout\ & (\cnt_hour_low[0]~17_combout\ & (!\cnt_hour_low[3]~7_combout\))) # (!\cnt_hour_low[1]~12_combout\ & ((\cnt_hour_low[2]~2_combout\ & ((!\cnt_hour_low[3]~7_combout\))) # (!\cnt_hour_low[2]~2_combout\ 
-- & (\cnt_hour_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110101001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[1]~12_combout\,
	datab => \cnt_hour_low[0]~17_combout\,
	datac => \cnt_hour_low[3]~7_combout\,
	datad => \cnt_hour_low[2]~2_combout\,
	combout => \se6|seg[4]~3_combout\);

-- Location: LCCOMB_X35_Y32_N22
\se12|seg[4]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se12|seg[4]~1_combout\ = (in_tim_hour_low(1) & (!in_tim_hour_low(3) & ((!in_tim_hour_low(0))))) # (!in_tim_hour_low(1) & ((in_tim_hour_low(2) & (!in_tim_hour_low(3))) # (!in_tim_hour_low(2) & ((!in_tim_hour_low(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010101000111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_low(3),
	datab => in_tim_hour_low(2),
	datac => in_tim_hour_low(0),
	datad => in_tim_hour_low(1),
	combout => \se12|seg[4]~1_combout\);

-- Location: LCCOMB_X36_Y32_N4
\hour_low~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~11_combout\ = (\hour_low~5_combout\) # ((\mode1~input_o\ & (\se6|seg[4]~3_combout\)) # (!\mode1~input_o\ & ((\se12|seg[4]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se6|seg[4]~3_combout\,
	datab => \se12|seg[4]~1_combout\,
	datac => \mode1~input_o\,
	datad => \hour_low~5_combout\,
	combout => \hour_low~11_combout\);

-- Location: LCCOMB_X35_Y31_N16
\hour_low~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~12_combout\ = (\cnt_hour_low[1]~12_combout\ & (!\cnt_hour_low[3]~7_combout\ & ((\cnt_hour_low[0]~17_combout\) # (!\cnt_hour_low[2]~2_combout\)))) # (!\cnt_hour_low[1]~12_combout\ & (\cnt_hour_low[0]~17_combout\ & (\cnt_hour_low[3]~7_combout\ $ 
-- (!\cnt_hour_low[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100100000001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[1]~12_combout\,
	datab => \cnt_hour_low[0]~17_combout\,
	datac => \cnt_hour_low[3]~7_combout\,
	datad => \cnt_hour_low[2]~2_combout\,
	combout => \hour_low~12_combout\);

-- Location: LCCOMB_X35_Y32_N16
\hour_low~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~13_combout\ = (in_tim_hour_low(2) & (!in_tim_hour_low(0) & (in_tim_hour_low(3) $ (in_tim_hour_low(1))))) # (!in_tim_hour_low(2) & (!in_tim_hour_low(3) & ((in_tim_hour_low(1)) # (!in_tim_hour_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001010100001001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_low(3),
	datab => in_tim_hour_low(2),
	datac => in_tim_hour_low(0),
	datad => in_tim_hour_low(1),
	combout => \hour_low~13_combout\);

-- Location: LCCOMB_X36_Y32_N14
\hour_low~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~14_combout\ = (\hour_low~13_combout\) # ((\current_state.HT0~q\ & \t1|toggle~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.HT0~q\,
	datac => \t1|toggle~q\,
	datad => \hour_low~13_combout\,
	combout => \hour_low~14_combout\);

-- Location: LCCOMB_X36_Y32_N8
\hour_low~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~15_combout\ = (\hour_low~2_combout\) # ((\mode1~input_o\ & (\hour_low~12_combout\)) # (!\mode1~input_o\ & ((\hour_low~14_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \hour_low~12_combout\,
	datab => \hour_low~14_combout\,
	datac => \mode1~input_o\,
	datad => \hour_low~2_combout\,
	combout => \hour_low~15_combout\);

-- Location: LCCOMB_X35_Y31_N26
\se6|seg[6]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \se6|seg[6]~4_combout\ = (\cnt_hour_low[0]~17_combout\ & ((\cnt_hour_low[3]~7_combout\) # (\cnt_hour_low[1]~12_combout\ $ (\cnt_hour_low[2]~2_combout\)))) # (!\cnt_hour_low[0]~17_combout\ & ((\cnt_hour_low[1]~12_combout\) # (\cnt_hour_low[3]~7_combout\ $ 
-- (\cnt_hour_low[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110011111111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_hour_low[1]~12_combout\,
	datab => \cnt_hour_low[0]~17_combout\,
	datac => \cnt_hour_low[3]~7_combout\,
	datad => \cnt_hour_low[2]~2_combout\,
	combout => \se6|seg[6]~4_combout\);

-- Location: LCCOMB_X35_Y32_N4
\se12|seg[6]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se12|seg[6]~2_combout\ = (in_tim_hour_low(0) & ((in_tim_hour_low(1)) # (in_tim_hour_low(3) $ (in_tim_hour_low(2))))) # (!in_tim_hour_low(0) & ((in_tim_hour_low(3)) # (in_tim_hour_low(2) $ (in_tim_hour_low(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101101101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_hour_low(3),
	datab => in_tim_hour_low(2),
	datac => in_tim_hour_low(0),
	datad => in_tim_hour_low(1),
	combout => \se12|seg[6]~2_combout\);

-- Location: LCCOMB_X36_Y32_N10
\hour_low~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \hour_low~16_combout\ = (\hour_low~5_combout\) # ((\mode1~input_o\ & (!\se6|seg[6]~4_combout\)) # (!\mode1~input_o\ & ((!\se12|seg[6]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111101010011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se6|seg[6]~4_combout\,
	datab => \se12|seg[6]~2_combout\,
	datac => \mode1~input_o\,
	datad => \hour_low~5_combout\,
	combout => \hour_low~16_combout\);

ww_led1 <= \led1~output_o\;

ww_led2 <= \led2~output_o\;

ww_led3 <= \led3~output_o\;

ww_led4 <= \led4~output_o\;

ww_led5 <= \led5~output_o\;

ww_led6 <= \led6~output_o\;

ww_led7 <= \led7~output_o\;

ww_led8 <= \led8~output_o\;

ww_led9 <= \led9~output_o\;

ww_led10 <= \led10~output_o\;

ww_led11 <= \led11~output_o\;

ww_led12 <= \led12~output_o\;

ww_led13 <= \led13~output_o\;

ww_led14 <= \led14~output_o\;

ww_led_flash <= \led_flash~output_o\;

ww_min_high(0) <= \min_high[0]~output_o\;

ww_min_high(1) <= \min_high[1]~output_o\;

ww_min_high(2) <= \min_high[2]~output_o\;

ww_min_high(3) <= \min_high[3]~output_o\;

ww_min_high(4) <= \min_high[4]~output_o\;

ww_min_high(5) <= \min_high[5]~output_o\;

ww_min_high(6) <= \min_high[6]~output_o\;

ww_min_low(0) <= \min_low[0]~output_o\;

ww_min_low(1) <= \min_low[1]~output_o\;

ww_min_low(2) <= \min_low[2]~output_o\;

ww_min_low(3) <= \min_low[3]~output_o\;

ww_min_low(4) <= \min_low[4]~output_o\;

ww_min_low(5) <= \min_low[5]~output_o\;

ww_min_low(6) <= \min_low[6]~output_o\;

ww_sec_high(0) <= \sec_high[0]~output_o\;

ww_sec_high(1) <= \sec_high[1]~output_o\;

ww_sec_high(2) <= \sec_high[2]~output_o\;

ww_sec_high(3) <= \sec_high[3]~output_o\;

ww_sec_high(4) <= \sec_high[4]~output_o\;

ww_sec_high(5) <= \sec_high[5]~output_o\;

ww_sec_high(6) <= \sec_high[6]~output_o\;

ww_sec_low(0) <= \sec_low[0]~output_o\;

ww_sec_low(1) <= \sec_low[1]~output_o\;

ww_sec_low(2) <= \sec_low[2]~output_o\;

ww_sec_low(3) <= \sec_low[3]~output_o\;

ww_sec_low(4) <= \sec_low[4]~output_o\;

ww_sec_low(5) <= \sec_low[5]~output_o\;

ww_sec_low(6) <= \sec_low[6]~output_o\;

ww_hour_high(0) <= \hour_high[0]~output_o\;

ww_hour_high(1) <= \hour_high[1]~output_o\;

ww_hour_high(2) <= \hour_high[2]~output_o\;

ww_hour_high(3) <= \hour_high[3]~output_o\;

ww_hour_high(4) <= \hour_high[4]~output_o\;

ww_hour_high(5) <= \hour_high[5]~output_o\;

ww_hour_high(6) <= \hour_high[6]~output_o\;

ww_hour_low(0) <= \hour_low[0]~output_o\;

ww_hour_low(1) <= \hour_low[1]~output_o\;

ww_hour_low(2) <= \hour_low[2]~output_o\;

ww_hour_low(3) <= \hour_low[3]~output_o\;

ww_hour_low(4) <= \hour_low[4]~output_o\;

ww_hour_low(5) <= \hour_low[5]~output_o\;

ww_hour_low(6) <= \hour_low[6]~output_o\;
END structure;


