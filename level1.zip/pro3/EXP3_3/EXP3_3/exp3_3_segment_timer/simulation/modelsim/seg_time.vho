-- Copyright (C) 2018  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 18.0.0 Build 614 04/24/2018 SJ Standard Edition"

-- DATE "05/16/2025 16:44:03"

-- 
-- Device: Altera EP4CE115F29C7 Package FBGA780
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY CYCLONEIVE;
LIBRARY IEEE;
USE CYCLONEIVE.CYCLONEIVE_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	hard_block IS
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic
	);
END hard_block;

-- Design Ports Information
-- ~ALTERA_ASDO_DATA1~	=>  Location: PIN_F4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_FLASH_nCE_nCSO~	=>  Location: PIN_E2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_DCLK~	=>  Location: PIN_P3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_DATA0~	=>  Location: PIN_N7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_nCEO~	=>  Location: PIN_P28,	 I/O Standard: 2.5 V,	 Current Strength: 8mA


ARCHITECTURE structure OF hard_block IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL \~ALTERA_ASDO_DATA1~~padout\ : std_logic;
SIGNAL \~ALTERA_FLASH_nCE_nCSO~~padout\ : std_logic;
SIGNAL \~ALTERA_DATA0~~padout\ : std_logic;
SIGNAL \~ALTERA_ASDO_DATA1~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_FLASH_nCE_nCSO~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_DATA0~~ibuf_o\ : std_logic;

BEGIN

ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
END structure;


LIBRARY ALTERA;
LIBRARY CYCLONEIVE;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIVE.CYCLONEIVE_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	seg_time IS
    PORT (
	clk : IN std_logic;
	en : IN std_logic;
	ct1_btn : IN std_logic;
	ct2_btn : IN std_logic;
	inc_btn : IN std_logic;
	done_btn : IN std_logic;
	led1 : OUT std_logic;
	led2 : OUT std_logic;
	led3 : OUT std_logic;
	led4 : OUT std_logic;
	led5 : OUT std_logic;
	led6 : OUT std_logic;
	led7 : OUT std_logic;
	led8 : OUT std_logic;
	led9 : OUT std_logic;
	led10 : OUT std_logic;
	led_flash : OUT std_logic;
	min_high : OUT std_logic_vector(6 DOWNTO 0);
	min_low : OUT std_logic_vector(6 DOWNTO 0);
	sec_high : OUT std_logic_vector(6 DOWNTO 0);
	sec_low : OUT std_logic_vector(6 DOWNTO 0);
	tim_min_high : OUT std_logic_vector(6 DOWNTO 0);
	tim_min_low : OUT std_logic_vector(6 DOWNTO 0);
	tim_sec_high : OUT std_logic_vector(6 DOWNTO 0);
	tim_sec_low : OUT std_logic_vector(6 DOWNTO 0)
	);
END seg_time;

-- Design Ports Information
-- led1	=>  Location: PIN_G19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led2	=>  Location: PIN_F19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led3	=>  Location: PIN_E19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led4	=>  Location: PIN_F21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led5	=>  Location: PIN_F18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led6	=>  Location: PIN_E18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led7	=>  Location: PIN_J19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led8	=>  Location: PIN_H19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led9	=>  Location: PIN_J17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led10	=>  Location: PIN_E21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led_flash	=>  Location: PIN_E22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_high[0]	=>  Location: PIN_AD17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_high[1]	=>  Location: PIN_AE17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_high[2]	=>  Location: PIN_AG17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_high[3]	=>  Location: PIN_AH17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_high[4]	=>  Location: PIN_AF17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_high[5]	=>  Location: PIN_AG18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_high[6]	=>  Location: PIN_AA14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_low[0]	=>  Location: PIN_AA17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_low[1]	=>  Location: PIN_AB16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_low[2]	=>  Location: PIN_AA16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_low[3]	=>  Location: PIN_AB17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_low[4]	=>  Location: PIN_AB15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_low[5]	=>  Location: PIN_AA15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- min_low[6]	=>  Location: PIN_AC17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_high[0]	=>  Location: PIN_AD18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_high[1]	=>  Location: PIN_AC18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_high[2]	=>  Location: PIN_AB18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_high[3]	=>  Location: PIN_AH19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_high[4]	=>  Location: PIN_AG19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_high[5]	=>  Location: PIN_AF18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_high[6]	=>  Location: PIN_AH18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_low[0]	=>  Location: PIN_AB19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_low[1]	=>  Location: PIN_AA19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_low[2]	=>  Location: PIN_AG21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_low[3]	=>  Location: PIN_AH21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_low[4]	=>  Location: PIN_AE19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_low[5]	=>  Location: PIN_AF19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sec_low[6]	=>  Location: PIN_AE18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_min_high[0]	=>  Location: PIN_V21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_min_high[1]	=>  Location: PIN_U21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_min_high[2]	=>  Location: PIN_AB20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_min_high[3]	=>  Location: PIN_AA21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_min_high[4]	=>  Location: PIN_AD24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_min_high[5]	=>  Location: PIN_AF23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_min_high[6]	=>  Location: PIN_Y19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_min_low[0]	=>  Location: PIN_AA25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_min_low[1]	=>  Location: PIN_AA26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_min_low[2]	=>  Location: PIN_Y25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_min_low[3]	=>  Location: PIN_W26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_min_low[4]	=>  Location: PIN_Y26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_min_low[5]	=>  Location: PIN_W27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_min_low[6]	=>  Location: PIN_W28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_sec_high[0]	=>  Location: PIN_M24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_sec_high[1]	=>  Location: PIN_Y22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_sec_high[2]	=>  Location: PIN_W21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_sec_high[3]	=>  Location: PIN_W22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_sec_high[4]	=>  Location: PIN_W25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_sec_high[5]	=>  Location: PIN_U23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_sec_high[6]	=>  Location: PIN_U24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_sec_low[0]	=>  Location: PIN_G18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_sec_low[1]	=>  Location: PIN_F22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_sec_low[2]	=>  Location: PIN_E17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_sec_low[3]	=>  Location: PIN_L26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_sec_low[4]	=>  Location: PIN_L25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_sec_low[5]	=>  Location: PIN_J22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tim_sec_low[6]	=>  Location: PIN_H22,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk	=>  Location: PIN_Y2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- en	=>  Location: PIN_AB28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- done_btn	=>  Location: PIN_N21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ct1_btn	=>  Location: PIN_M23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ct2_btn	=>  Location: PIN_M21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- inc_btn	=>  Location: PIN_R24,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF seg_time IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk : std_logic;
SIGNAL ww_en : std_logic;
SIGNAL ww_ct1_btn : std_logic;
SIGNAL ww_ct2_btn : std_logic;
SIGNAL ww_inc_btn : std_logic;
SIGNAL ww_done_btn : std_logic;
SIGNAL ww_led1 : std_logic;
SIGNAL ww_led2 : std_logic;
SIGNAL ww_led3 : std_logic;
SIGNAL ww_led4 : std_logic;
SIGNAL ww_led5 : std_logic;
SIGNAL ww_led6 : std_logic;
SIGNAL ww_led7 : std_logic;
SIGNAL ww_led8 : std_logic;
SIGNAL ww_led9 : std_logic;
SIGNAL ww_led10 : std_logic;
SIGNAL ww_led_flash : std_logic;
SIGNAL ww_min_high : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_min_low : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_sec_high : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_sec_low : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_tim_min_high : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_tim_min_low : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_tim_sec_high : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_tim_sec_low : std_logic_vector(6 DOWNTO 0);
SIGNAL \clk~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \cnt_min_high[2]~0clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \led1~output_o\ : std_logic;
SIGNAL \led2~output_o\ : std_logic;
SIGNAL \led3~output_o\ : std_logic;
SIGNAL \led4~output_o\ : std_logic;
SIGNAL \led5~output_o\ : std_logic;
SIGNAL \led6~output_o\ : std_logic;
SIGNAL \led7~output_o\ : std_logic;
SIGNAL \led8~output_o\ : std_logic;
SIGNAL \led9~output_o\ : std_logic;
SIGNAL \led10~output_o\ : std_logic;
SIGNAL \led_flash~output_o\ : std_logic;
SIGNAL \min_high[0]~output_o\ : std_logic;
SIGNAL \min_high[1]~output_o\ : std_logic;
SIGNAL \min_high[2]~output_o\ : std_logic;
SIGNAL \min_high[3]~output_o\ : std_logic;
SIGNAL \min_high[4]~output_o\ : std_logic;
SIGNAL \min_high[5]~output_o\ : std_logic;
SIGNAL \min_high[6]~output_o\ : std_logic;
SIGNAL \min_low[0]~output_o\ : std_logic;
SIGNAL \min_low[1]~output_o\ : std_logic;
SIGNAL \min_low[2]~output_o\ : std_logic;
SIGNAL \min_low[3]~output_o\ : std_logic;
SIGNAL \min_low[4]~output_o\ : std_logic;
SIGNAL \min_low[5]~output_o\ : std_logic;
SIGNAL \min_low[6]~output_o\ : std_logic;
SIGNAL \sec_high[0]~output_o\ : std_logic;
SIGNAL \sec_high[1]~output_o\ : std_logic;
SIGNAL \sec_high[2]~output_o\ : std_logic;
SIGNAL \sec_high[3]~output_o\ : std_logic;
SIGNAL \sec_high[4]~output_o\ : std_logic;
SIGNAL \sec_high[5]~output_o\ : std_logic;
SIGNAL \sec_high[6]~output_o\ : std_logic;
SIGNAL \sec_low[0]~output_o\ : std_logic;
SIGNAL \sec_low[1]~output_o\ : std_logic;
SIGNAL \sec_low[2]~output_o\ : std_logic;
SIGNAL \sec_low[3]~output_o\ : std_logic;
SIGNAL \sec_low[4]~output_o\ : std_logic;
SIGNAL \sec_low[5]~output_o\ : std_logic;
SIGNAL \sec_low[6]~output_o\ : std_logic;
SIGNAL \tim_min_high[0]~output_o\ : std_logic;
SIGNAL \tim_min_high[1]~output_o\ : std_logic;
SIGNAL \tim_min_high[2]~output_o\ : std_logic;
SIGNAL \tim_min_high[3]~output_o\ : std_logic;
SIGNAL \tim_min_high[4]~output_o\ : std_logic;
SIGNAL \tim_min_high[5]~output_o\ : std_logic;
SIGNAL \tim_min_high[6]~output_o\ : std_logic;
SIGNAL \tim_min_low[0]~output_o\ : std_logic;
SIGNAL \tim_min_low[1]~output_o\ : std_logic;
SIGNAL \tim_min_low[2]~output_o\ : std_logic;
SIGNAL \tim_min_low[3]~output_o\ : std_logic;
SIGNAL \tim_min_low[4]~output_o\ : std_logic;
SIGNAL \tim_min_low[5]~output_o\ : std_logic;
SIGNAL \tim_min_low[6]~output_o\ : std_logic;
SIGNAL \tim_sec_high[0]~output_o\ : std_logic;
SIGNAL \tim_sec_high[1]~output_o\ : std_logic;
SIGNAL \tim_sec_high[2]~output_o\ : std_logic;
SIGNAL \tim_sec_high[3]~output_o\ : std_logic;
SIGNAL \tim_sec_high[4]~output_o\ : std_logic;
SIGNAL \tim_sec_high[5]~output_o\ : std_logic;
SIGNAL \tim_sec_high[6]~output_o\ : std_logic;
SIGNAL \tim_sec_low[0]~output_o\ : std_logic;
SIGNAL \tim_sec_low[1]~output_o\ : std_logic;
SIGNAL \tim_sec_low[2]~output_o\ : std_logic;
SIGNAL \tim_sec_low[3]~output_o\ : std_logic;
SIGNAL \tim_sec_low[4]~output_o\ : std_logic;
SIGNAL \tim_sec_low[5]~output_o\ : std_logic;
SIGNAL \tim_sec_low[6]~output_o\ : std_logic;
SIGNAL \clk~input_o\ : std_logic;
SIGNAL \clk~inputclkctrl_outclk\ : std_logic;
SIGNAL \done_btn~input_o\ : std_logic;
SIGNAL \bt4|btn_sync~q\ : std_logic;
SIGNAL \ct2_btn~input_o\ : std_logic;
SIGNAL \bt2|btn_sync~q\ : std_logic;
SIGNAL \bt2|btn_delay~q\ : std_logic;
SIGNAL \ct1_btn~input_o\ : std_logic;
SIGNAL \bt1|btn_sync~q\ : std_logic;
SIGNAL \bt1|btn_delay~q\ : std_logic;
SIGNAL \Selector0~6_combout\ : std_logic;
SIGNAL \bt2|trig~combout\ : std_logic;
SIGNAL \bt4|btn_delay~q\ : std_logic;
SIGNAL \next_state~1_combout\ : std_logic;
SIGNAL \Selector5~0_combout\ : std_logic;
SIGNAL \en~input_o\ : std_logic;
SIGNAL \current_state.ST0~q\ : std_logic;
SIGNAL \Selector6~0_combout\ : std_logic;
SIGNAL \current_state.ST1~q\ : std_logic;
SIGNAL \Selector7~0_combout\ : std_logic;
SIGNAL \current_state.MT0~q\ : std_logic;
SIGNAL \Selector0~1_combout\ : std_logic;
SIGNAL \bt1|trig~combout\ : std_logic;
SIGNAL \Selector1~0_combout\ : std_logic;
SIGNAL \next_state~0_combout\ : std_logic;
SIGNAL \current_state.S0~q\ : std_logic;
SIGNAL \Selector2~0_combout\ : std_logic;
SIGNAL \current_state.S1~q\ : std_logic;
SIGNAL \Selector3~0_combout\ : std_logic;
SIGNAL \current_state.M0~q\ : std_logic;
SIGNAL \Selector0~0_combout\ : std_logic;
SIGNAL \Selector0~2_combout\ : std_logic;
SIGNAL \current_state.IDLE~0_combout\ : std_logic;
SIGNAL \current_state.IDLE~q\ : std_logic;
SIGNAL \Selector0~4_combout\ : std_logic;
SIGNAL \Selector4~0_combout\ : std_logic;
SIGNAL \current_state.M1~q\ : std_logic;
SIGNAL \Selector8~0_combout\ : std_logic;
SIGNAL \current_state.MT1~q\ : std_logic;
SIGNAL \Selector0~3_combout\ : std_logic;
SIGNAL \Selector0~5_combout\ : std_logic;
SIGNAL \current_state.INC~q\ : std_logic;
SIGNAL \t1|toggle~0_combout\ : std_logic;
SIGNAL \t1|Add0~0_combout\ : std_logic;
SIGNAL \t1|Add0~1\ : std_logic;
SIGNAL \t1|Add0~2_combout\ : std_logic;
SIGNAL \t1|Add0~3\ : std_logic;
SIGNAL \t1|Add0~4_combout\ : std_logic;
SIGNAL \t1|Add0~5\ : std_logic;
SIGNAL \t1|Add0~6_combout\ : std_logic;
SIGNAL \t1|Add0~7\ : std_logic;
SIGNAL \t1|Add0~8_combout\ : std_logic;
SIGNAL \t1|Add0~9\ : std_logic;
SIGNAL \t1|Add0~10_combout\ : std_logic;
SIGNAL \t1|Add0~11\ : std_logic;
SIGNAL \t1|Add0~12_combout\ : std_logic;
SIGNAL \t1|Add0~13\ : std_logic;
SIGNAL \t1|Add0~14_combout\ : std_logic;
SIGNAL \t1|count~2_combout\ : std_logic;
SIGNAL \t1|Add0~15\ : std_logic;
SIGNAL \t1|Add0~16_combout\ : std_logic;
SIGNAL \t1|Add0~17\ : std_logic;
SIGNAL \t1|Add0~18_combout\ : std_logic;
SIGNAL \t1|Add0~19\ : std_logic;
SIGNAL \t1|Add0~20_combout\ : std_logic;
SIGNAL \t1|Add0~21\ : std_logic;
SIGNAL \t1|Add0~22_combout\ : std_logic;
SIGNAL \t1|Add0~23\ : std_logic;
SIGNAL \t1|Add0~24_combout\ : std_logic;
SIGNAL \t1|count~1_combout\ : std_logic;
SIGNAL \t1|Add0~25\ : std_logic;
SIGNAL \t1|Add0~26_combout\ : std_logic;
SIGNAL \t1|count~0_combout\ : std_logic;
SIGNAL \t1|Add0~27\ : std_logic;
SIGNAL \t1|Add0~28_combout\ : std_logic;
SIGNAL \t1|count~3_combout\ : std_logic;
SIGNAL \t1|Add0~29\ : std_logic;
SIGNAL \t1|Add0~30_combout\ : std_logic;
SIGNAL \t1|count~4_combout\ : std_logic;
SIGNAL \t1|Add0~31\ : std_logic;
SIGNAL \t1|Add0~32_combout\ : std_logic;
SIGNAL \t1|Add0~33\ : std_logic;
SIGNAL \t1|Add0~34_combout\ : std_logic;
SIGNAL \t1|count~5_combout\ : std_logic;
SIGNAL \t1|Add0~35\ : std_logic;
SIGNAL \t1|Add0~36_combout\ : std_logic;
SIGNAL \t1|Add0~37\ : std_logic;
SIGNAL \t1|Add0~38_combout\ : std_logic;
SIGNAL \t1|count~6_combout\ : std_logic;
SIGNAL \t1|Add0~39\ : std_logic;
SIGNAL \t1|Add0~40_combout\ : std_logic;
SIGNAL \t1|count~7_combout\ : std_logic;
SIGNAL \t1|Add0~41\ : std_logic;
SIGNAL \t1|Add0~42_combout\ : std_logic;
SIGNAL \t1|count~8_combout\ : std_logic;
SIGNAL \t1|Add0~43\ : std_logic;
SIGNAL \t1|Add0~44_combout\ : std_logic;
SIGNAL \t1|count~9_combout\ : std_logic;
SIGNAL \t1|Add0~45\ : std_logic;
SIGNAL \t1|Add0~46_combout\ : std_logic;
SIGNAL \t1|count~10_combout\ : std_logic;
SIGNAL \t1|Equal0~6_combout\ : std_logic;
SIGNAL \t1|Equal0~3_combout\ : std_logic;
SIGNAL \t1|Equal0~1_combout\ : std_logic;
SIGNAL \t1|Equal0~2_combout\ : std_logic;
SIGNAL \t1|Equal0~0_combout\ : std_logic;
SIGNAL \t1|Equal0~4_combout\ : std_logic;
SIGNAL \t1|Add0~47\ : std_logic;
SIGNAL \t1|Add0~48_combout\ : std_logic;
SIGNAL \t1|Add0~49\ : std_logic;
SIGNAL \t1|Add0~50_combout\ : std_logic;
SIGNAL \t1|count~11_combout\ : std_logic;
SIGNAL \t1|Equal0~7_combout\ : std_logic;
SIGNAL \t1|Equal0~5_combout\ : std_logic;
SIGNAL \t1|Equal0~8_combout\ : std_logic;
SIGNAL \t1|toggle~q\ : std_logic;
SIGNAL \in_min_low[0]~13_combout\ : std_logic;
SIGNAL \in_min_low[0]~15_combout\ : std_logic;
SIGNAL \inc_btn~input_o\ : std_logic;
SIGNAL \bt3|btn_sync~feeder_combout\ : std_logic;
SIGNAL \bt3|btn_sync~q\ : std_logic;
SIGNAL \bt3|btn_delay~feeder_combout\ : std_logic;
SIGNAL \bt3|btn_delay~q\ : std_logic;
SIGNAL \bt3|trig~combout\ : std_logic;
SIGNAL \in_min_low[0]~_emulated_q\ : std_logic;
SIGNAL \in_min_low[0]~14_combout\ : std_logic;
SIGNAL \cnt_min_low~29_combout\ : std_logic;
SIGNAL \cnt_sec_low[3]~28_combout\ : std_logic;
SIGNAL \cnt_min_low[0]~16_combout\ : std_logic;
SIGNAL \cnt_min_low[0]~19_combout\ : std_logic;
SIGNAL \cnt_min_high[2]~0_combout\ : std_logic;
SIGNAL \cnt_min_high[2]~0clkctrl_outclk\ : std_logic;
SIGNAL \in_sec_low[1]~9_combout\ : std_logic;
SIGNAL \cnt_sec_low~30_combout\ : std_logic;
SIGNAL \cnt_sec_low[0]~16_combout\ : std_logic;
SIGNAL \cnt_sec_low[0]~19_combout\ : std_logic;
SIGNAL \cnt_sec_low[0]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_low[0]~18_combout\ : std_logic;
SIGNAL \cnt_sec_low[0]~17_combout\ : std_logic;
SIGNAL \in_sec_low[0]~13_combout\ : std_logic;
SIGNAL \in_sec_low[0]~15_combout\ : std_logic;
SIGNAL \in_sec_low[0]~_emulated_q\ : std_logic;
SIGNAL \in_sec_low[0]~14_combout\ : std_logic;
SIGNAL \cnt_sec_low~31_combout\ : std_logic;
SIGNAL \Add0~0_combout\ : std_logic;
SIGNAL \in_sec_low[2]~1_combout\ : std_logic;
SIGNAL \in_sec_low[2]~3_combout\ : std_logic;
SIGNAL \in_sec_low[2]~_emulated_q\ : std_logic;
SIGNAL \in_sec_low[2]~2_combout\ : std_logic;
SIGNAL \cnt_sec_low~29_combout\ : std_logic;
SIGNAL \cnt_sec_low[2]~1_combout\ : std_logic;
SIGNAL \cnt_sec_low[2]~4_combout\ : std_logic;
SIGNAL \cnt_sec_low[2]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_low[2]~3_combout\ : std_logic;
SIGNAL \cnt_sec_low[2]~2_combout\ : std_logic;
SIGNAL \Add1~0_combout\ : std_logic;
SIGNAL \cnt_sec_low[3]~6_combout\ : std_logic;
SIGNAL \cnt_sec_low[3]~9_combout\ : std_logic;
SIGNAL \cnt_sec_low[3]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_low[3]~8_combout\ : std_logic;
SIGNAL \cnt_sec_low[3]~7_combout\ : std_logic;
SIGNAL \in_sec_low[3]~5_combout\ : std_logic;
SIGNAL \Add0~1_combout\ : std_logic;
SIGNAL \in_sec_low[3]~7_combout\ : std_logic;
SIGNAL \in_sec_low[3]~_emulated_q\ : std_logic;
SIGNAL \in_sec_low[3]~6_combout\ : std_logic;
SIGNAL \Equal0~0_combout\ : std_logic;
SIGNAL \in_sec_low[1]~11_combout\ : std_logic;
SIGNAL \in_sec_low[1]~_emulated_q\ : std_logic;
SIGNAL \in_sec_low[1]~10_combout\ : std_logic;
SIGNAL \cnt_sec_low~32_combout\ : std_logic;
SIGNAL \cnt_sec_low[1]~11_combout\ : std_logic;
SIGNAL \se4|Equal15~1_combout\ : std_logic;
SIGNAL \cnt_sec_low[1]~14_combout\ : std_logic;
SIGNAL \cnt_sec_low[1]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_low[1]~13_combout\ : std_logic;
SIGNAL \cnt_sec_low[1]~12_combout\ : std_logic;
SIGNAL \se4|Equal15~0_combout\ : std_logic;
SIGNAL \in_sec_high[0]~13_combout\ : std_logic;
SIGNAL \in_sec_high[0]~15_combout\ : std_logic;
SIGNAL \in_sec_high[0]~_emulated_q\ : std_logic;
SIGNAL \in_sec_high[0]~14_combout\ : std_logic;
SIGNAL \cnt_sec_high~29_combout\ : std_logic;
SIGNAL \cnt_sec_high[0]~16_combout\ : std_logic;
SIGNAL \cnt_sec_high[0]~19_combout\ : std_logic;
SIGNAL \cnt_sec_high[0]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_high[0]~18_combout\ : std_logic;
SIGNAL \cnt_sec_high[0]~17_combout\ : std_logic;
SIGNAL \cnt_sec_high~32_combout\ : std_logic;
SIGNAL \cnt_sec_high[1]~11_combout\ : std_logic;
SIGNAL \in_sec_high[3]~5_combout\ : std_logic;
SIGNAL \in_sec_high[3]~22_combout\ : std_logic;
SIGNAL \Add2~0_combout\ : std_logic;
SIGNAL \in_sec_high[3]~7_combout\ : std_logic;
SIGNAL \in_sec_high[3]~_emulated_q\ : std_logic;
SIGNAL \in_sec_high[3]~6_combout\ : std_logic;
SIGNAL \cnt_sec_high~31_combout\ : std_logic;
SIGNAL \cnt_sec_high[3]~6_combout\ : std_logic;
SIGNAL \se3|seg[1]~4_combout\ : std_logic;
SIGNAL \cnt_sec_high[3]~30_combout\ : std_logic;
SIGNAL \cnt_sec_high[3]~9_combout\ : std_logic;
SIGNAL \cnt_sec_high[3]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_high[3]~8_combout\ : std_logic;
SIGNAL \cnt_sec_high[3]~7_combout\ : std_logic;
SIGNAL \se3|Equal15~1_combout\ : std_logic;
SIGNAL \cnt_sec_high[1]~14_combout\ : std_logic;
SIGNAL \cnt_sec_high[1]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_high[1]~13_combout\ : std_logic;
SIGNAL \cnt_sec_high[1]~12_combout\ : std_logic;
SIGNAL \in_sec_high[1]~9_combout\ : std_logic;
SIGNAL \in_sec_high[1]~11_combout\ : std_logic;
SIGNAL \in_sec_high[1]~_emulated_q\ : std_logic;
SIGNAL \in_sec_high[1]~10_combout\ : std_logic;
SIGNAL \Equal2~0_combout\ : std_logic;
SIGNAL \in_sec_high[2]~1_combout\ : std_logic;
SIGNAL \in_sec_high[2]~3_combout\ : std_logic;
SIGNAL \in_sec_high[2]~_emulated_q\ : std_logic;
SIGNAL \in_sec_high[2]~2_combout\ : std_logic;
SIGNAL \cnt_sec_high~28_combout\ : std_logic;
SIGNAL \cnt_sec_high[2]~1_combout\ : std_logic;
SIGNAL \cnt_sec_high[2]~4_combout\ : std_logic;
SIGNAL \cnt_sec_high[2]~_emulated_q\ : std_logic;
SIGNAL \cnt_sec_high[2]~3_combout\ : std_logic;
SIGNAL \cnt_sec_high[2]~2_combout\ : std_logic;
SIGNAL \se3|Equal15~0_combout\ : std_logic;
SIGNAL \process_7~0_combout\ : std_logic;
SIGNAL \cnt_min_low[0]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_low[0]~18_combout\ : std_logic;
SIGNAL \cnt_min_low[0]~17_combout\ : std_logic;
SIGNAL \in_tim_min_low[0]~4_combout\ : std_logic;
SIGNAL \in_tim_min_low[0]~0_combout\ : std_logic;
SIGNAL \Equal14~0_combout\ : std_logic;
SIGNAL \in_min_low[1]~9_combout\ : std_logic;
SIGNAL \cnt_min_low~30_combout\ : std_logic;
SIGNAL \in_min_low[2]~1_combout\ : std_logic;
SIGNAL \Add4~0_combout\ : std_logic;
SIGNAL \in_min_low[2]~3_combout\ : std_logic;
SIGNAL \in_min_low[2]~_emulated_q\ : std_logic;
SIGNAL \in_min_low[2]~2_combout\ : std_logic;
SIGNAL \cnt_min_low~28_combout\ : std_logic;
SIGNAL \se2|seg[1]~4_combout\ : std_logic;
SIGNAL \cnt_min_low[2]~1_combout\ : std_logic;
SIGNAL \cnt_min_low[2]~4_combout\ : std_logic;
SIGNAL \cnt_min_low[2]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_low[2]~3_combout\ : std_logic;
SIGNAL \cnt_min_low[2]~2_combout\ : std_logic;
SIGNAL \Add5~0_combout\ : std_logic;
SIGNAL \cnt_min_low[3]~6_combout\ : std_logic;
SIGNAL \se2|Equal15~0_combout\ : std_logic;
SIGNAL \cnt_min_low[3]~9_combout\ : std_logic;
SIGNAL \cnt_min_low[3]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_low[3]~8_combout\ : std_logic;
SIGNAL \cnt_min_low[3]~7_combout\ : std_logic;
SIGNAL \in_min_low[3]~5_combout\ : std_logic;
SIGNAL \Add4~1_combout\ : std_logic;
SIGNAL \in_min_low[3]~7_combout\ : std_logic;
SIGNAL \in_min_low[3]~_emulated_q\ : std_logic;
SIGNAL \in_min_low[3]~6_combout\ : std_logic;
SIGNAL \Equal4~0_combout\ : std_logic;
SIGNAL \in_min_low[1]~11_combout\ : std_logic;
SIGNAL \in_min_low[1]~_emulated_q\ : std_logic;
SIGNAL \in_min_low[1]~10_combout\ : std_logic;
SIGNAL \cnt_min_low~31_combout\ : std_logic;
SIGNAL \cnt_min_low[1]~11_combout\ : std_logic;
SIGNAL \se2|Equal15~1_combout\ : std_logic;
SIGNAL \cnt_min_low[1]~14_combout\ : std_logic;
SIGNAL \cnt_min_low[1]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_low[1]~13_combout\ : std_logic;
SIGNAL \cnt_min_low[1]~12_combout\ : std_logic;
SIGNAL \in_tim_min_low~2_combout\ : std_logic;
SIGNAL \in_tim_min_low~3_combout\ : std_logic;
SIGNAL \in_tim_min_low[2]~1_combout\ : std_logic;
SIGNAL \process_14~5_combout\ : std_logic;
SIGNAL \process_14~6_combout\ : std_logic;
SIGNAL \in_min_high[2]~1_combout\ : std_logic;
SIGNAL \cnt_min_high~32_combout\ : std_logic;
SIGNAL \cnt_min_high[3]~6_combout\ : std_logic;
SIGNAL \in_min_high[0]~13_combout\ : std_logic;
SIGNAL \in_min_high[0]~15_combout\ : std_logic;
SIGNAL \in_min_high[0]~_emulated_q\ : std_logic;
SIGNAL \in_min_high[0]~14_combout\ : std_logic;
SIGNAL \cnt_min_high~30_combout\ : std_logic;
SIGNAL \cnt_min_high[0]~16_combout\ : std_logic;
SIGNAL \cnt_min_high[0]~19_combout\ : std_logic;
SIGNAL \process_9~0_combout\ : std_logic;
SIGNAL \cnt_min_high[0]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_high[0]~18_combout\ : std_logic;
SIGNAL \cnt_min_high[0]~17_combout\ : std_logic;
SIGNAL \in_min_high[1]~9_combout\ : std_logic;
SIGNAL \in_min_high[1]~11_combout\ : std_logic;
SIGNAL \in_min_high[1]~_emulated_q\ : std_logic;
SIGNAL \in_min_high[1]~10_combout\ : std_logic;
SIGNAL \cnt_min_high~33_combout\ : std_logic;
SIGNAL \se1|Equal15~1_combout\ : std_logic;
SIGNAL \cnt_min_high[1]~11_combout\ : std_logic;
SIGNAL \cnt_min_high[1]~14_combout\ : std_logic;
SIGNAL \cnt_min_high[1]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_high[1]~13_combout\ : std_logic;
SIGNAL \cnt_min_high[1]~12_combout\ : std_logic;
SIGNAL \se1|seg[1]~4_combout\ : std_logic;
SIGNAL \cnt_min_high[3]~31_combout\ : std_logic;
SIGNAL \cnt_min_high[3]~9_combout\ : std_logic;
SIGNAL \cnt_min_high[3]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_high[3]~8_combout\ : std_logic;
SIGNAL \cnt_min_high[3]~7_combout\ : std_logic;
SIGNAL \in_min_high[3]~5_combout\ : std_logic;
SIGNAL \Add6~0_combout\ : std_logic;
SIGNAL \in_min_high[3]~22_combout\ : std_logic;
SIGNAL \in_min_high[3]~7_combout\ : std_logic;
SIGNAL \in_min_high[3]~_emulated_q\ : std_logic;
SIGNAL \in_min_high[3]~6_combout\ : std_logic;
SIGNAL \Equal6~0_combout\ : std_logic;
SIGNAL \in_min_high[2]~3_combout\ : std_logic;
SIGNAL \in_min_high[2]~_emulated_q\ : std_logic;
SIGNAL \in_min_high[2]~2_combout\ : std_logic;
SIGNAL \cnt_min_high~29_combout\ : std_logic;
SIGNAL \cnt_min_high[2]~1_combout\ : std_logic;
SIGNAL \se1|Equal15~0_combout\ : std_logic;
SIGNAL \cnt_min_high[2]~4_combout\ : std_logic;
SIGNAL \cnt_min_high[2]~_emulated_q\ : std_logic;
SIGNAL \cnt_min_high[2]~3_combout\ : std_logic;
SIGNAL \cnt_min_high[2]~2_combout\ : std_logic;
SIGNAL \in_tim_min_high[0]~4_combout\ : std_logic;
SIGNAL \in_tim_min_high[0]~1_combout\ : std_logic;
SIGNAL \in_tim_min_high~0_combout\ : std_logic;
SIGNAL \in_tim_min_high~3_combout\ : std_logic;
SIGNAL \se5|seg[1]~4_combout\ : std_logic;
SIGNAL \in_tim_min_high[3]~2_combout\ : std_logic;
SIGNAL \process_14~1_combout\ : std_logic;
SIGNAL \process_14~0_combout\ : std_logic;
SIGNAL \in_tim_sec_high[0]~4_combout\ : std_logic;
SIGNAL \in_tim_sec_high[0]~1_combout\ : std_logic;
SIGNAL \se7|seg[1]~4_combout\ : std_logic;
SIGNAL \in_tim_sec_high[3]~2_combout\ : std_logic;
SIGNAL \in_tim_sec_high~3_combout\ : std_logic;
SIGNAL \in_tim_sec_high~0_combout\ : std_logic;
SIGNAL \process_14~3_combout\ : std_logic;
SIGNAL \process_14~2_combout\ : std_logic;
SIGNAL \process_14~4_combout\ : std_logic;
SIGNAL \in_tim_sec_low[0]~4_combout\ : std_logic;
SIGNAL \in_tim_sec_low[0]~0_combout\ : std_logic;
SIGNAL \in_tim_sec_low[2]~1_combout\ : std_logic;
SIGNAL \in_tim_sec_low~2_combout\ : std_logic;
SIGNAL \in_tim_sec_low~3_combout\ : std_logic;
SIGNAL \process_14~7_combout\ : std_logic;
SIGNAL \process_14~8_combout\ : std_logic;
SIGNAL \process_14~9_combout\ : std_logic;
SIGNAL \time_trig~2_combout\ : std_logic;
SIGNAL \time_trig~combout\ : std_logic;
SIGNAL \t2|toggle~0_combout\ : std_logic;
SIGNAL \t2|toggle~q\ : std_logic;
SIGNAL \led_flash~0_combout\ : std_logic;
SIGNAL \min_high~0_combout\ : std_logic;
SIGNAL \min_high~1_combout\ : std_logic;
SIGNAL \min_high~2_combout\ : std_logic;
SIGNAL \se1|seg[1]~0_combout\ : std_logic;
SIGNAL \min_high~3_combout\ : std_logic;
SIGNAL \min_high~4_combout\ : std_logic;
SIGNAL \min_high~5_combout\ : std_logic;
SIGNAL \se1|seg[3]~1_combout\ : std_logic;
SIGNAL \min_high~6_combout\ : std_logic;
SIGNAL \se1|seg[4]~2_combout\ : std_logic;
SIGNAL \min_high~7_combout\ : std_logic;
SIGNAL \min_high~8_combout\ : std_logic;
SIGNAL \min_high~9_combout\ : std_logic;
SIGNAL \se1|seg[6]~3_combout\ : std_logic;
SIGNAL \min_high~10_combout\ : std_logic;
SIGNAL \min_low~0_combout\ : std_logic;
SIGNAL \min_low~1_combout\ : std_logic;
SIGNAL \se2|seg[1]~0_combout\ : std_logic;
SIGNAL \min_low~2_combout\ : std_logic;
SIGNAL \min_low~3_combout\ : std_logic;
SIGNAL \min_low~4_combout\ : std_logic;
SIGNAL \min_low~5_combout\ : std_logic;
SIGNAL \se2|seg[3]~1_combout\ : std_logic;
SIGNAL \min_low~6_combout\ : std_logic;
SIGNAL \se2|seg[4]~2_combout\ : std_logic;
SIGNAL \min_low~7_combout\ : std_logic;
SIGNAL \min_low~8_combout\ : std_logic;
SIGNAL \min_low~9_combout\ : std_logic;
SIGNAL \se2|seg[6]~3_combout\ : std_logic;
SIGNAL \min_low~10_combout\ : std_logic;
SIGNAL \sec_high~0_combout\ : std_logic;
SIGNAL \sec_high~1_combout\ : std_logic;
SIGNAL \se3|seg[1]~0_combout\ : std_logic;
SIGNAL \sec_high~2_combout\ : std_logic;
SIGNAL \sec_high~3_combout\ : std_logic;
SIGNAL \sec_high~4_combout\ : std_logic;
SIGNAL \sec_high~5_combout\ : std_logic;
SIGNAL \se3|seg[3]~1_combout\ : std_logic;
SIGNAL \sec_high~6_combout\ : std_logic;
SIGNAL \se3|seg[4]~2_combout\ : std_logic;
SIGNAL \sec_high~7_combout\ : std_logic;
SIGNAL \sec_high~8_combout\ : std_logic;
SIGNAL \sec_high~9_combout\ : std_logic;
SIGNAL \se3|seg[6]~3_combout\ : std_logic;
SIGNAL \sec_high~10_combout\ : std_logic;
SIGNAL \sec_low~0_combout\ : std_logic;
SIGNAL \sec_low~1_combout\ : std_logic;
SIGNAL \sec_low~2_combout\ : std_logic;
SIGNAL \se4|seg[1]~0_combout\ : std_logic;
SIGNAL \sec_low~3_combout\ : std_logic;
SIGNAL \sec_low~4_combout\ : std_logic;
SIGNAL \sec_low~5_combout\ : std_logic;
SIGNAL \se4|seg[3]~1_combout\ : std_logic;
SIGNAL \sec_low~6_combout\ : std_logic;
SIGNAL \se4|seg[4]~2_combout\ : std_logic;
SIGNAL \sec_low~7_combout\ : std_logic;
SIGNAL \sec_low~8_combout\ : std_logic;
SIGNAL \sec_low~9_combout\ : std_logic;
SIGNAL \se4|seg[6]~3_combout\ : std_logic;
SIGNAL \sec_low~10_combout\ : std_logic;
SIGNAL \tim_min_high~0_combout\ : std_logic;
SIGNAL \tim_min_high~1_combout\ : std_logic;
SIGNAL \se5|seg[1]~0_combout\ : std_logic;
SIGNAL \tim_min_high~2_combout\ : std_logic;
SIGNAL \tim_min_high~3_combout\ : std_logic;
SIGNAL \tim_min_high~4_combout\ : std_logic;
SIGNAL \tim_min_high~5_combout\ : std_logic;
SIGNAL \se5|seg[3]~1_combout\ : std_logic;
SIGNAL \tim_min_high~6_combout\ : std_logic;
SIGNAL \se5|seg[4]~2_combout\ : std_logic;
SIGNAL \tim_min_high~7_combout\ : std_logic;
SIGNAL \tim_min_high~8_combout\ : std_logic;
SIGNAL \tim_min_high~9_combout\ : std_logic;
SIGNAL \se5|seg[6]~3_combout\ : std_logic;
SIGNAL \tim_min_high~10_combout\ : std_logic;
SIGNAL \tim_min_low~0_combout\ : std_logic;
SIGNAL \tim_min_low~1_combout\ : std_logic;
SIGNAL \tim_min_low~2_combout\ : std_logic;
SIGNAL \se6|seg[1]~0_combout\ : std_logic;
SIGNAL \tim_min_low~3_combout\ : std_logic;
SIGNAL \tim_min_low~4_combout\ : std_logic;
SIGNAL \tim_min_low~5_combout\ : std_logic;
SIGNAL \se6|seg[3]~1_combout\ : std_logic;
SIGNAL \tim_min_low~6_combout\ : std_logic;
SIGNAL \se6|seg[4]~2_combout\ : std_logic;
SIGNAL \tim_min_low~7_combout\ : std_logic;
SIGNAL \tim_min_low~8_combout\ : std_logic;
SIGNAL \tim_min_low~9_combout\ : std_logic;
SIGNAL \se6|seg[6]~3_combout\ : std_logic;
SIGNAL \tim_min_low~10_combout\ : std_logic;
SIGNAL \tim_sec_high~0_combout\ : std_logic;
SIGNAL \tim_sec_high~1_combout\ : std_logic;
SIGNAL \se7|seg[1]~0_combout\ : std_logic;
SIGNAL \tim_sec_high~2_combout\ : std_logic;
SIGNAL \tim_sec_high~3_combout\ : std_logic;
SIGNAL \tim_sec_high~4_combout\ : std_logic;
SIGNAL \tim_sec_high~5_combout\ : std_logic;
SIGNAL \se7|seg[3]~1_combout\ : std_logic;
SIGNAL \tim_sec_high~6_combout\ : std_logic;
SIGNAL \se7|seg[4]~2_combout\ : std_logic;
SIGNAL \tim_sec_high~7_combout\ : std_logic;
SIGNAL \tim_sec_high~8_combout\ : std_logic;
SIGNAL \tim_sec_high~9_combout\ : std_logic;
SIGNAL \se7|seg[6]~3_combout\ : std_logic;
SIGNAL \tim_sec_high~10_combout\ : std_logic;
SIGNAL \tim_sec_low~0_combout\ : std_logic;
SIGNAL \tim_sec_low~1_combout\ : std_logic;
SIGNAL \tim_sec_low~2_combout\ : std_logic;
SIGNAL \se8|seg[1]~0_combout\ : std_logic;
SIGNAL \tim_sec_low~3_combout\ : std_logic;
SIGNAL \tim_sec_low~4_combout\ : std_logic;
SIGNAL \tim_sec_low~5_combout\ : std_logic;
SIGNAL \se8|seg[3]~1_combout\ : std_logic;
SIGNAL \tim_sec_low~6_combout\ : std_logic;
SIGNAL \se8|seg[4]~2_combout\ : std_logic;
SIGNAL \tim_sec_low~7_combout\ : std_logic;
SIGNAL \tim_sec_low~8_combout\ : std_logic;
SIGNAL \tim_sec_low~9_combout\ : std_logic;
SIGNAL \se8|seg[6]~3_combout\ : std_logic;
SIGNAL \tim_sec_low~10_combout\ : std_logic;
SIGNAL in_tim_min_high : std_logic_vector(3 DOWNTO 0);
SIGNAL \t1|count\ : std_logic_vector(25 DOWNTO 0);
SIGNAL in_tim_min_low : std_logic_vector(3 DOWNTO 0);
SIGNAL in_tim_sec_high : std_logic_vector(3 DOWNTO 0);
SIGNAL in_tim_sec_low : std_logic_vector(3 DOWNTO 0);
SIGNAL \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\ : std_logic;

COMPONENT hard_block
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic);
END COMPONENT;

BEGIN

ww_clk <= clk;
ww_en <= en;
ww_ct1_btn <= ct1_btn;
ww_ct2_btn <= ct2_btn;
ww_inc_btn <= inc_btn;
ww_done_btn <= done_btn;
led1 <= ww_led1;
led2 <= ww_led2;
led3 <= ww_led3;
led4 <= ww_led4;
led5 <= ww_led5;
led6 <= ww_led6;
led7 <= ww_led7;
led8 <= ww_led8;
led9 <= ww_led9;
led10 <= ww_led10;
led_flash <= ww_led_flash;
min_high <= ww_min_high;
min_low <= ww_min_low;
sec_high <= ww_sec_high;
sec_low <= ww_sec_low;
tim_min_high <= ww_tim_min_high;
tim_min_low <= ww_tim_min_low;
tim_sec_high <= ww_tim_sec_high;
tim_sec_low <= ww_tim_sec_low;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\clk~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk~input_o\);

\cnt_min_high[2]~0clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \cnt_min_high[2]~0_combout\);
\ALT_INV_cnt_min_high[2]~0clkctrl_outclk\ <= NOT \cnt_min_high[2]~0clkctrl_outclk\;
auto_generated_inst : hard_block
PORT MAP (
	devoe => ww_devoe,
	devclrn => ww_devclrn,
	devpor => ww_devpor);

-- Location: IOOBUF_X69_Y73_N16
\led1~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.INC~q\,
	devoe => ww_devoe,
	o => \led1~output_o\);

-- Location: IOOBUF_X94_Y73_N2
\led2~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.S0~q\,
	devoe => ww_devoe,
	o => \led2~output_o\);

-- Location: IOOBUF_X94_Y73_N9
\led3~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.S1~q\,
	devoe => ww_devoe,
	o => \led3~output_o\);

-- Location: IOOBUF_X107_Y73_N16
\led4~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.M0~q\,
	devoe => ww_devoe,
	o => \led4~output_o\);

-- Location: IOOBUF_X87_Y73_N16
\led5~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.M1~q\,
	devoe => ww_devoe,
	o => \led5~output_o\);

-- Location: IOOBUF_X87_Y73_N9
\led6~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.ST0~q\,
	devoe => ww_devoe,
	o => \led6~output_o\);

-- Location: IOOBUF_X72_Y73_N9
\led7~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.ST1~q\,
	devoe => ww_devoe,
	o => \led7~output_o\);

-- Location: IOOBUF_X72_Y73_N2
\led8~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.MT0~q\,
	devoe => ww_devoe,
	o => \led8~output_o\);

-- Location: IOOBUF_X69_Y73_N2
\led9~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.MT1~q\,
	devoe => ww_devoe,
	o => \led9~output_o\);

-- Location: IOOBUF_X107_Y73_N9
\led10~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \t1|toggle~q\,
	devoe => ww_devoe,
	o => \led10~output_o\);

-- Location: IOOBUF_X111_Y73_N9
\led_flash~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \led_flash~0_combout\,
	devoe => ww_devoe,
	o => \led_flash~output_o\);

-- Location: IOOBUF_X74_Y0_N16
\min_high[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_high~1_combout\,
	devoe => ww_devoe,
	o => \min_high[0]~output_o\);

-- Location: IOOBUF_X67_Y0_N9
\min_high[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_high~3_combout\,
	devoe => ww_devoe,
	o => \min_high[1]~output_o\);

-- Location: IOOBUF_X62_Y0_N23
\min_high[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_high~5_combout\,
	devoe => ww_devoe,
	o => \min_high[2]~output_o\);

-- Location: IOOBUF_X62_Y0_N16
\min_high[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_high~6_combout\,
	devoe => ww_devoe,
	o => \min_high[3]~output_o\);

-- Location: IOOBUF_X67_Y0_N2
\min_high[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_high~7_combout\,
	devoe => ww_devoe,
	o => \min_high[4]~output_o\);

-- Location: IOOBUF_X69_Y0_N9
\min_high[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_high~9_combout\,
	devoe => ww_devoe,
	o => \min_high[5]~output_o\);

-- Location: IOOBUF_X54_Y0_N23
\min_high[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_high~10_combout\,
	devoe => ww_devoe,
	o => \min_high[6]~output_o\);

-- Location: IOOBUF_X89_Y0_N23
\min_low[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_low~1_combout\,
	devoe => ww_devoe,
	o => \min_low[0]~output_o\);

-- Location: IOOBUF_X65_Y0_N2
\min_low[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_low~3_combout\,
	devoe => ww_devoe,
	o => \min_low[1]~output_o\);

-- Location: IOOBUF_X65_Y0_N9
\min_low[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_low~5_combout\,
	devoe => ww_devoe,
	o => \min_low[2]~output_o\);

-- Location: IOOBUF_X89_Y0_N16
\min_low[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_low~6_combout\,
	devoe => ww_devoe,
	o => \min_low[3]~output_o\);

-- Location: IOOBUF_X67_Y0_N16
\min_low[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_low~7_combout\,
	devoe => ww_devoe,
	o => \min_low[4]~output_o\);

-- Location: IOOBUF_X67_Y0_N23
\min_low[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_low~9_combout\,
	devoe => ww_devoe,
	o => \min_low[5]~output_o\);

-- Location: IOOBUF_X74_Y0_N23
\min_low[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \min_low~10_combout\,
	devoe => ww_devoe,
	o => \min_low[6]~output_o\);

-- Location: IOOBUF_X85_Y0_N9
\sec_high[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_high~1_combout\,
	devoe => ww_devoe,
	o => \sec_high[0]~output_o\);

-- Location: IOOBUF_X87_Y0_N16
\sec_high[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_high~3_combout\,
	devoe => ww_devoe,
	o => \sec_high[1]~output_o\);

-- Location: IOOBUF_X98_Y0_N16
\sec_high[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_high~5_combout\,
	devoe => ww_devoe,
	o => \sec_high[2]~output_o\);

-- Location: IOOBUF_X72_Y0_N2
\sec_high[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_high~6_combout\,
	devoe => ww_devoe,
	o => \sec_high[3]~output_o\);

-- Location: IOOBUF_X72_Y0_N9
\sec_high[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_high~7_combout\,
	devoe => ww_devoe,
	o => \sec_high[4]~output_o\);

-- Location: IOOBUF_X79_Y0_N16
\sec_high[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_high~9_combout\,
	devoe => ww_devoe,
	o => \sec_high[5]~output_o\);

-- Location: IOOBUF_X69_Y0_N2
\sec_high[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_high~10_combout\,
	devoe => ww_devoe,
	o => \sec_high[6]~output_o\);

-- Location: IOOBUF_X98_Y0_N23
\sec_low[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_low~1_combout\,
	devoe => ww_devoe,
	o => \sec_low[0]~output_o\);

-- Location: IOOBUF_X107_Y0_N9
\sec_low[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_low~3_combout\,
	devoe => ww_devoe,
	o => \sec_low[1]~output_o\);

-- Location: IOOBUF_X74_Y0_N9
\sec_low[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_low~5_combout\,
	devoe => ww_devoe,
	o => \sec_low[2]~output_o\);

-- Location: IOOBUF_X74_Y0_N2
\sec_low[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_low~6_combout\,
	devoe => ww_devoe,
	o => \sec_low[3]~output_o\);

-- Location: IOOBUF_X83_Y0_N23
\sec_low[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_low~7_combout\,
	devoe => ww_devoe,
	o => \sec_low[4]~output_o\);

-- Location: IOOBUF_X83_Y0_N16
\sec_low[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_low~9_combout\,
	devoe => ww_devoe,
	o => \sec_low[5]~output_o\);

-- Location: IOOBUF_X79_Y0_N23
\sec_low[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \sec_low~10_combout\,
	devoe => ww_devoe,
	o => \sec_low[6]~output_o\);

-- Location: IOOBUF_X115_Y25_N16
\tim_min_high[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_min_high~1_combout\,
	devoe => ww_devoe,
	o => \tim_min_high[0]~output_o\);

-- Location: IOOBUF_X115_Y29_N2
\tim_min_high[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_min_high~3_combout\,
	devoe => ww_devoe,
	o => \tim_min_high[1]~output_o\);

-- Location: IOOBUF_X100_Y0_N2
\tim_min_high[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_min_high~5_combout\,
	devoe => ww_devoe,
	o => \tim_min_high[2]~output_o\);

-- Location: IOOBUF_X111_Y0_N2
\tim_min_high[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_min_high~6_combout\,
	devoe => ww_devoe,
	o => \tim_min_high[3]~output_o\);

-- Location: IOOBUF_X105_Y0_N23
\tim_min_high[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_min_high~7_combout\,
	devoe => ww_devoe,
	o => \tim_min_high[4]~output_o\);

-- Location: IOOBUF_X105_Y0_N9
\tim_min_high[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_min_high~9_combout\,
	devoe => ww_devoe,
	o => \tim_min_high[5]~output_o\);

-- Location: IOOBUF_X105_Y0_N2
\tim_min_high[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_min_high~10_combout\,
	devoe => ww_devoe,
	o => \tim_min_high[6]~output_o\);

-- Location: IOOBUF_X115_Y17_N9
\tim_min_low[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_min_low~1_combout\,
	devoe => ww_devoe,
	o => \tim_min_low[0]~output_o\);

-- Location: IOOBUF_X115_Y16_N2
\tim_min_low[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_min_low~3_combout\,
	devoe => ww_devoe,
	o => \tim_min_low[1]~output_o\);

-- Location: IOOBUF_X115_Y19_N9
\tim_min_low[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_min_low~5_combout\,
	devoe => ww_devoe,
	o => \tim_min_low[2]~output_o\);

-- Location: IOOBUF_X115_Y19_N2
\tim_min_low[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_min_low~6_combout\,
	devoe => ww_devoe,
	o => \tim_min_low[3]~output_o\);

-- Location: IOOBUF_X115_Y18_N2
\tim_min_low[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_min_low~7_combout\,
	devoe => ww_devoe,
	o => \tim_min_low[4]~output_o\);

-- Location: IOOBUF_X115_Y20_N2
\tim_min_low[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_min_low~9_combout\,
	devoe => ww_devoe,
	o => \tim_min_low[5]~output_o\);

-- Location: IOOBUF_X115_Y21_N16
\tim_min_low[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_min_low~10_combout\,
	devoe => ww_devoe,
	o => \tim_min_low[6]~output_o\);

-- Location: IOOBUF_X115_Y41_N2
\tim_sec_high[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_sec_high~1_combout\,
	devoe => ww_devoe,
	o => \tim_sec_high[0]~output_o\);

-- Location: IOOBUF_X115_Y30_N9
\tim_sec_high[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_sec_high~3_combout\,
	devoe => ww_devoe,
	o => \tim_sec_high[1]~output_o\);

-- Location: IOOBUF_X115_Y25_N23
\tim_sec_high[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_sec_high~5_combout\,
	devoe => ww_devoe,
	o => \tim_sec_high[2]~output_o\);

-- Location: IOOBUF_X115_Y30_N2
\tim_sec_high[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_sec_high~6_combout\,
	devoe => ww_devoe,
	o => \tim_sec_high[3]~output_o\);

-- Location: IOOBUF_X115_Y20_N9
\tim_sec_high[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_sec_high~7_combout\,
	devoe => ww_devoe,
	o => \tim_sec_high[4]~output_o\);

-- Location: IOOBUF_X115_Y22_N2
\tim_sec_high[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_sec_high~9_combout\,
	devoe => ww_devoe,
	o => \tim_sec_high[5]~output_o\);

-- Location: IOOBUF_X115_Y28_N9
\tim_sec_high[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_sec_high~10_combout\,
	devoe => ww_devoe,
	o => \tim_sec_high[6]~output_o\);

-- Location: IOOBUF_X69_Y73_N23
\tim_sec_low[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_sec_low~1_combout\,
	devoe => ww_devoe,
	o => \tim_sec_low[0]~output_o\);

-- Location: IOOBUF_X107_Y73_N23
\tim_sec_low[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_sec_low~3_combout\,
	devoe => ww_devoe,
	o => \tim_sec_low[1]~output_o\);

-- Location: IOOBUF_X67_Y73_N23
\tim_sec_low[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_sec_low~5_combout\,
	devoe => ww_devoe,
	o => \tim_sec_low[2]~output_o\);

-- Location: IOOBUF_X115_Y50_N2
\tim_sec_low[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_sec_low~6_combout\,
	devoe => ww_devoe,
	o => \tim_sec_low[3]~output_o\);

-- Location: IOOBUF_X115_Y54_N16
\tim_sec_low[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_sec_low~7_combout\,
	devoe => ww_devoe,
	o => \tim_sec_low[4]~output_o\);

-- Location: IOOBUF_X115_Y67_N16
\tim_sec_low[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_sec_low~9_combout\,
	devoe => ww_devoe,
	o => \tim_sec_low[5]~output_o\);

-- Location: IOOBUF_X115_Y69_N2
\tim_sec_low[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \tim_sec_low~10_combout\,
	devoe => ww_devoe,
	o => \tim_sec_low[6]~output_o\);

-- Location: IOIBUF_X0_Y36_N15
\clk~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk,
	o => \clk~input_o\);

-- Location: CLKCTRL_G4
\clk~inputclkctrl\ : cycloneive_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk~inputclkctrl_outclk\);

-- Location: IOIBUF_X115_Y42_N15
\done_btn~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_done_btn,
	o => \done_btn~input_o\);

-- Location: FF_X50_Y34_N23
\bt4|btn_sync\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \done_btn~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt4|btn_sync~q\);

-- Location: IOIBUF_X115_Y53_N15
\ct2_btn~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_ct2_btn,
	o => \ct2_btn~input_o\);

-- Location: FF_X53_Y33_N27
\bt2|btn_sync\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \ct2_btn~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt2|btn_sync~q\);

-- Location: FF_X50_Y34_N7
\bt2|btn_delay\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \bt2|btn_sync~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt2|btn_delay~q\);

-- Location: IOIBUF_X115_Y40_N8
\ct1_btn~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_ct1_btn,
	o => \ct1_btn~input_o\);

-- Location: FF_X50_Y34_N19
\bt1|btn_sync\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \ct1_btn~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt1|btn_sync~q\);

-- Location: FF_X50_Y34_N13
\bt1|btn_delay\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \bt1|btn_sync~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt1|btn_delay~q\);

-- Location: LCCOMB_X50_Y34_N12
\Selector0~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~6_combout\ = (\current_state.INC~q\ & ((\bt1|btn_delay~q\) # (!\bt1|btn_sync~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.INC~q\,
	datac => \bt1|btn_delay~q\,
	datad => \bt1|btn_sync~q\,
	combout => \Selector0~6_combout\);

-- Location: LCCOMB_X50_Y34_N4
\bt2|trig\ : cycloneive_lcell_comb
-- Equation(s):
-- \bt2|trig~combout\ = (\bt2|btn_delay~q\) # (!\bt2|btn_sync~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \bt2|btn_sync~q\,
	datad => \bt2|btn_delay~q\,
	combout => \bt2|trig~combout\);

-- Location: FF_X50_Y34_N17
\bt4|btn_delay\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \bt4|btn_sync~q\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt4|btn_delay~q\);

-- Location: LCCOMB_X50_Y34_N22
\next_state~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \next_state~1_combout\ = (\bt2|btn_delay~q\ & (((\bt4|btn_sync~q\ & !\bt4|btn_delay~q\)))) # (!\bt2|btn_delay~q\ & ((\bt2|btn_sync~q\) # ((\bt4|btn_sync~q\ & !\bt4|btn_delay~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010011110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt2|btn_delay~q\,
	datab => \bt2|btn_sync~q\,
	datac => \bt4|btn_sync~q\,
	datad => \bt4|btn_delay~q\,
	combout => \next_state~1_combout\);

-- Location: LCCOMB_X50_Y34_N26
\Selector5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector5~0_combout\ = (\Selector0~6_combout\ & (((\current_state.ST0~q\ & !\next_state~1_combout\)) # (!\bt2|trig~combout\))) # (!\Selector0~6_combout\ & (((\current_state.ST0~q\ & !\next_state~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001011110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector0~6_combout\,
	datab => \bt2|trig~combout\,
	datac => \current_state.ST0~q\,
	datad => \next_state~1_combout\,
	combout => \Selector5~0_combout\);

-- Location: IOIBUF_X115_Y17_N1
\en~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_en,
	o => \en~input_o\);

-- Location: FF_X50_Y34_N27
\current_state.ST0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \Selector5~0_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.ST0~q\);

-- Location: LCCOMB_X50_Y34_N28
\Selector6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector6~0_combout\ = (!\bt2|btn_delay~q\ & (\bt2|btn_sync~q\ & \current_state.ST0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt2|btn_delay~q\,
	datac => \bt2|btn_sync~q\,
	datad => \current_state.ST0~q\,
	combout => \Selector6~0_combout\);

-- Location: FF_X54_Y31_N17
\current_state.ST1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \Selector6~0_combout\,
	clrn => \en~input_o\,
	sload => VCC,
	ena => \next_state~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.ST1~q\);

-- Location: LCCOMB_X54_Y31_N2
\Selector7~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector7~0_combout\ = (!\bt2|btn_delay~q\ & (\bt2|btn_sync~q\ & \current_state.ST1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt2|btn_delay~q\,
	datac => \bt2|btn_sync~q\,
	datad => \current_state.ST1~q\,
	combout => \Selector7~0_combout\);

-- Location: FF_X54_Y31_N3
\current_state.MT0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \Selector7~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.MT0~q\);

-- Location: LCCOMB_X50_Y34_N24
\Selector0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~1_combout\ = (\bt2|trig~combout\ & ((\current_state.MT0~q\) # ((\current_state.ST0~q\) # (\current_state.ST1~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.MT0~q\,
	datab => \current_state.ST0~q\,
	datac => \bt2|trig~combout\,
	datad => \current_state.ST1~q\,
	combout => \Selector0~1_combout\);

-- Location: LCCOMB_X50_Y34_N18
\bt1|trig\ : cycloneive_lcell_comb
-- Equation(s):
-- \bt1|trig~combout\ = (\bt1|btn_delay~q\) # (!\bt1|btn_sync~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \bt1|btn_delay~q\,
	datac => \bt1|btn_sync~q\,
	combout => \bt1|trig~combout\);

-- Location: LCCOMB_X50_Y32_N24
\Selector1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector1~0_combout\ = (\bt1|btn_sync~q\ & (\current_state.INC~q\ & !\bt1|btn_delay~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt1|btn_sync~q\,
	datab => \current_state.INC~q\,
	datad => \bt1|btn_delay~q\,
	combout => \Selector1~0_combout\);

-- Location: LCCOMB_X50_Y34_N16
\next_state~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \next_state~0_combout\ = (\bt4|btn_sync~q\ & (((!\bt1|btn_delay~q\ & \bt1|btn_sync~q\)) # (!\bt4|btn_delay~q\))) # (!\bt4|btn_sync~q\ & (!\bt1|btn_delay~q\ & ((\bt1|btn_sync~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011101100001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt4|btn_sync~q\,
	datab => \bt1|btn_delay~q\,
	datac => \bt4|btn_delay~q\,
	datad => \bt1|btn_sync~q\,
	combout => \next_state~0_combout\);

-- Location: FF_X50_Y32_N25
\current_state.S0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \Selector1~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.S0~q\);

-- Location: LCCOMB_X49_Y33_N4
\Selector2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector2~0_combout\ = (\bt1|btn_sync~q\ & (!\bt1|btn_delay~q\ & \current_state.S0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt1|btn_sync~q\,
	datac => \bt1|btn_delay~q\,
	datad => \current_state.S0~q\,
	combout => \Selector2~0_combout\);

-- Location: FF_X49_Y33_N5
\current_state.S1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \Selector2~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.S1~q\);

-- Location: LCCOMB_X50_Y32_N28
\Selector3~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector3~0_combout\ = (\bt1|btn_sync~q\ & (\current_state.S1~q\ & !\bt1|btn_delay~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt1|btn_sync~q\,
	datab => \current_state.S1~q\,
	datad => \bt1|btn_delay~q\,
	combout => \Selector3~0_combout\);

-- Location: FF_X46_Y32_N29
\current_state.M0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	asdata => \Selector3~0_combout\,
	clrn => \en~input_o\,
	sload => VCC,
	ena => \next_state~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.M0~q\);

-- Location: LCCOMB_X49_Y31_N18
\Selector0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~0_combout\ = (\bt1|trig~combout\ & ((\current_state.S1~q\) # ((\current_state.S0~q\) # (\current_state.M0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt1|trig~combout\,
	datab => \current_state.S1~q\,
	datac => \current_state.S0~q\,
	datad => \current_state.M0~q\,
	combout => \Selector0~0_combout\);

-- Location: LCCOMB_X50_Y34_N10
\Selector0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~2_combout\ = (\bt4|btn_sync~q\ & (!\bt4|btn_delay~q\ & ((\Selector0~1_combout\) # (\Selector0~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt4|btn_sync~q\,
	datab => \Selector0~1_combout\,
	datac => \Selector0~0_combout\,
	datad => \bt4|btn_delay~q\,
	combout => \Selector0~2_combout\);

-- Location: LCCOMB_X50_Y34_N20
\current_state.IDLE~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \current_state.IDLE~0_combout\ = (\current_state.IDLE~q\) # ((!\bt1|btn_delay~q\ & \bt1|btn_sync~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \bt1|btn_delay~q\,
	datac => \current_state.IDLE~q\,
	datad => \bt1|btn_sync~q\,
	combout => \current_state.IDLE~0_combout\);

-- Location: FF_X50_Y34_N21
\current_state.IDLE\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \current_state.IDLE~0_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.IDLE~q\);

-- Location: LCCOMB_X50_Y34_N8
\Selector0~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~4_combout\ = (\bt1|trig~combout\ & (((\current_state.INC~q\ & \bt2|trig~combout\)))) # (!\bt1|trig~combout\ & (!\current_state.IDLE~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011000100010001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt1|trig~combout\,
	datab => \current_state.IDLE~q\,
	datac => \current_state.INC~q\,
	datad => \bt2|trig~combout\,
	combout => \Selector0~4_combout\);

-- Location: LCCOMB_X46_Y32_N12
\Selector4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector4~0_combout\ = (\bt1|btn_sync~q\ & (!\bt1|btn_delay~q\ & \current_state.M0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt1|btn_sync~q\,
	datac => \bt1|btn_delay~q\,
	datad => \current_state.M0~q\,
	combout => \Selector4~0_combout\);

-- Location: FF_X46_Y32_N13
\current_state.M1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \Selector4~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.M1~q\);

-- Location: LCCOMB_X54_Y31_N4
\Selector8~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector8~0_combout\ = (!\bt2|btn_delay~q\ & (\bt2|btn_sync~q\ & \current_state.MT0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt2|btn_delay~q\,
	datac => \bt2|btn_sync~q\,
	datad => \current_state.MT0~q\,
	combout => \Selector8~0_combout\);

-- Location: FF_X54_Y31_N5
\current_state.MT1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \Selector8~0_combout\,
	clrn => \en~input_o\,
	ena => \next_state~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.MT1~q\);

-- Location: LCCOMB_X50_Y34_N14
\Selector0~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~3_combout\ = (\next_state~0_combout\ & ((\current_state.M1~q\) # ((\current_state.MT1~q\ & \next_state~1_combout\)))) # (!\next_state~0_combout\ & (((\current_state.MT1~q\ & \next_state~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \next_state~0_combout\,
	datab => \current_state.M1~q\,
	datac => \current_state.MT1~q\,
	datad => \next_state~1_combout\,
	combout => \Selector0~3_combout\);

-- Location: LCCOMB_X50_Y34_N30
\Selector0~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~5_combout\ = (\Selector0~2_combout\) # ((\Selector0~4_combout\) # (\Selector0~3_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selector0~2_combout\,
	datab => \Selector0~4_combout\,
	datac => \Selector0~3_combout\,
	combout => \Selector0~5_combout\);

-- Location: FF_X50_Y34_N31
\current_state.INC\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \Selector0~5_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.INC~q\);

-- Location: LCCOMB_X53_Y32_N10
\t1|toggle~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|toggle~0_combout\ = !\t1|toggle~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \t1|toggle~q\,
	combout => \t1|toggle~0_combout\);

-- Location: LCCOMB_X54_Y33_N6
\t1|Add0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~0_combout\ = \t1|count\(0) $ (VCC)
-- \t1|Add0~1\ = CARRY(\t1|count\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(0),
	datad => VCC,
	combout => \t1|Add0~0_combout\,
	cout => \t1|Add0~1\);

-- Location: FF_X54_Y33_N7
\t1|count[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(0));

-- Location: LCCOMB_X54_Y33_N8
\t1|Add0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~2_combout\ = (\t1|count\(1) & (!\t1|Add0~1\)) # (!\t1|count\(1) & ((\t1|Add0~1\) # (GND)))
-- \t1|Add0~3\ = CARRY((!\t1|Add0~1\) # (!\t1|count\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(1),
	datad => VCC,
	cin => \t1|Add0~1\,
	combout => \t1|Add0~2_combout\,
	cout => \t1|Add0~3\);

-- Location: FF_X54_Y33_N9
\t1|count[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(1));

-- Location: LCCOMB_X54_Y33_N10
\t1|Add0~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~4_combout\ = (\t1|count\(2) & (\t1|Add0~3\ $ (GND))) # (!\t1|count\(2) & (!\t1|Add0~3\ & VCC))
-- \t1|Add0~5\ = CARRY((\t1|count\(2) & !\t1|Add0~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(2),
	datad => VCC,
	cin => \t1|Add0~3\,
	combout => \t1|Add0~4_combout\,
	cout => \t1|Add0~5\);

-- Location: FF_X54_Y33_N11
\t1|count[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(2));

-- Location: LCCOMB_X54_Y33_N12
\t1|Add0~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~6_combout\ = (\t1|count\(3) & (!\t1|Add0~5\)) # (!\t1|count\(3) & ((\t1|Add0~5\) # (GND)))
-- \t1|Add0~7\ = CARRY((!\t1|Add0~5\) # (!\t1|count\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(3),
	datad => VCC,
	cin => \t1|Add0~5\,
	combout => \t1|Add0~6_combout\,
	cout => \t1|Add0~7\);

-- Location: FF_X54_Y33_N13
\t1|count[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(3));

-- Location: LCCOMB_X54_Y33_N14
\t1|Add0~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~8_combout\ = (\t1|count\(4) & (\t1|Add0~7\ $ (GND))) # (!\t1|count\(4) & (!\t1|Add0~7\ & VCC))
-- \t1|Add0~9\ = CARRY((\t1|count\(4) & !\t1|Add0~7\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(4),
	datad => VCC,
	cin => \t1|Add0~7\,
	combout => \t1|Add0~8_combout\,
	cout => \t1|Add0~9\);

-- Location: FF_X54_Y33_N15
\t1|count[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(4));

-- Location: LCCOMB_X54_Y33_N16
\t1|Add0~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~10_combout\ = (\t1|count\(5) & (!\t1|Add0~9\)) # (!\t1|count\(5) & ((\t1|Add0~9\) # (GND)))
-- \t1|Add0~11\ = CARRY((!\t1|Add0~9\) # (!\t1|count\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(5),
	datad => VCC,
	cin => \t1|Add0~9\,
	combout => \t1|Add0~10_combout\,
	cout => \t1|Add0~11\);

-- Location: FF_X54_Y33_N17
\t1|count[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~10_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(5));

-- Location: LCCOMB_X54_Y33_N18
\t1|Add0~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~12_combout\ = (\t1|count\(6) & (\t1|Add0~11\ $ (GND))) # (!\t1|count\(6) & (!\t1|Add0~11\ & VCC))
-- \t1|Add0~13\ = CARRY((\t1|count\(6) & !\t1|Add0~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(6),
	datad => VCC,
	cin => \t1|Add0~11\,
	combout => \t1|Add0~12_combout\,
	cout => \t1|Add0~13\);

-- Location: FF_X54_Y33_N19
\t1|count[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~12_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(6));

-- Location: LCCOMB_X54_Y33_N20
\t1|Add0~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~14_combout\ = (\t1|count\(7) & (!\t1|Add0~13\)) # (!\t1|count\(7) & ((\t1|Add0~13\) # (GND)))
-- \t1|Add0~15\ = CARRY((!\t1|Add0~13\) # (!\t1|count\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(7),
	datad => VCC,
	cin => \t1|Add0~13\,
	combout => \t1|Add0~14_combout\,
	cout => \t1|Add0~15\);

-- Location: LCCOMB_X54_Y33_N0
\t1|count~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~2_combout\ = (!\t1|Equal0~8_combout\ & \t1|Add0~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|Equal0~8_combout\,
	datad => \t1|Add0~14_combout\,
	combout => \t1|count~2_combout\);

-- Location: FF_X54_Y33_N1
\t1|count[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(7));

-- Location: LCCOMB_X54_Y33_N22
\t1|Add0~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~16_combout\ = (\t1|count\(8) & (\t1|Add0~15\ $ (GND))) # (!\t1|count\(8) & (!\t1|Add0~15\ & VCC))
-- \t1|Add0~17\ = CARRY((\t1|count\(8) & !\t1|Add0~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(8),
	datad => VCC,
	cin => \t1|Add0~15\,
	combout => \t1|Add0~16_combout\,
	cout => \t1|Add0~17\);

-- Location: FF_X54_Y33_N23
\t1|count[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~16_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(8));

-- Location: LCCOMB_X54_Y33_N24
\t1|Add0~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~18_combout\ = (\t1|count\(9) & (!\t1|Add0~17\)) # (!\t1|count\(9) & ((\t1|Add0~17\) # (GND)))
-- \t1|Add0~19\ = CARRY((!\t1|Add0~17\) # (!\t1|count\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(9),
	datad => VCC,
	cin => \t1|Add0~17\,
	combout => \t1|Add0~18_combout\,
	cout => \t1|Add0~19\);

-- Location: FF_X54_Y33_N25
\t1|count[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~18_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(9));

-- Location: LCCOMB_X54_Y33_N26
\t1|Add0~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~20_combout\ = (\t1|count\(10) & (\t1|Add0~19\ $ (GND))) # (!\t1|count\(10) & (!\t1|Add0~19\ & VCC))
-- \t1|Add0~21\ = CARRY((\t1|count\(10) & !\t1|Add0~19\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(10),
	datad => VCC,
	cin => \t1|Add0~19\,
	combout => \t1|Add0~20_combout\,
	cout => \t1|Add0~21\);

-- Location: FF_X54_Y33_N27
\t1|count[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(10));

-- Location: LCCOMB_X54_Y33_N28
\t1|Add0~22\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~22_combout\ = (\t1|count\(11) & (!\t1|Add0~21\)) # (!\t1|count\(11) & ((\t1|Add0~21\) # (GND)))
-- \t1|Add0~23\ = CARRY((!\t1|Add0~21\) # (!\t1|count\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(11),
	datad => VCC,
	cin => \t1|Add0~21\,
	combout => \t1|Add0~22_combout\,
	cout => \t1|Add0~23\);

-- Location: FF_X54_Y33_N29
\t1|count[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~22_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(11));

-- Location: LCCOMB_X54_Y33_N30
\t1|Add0~24\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~24_combout\ = (\t1|count\(12) & (\t1|Add0~23\ $ (GND))) # (!\t1|count\(12) & (!\t1|Add0~23\ & VCC))
-- \t1|Add0~25\ = CARRY((\t1|count\(12) & !\t1|Add0~23\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(12),
	datad => VCC,
	cin => \t1|Add0~23\,
	combout => \t1|Add0~24_combout\,
	cout => \t1|Add0~25\);

-- Location: LCCOMB_X53_Y33_N12
\t1|count~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~1_combout\ = (!\t1|Equal0~8_combout\ & \t1|Add0~24_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|Equal0~8_combout\,
	datac => \t1|Add0~24_combout\,
	combout => \t1|count~1_combout\);

-- Location: FF_X53_Y33_N13
\t1|count[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(12));

-- Location: LCCOMB_X54_Y32_N0
\t1|Add0~26\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~26_combout\ = (\t1|count\(13) & (!\t1|Add0~25\)) # (!\t1|count\(13) & ((\t1|Add0~25\) # (GND)))
-- \t1|Add0~27\ = CARRY((!\t1|Add0~25\) # (!\t1|count\(13)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(13),
	datad => VCC,
	cin => \t1|Add0~25\,
	combout => \t1|Add0~26_combout\,
	cout => \t1|Add0~27\);

-- Location: LCCOMB_X53_Y32_N0
\t1|count~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~0_combout\ = (!\t1|Equal0~8_combout\ & \t1|Add0~26_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|Equal0~8_combout\,
	datac => \t1|Add0~26_combout\,
	combout => \t1|count~0_combout\);

-- Location: FF_X53_Y32_N1
\t1|count[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(13));

-- Location: LCCOMB_X54_Y32_N2
\t1|Add0~28\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~28_combout\ = (\t1|count\(14) & (\t1|Add0~27\ $ (GND))) # (!\t1|count\(14) & (!\t1|Add0~27\ & VCC))
-- \t1|Add0~29\ = CARRY((\t1|count\(14) & !\t1|Add0~27\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(14),
	datad => VCC,
	cin => \t1|Add0~27\,
	combout => \t1|Add0~28_combout\,
	cout => \t1|Add0~29\);

-- Location: LCCOMB_X53_Y32_N2
\t1|count~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~3_combout\ = (\t1|Add0~28_combout\ & !\t1|Equal0~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|Add0~28_combout\,
	datac => \t1|Equal0~8_combout\,
	combout => \t1|count~3_combout\);

-- Location: FF_X53_Y32_N3
\t1|count[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(14));

-- Location: LCCOMB_X54_Y32_N4
\t1|Add0~30\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~30_combout\ = (\t1|count\(15) & (!\t1|Add0~29\)) # (!\t1|count\(15) & ((\t1|Add0~29\) # (GND)))
-- \t1|Add0~31\ = CARRY((!\t1|Add0~29\) # (!\t1|count\(15)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(15),
	datad => VCC,
	cin => \t1|Add0~29\,
	combout => \t1|Add0~30_combout\,
	cout => \t1|Add0~31\);

-- Location: LCCOMB_X53_Y32_N20
\t1|count~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~4_combout\ = (\t1|Add0~30_combout\ & !\t1|Equal0~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|Add0~30_combout\,
	datac => \t1|Equal0~8_combout\,
	combout => \t1|count~4_combout\);

-- Location: FF_X53_Y32_N21
\t1|count[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(15));

-- Location: LCCOMB_X54_Y32_N6
\t1|Add0~32\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~32_combout\ = (\t1|count\(16) & (\t1|Add0~31\ $ (GND))) # (!\t1|count\(16) & (!\t1|Add0~31\ & VCC))
-- \t1|Add0~33\ = CARRY((\t1|count\(16) & !\t1|Add0~31\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(16),
	datad => VCC,
	cin => \t1|Add0~31\,
	combout => \t1|Add0~32_combout\,
	cout => \t1|Add0~33\);

-- Location: FF_X54_Y32_N7
\t1|count[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(16));

-- Location: LCCOMB_X54_Y32_N8
\t1|Add0~34\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~34_combout\ = (\t1|count\(17) & (!\t1|Add0~33\)) # (!\t1|count\(17) & ((\t1|Add0~33\) # (GND)))
-- \t1|Add0~35\ = CARRY((!\t1|Add0~33\) # (!\t1|count\(17)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(17),
	datad => VCC,
	cin => \t1|Add0~33\,
	combout => \t1|Add0~34_combout\,
	cout => \t1|Add0~35\);

-- Location: LCCOMB_X53_Y32_N18
\t1|count~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~5_combout\ = (!\t1|Equal0~8_combout\ & \t1|Add0~34_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|Equal0~8_combout\,
	datac => \t1|Add0~34_combout\,
	combout => \t1|count~5_combout\);

-- Location: FF_X53_Y32_N19
\t1|count[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(17));

-- Location: LCCOMB_X54_Y32_N10
\t1|Add0~36\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~36_combout\ = (\t1|count\(18) & (\t1|Add0~35\ $ (GND))) # (!\t1|count\(18) & (!\t1|Add0~35\ & VCC))
-- \t1|Add0~37\ = CARRY((\t1|count\(18) & !\t1|Add0~35\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(18),
	datad => VCC,
	cin => \t1|Add0~35\,
	combout => \t1|Add0~36_combout\,
	cout => \t1|Add0~37\);

-- Location: FF_X54_Y32_N11
\t1|count[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~36_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(18));

-- Location: LCCOMB_X54_Y32_N12
\t1|Add0~38\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~38_combout\ = (\t1|count\(19) & (!\t1|Add0~37\)) # (!\t1|count\(19) & ((\t1|Add0~37\) # (GND)))
-- \t1|Add0~39\ = CARRY((!\t1|Add0~37\) # (!\t1|count\(19)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(19),
	datad => VCC,
	cin => \t1|Add0~37\,
	combout => \t1|Add0~38_combout\,
	cout => \t1|Add0~39\);

-- Location: LCCOMB_X53_Y32_N28
\t1|count~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~6_combout\ = (!\t1|Equal0~8_combout\ & \t1|Add0~38_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|Equal0~8_combout\,
	datac => \t1|Add0~38_combout\,
	combout => \t1|count~6_combout\);

-- Location: FF_X53_Y32_N29
\t1|count[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(19));

-- Location: LCCOMB_X54_Y32_N14
\t1|Add0~40\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~40_combout\ = (\t1|count\(20) & (\t1|Add0~39\ $ (GND))) # (!\t1|count\(20) & (!\t1|Add0~39\ & VCC))
-- \t1|Add0~41\ = CARRY((\t1|count\(20) & !\t1|Add0~39\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(20),
	datad => VCC,
	cin => \t1|Add0~39\,
	combout => \t1|Add0~40_combout\,
	cout => \t1|Add0~41\);

-- Location: LCCOMB_X54_Y32_N26
\t1|count~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~7_combout\ = (\t1|Add0~40_combout\ & !\t1|Equal0~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \t1|Add0~40_combout\,
	datad => \t1|Equal0~8_combout\,
	combout => \t1|count~7_combout\);

-- Location: FF_X54_Y32_N27
\t1|count[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(20));

-- Location: LCCOMB_X54_Y32_N16
\t1|Add0~42\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~42_combout\ = (\t1|count\(21) & (!\t1|Add0~41\)) # (!\t1|count\(21) & ((\t1|Add0~41\) # (GND)))
-- \t1|Add0~43\ = CARRY((!\t1|Add0~41\) # (!\t1|count\(21)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(21),
	datad => VCC,
	cin => \t1|Add0~41\,
	combout => \t1|Add0~42_combout\,
	cout => \t1|Add0~43\);

-- Location: LCCOMB_X53_Y32_N16
\t1|count~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~8_combout\ = (!\t1|Equal0~8_combout\ & \t1|Add0~42_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \t1|Equal0~8_combout\,
	datad => \t1|Add0~42_combout\,
	combout => \t1|count~8_combout\);

-- Location: FF_X53_Y32_N17
\t1|count[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(21));

-- Location: LCCOMB_X54_Y32_N18
\t1|Add0~44\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~44_combout\ = (\t1|count\(22) & (\t1|Add0~43\ $ (GND))) # (!\t1|count\(22) & (!\t1|Add0~43\ & VCC))
-- \t1|Add0~45\ = CARRY((\t1|count\(22) & !\t1|Add0~43\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \t1|count\(22),
	datad => VCC,
	cin => \t1|Add0~43\,
	combout => \t1|Add0~44_combout\,
	cout => \t1|Add0~45\);

-- Location: LCCOMB_X54_Y32_N28
\t1|count~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~9_combout\ = (!\t1|Equal0~8_combout\ & \t1|Add0~44_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|Equal0~8_combout\,
	datad => \t1|Add0~44_combout\,
	combout => \t1|count~9_combout\);

-- Location: FF_X54_Y32_N29
\t1|count[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~9_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(22));

-- Location: LCCOMB_X54_Y32_N20
\t1|Add0~46\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~46_combout\ = (\t1|count\(23) & (!\t1|Add0~45\)) # (!\t1|count\(23) & ((\t1|Add0~45\) # (GND)))
-- \t1|Add0~47\ = CARRY((!\t1|Add0~45\) # (!\t1|count\(23)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(23),
	datad => VCC,
	cin => \t1|Add0~45\,
	combout => \t1|Add0~46_combout\,
	cout => \t1|Add0~47\);

-- Location: LCCOMB_X54_Y32_N30
\t1|count~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~10_combout\ = (!\t1|Equal0~8_combout\ & \t1|Add0~46_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|Equal0~8_combout\,
	datad => \t1|Add0~46_combout\,
	combout => \t1|count~10_combout\);

-- Location: FF_X54_Y32_N31
\t1|count[23]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~10_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(23));

-- Location: LCCOMB_X53_Y32_N26
\t1|Equal0~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~6_combout\ = (\t1|count\(21) & (\t1|count\(23) & (\t1|count\(20) & \t1|count\(22))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(21),
	datab => \t1|count\(23),
	datac => \t1|count\(20),
	datad => \t1|count\(22),
	combout => \t1|Equal0~6_combout\);

-- Location: LCCOMB_X53_Y32_N22
\t1|Equal0~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~3_combout\ = (\t1|count\(15) & (\t1|count\(14) & (\t1|count\(0) & \t1|count\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(15),
	datab => \t1|count\(14),
	datac => \t1|count\(0),
	datad => \t1|count\(1),
	combout => \t1|Equal0~3_combout\);

-- Location: LCCOMB_X54_Y33_N2
\t1|Equal0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~1_combout\ = (!\t1|count\(9) & (\t1|count\(6) & (!\t1|count\(8) & !\t1|count\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(9),
	datab => \t1|count\(6),
	datac => \t1|count\(8),
	datad => \t1|count\(7),
	combout => \t1|Equal0~1_combout\);

-- Location: LCCOMB_X54_Y33_N4
\t1|Equal0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~2_combout\ = (\t1|count\(3) & (\t1|count\(5) & (\t1|count\(4) & \t1|count\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(3),
	datab => \t1|count\(5),
	datac => \t1|count\(4),
	datad => \t1|count\(2),
	combout => \t1|Equal0~2_combout\);

-- Location: LCCOMB_X53_Y33_N30
\t1|Equal0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~0_combout\ = (\t1|count\(12) & (!\t1|count\(11) & (\t1|count\(13) & !\t1|count\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(12),
	datab => \t1|count\(11),
	datac => \t1|count\(13),
	datad => \t1|count\(10),
	combout => \t1|Equal0~0_combout\);

-- Location: LCCOMB_X53_Y32_N24
\t1|Equal0~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~4_combout\ = (\t1|Equal0~3_combout\ & (\t1|Equal0~1_combout\ & (\t1|Equal0~2_combout\ & \t1|Equal0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|Equal0~3_combout\,
	datab => \t1|Equal0~1_combout\,
	datac => \t1|Equal0~2_combout\,
	datad => \t1|Equal0~0_combout\,
	combout => \t1|Equal0~4_combout\);

-- Location: LCCOMB_X54_Y32_N22
\t1|Add0~48\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~48_combout\ = (\t1|count\(24) & (\t1|Add0~47\ $ (GND))) # (!\t1|count\(24) & (!\t1|Add0~47\ & VCC))
-- \t1|Add0~49\ = CARRY((\t1|count\(24) & !\t1|Add0~47\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(24),
	datad => VCC,
	cin => \t1|Add0~47\,
	combout => \t1|Add0~48_combout\,
	cout => \t1|Add0~49\);

-- Location: FF_X54_Y32_N23
\t1|count[24]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|Add0~48_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(24));

-- Location: LCCOMB_X54_Y32_N24
\t1|Add0~50\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Add0~50_combout\ = \t1|Add0~49\ $ (\t1|count\(25))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \t1|count\(25),
	cin => \t1|Add0~49\,
	combout => \t1|Add0~50_combout\);

-- Location: LCCOMB_X53_Y32_N12
\t1|count~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|count~11_combout\ = (!\t1|Equal0~8_combout\ & \t1|Add0~50_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \t1|Equal0~8_combout\,
	datad => \t1|Add0~50_combout\,
	combout => \t1|count~11_combout\);

-- Location: FF_X53_Y32_N13
\t1|count[25]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t1|count~11_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|count\(25));

-- Location: LCCOMB_X53_Y32_N30
\t1|Equal0~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~7_combout\ = (\t1|count\(25) & !\t1|count\(24))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(25),
	datac => \t1|count\(24),
	combout => \t1|Equal0~7_combout\);

-- Location: LCCOMB_X53_Y32_N6
\t1|Equal0~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~5_combout\ = (\t1|count\(17) & (\t1|count\(19) & (!\t1|count\(18) & !\t1|count\(16))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|count\(17),
	datab => \t1|count\(19),
	datac => \t1|count\(18),
	datad => \t1|count\(16),
	combout => \t1|Equal0~5_combout\);

-- Location: LCCOMB_X53_Y32_N8
\t1|Equal0~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \t1|Equal0~8_combout\ = (\t1|Equal0~6_combout\ & (\t1|Equal0~4_combout\ & (\t1|Equal0~7_combout\ & \t1|Equal0~5_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|Equal0~6_combout\,
	datab => \t1|Equal0~4_combout\,
	datac => \t1|Equal0~7_combout\,
	datad => \t1|Equal0~5_combout\,
	combout => \t1|Equal0~8_combout\);

-- Location: FF_X52_Y32_N31
\t1|toggle\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	asdata => \t1|toggle~0_combout\,
	sload => VCC,
	ena => \t1|Equal0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t1|toggle~q\);

-- Location: LCCOMB_X45_Y32_N12
\in_min_low[0]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[0]~13_combout\ = (\current_state.M0~q\ & (\in_min_low[0]~13_combout\)) # (!\current_state.M0~q\ & ((\cnt_min_low[0]~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[0]~13_combout\,
	datac => \cnt_min_low[0]~17_combout\,
	datad => \current_state.M0~q\,
	combout => \in_min_low[0]~13_combout\);

-- Location: LCCOMB_X45_Y32_N30
\in_min_low[0]~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[0]~15_combout\ = \in_min_low[0]~13_combout\ $ (!\in_min_low[0]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101001010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[0]~13_combout\,
	datad => \in_min_low[0]~14_combout\,
	combout => \in_min_low[0]~15_combout\);

-- Location: IOIBUF_X115_Y35_N22
\inc_btn~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_inc_btn,
	o => \inc_btn~input_o\);

-- Location: LCCOMB_X49_Y34_N28
\bt3|btn_sync~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \bt3|btn_sync~feeder_combout\ = \inc_btn~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \inc_btn~input_o\,
	combout => \bt3|btn_sync~feeder_combout\);

-- Location: FF_X49_Y34_N29
\bt3|btn_sync\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \bt3|btn_sync~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt3|btn_sync~q\);

-- Location: LCCOMB_X49_Y34_N2
\bt3|btn_delay~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \bt3|btn_delay~feeder_combout\ = \bt3|btn_sync~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \bt3|btn_sync~q\,
	combout => \bt3|btn_delay~feeder_combout\);

-- Location: FF_X49_Y34_N3
\bt3|btn_delay\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \bt3|btn_delay~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \bt3|btn_delay~q\);

-- Location: LCCOMB_X47_Y34_N18
\bt3|trig\ : cycloneive_lcell_comb
-- Equation(s):
-- \bt3|trig~combout\ = (\bt3|btn_sync~q\ & !\bt3|btn_delay~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \bt3|btn_sync~q\,
	datad => \bt3|btn_delay~q\,
	combout => \bt3|trig~combout\);

-- Location: FF_X45_Y32_N31
\in_min_low[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_low[0]~15_combout\,
	clrn => \current_state.M0~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_low[0]~_emulated_q\);

-- Location: LCCOMB_X45_Y32_N24
\in_min_low[0]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[0]~14_combout\ = (\current_state.M0~q\ & (\in_min_low[0]~13_combout\ $ (((\in_min_low[0]~_emulated_q\))))) # (!\current_state.M0~q\ & (((\cnt_min_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[0]~13_combout\,
	datab => \cnt_min_low[0]~17_combout\,
	datac => \in_min_low[0]~_emulated_q\,
	datad => \current_state.M0~q\,
	combout => \in_min_low[0]~14_combout\);

-- Location: LCCOMB_X46_Y32_N6
\cnt_min_low~29\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low~29_combout\ = (\current_state.M0~q\ & (\in_min_low[0]~14_combout\)) # (!\current_state.M0~q\ & ((\cnt_min_low[0]~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[0]~14_combout\,
	datac => \cnt_min_low[0]~17_combout\,
	datad => \current_state.M0~q\,
	combout => \cnt_min_low~29_combout\);

-- Location: LCCOMB_X50_Y32_N2
\cnt_sec_low[3]~28\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[3]~28_combout\ = (\en~input_o\ & !\current_state.INC~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \en~input_o\,
	datad => \current_state.INC~q\,
	combout => \cnt_sec_low[3]~28_combout\);

-- Location: LCCOMB_X47_Y32_N18
\cnt_min_low[0]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[0]~16_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low~29_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_low[0]~16_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_min_low[0]~16_combout\,
	datac => \cnt_min_low~29_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_low[0]~16_combout\);

-- Location: LCCOMB_X47_Y32_N8
\cnt_min_low[0]~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[0]~19_combout\ = \cnt_min_low[0]~17_combout\ $ (!\cnt_min_low[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_low[0]~17_combout\,
	datad => \cnt_min_low[0]~16_combout\,
	combout => \cnt_min_low[0]~19_combout\);

-- Location: LCCOMB_X50_Y32_N18
\cnt_min_high[2]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[2]~0_combout\ = (\cnt_sec_low[3]~28_combout\) # (!\en~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \en~input_o\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_high[2]~0_combout\);

-- Location: CLKCTRL_G15
\cnt_min_high[2]~0clkctrl\ : cycloneive_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \cnt_min_high[2]~0clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \cnt_min_high[2]~0clkctrl_outclk\);

-- Location: LCCOMB_X47_Y36_N14
\in_sec_low[1]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[1]~9_combout\ = (\current_state.S0~q\ & ((\in_sec_low[1]~9_combout\))) # (!\current_state.S0~q\ & (\cnt_sec_low[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[1]~12_combout\,
	datac => \in_sec_low[1]~9_combout\,
	datad => \current_state.S0~q\,
	combout => \in_sec_low[1]~9_combout\);

-- Location: LCCOMB_X50_Y32_N14
\cnt_sec_low~30\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low~30_combout\ = (\current_state.S0~q\ & ((\in_sec_low[0]~14_combout\))) # (!\current_state.S0~q\ & (\cnt_sec_low[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[0]~17_combout\,
	datac => \in_sec_low[0]~14_combout\,
	datad => \current_state.S0~q\,
	combout => \cnt_sec_low~30_combout\);

-- Location: LCCOMB_X50_Y32_N10
\cnt_sec_low[0]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[0]~16_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low~30_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low[0]~16_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[0]~16_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low~30_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_sec_low[0]~16_combout\);

-- Location: LCCOMB_X50_Y32_N16
\cnt_sec_low[0]~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[0]~19_combout\ = \cnt_sec_low[0]~17_combout\ $ (!\cnt_sec_low[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_low[0]~17_combout\,
	datad => \cnt_sec_low[0]~16_combout\,
	combout => \cnt_sec_low[0]~19_combout\);

-- Location: FF_X50_Y32_N23
\cnt_sec_low[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_low[0]~19_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_low[0]~_emulated_q\);

-- Location: LCCOMB_X50_Y32_N22
\cnt_sec_low[0]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[0]~18_combout\ = \cnt_sec_low[0]~_emulated_q\ $ (\cnt_sec_low[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_low[0]~_emulated_q\,
	datad => \cnt_sec_low[0]~16_combout\,
	combout => \cnt_sec_low[0]~18_combout\);

-- Location: LCCOMB_X50_Y32_N26
\cnt_sec_low[0]~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[0]~17_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low~30_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low[0]~18_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_sec_low~30_combout\,
	datac => \cnt_sec_low[0]~18_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_sec_low[0]~17_combout\);

-- Location: LCCOMB_X47_Y36_N0
\in_sec_low[0]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[0]~13_combout\ = (\current_state.S0~q\ & ((\in_sec_low[0]~13_combout\))) # (!\current_state.S0~q\ & (\cnt_sec_low[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[0]~17_combout\,
	datac => \current_state.S0~q\,
	datad => \in_sec_low[0]~13_combout\,
	combout => \in_sec_low[0]~13_combout\);

-- Location: LCCOMB_X47_Y36_N26
\in_sec_low[0]~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[0]~15_combout\ = \in_sec_low[0]~14_combout\ $ (!\in_sec_low[0]~13_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_sec_low[0]~14_combout\,
	datad => \in_sec_low[0]~13_combout\,
	combout => \in_sec_low[0]~15_combout\);

-- Location: FF_X47_Y36_N27
\in_sec_low[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_low[0]~15_combout\,
	clrn => \current_state.S0~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_low[0]~_emulated_q\);

-- Location: LCCOMB_X47_Y36_N18
\in_sec_low[0]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[0]~14_combout\ = (\current_state.S0~q\ & ((\in_sec_low[0]~_emulated_q\ $ (\in_sec_low[0]~13_combout\)))) # (!\current_state.S0~q\ & (\cnt_sec_low[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.S0~q\,
	datab => \cnt_sec_low[0]~17_combout\,
	datac => \in_sec_low[0]~_emulated_q\,
	datad => \in_sec_low[0]~13_combout\,
	combout => \in_sec_low[0]~14_combout\);

-- Location: LCCOMB_X52_Y32_N22
\cnt_sec_low~31\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low~31_combout\ = (\current_state.S0~q\ & ((\in_sec_low[3]~6_combout\))) # (!\current_state.S0~q\ & (\cnt_sec_low[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[3]~7_combout\,
	datac => \in_sec_low[3]~6_combout\,
	datad => \current_state.S0~q\,
	combout => \cnt_sec_low~31_combout\);

-- Location: LCCOMB_X47_Y36_N16
\Add0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add0~0_combout\ = (\in_sec_low[1]~10_combout\ & \in_sec_low[0]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \in_sec_low[1]~10_combout\,
	datad => \in_sec_low[0]~14_combout\,
	combout => \Add0~0_combout\);

-- Location: LCCOMB_X47_Y36_N20
\in_sec_low[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[2]~1_combout\ = (\current_state.S0~q\ & ((\in_sec_low[2]~1_combout\))) # (!\current_state.S0~q\ & (\cnt_sec_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[2]~2_combout\,
	datac => \current_state.S0~q\,
	datad => \in_sec_low[2]~1_combout\,
	combout => \in_sec_low[2]~1_combout\);

-- Location: LCCOMB_X47_Y36_N22
\in_sec_low[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[2]~3_combout\ = \in_sec_low[2]~1_combout\ $ (\in_sec_low[2]~2_combout\ $ (((\Add0~0_combout\ & \bt3|trig~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001001101101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Add0~0_combout\,
	datab => \in_sec_low[2]~1_combout\,
	datac => \bt3|trig~combout\,
	datad => \in_sec_low[2]~2_combout\,
	combout => \in_sec_low[2]~3_combout\);

-- Location: FF_X47_Y36_N23
\in_sec_low[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_low[2]~3_combout\,
	clrn => \current_state.S0~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_low[2]~_emulated_q\);

-- Location: LCCOMB_X47_Y36_N24
\in_sec_low[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[2]~2_combout\ = (\current_state.S0~q\ & (\in_sec_low[2]~_emulated_q\ $ (((\in_sec_low[2]~1_combout\))))) # (!\current_state.S0~q\ & (((\cnt_sec_low[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_low[2]~_emulated_q\,
	datab => \cnt_sec_low[2]~2_combout\,
	datac => \current_state.S0~q\,
	datad => \in_sec_low[2]~1_combout\,
	combout => \in_sec_low[2]~2_combout\);

-- Location: LCCOMB_X52_Y32_N12
\cnt_sec_low~29\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low~29_combout\ = (\current_state.S0~q\ & ((\in_sec_low[2]~2_combout\))) # (!\current_state.S0~q\ & (\cnt_sec_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_low[2]~2_combout\,
	datac => \in_sec_low[2]~2_combout\,
	datad => \current_state.S0~q\,
	combout => \cnt_sec_low~29_combout\);

-- Location: LCCOMB_X52_Y32_N28
\cnt_sec_low[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[2]~1_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low~29_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low[2]~1_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low~29_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_sec_low[2]~1_combout\,
	combout => \cnt_sec_low[2]~1_combout\);

-- Location: LCCOMB_X52_Y32_N4
\cnt_sec_low[2]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[2]~4_combout\ = \cnt_sec_low[2]~2_combout\ $ (\cnt_sec_low[2]~1_combout\ $ (((\cnt_sec_low[1]~12_combout\ & \cnt_sec_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001001101101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[1]~12_combout\,
	datab => \cnt_sec_low[2]~2_combout\,
	datac => \cnt_sec_low[0]~17_combout\,
	datad => \cnt_sec_low[2]~1_combout\,
	combout => \cnt_sec_low[2]~4_combout\);

-- Location: FF_X52_Y32_N21
\cnt_sec_low[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_low[2]~4_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_low[2]~_emulated_q\);

-- Location: LCCOMB_X52_Y32_N20
\cnt_sec_low[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[2]~3_combout\ = \cnt_sec_low[2]~_emulated_q\ $ (\cnt_sec_low[2]~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_low[2]~_emulated_q\,
	datad => \cnt_sec_low[2]~1_combout\,
	combout => \cnt_sec_low[2]~3_combout\);

-- Location: LCCOMB_X52_Y32_N26
\cnt_sec_low[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[2]~2_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low~29_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low[2]~3_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low~29_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_sec_low[2]~3_combout\,
	combout => \cnt_sec_low[2]~2_combout\);

-- Location: LCCOMB_X56_Y30_N8
\Add1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add1~0_combout\ = (\cnt_sec_low[0]~17_combout\ & (\cnt_sec_low[2]~2_combout\ & \cnt_sec_low[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[0]~17_combout\,
	datac => \cnt_sec_low[2]~2_combout\,
	datad => \cnt_sec_low[1]~12_combout\,
	combout => \Add1~0_combout\);

-- Location: LCCOMB_X52_Y32_N0
\cnt_sec_low[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[3]~6_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low~31_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low[3]~6_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low~31_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_sec_low[3]~6_combout\,
	combout => \cnt_sec_low[3]~6_combout\);

-- Location: LCCOMB_X52_Y32_N6
\cnt_sec_low[3]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[3]~9_combout\ = \cnt_sec_low[3]~6_combout\ $ (((!\se4|Equal15~0_combout\ & (\Add1~0_combout\ $ (\cnt_sec_low[3]~7_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100100000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Add1~0_combout\,
	datab => \cnt_sec_low[3]~7_combout\,
	datac => \se4|Equal15~0_combout\,
	datad => \cnt_sec_low[3]~6_combout\,
	combout => \cnt_sec_low[3]~9_combout\);

-- Location: FF_X52_Y32_N11
\cnt_sec_low[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_low[3]~9_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_low[3]~_emulated_q\);

-- Location: LCCOMB_X52_Y32_N10
\cnt_sec_low[3]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[3]~8_combout\ = \cnt_sec_low[3]~_emulated_q\ $ (\cnt_sec_low[3]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_low[3]~_emulated_q\,
	datad => \cnt_sec_low[3]~6_combout\,
	combout => \cnt_sec_low[3]~8_combout\);

-- Location: LCCOMB_X52_Y32_N18
\cnt_sec_low[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[3]~7_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low~31_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low[3]~8_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low~31_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_sec_low[3]~8_combout\,
	combout => \cnt_sec_low[3]~7_combout\);

-- Location: LCCOMB_X47_Y36_N28
\in_sec_low[3]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[3]~5_combout\ = (\current_state.S0~q\ & (\in_sec_low[3]~5_combout\)) # (!\current_state.S0~q\ & ((\cnt_sec_low[3]~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_sec_low[3]~5_combout\,
	datac => \cnt_sec_low[3]~7_combout\,
	datad => \current_state.S0~q\,
	combout => \in_sec_low[3]~5_combout\);

-- Location: LCCOMB_X47_Y36_N4
\Add0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add0~1_combout\ = (\in_sec_low[0]~14_combout\ & (\in_sec_low[1]~10_combout\ & \in_sec_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_sec_low[0]~14_combout\,
	datac => \in_sec_low[1]~10_combout\,
	datad => \in_sec_low[2]~2_combout\,
	combout => \Add0~1_combout\);

-- Location: LCCOMB_X47_Y36_N30
\in_sec_low[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[3]~7_combout\ = \in_sec_low[3]~5_combout\ $ (((!\Equal0~0_combout\ & (\Add0~1_combout\ $ (\in_sec_low[3]~6_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100100110011100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Equal0~0_combout\,
	datab => \in_sec_low[3]~5_combout\,
	datac => \Add0~1_combout\,
	datad => \in_sec_low[3]~6_combout\,
	combout => \in_sec_low[3]~7_combout\);

-- Location: FF_X47_Y36_N31
\in_sec_low[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_low[3]~7_combout\,
	clrn => \current_state.S0~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_low[3]~_emulated_q\);

-- Location: LCCOMB_X47_Y36_N2
\in_sec_low[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[3]~6_combout\ = (\current_state.S0~q\ & (\in_sec_low[3]~_emulated_q\ $ (((\in_sec_low[3]~5_combout\))))) # (!\current_state.S0~q\ & (((\cnt_sec_low[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_low[3]~_emulated_q\,
	datab => \cnt_sec_low[3]~7_combout\,
	datac => \current_state.S0~q\,
	datad => \in_sec_low[3]~5_combout\,
	combout => \in_sec_low[3]~6_combout\);

-- Location: LCCOMB_X47_Y36_N12
\Equal0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Equal0~0_combout\ = (\in_sec_low[0]~14_combout\ & (\in_sec_low[3]~6_combout\ & (!\in_sec_low[1]~10_combout\ & !\in_sec_low[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_low[0]~14_combout\,
	datab => \in_sec_low[3]~6_combout\,
	datac => \in_sec_low[1]~10_combout\,
	datad => \in_sec_low[2]~2_combout\,
	combout => \Equal0~0_combout\);

-- Location: LCCOMB_X47_Y36_N10
\in_sec_low[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[1]~11_combout\ = \in_sec_low[1]~9_combout\ $ (((!\Equal0~0_combout\ & (\in_sec_low[1]~10_combout\ $ (\in_sec_low[0]~14_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101100010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Equal0~0_combout\,
	datab => \in_sec_low[1]~10_combout\,
	datac => \in_sec_low[0]~14_combout\,
	datad => \in_sec_low[1]~9_combout\,
	combout => \in_sec_low[1]~11_combout\);

-- Location: FF_X47_Y36_N11
\in_sec_low[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_low[1]~11_combout\,
	clrn => \current_state.S0~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_low[1]~_emulated_q\);

-- Location: LCCOMB_X47_Y36_N8
\in_sec_low[1]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_low[1]~10_combout\ = (\current_state.S0~q\ & ((\in_sec_low[1]~9_combout\ $ (\in_sec_low[1]~_emulated_q\)))) # (!\current_state.S0~q\ & (\cnt_sec_low[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.S0~q\,
	datab => \cnt_sec_low[1]~12_combout\,
	datac => \in_sec_low[1]~9_combout\,
	datad => \in_sec_low[1]~_emulated_q\,
	combout => \in_sec_low[1]~10_combout\);

-- Location: LCCOMB_X47_Y36_N6
\cnt_sec_low~32\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low~32_combout\ = (\current_state.S0~q\ & (\in_sec_low[1]~10_combout\)) # (!\current_state.S0~q\ & ((\cnt_sec_low[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_sec_low[1]~10_combout\,
	datac => \current_state.S0~q\,
	datad => \cnt_sec_low[1]~12_combout\,
	combout => \cnt_sec_low~32_combout\);

-- Location: LCCOMB_X52_Y32_N2
\cnt_sec_low[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[1]~11_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low~32_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low[1]~11_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low~32_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_sec_low[1]~11_combout\,
	combout => \cnt_sec_low[1]~11_combout\);

-- Location: LCCOMB_X52_Y32_N30
\se4|Equal15~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se4|Equal15~1_combout\ = (\cnt_sec_low[3]~7_combout\ & !\cnt_sec_low[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[3]~7_combout\,
	datab => \cnt_sec_low[2]~2_combout\,
	combout => \se4|Equal15~1_combout\);

-- Location: LCCOMB_X52_Y32_N16
\cnt_sec_low[1]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[1]~14_combout\ = \cnt_sec_low[1]~11_combout\ $ (((\cnt_sec_low[1]~12_combout\ & (!\cnt_sec_low[0]~17_combout\)) # (!\cnt_sec_low[1]~12_combout\ & (\cnt_sec_low[0]~17_combout\ & !\se4|Equal15~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100011010010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[1]~12_combout\,
	datab => \cnt_sec_low[1]~11_combout\,
	datac => \cnt_sec_low[0]~17_combout\,
	datad => \se4|Equal15~1_combout\,
	combout => \cnt_sec_low[1]~14_combout\);

-- Location: FF_X52_Y32_N25
\cnt_sec_low[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_low[1]~14_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_low[1]~_emulated_q\);

-- Location: LCCOMB_X52_Y32_N24
\cnt_sec_low[1]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[1]~13_combout\ = \cnt_sec_low[1]~_emulated_q\ $ (\cnt_sec_low[1]~11_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_low[1]~_emulated_q\,
	datad => \cnt_sec_low[1]~11_combout\,
	combout => \cnt_sec_low[1]~13_combout\);

-- Location: LCCOMB_X52_Y32_N8
\cnt_sec_low[1]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_low[1]~12_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_low~32_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_low[1]~13_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low~32_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_sec_low[1]~13_combout\,
	combout => \cnt_sec_low[1]~12_combout\);

-- Location: LCCOMB_X52_Y32_N14
\se4|Equal15~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se4|Equal15~0_combout\ = (!\cnt_sec_low[1]~12_combout\ & (!\cnt_sec_low[2]~2_combout\ & (\cnt_sec_low[0]~17_combout\ & \cnt_sec_low[3]~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[1]~12_combout\,
	datab => \cnt_sec_low[2]~2_combout\,
	datac => \cnt_sec_low[0]~17_combout\,
	datad => \cnt_sec_low[3]~7_combout\,
	combout => \se4|Equal15~0_combout\);

-- Location: LCCOMB_X46_Y33_N8
\in_sec_high[0]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[0]~13_combout\ = (\current_state.S1~q\ & (\in_sec_high[0]~13_combout\)) # (!\current_state.S1~q\ & ((\cnt_sec_high[0]~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_sec_high[0]~13_combout\,
	datac => \cnt_sec_high[0]~17_combout\,
	datad => \current_state.S1~q\,
	combout => \in_sec_high[0]~13_combout\);

-- Location: LCCOMB_X46_Y33_N0
\in_sec_high[0]~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[0]~15_combout\ = \in_sec_high[0]~13_combout\ $ (!\in_sec_high[0]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001111000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_sec_high[0]~13_combout\,
	datac => \in_sec_high[0]~14_combout\,
	combout => \in_sec_high[0]~15_combout\);

-- Location: FF_X46_Y33_N1
\in_sec_high[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_high[0]~15_combout\,
	clrn => \current_state.S1~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_high[0]~_emulated_q\);

-- Location: LCCOMB_X46_Y33_N14
\in_sec_high[0]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[0]~14_combout\ = (\current_state.S1~q\ & ((\in_sec_high[0]~13_combout\ $ (\in_sec_high[0]~_emulated_q\)))) # (!\current_state.S1~q\ & (\cnt_sec_high[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[0]~17_combout\,
	datab => \in_sec_high[0]~13_combout\,
	datac => \current_state.S1~q\,
	datad => \in_sec_high[0]~_emulated_q\,
	combout => \in_sec_high[0]~14_combout\);

-- Location: LCCOMB_X46_Y33_N16
\cnt_sec_high~29\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high~29_combout\ = (\current_state.S1~q\ & ((\in_sec_high[0]~14_combout\))) # (!\current_state.S1~q\ & (\cnt_sec_high[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[0]~17_combout\,
	datac => \in_sec_high[0]~14_combout\,
	datad => \current_state.S1~q\,
	combout => \cnt_sec_high~29_combout\);

-- Location: LCCOMB_X49_Y31_N20
\cnt_sec_high[0]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[0]~16_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high~29_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high[0]~16_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_sec_high[0]~16_combout\,
	datac => \cnt_sec_high~29_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_sec_high[0]~16_combout\);

-- Location: LCCOMB_X49_Y31_N30
\cnt_sec_high[0]~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[0]~19_combout\ = \cnt_sec_high[0]~16_combout\ $ (!\cnt_sec_high[0]~17_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001111000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_high[0]~16_combout\,
	datac => \cnt_sec_high[0]~17_combout\,
	combout => \cnt_sec_high[0]~19_combout\);

-- Location: FF_X49_Y31_N15
\cnt_sec_high[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_high[0]~19_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \se4|Equal15~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_high[0]~_emulated_q\);

-- Location: LCCOMB_X49_Y31_N14
\cnt_sec_high[0]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[0]~18_combout\ = \cnt_sec_high[0]~_emulated_q\ $ (\cnt_sec_high[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_high[0]~_emulated_q\,
	datad => \cnt_sec_high[0]~16_combout\,
	combout => \cnt_sec_high[0]~18_combout\);

-- Location: LCCOMB_X49_Y31_N4
\cnt_sec_high[0]~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[0]~17_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high~29_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high[0]~18_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_sec_high~29_combout\,
	datac => \cnt_sec_high[0]~18_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_sec_high[0]~17_combout\);

-- Location: LCCOMB_X49_Y31_N22
\cnt_sec_high~32\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high~32_combout\ = (\current_state.S1~q\ & (\in_sec_high[1]~10_combout\)) # (!\current_state.S1~q\ & ((\cnt_sec_high[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_high[1]~10_combout\,
	datac => \cnt_sec_high[1]~12_combout\,
	datad => \current_state.S1~q\,
	combout => \cnt_sec_high~32_combout\);

-- Location: LCCOMB_X49_Y31_N16
\cnt_sec_high[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[1]~11_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high~32_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high[1]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_sec_high[1]~11_combout\,
	datac => \cnt_sec_high~32_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_sec_high[1]~11_combout\);

-- Location: LCCOMB_X46_Y33_N10
\in_sec_high[3]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[3]~5_combout\ = (\current_state.S1~q\ & ((\in_sec_high[3]~5_combout\))) # (!\current_state.S1~q\ & (\cnt_sec_high[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_high[3]~7_combout\,
	datac => \current_state.S1~q\,
	datad => \in_sec_high[3]~5_combout\,
	combout => \in_sec_high[3]~5_combout\);

-- Location: LCCOMB_X46_Y33_N12
\in_sec_high[3]~22\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[3]~22_combout\ = (\bt3|btn_sync~q\ & (!\bt3|btn_delay~q\ & \in_sec_high[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt3|btn_sync~q\,
	datac => \bt3|btn_delay~q\,
	datad => \in_sec_high[2]~2_combout\,
	combout => \in_sec_high[3]~22_combout\);

-- Location: LCCOMB_X46_Y33_N28
\Add2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add2~0_combout\ = (\in_sec_high[1]~10_combout\ & \in_sec_high[0]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_high[1]~10_combout\,
	datac => \in_sec_high[0]~14_combout\,
	combout => \Add2~0_combout\);

-- Location: LCCOMB_X46_Y33_N30
\in_sec_high[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[3]~7_combout\ = \in_sec_high[3]~5_combout\ $ (\in_sec_high[3]~6_combout\ $ (((\in_sec_high[3]~22_combout\ & \Add2~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001010101101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_high[3]~5_combout\,
	datab => \in_sec_high[3]~22_combout\,
	datac => \Add2~0_combout\,
	datad => \in_sec_high[3]~6_combout\,
	combout => \in_sec_high[3]~7_combout\);

-- Location: FF_X46_Y33_N31
\in_sec_high[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_high[3]~7_combout\,
	clrn => \current_state.S1~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_high[3]~_emulated_q\);

-- Location: LCCOMB_X46_Y33_N24
\in_sec_high[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[3]~6_combout\ = (\current_state.S1~q\ & (\in_sec_high[3]~_emulated_q\ $ (((\in_sec_high[3]~5_combout\))))) # (!\current_state.S1~q\ & (((\cnt_sec_high[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_high[3]~_emulated_q\,
	datab => \cnt_sec_high[3]~7_combout\,
	datac => \current_state.S1~q\,
	datad => \in_sec_high[3]~5_combout\,
	combout => \in_sec_high[3]~6_combout\);

-- Location: LCCOMB_X49_Y33_N10
\cnt_sec_high~31\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high~31_combout\ = (\current_state.S1~q\ & ((\in_sec_high[3]~6_combout\))) # (!\current_state.S1~q\ & (\cnt_sec_high[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_high[3]~7_combout\,
	datac => \in_sec_high[3]~6_combout\,
	datad => \current_state.S1~q\,
	combout => \cnt_sec_high~31_combout\);

-- Location: LCCOMB_X50_Y32_N0
\cnt_sec_high[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[3]~6_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high~31_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high[3]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_sec_high[3]~6_combout\,
	datac => \cnt_sec_high~31_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_sec_high[3]~6_combout\);

-- Location: LCCOMB_X49_Y32_N10
\se3|seg[1]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \se3|seg[1]~4_combout\ = (\cnt_sec_high[1]~12_combout\ & \cnt_sec_high[0]~17_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[1]~12_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \se3|seg[1]~4_combout\);

-- Location: LCCOMB_X49_Y32_N14
\cnt_sec_high[3]~30\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[3]~30_combout\ = \cnt_sec_high[3]~7_combout\ $ (((\se3|seg[1]~4_combout\ & (\se4|Equal15~0_combout\ & \cnt_sec_high[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se3|seg[1]~4_combout\,
	datab => \se4|Equal15~0_combout\,
	datac => \cnt_sec_high[3]~7_combout\,
	datad => \cnt_sec_high[2]~2_combout\,
	combout => \cnt_sec_high[3]~30_combout\);

-- Location: LCCOMB_X50_Y32_N12
\cnt_sec_high[3]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[3]~9_combout\ = \cnt_sec_high[3]~6_combout\ $ (\cnt_sec_high[3]~30_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_high[3]~6_combout\,
	datad => \cnt_sec_high[3]~30_combout\,
	combout => \cnt_sec_high[3]~9_combout\);

-- Location: FF_X50_Y32_N9
\cnt_sec_high[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_high[3]~9_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_high[3]~_emulated_q\);

-- Location: LCCOMB_X50_Y32_N8
\cnt_sec_high[3]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[3]~8_combout\ = \cnt_sec_high[3]~_emulated_q\ $ (\cnt_sec_high[3]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_high[3]~_emulated_q\,
	datad => \cnt_sec_high[3]~6_combout\,
	combout => \cnt_sec_high[3]~8_combout\);

-- Location: LCCOMB_X50_Y32_N30
\cnt_sec_high[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[3]~7_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high~31_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high[3]~8_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high~31_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_high[3]~8_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_sec_high[3]~7_combout\);

-- Location: LCCOMB_X48_Y31_N14
\se3|Equal15~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se3|Equal15~1_combout\ = (\cnt_sec_high[2]~2_combout\ & !\cnt_sec_high[3]~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_high[2]~2_combout\,
	datac => \cnt_sec_high[3]~7_combout\,
	combout => \se3|Equal15~1_combout\);

-- Location: LCCOMB_X49_Y31_N0
\cnt_sec_high[1]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[1]~14_combout\ = \cnt_sec_high[1]~11_combout\ $ (((\cnt_sec_high[1]~12_combout\ & (!\cnt_sec_high[0]~17_combout\)) # (!\cnt_sec_high[1]~12_combout\ & (\cnt_sec_high[0]~17_combout\ & !\se3|Equal15~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100011010010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[1]~12_combout\,
	datab => \cnt_sec_high[1]~11_combout\,
	datac => \cnt_sec_high[0]~17_combout\,
	datad => \se3|Equal15~1_combout\,
	combout => \cnt_sec_high[1]~14_combout\);

-- Location: FF_X49_Y31_N9
\cnt_sec_high[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_high[1]~14_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \se4|Equal15~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_high[1]~_emulated_q\);

-- Location: LCCOMB_X49_Y31_N8
\cnt_sec_high[1]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[1]~13_combout\ = \cnt_sec_high[1]~_emulated_q\ $ (\cnt_sec_high[1]~11_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_high[1]~_emulated_q\,
	datad => \cnt_sec_high[1]~11_combout\,
	combout => \cnt_sec_high[1]~13_combout\);

-- Location: LCCOMB_X49_Y31_N26
\cnt_sec_high[1]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[1]~12_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high~32_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high[1]~13_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high~32_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_high[1]~13_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_sec_high[1]~12_combout\);

-- Location: LCCOMB_X46_Y33_N20
\in_sec_high[1]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[1]~9_combout\ = (\current_state.S1~q\ & ((\in_sec_high[1]~9_combout\))) # (!\current_state.S1~q\ & (\cnt_sec_high[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[1]~12_combout\,
	datac => \current_state.S1~q\,
	datad => \in_sec_high[1]~9_combout\,
	combout => \in_sec_high[1]~9_combout\);

-- Location: LCCOMB_X46_Y33_N22
\in_sec_high[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[1]~11_combout\ = \in_sec_high[1]~9_combout\ $ (((!\Equal2~0_combout\ & (\in_sec_high[1]~10_combout\ $ (\in_sec_high[0]~14_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_high[1]~10_combout\,
	datab => \in_sec_high[1]~9_combout\,
	datac => \in_sec_high[0]~14_combout\,
	datad => \Equal2~0_combout\,
	combout => \in_sec_high[1]~11_combout\);

-- Location: FF_X46_Y33_N23
\in_sec_high[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_high[1]~11_combout\,
	clrn => \current_state.S1~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_high[1]~_emulated_q\);

-- Location: LCCOMB_X46_Y33_N26
\in_sec_high[1]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[1]~10_combout\ = (\current_state.S1~q\ & ((\in_sec_high[1]~_emulated_q\ $ (\in_sec_high[1]~9_combout\)))) # (!\current_state.S1~q\ & (\cnt_sec_high[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010111011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[1]~12_combout\,
	datab => \current_state.S1~q\,
	datac => \in_sec_high[1]~_emulated_q\,
	datad => \in_sec_high[1]~9_combout\,
	combout => \in_sec_high[1]~10_combout\);

-- Location: LCCOMB_X46_Y33_N4
\Equal2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Equal2~0_combout\ = (!\in_sec_high[1]~10_combout\ & (\in_sec_high[2]~2_combout\ & (\in_sec_high[0]~14_combout\ & !\in_sec_high[3]~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_high[1]~10_combout\,
	datab => \in_sec_high[2]~2_combout\,
	datac => \in_sec_high[0]~14_combout\,
	datad => \in_sec_high[3]~6_combout\,
	combout => \Equal2~0_combout\);

-- Location: LCCOMB_X46_Y33_N2
\in_sec_high[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[2]~1_combout\ = (\current_state.S1~q\ & ((\in_sec_high[2]~1_combout\))) # (!\current_state.S1~q\ & (\cnt_sec_high[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_sec_high[2]~2_combout\,
	datac => \current_state.S1~q\,
	datad => \in_sec_high[2]~1_combout\,
	combout => \in_sec_high[2]~1_combout\);

-- Location: LCCOMB_X46_Y33_N6
\in_sec_high[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[2]~3_combout\ = \in_sec_high[2]~1_combout\ $ (((!\Equal2~0_combout\ & (\Add2~0_combout\ $ (\in_sec_high[2]~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100100110011100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Equal2~0_combout\,
	datab => \in_sec_high[2]~1_combout\,
	datac => \Add2~0_combout\,
	datad => \in_sec_high[2]~2_combout\,
	combout => \in_sec_high[2]~3_combout\);

-- Location: FF_X46_Y33_N7
\in_sec_high[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_sec_high[2]~3_combout\,
	clrn => \current_state.S1~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_sec_high[2]~_emulated_q\);

-- Location: LCCOMB_X46_Y33_N18
\in_sec_high[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_sec_high[2]~2_combout\ = (\current_state.S1~q\ & (\in_sec_high[2]~_emulated_q\ $ (((\in_sec_high[2]~1_combout\))))) # (!\current_state.S1~q\ & (((\cnt_sec_high[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_sec_high[2]~_emulated_q\,
	datab => \cnt_sec_high[2]~2_combout\,
	datac => \current_state.S1~q\,
	datad => \in_sec_high[2]~1_combout\,
	combout => \in_sec_high[2]~2_combout\);

-- Location: LCCOMB_X49_Y33_N30
\cnt_sec_high~28\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high~28_combout\ = (\current_state.S1~q\ & ((\in_sec_high[2]~2_combout\))) # (!\current_state.S1~q\ & (\cnt_sec_high[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[2]~2_combout\,
	datac => \in_sec_high[2]~2_combout\,
	datad => \current_state.S1~q\,
	combout => \cnt_sec_high~28_combout\);

-- Location: LCCOMB_X49_Y32_N16
\cnt_sec_high[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[2]~1_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high~28_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high[2]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_sec_high[2]~1_combout\,
	datac => \cnt_sec_high~28_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_sec_high[2]~1_combout\);

-- Location: LCCOMB_X49_Y32_N8
\cnt_sec_high[2]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[2]~4_combout\ = \cnt_sec_high[2]~1_combout\ $ (((!\se3|Equal15~0_combout\ & (\se3|seg[1]~4_combout\ $ (\cnt_sec_high[2]~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se3|seg[1]~4_combout\,
	datab => \cnt_sec_high[2]~1_combout\,
	datac => \cnt_sec_high[2]~2_combout\,
	datad => \se3|Equal15~0_combout\,
	combout => \cnt_sec_high[2]~4_combout\);

-- Location: FF_X49_Y32_N27
\cnt_sec_high[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_sec_high[2]~4_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \se4|Equal15~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_sec_high[2]~_emulated_q\);

-- Location: LCCOMB_X49_Y32_N26
\cnt_sec_high[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[2]~3_combout\ = \cnt_sec_high[2]~_emulated_q\ $ (\cnt_sec_high[2]~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_sec_high[2]~_emulated_q\,
	datad => \cnt_sec_high[2]~1_combout\,
	combout => \cnt_sec_high[2]~3_combout\);

-- Location: LCCOMB_X49_Y32_N30
\cnt_sec_high[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_sec_high[2]~2_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_sec_high~28_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_sec_high[2]~3_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high~28_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_high[2]~3_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_sec_high[2]~2_combout\);

-- Location: LCCOMB_X49_Y32_N18
\se3|Equal15~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se3|Equal15~0_combout\ = (\cnt_sec_high[0]~17_combout\ & (\cnt_sec_high[2]~2_combout\ & (!\cnt_sec_high[3]~7_combout\ & !\cnt_sec_high[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[0]~17_combout\,
	datab => \cnt_sec_high[2]~2_combout\,
	datac => \cnt_sec_high[3]~7_combout\,
	datad => \cnt_sec_high[1]~12_combout\,
	combout => \se3|Equal15~0_combout\);

-- Location: LCCOMB_X49_Y32_N2
\process_7~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_7~0_combout\ = (\se4|Equal15~0_combout\ & \se3|Equal15~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se4|Equal15~0_combout\,
	datad => \se3|Equal15~0_combout\,
	combout => \process_7~0_combout\);

-- Location: FF_X47_Y32_N7
\cnt_min_low[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_low[0]~19_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_7~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_low[0]~_emulated_q\);

-- Location: LCCOMB_X47_Y32_N6
\cnt_min_low[0]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[0]~18_combout\ = \cnt_min_low[0]~_emulated_q\ $ (\cnt_min_low[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_low[0]~_emulated_q\,
	datad => \cnt_min_low[0]~16_combout\,
	combout => \cnt_min_low[0]~18_combout\);

-- Location: LCCOMB_X47_Y32_N14
\cnt_min_low[0]~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[0]~17_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_low~29_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low[0]~18_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_min_low~29_combout\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_min_low[0]~18_combout\,
	combout => \cnt_min_low[0]~17_combout\);

-- Location: LCCOMB_X48_Y31_N8
\in_tim_min_low[0]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_low[0]~4_combout\ = !in_tim_min_low(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => in_tim_min_low(0),
	combout => \in_tim_min_low[0]~4_combout\);

-- Location: LCCOMB_X47_Y31_N22
\in_tim_min_low[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_low[0]~0_combout\ = (\current_state.MT0~q\ & (\bt3|btn_sync~q\ & !\bt3|btn_delay~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.MT0~q\,
	datab => \bt3|btn_sync~q\,
	datad => \bt3|btn_delay~q\,
	combout => \in_tim_min_low[0]~0_combout\);

-- Location: FF_X47_Y31_N23
\in_tim_min_low[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	asdata => \in_tim_min_low[0]~4_combout\,
	clrn => \en~input_o\,
	sload => VCC,
	ena => \in_tim_min_low[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_low(0));

-- Location: LCCOMB_X47_Y32_N30
\Equal14~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Equal14~0_combout\ = \cnt_min_low[0]~17_combout\ $ (!in_tim_min_low(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_low[0]~17_combout\,
	datad => in_tim_min_low(0),
	combout => \Equal14~0_combout\);

-- Location: LCCOMB_X45_Y32_N20
\in_min_low[1]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[1]~9_combout\ = (\current_state.M0~q\ & ((\in_min_low[1]~9_combout\))) # (!\current_state.M0~q\ & (\cnt_min_low[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_min_low[1]~12_combout\,
	datac => \in_min_low[1]~9_combout\,
	datad => \current_state.M0~q\,
	combout => \in_min_low[1]~9_combout\);

-- Location: LCCOMB_X45_Y32_N18
\cnt_min_low~30\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low~30_combout\ = (\current_state.M0~q\ & ((\in_min_low[3]~6_combout\))) # (!\current_state.M0~q\ & (\cnt_min_low[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_min_low[3]~7_combout\,
	datac => \in_min_low[3]~6_combout\,
	datad => \current_state.M0~q\,
	combout => \cnt_min_low~30_combout\);

-- Location: LCCOMB_X45_Y32_N2
\in_min_low[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[2]~1_combout\ = (\current_state.M0~q\ & (\in_min_low[2]~1_combout\)) # (!\current_state.M0~q\ & ((\cnt_min_low[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \in_min_low[2]~1_combout\,
	datac => \cnt_min_low[2]~2_combout\,
	datad => \current_state.M0~q\,
	combout => \in_min_low[2]~1_combout\);

-- Location: LCCOMB_X45_Y32_N16
\Add4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add4~0_combout\ = (\in_min_low[1]~10_combout\ & \in_min_low[0]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[1]~10_combout\,
	datad => \in_min_low[0]~14_combout\,
	combout => \Add4~0_combout\);

-- Location: LCCOMB_X45_Y32_N22
\in_min_low[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[2]~3_combout\ = \in_min_low[2]~2_combout\ $ (\in_min_low[2]~1_combout\ $ (((\bt3|trig~combout\ & \Add4~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011001100110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[2]~2_combout\,
	datab => \in_min_low[2]~1_combout\,
	datac => \bt3|trig~combout\,
	datad => \Add4~0_combout\,
	combout => \in_min_low[2]~3_combout\);

-- Location: FF_X45_Y32_N23
\in_min_low[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_low[2]~3_combout\,
	clrn => \current_state.M0~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_low[2]~_emulated_q\);

-- Location: LCCOMB_X45_Y32_N28
\in_min_low[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[2]~2_combout\ = (\current_state.M0~q\ & ((\in_min_low[2]~1_combout\ $ (\in_min_low[2]~_emulated_q\)))) # (!\current_state.M0~q\ & (\cnt_min_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[2]~2_combout\,
	datab => \in_min_low[2]~1_combout\,
	datac => \in_min_low[2]~_emulated_q\,
	datad => \current_state.M0~q\,
	combout => \in_min_low[2]~2_combout\);

-- Location: LCCOMB_X46_Y32_N16
\cnt_min_low~28\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low~28_combout\ = (\current_state.M0~q\ & ((\in_min_low[2]~2_combout\))) # (!\current_state.M0~q\ & (\cnt_min_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[2]~2_combout\,
	datab => \in_min_low[2]~2_combout\,
	datad => \current_state.M0~q\,
	combout => \cnt_min_low~28_combout\);

-- Location: LCCOMB_X46_Y32_N8
\se2|seg[1]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \se2|seg[1]~4_combout\ = (\cnt_min_low[0]~17_combout\ & \cnt_min_low[1]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_low[0]~17_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \se2|seg[1]~4_combout\);

-- Location: LCCOMB_X47_Y32_N10
\cnt_min_low[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[2]~1_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low~28_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_low[2]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[2]~1_combout\,
	datab => \cnt_min_low~28_combout\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \en~input_o\,
	combout => \cnt_min_low[2]~1_combout\);

-- Location: LCCOMB_X47_Y32_N20
\cnt_min_low[2]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[2]~4_combout\ = \cnt_min_low[2]~2_combout\ $ (\cnt_min_low[2]~1_combout\ $ (((\se2|seg[1]~4_combout\ & \process_7~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001001101101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se2|seg[1]~4_combout\,
	datab => \cnt_min_low[2]~2_combout\,
	datac => \process_7~0_combout\,
	datad => \cnt_min_low[2]~1_combout\,
	combout => \cnt_min_low[2]~4_combout\);

-- Location: FF_X47_Y32_N27
\cnt_min_low[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_low[2]~4_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_low[2]~_emulated_q\);

-- Location: LCCOMB_X47_Y32_N26
\cnt_min_low[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[2]~3_combout\ = \cnt_min_low[2]~_emulated_q\ $ (\cnt_min_low[2]~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_low[2]~_emulated_q\,
	datad => \cnt_min_low[2]~1_combout\,
	combout => \cnt_min_low[2]~3_combout\);

-- Location: LCCOMB_X47_Y32_N22
\cnt_min_low[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[2]~2_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_low~28_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low[2]~3_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low~28_combout\,
	datab => \en~input_o\,
	datac => \cnt_min_low[2]~3_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_low[2]~2_combout\);

-- Location: LCCOMB_X48_Y32_N8
\Add5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add5~0_combout\ = (\cnt_min_low[0]~17_combout\ & (\cnt_min_low[2]~2_combout\ & \cnt_min_low[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~17_combout\,
	datac => \cnt_min_low[2]~2_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \Add5~0_combout\);

-- Location: LCCOMB_X49_Y32_N0
\cnt_min_low[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[3]~6_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low~30_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_low[3]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_min_low[3]~6_combout\,
	datac => \cnt_min_low~30_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_low[3]~6_combout\);

-- Location: LCCOMB_X48_Y32_N14
\se2|Equal15~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se2|Equal15~0_combout\ = (\cnt_min_low[0]~17_combout\ & (\cnt_min_low[3]~7_combout\ & (!\cnt_min_low[2]~2_combout\ & !\cnt_min_low[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~17_combout\,
	datab => \cnt_min_low[3]~7_combout\,
	datac => \cnt_min_low[2]~2_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \se2|Equal15~0_combout\);

-- Location: LCCOMB_X49_Y32_N22
\cnt_min_low[3]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[3]~9_combout\ = \cnt_min_low[3]~6_combout\ $ (((!\se2|Equal15~0_combout\ & (\Add5~0_combout\ $ (\cnt_min_low[3]~7_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010010110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Add5~0_combout\,
	datab => \cnt_min_low[3]~6_combout\,
	datac => \cnt_min_low[3]~7_combout\,
	datad => \se2|Equal15~0_combout\,
	combout => \cnt_min_low[3]~9_combout\);

-- Location: FF_X49_Y32_N5
\cnt_min_low[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_low[3]~9_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_7~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_low[3]~_emulated_q\);

-- Location: LCCOMB_X49_Y32_N4
\cnt_min_low[3]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[3]~8_combout\ = \cnt_min_low[3]~_emulated_q\ $ (\cnt_min_low[3]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_low[3]~_emulated_q\,
	datad => \cnt_min_low[3]~6_combout\,
	combout => \cnt_min_low[3]~8_combout\);

-- Location: LCCOMB_X49_Y32_N28
\cnt_min_low[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[3]~7_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_low~30_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low[3]~8_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_min_low~30_combout\,
	datac => \cnt_min_low[3]~8_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_low[3]~7_combout\);

-- Location: LCCOMB_X45_Y32_N14
\in_min_low[3]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[3]~5_combout\ = (\current_state.M0~q\ & ((\in_min_low[3]~5_combout\))) # (!\current_state.M0~q\ & (\cnt_min_low[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_min_low[3]~7_combout\,
	datac => \in_min_low[3]~5_combout\,
	datad => \current_state.M0~q\,
	combout => \in_min_low[3]~5_combout\);

-- Location: LCCOMB_X45_Y32_N0
\Add4~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add4~1_combout\ = (\in_min_low[1]~10_combout\ & (\in_min_low[0]~14_combout\ & \in_min_low[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[1]~10_combout\,
	datab => \in_min_low[0]~14_combout\,
	datad => \in_min_low[2]~2_combout\,
	combout => \Add4~1_combout\);

-- Location: LCCOMB_X45_Y32_N8
\in_min_low[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[3]~7_combout\ = \in_min_low[3]~5_combout\ $ (((!\Equal4~0_combout\ & (\Add4~1_combout\ $ (\in_min_low[3]~6_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101100010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Equal4~0_combout\,
	datab => \Add4~1_combout\,
	datac => \in_min_low[3]~6_combout\,
	datad => \in_min_low[3]~5_combout\,
	combout => \in_min_low[3]~7_combout\);

-- Location: FF_X45_Y32_N9
\in_min_low[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_low[3]~7_combout\,
	clrn => \current_state.M0~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_low[3]~_emulated_q\);

-- Location: LCCOMB_X45_Y32_N10
\in_min_low[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[3]~6_combout\ = (\current_state.M0~q\ & ((\in_min_low[3]~5_combout\ $ (\in_min_low[3]~_emulated_q\)))) # (!\current_state.M0~q\ & (\cnt_min_low[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[3]~7_combout\,
	datab => \in_min_low[3]~5_combout\,
	datac => \in_min_low[3]~_emulated_q\,
	datad => \current_state.M0~q\,
	combout => \in_min_low[3]~6_combout\);

-- Location: LCCOMB_X45_Y32_N4
\Equal4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Equal4~0_combout\ = (!\in_min_low[1]~10_combout\ & (\in_min_low[0]~14_combout\ & (\in_min_low[3]~6_combout\ & !\in_min_low[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[1]~10_combout\,
	datab => \in_min_low[0]~14_combout\,
	datac => \in_min_low[3]~6_combout\,
	datad => \in_min_low[2]~2_combout\,
	combout => \Equal4~0_combout\);

-- Location: LCCOMB_X45_Y32_N26
\in_min_low[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[1]~11_combout\ = \in_min_low[1]~9_combout\ $ (((!\Equal4~0_combout\ & (\in_min_low[1]~10_combout\ $ (\in_min_low[0]~14_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100100111000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[1]~10_combout\,
	datab => \in_min_low[1]~9_combout\,
	datac => \Equal4~0_combout\,
	datad => \in_min_low[0]~14_combout\,
	combout => \in_min_low[1]~11_combout\);

-- Location: FF_X45_Y32_N27
\in_min_low[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_low[1]~11_combout\,
	clrn => \current_state.M0~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_low[1]~_emulated_q\);

-- Location: LCCOMB_X45_Y32_N6
\in_min_low[1]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_low[1]~10_combout\ = (\current_state.M0~q\ & (\in_min_low[1]~_emulated_q\ $ ((\in_min_low[1]~9_combout\)))) # (!\current_state.M0~q\ & (((\cnt_min_low[1]~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_low[1]~_emulated_q\,
	datab => \in_min_low[1]~9_combout\,
	datac => \cnt_min_low[1]~12_combout\,
	datad => \current_state.M0~q\,
	combout => \in_min_low[1]~10_combout\);

-- Location: LCCOMB_X46_Y32_N0
\cnt_min_low~31\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low~31_combout\ = (\current_state.M0~q\ & ((\in_min_low[1]~10_combout\))) # (!\current_state.M0~q\ & (\cnt_min_low[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_min_low[1]~12_combout\,
	datac => \in_min_low[1]~10_combout\,
	datad => \current_state.M0~q\,
	combout => \cnt_min_low~31_combout\);

-- Location: LCCOMB_X47_Y32_N0
\cnt_min_low[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[1]~11_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low~31_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_low[1]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_min_low[1]~11_combout\,
	datac => \cnt_min_low~31_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_low[1]~11_combout\);

-- Location: LCCOMB_X47_Y32_N24
\se2|Equal15~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se2|Equal15~1_combout\ = (!\cnt_min_low[2]~2_combout\ & \cnt_min_low[3]~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[2]~2_combout\,
	datac => \cnt_min_low[3]~7_combout\,
	combout => \se2|Equal15~1_combout\);

-- Location: LCCOMB_X47_Y32_N12
\cnt_min_low[1]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[1]~14_combout\ = \cnt_min_low[1]~11_combout\ $ (((\cnt_min_low[0]~17_combout\ & (!\se2|Equal15~1_combout\ & !\cnt_min_low[1]~12_combout\)) # (!\cnt_min_low[0]~17_combout\ & ((\cnt_min_low[1]~12_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001100111000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~17_combout\,
	datab => \cnt_min_low[1]~11_combout\,
	datac => \se2|Equal15~1_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \cnt_min_low[1]~14_combout\);

-- Location: FF_X47_Y32_N17
\cnt_min_low[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_low[1]~14_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_7~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_low[1]~_emulated_q\);

-- Location: LCCOMB_X47_Y32_N16
\cnt_min_low[1]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[1]~13_combout\ = \cnt_min_low[1]~_emulated_q\ $ (\cnt_min_low[1]~11_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_low[1]~_emulated_q\,
	datad => \cnt_min_low[1]~11_combout\,
	combout => \cnt_min_low[1]~13_combout\);

-- Location: LCCOMB_X47_Y32_N28
\cnt_min_low[1]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_low[1]~12_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_low~31_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_low[1]~13_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low~31_combout\,
	datab => \en~input_o\,
	datac => \cnt_sec_low[3]~28_combout\,
	datad => \cnt_min_low[1]~13_combout\,
	combout => \cnt_min_low[1]~12_combout\);

-- Location: LCCOMB_X47_Y31_N6
\in_tim_min_low~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_low~2_combout\ = (in_tim_min_low(1) & (in_tim_min_low(3) $ (((in_tim_min_low(2) & !in_tim_min_low(0)))))) # (!in_tim_min_low(1) & (in_tim_min_low(3) & ((in_tim_min_low(2)) # (in_tim_min_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(1),
	datab => in_tim_min_low(2),
	datac => in_tim_min_low(3),
	datad => in_tim_min_low(0),
	combout => \in_tim_min_low~2_combout\);

-- Location: FF_X47_Y31_N7
\in_tim_min_low[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_min_low~2_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_min_low[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_low(3));

-- Location: LCCOMB_X47_Y31_N14
\in_tim_min_low~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_low~3_combout\ = (in_tim_min_low(1) & (((in_tim_min_low(0))))) # (!in_tim_min_low(1) & (!in_tim_min_low(0) & ((in_tim_min_low(2)) # (!in_tim_min_low(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(3),
	datab => in_tim_min_low(2),
	datac => in_tim_min_low(1),
	datad => in_tim_min_low(0),
	combout => \in_tim_min_low~3_combout\);

-- Location: FF_X47_Y31_N15
\in_tim_min_low[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_min_low~3_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_min_low[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_low(1));

-- Location: LCCOMB_X47_Y31_N0
\in_tim_min_low[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_low[2]~1_combout\ = in_tim_min_low(2) $ (((\in_tim_min_low[0]~0_combout\ & (in_tim_min_low(1) & !in_tim_min_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_tim_min_low[0]~0_combout\,
	datab => in_tim_min_low(1),
	datac => in_tim_min_low(2),
	datad => in_tim_min_low(0),
	combout => \in_tim_min_low[2]~1_combout\);

-- Location: FF_X47_Y31_N1
\in_tim_min_low[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_min_low[2]~1_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_low(2));

-- Location: LCCOMB_X47_Y32_N4
\process_14~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_14~5_combout\ = (\cnt_min_low[2]~2_combout\ & (in_tim_min_low(2) & (\cnt_min_low[3]~7_combout\ $ (!in_tim_min_low(3))))) # (!\cnt_min_low[2]~2_combout\ & (!in_tim_min_low(2) & (\cnt_min_low[3]~7_combout\ $ (!in_tim_min_low(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001000000001001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[2]~2_combout\,
	datab => in_tim_min_low(2),
	datac => \cnt_min_low[3]~7_combout\,
	datad => in_tim_min_low(3),
	combout => \process_14~5_combout\);

-- Location: LCCOMB_X47_Y32_N2
\process_14~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_14~6_combout\ = (!\Equal14~0_combout\ & (\process_14~5_combout\ & (\cnt_min_low[1]~12_combout\ $ (!in_tim_min_low(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Equal14~0_combout\,
	datab => \cnt_min_low[1]~12_combout\,
	datac => \process_14~5_combout\,
	datad => in_tim_min_low(1),
	combout => \process_14~6_combout\);

-- Location: LCCOMB_X43_Y32_N12
\in_min_high[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[2]~1_combout\ = (\current_state.M1~q\ & ((\in_min_high[2]~1_combout\))) # (!\current_state.M1~q\ & (\cnt_min_high[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~2_combout\,
	datac => \current_state.M1~q\,
	datad => \in_min_high[2]~1_combout\,
	combout => \in_min_high[2]~1_combout\);

-- Location: LCCOMB_X46_Y32_N2
\cnt_min_high~32\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high~32_combout\ = (\current_state.M1~q\ & ((\in_min_high[3]~6_combout\))) # (!\current_state.M1~q\ & (\cnt_min_high[3]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[3]~7_combout\,
	datac => \in_min_high[3]~6_combout\,
	datad => \current_state.M1~q\,
	combout => \cnt_min_high~32_combout\);

-- Location: LCCOMB_X50_Y32_N6
\cnt_min_high[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[3]~6_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high~32_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_high[3]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[3]~6_combout\,
	datab => \en~input_o\,
	datac => \cnt_min_high~32_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_high[3]~6_combout\);

-- Location: LCCOMB_X43_Y32_N22
\in_min_high[0]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[0]~13_combout\ = (\current_state.M1~q\ & (\in_min_high[0]~13_combout\)) # (!\current_state.M1~q\ & ((\cnt_min_high[0]~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[0]~13_combout\,
	datab => \cnt_min_high[0]~17_combout\,
	datac => \current_state.M1~q\,
	combout => \in_min_high[0]~13_combout\);

-- Location: LCCOMB_X43_Y32_N2
\in_min_high[0]~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[0]~15_combout\ = \in_min_high[0]~13_combout\ $ (!\in_min_high[0]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \in_min_high[0]~13_combout\,
	datad => \in_min_high[0]~14_combout\,
	combout => \in_min_high[0]~15_combout\);

-- Location: FF_X43_Y32_N3
\in_min_high[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_high[0]~15_combout\,
	clrn => \current_state.M1~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_high[0]~_emulated_q\);

-- Location: LCCOMB_X43_Y32_N18
\in_min_high[0]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[0]~14_combout\ = (\current_state.M1~q\ & (\in_min_high[0]~13_combout\ $ (((\in_min_high[0]~_emulated_q\))))) # (!\current_state.M1~q\ & (((\cnt_min_high[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[0]~13_combout\,
	datab => \cnt_min_high[0]~17_combout\,
	datac => \current_state.M1~q\,
	datad => \in_min_high[0]~_emulated_q\,
	combout => \in_min_high[0]~14_combout\);

-- Location: LCCOMB_X46_Y32_N24
\cnt_min_high~30\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high~30_combout\ = (\current_state.M1~q\ & ((\in_min_high[0]~14_combout\))) # (!\current_state.M1~q\ & (\cnt_min_high[0]~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[0]~17_combout\,
	datac => \in_min_high[0]~14_combout\,
	datad => \current_state.M1~q\,
	combout => \cnt_min_high~30_combout\);

-- Location: LCCOMB_X49_Y30_N0
\cnt_min_high[0]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[0]~16_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high~30_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_high[0]~16_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_min_high[0]~16_combout\,
	datac => \cnt_min_high~30_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_high[0]~16_combout\);

-- Location: LCCOMB_X49_Y30_N26
\cnt_min_high[0]~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[0]~19_combout\ = \cnt_min_high[0]~17_combout\ $ (!\cnt_min_high[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[0]~16_combout\,
	combout => \cnt_min_high[0]~19_combout\);

-- Location: LCCOMB_X49_Y32_N12
\process_9~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_9~0_combout\ = (\se4|Equal15~0_combout\ & (\se3|Equal15~0_combout\ & \se2|Equal15~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se4|Equal15~0_combout\,
	datab => \se3|Equal15~0_combout\,
	datad => \se2|Equal15~0_combout\,
	combout => \process_9~0_combout\);

-- Location: FF_X49_Y30_N9
\cnt_min_high[0]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_high[0]~19_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_9~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_high[0]~_emulated_q\);

-- Location: LCCOMB_X49_Y30_N8
\cnt_min_high[0]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[0]~18_combout\ = \cnt_min_high[0]~_emulated_q\ $ (\cnt_min_high[0]~16_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_high[0]~_emulated_q\,
	datad => \cnt_min_high[0]~16_combout\,
	combout => \cnt_min_high[0]~18_combout\);

-- Location: LCCOMB_X49_Y30_N16
\cnt_min_high[0]~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[0]~17_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_high~30_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high[0]~18_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high~30_combout\,
	datab => \en~input_o\,
	datac => \cnt_min_high[0]~18_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_high[0]~17_combout\);

-- Location: LCCOMB_X43_Y32_N26
\in_min_high[1]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[1]~9_combout\ = (\current_state.M1~q\ & (\in_min_high[1]~9_combout\)) # (!\current_state.M1~q\ & ((\cnt_min_high[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[1]~9_combout\,
	datac => \cnt_min_high[1]~12_combout\,
	datad => \current_state.M1~q\,
	combout => \in_min_high[1]~9_combout\);

-- Location: LCCOMB_X43_Y32_N20
\in_min_high[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[1]~11_combout\ = \in_min_high[1]~9_combout\ $ (((!\Equal6~0_combout\ & (\in_min_high[1]~10_combout\ $ (\in_min_high[0]~14_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100110100110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[1]~9_combout\,
	datab => \in_min_high[1]~10_combout\,
	datac => \Equal6~0_combout\,
	datad => \in_min_high[0]~14_combout\,
	combout => \in_min_high[1]~11_combout\);

-- Location: FF_X43_Y32_N21
\in_min_high[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_high[1]~11_combout\,
	clrn => \current_state.M1~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_high[1]~_emulated_q\);

-- Location: LCCOMB_X43_Y32_N6
\in_min_high[1]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[1]~10_combout\ = (\current_state.M1~q\ & (\in_min_high[1]~9_combout\ $ (((\in_min_high[1]~_emulated_q\))))) # (!\current_state.M1~q\ & (((\cnt_min_high[1]~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[1]~9_combout\,
	datab => \cnt_min_high[1]~12_combout\,
	datac => \current_state.M1~q\,
	datad => \in_min_high[1]~_emulated_q\,
	combout => \in_min_high[1]~10_combout\);

-- Location: LCCOMB_X43_Y32_N10
\cnt_min_high~33\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high~33_combout\ = (\current_state.M1~q\ & ((\in_min_high[1]~10_combout\))) # (!\current_state.M1~q\ & (\cnt_min_high[1]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_min_high[1]~12_combout\,
	datac => \in_min_high[1]~10_combout\,
	datad => \current_state.M1~q\,
	combout => \cnt_min_high~33_combout\);

-- Location: LCCOMB_X49_Y30_N12
\se1|Equal15~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se1|Equal15~1_combout\ = (!\cnt_min_high[3]~7_combout\ & \cnt_min_high[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \cnt_min_high[3]~7_combout\,
	datad => \cnt_min_high[2]~2_combout\,
	combout => \se1|Equal15~1_combout\);

-- Location: LCCOMB_X49_Y30_N24
\cnt_min_high[1]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[1]~11_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high~33_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_high[1]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \en~input_o\,
	datab => \cnt_min_high[1]~11_combout\,
	datac => \cnt_min_high~33_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_high[1]~11_combout\);

-- Location: LCCOMB_X49_Y30_N22
\cnt_min_high[1]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[1]~14_combout\ = \cnt_min_high[1]~11_combout\ $ (((\cnt_min_high[0]~17_combout\ & (!\se1|Equal15~1_combout\ & !\cnt_min_high[1]~12_combout\)) # (!\cnt_min_high[0]~17_combout\ & ((\cnt_min_high[1]~12_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101100110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se1|Equal15~1_combout\,
	datab => \cnt_min_high[0]~17_combout\,
	datac => \cnt_min_high[1]~12_combout\,
	datad => \cnt_min_high[1]~11_combout\,
	combout => \cnt_min_high[1]~14_combout\);

-- Location: FF_X49_Y30_N31
\cnt_min_high[1]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_high[1]~14_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_9~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_high[1]~_emulated_q\);

-- Location: LCCOMB_X49_Y30_N30
\cnt_min_high[1]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[1]~13_combout\ = \cnt_min_high[1]~_emulated_q\ $ (\cnt_min_high[1]~11_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_high[1]~_emulated_q\,
	datad => \cnt_min_high[1]~11_combout\,
	combout => \cnt_min_high[1]~13_combout\);

-- Location: LCCOMB_X49_Y30_N20
\cnt_min_high[1]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[1]~12_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_high~33_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high[1]~13_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high~33_combout\,
	datab => \en~input_o\,
	datac => \cnt_min_high[1]~13_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_high[1]~12_combout\);

-- Location: LCCOMB_X49_Y30_N14
\se1|seg[1]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \se1|seg[1]~4_combout\ = (\cnt_min_high[0]~17_combout\ & \cnt_min_high[1]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[1]~12_combout\,
	combout => \se1|seg[1]~4_combout\);

-- Location: LCCOMB_X49_Y30_N18
\cnt_min_high[3]~31\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[3]~31_combout\ = \cnt_min_high[3]~7_combout\ $ (((\cnt_min_high[2]~2_combout\ & (\se1|seg[1]~4_combout\ & \process_9~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~2_combout\,
	datab => \se1|seg[1]~4_combout\,
	datac => \cnt_min_high[3]~7_combout\,
	datad => \process_9~0_combout\,
	combout => \cnt_min_high[3]~31_combout\);

-- Location: LCCOMB_X49_Y33_N26
\cnt_min_high[3]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[3]~9_combout\ = \cnt_min_high[3]~6_combout\ $ (\cnt_min_high[3]~31_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_high[3]~6_combout\,
	datad => \cnt_min_high[3]~31_combout\,
	combout => \cnt_min_high[3]~9_combout\);

-- Location: FF_X50_Y32_N5
\cnt_min_high[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_high[3]~9_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_high[3]~_emulated_q\);

-- Location: LCCOMB_X50_Y32_N4
\cnt_min_high[3]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[3]~8_combout\ = \cnt_min_high[3]~_emulated_q\ $ (\cnt_min_high[3]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_high[3]~_emulated_q\,
	datad => \cnt_min_high[3]~6_combout\,
	combout => \cnt_min_high[3]~8_combout\);

-- Location: LCCOMB_X50_Y32_N20
\cnt_min_high[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[3]~7_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_high~32_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high[3]~8_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high~32_combout\,
	datab => \en~input_o\,
	datac => \cnt_min_high[3]~8_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_high[3]~7_combout\);

-- Location: LCCOMB_X43_Y32_N30
\in_min_high[3]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[3]~5_combout\ = (\current_state.M1~q\ & (\in_min_high[3]~5_combout\)) # (!\current_state.M1~q\ & ((\cnt_min_high[3]~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[3]~5_combout\,
	datac => \cnt_min_high[3]~7_combout\,
	datad => \current_state.M1~q\,
	combout => \in_min_high[3]~5_combout\);

-- Location: LCCOMB_X43_Y32_N16
\Add6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Add6~0_combout\ = (\in_min_high[1]~10_combout\ & \in_min_high[0]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \in_min_high[1]~10_combout\,
	datad => \in_min_high[0]~14_combout\,
	combout => \Add6~0_combout\);

-- Location: LCCOMB_X43_Y32_N24
\in_min_high[3]~22\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[3]~22_combout\ = (!\bt3|btn_delay~q\ & (\bt3|btn_sync~q\ & \in_min_high[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \bt3|btn_delay~q\,
	datac => \bt3|btn_sync~q\,
	datad => \in_min_high[2]~2_combout\,
	combout => \in_min_high[3]~22_combout\);

-- Location: LCCOMB_X43_Y32_N28
\in_min_high[3]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[3]~7_combout\ = \in_min_high[3]~5_combout\ $ (\in_min_high[3]~6_combout\ $ (((\Add6~0_combout\ & \in_min_high[3]~22_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Add6~0_combout\,
	datab => \in_min_high[3]~5_combout\,
	datac => \in_min_high[3]~6_combout\,
	datad => \in_min_high[3]~22_combout\,
	combout => \in_min_high[3]~7_combout\);

-- Location: FF_X43_Y32_N29
\in_min_high[3]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_high[3]~7_combout\,
	clrn => \current_state.M1~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_high[3]~_emulated_q\);

-- Location: LCCOMB_X43_Y32_N0
\in_min_high[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[3]~6_combout\ = (\current_state.M1~q\ & (\in_min_high[3]~5_combout\ $ (((\in_min_high[3]~_emulated_q\))))) # (!\current_state.M1~q\ & (((\cnt_min_high[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[3]~5_combout\,
	datab => \cnt_min_high[3]~7_combout\,
	datac => \current_state.M1~q\,
	datad => \in_min_high[3]~_emulated_q\,
	combout => \in_min_high[3]~6_combout\);

-- Location: LCCOMB_X43_Y32_N4
\Equal6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Equal6~0_combout\ = (!\in_min_high[3]~6_combout\ & (\in_min_high[0]~14_combout\ & (!\in_min_high[1]~10_combout\ & \in_min_high[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[3]~6_combout\,
	datab => \in_min_high[0]~14_combout\,
	datac => \in_min_high[1]~10_combout\,
	datad => \in_min_high[2]~2_combout\,
	combout => \Equal6~0_combout\);

-- Location: LCCOMB_X43_Y32_N14
\in_min_high[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[2]~3_combout\ = \in_min_high[2]~1_combout\ $ (((!\Equal6~0_combout\ & (\Add6~0_combout\ $ (\in_min_high[2]~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100110011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[2]~1_combout\,
	datab => \Equal6~0_combout\,
	datac => \Add6~0_combout\,
	datad => \in_min_high[2]~2_combout\,
	combout => \in_min_high[2]~3_combout\);

-- Location: FF_X43_Y32_N15
\in_min_high[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_min_high[2]~3_combout\,
	clrn => \current_state.M1~q\,
	ena => \bt3|trig~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \in_min_high[2]~_emulated_q\);

-- Location: LCCOMB_X43_Y32_N8
\in_min_high[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_min_high[2]~2_combout\ = (\current_state.M1~q\ & ((\in_min_high[2]~_emulated_q\ $ (\in_min_high[2]~1_combout\)))) # (!\current_state.M1~q\ & (\cnt_min_high[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~2_combout\,
	datab => \in_min_high[2]~_emulated_q\,
	datac => \current_state.M1~q\,
	datad => \in_min_high[2]~1_combout\,
	combout => \in_min_high[2]~2_combout\);

-- Location: LCCOMB_X46_Y32_N28
\cnt_min_high~29\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high~29_combout\ = (\current_state.M1~q\ & (\in_min_high[2]~2_combout\)) # (!\current_state.M1~q\ & ((\cnt_min_high[2]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \in_min_high[2]~2_combout\,
	datab => \cnt_min_high[2]~2_combout\,
	datad => \current_state.M1~q\,
	combout => \cnt_min_high~29_combout\);

-- Location: LCCOMB_X49_Y30_N6
\cnt_min_high[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[2]~1_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high~29_combout\))) # (!\cnt_sec_low[3]~28_combout\ & (\cnt_min_high[2]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~1_combout\,
	datab => \en~input_o\,
	datac => \cnt_min_high~29_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_high[2]~1_combout\);

-- Location: LCCOMB_X49_Y30_N28
\se1|Equal15~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se1|Equal15~0_combout\ = (\cnt_min_high[2]~2_combout\ & (\cnt_min_high[0]~17_combout\ & (!\cnt_min_high[3]~7_combout\ & !\cnt_min_high[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~2_combout\,
	datab => \cnt_min_high[0]~17_combout\,
	datac => \cnt_min_high[3]~7_combout\,
	datad => \cnt_min_high[1]~12_combout\,
	combout => \se1|Equal15~0_combout\);

-- Location: LCCOMB_X49_Y30_N2
\cnt_min_high[2]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[2]~4_combout\ = \cnt_min_high[2]~1_combout\ $ (((!\se1|Equal15~0_combout\ & (\se1|seg[1]~4_combout\ $ (\cnt_min_high[2]~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100110011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~1_combout\,
	datab => \se1|Equal15~0_combout\,
	datac => \se1|seg[1]~4_combout\,
	datad => \cnt_min_high[2]~2_combout\,
	combout => \cnt_min_high[2]~4_combout\);

-- Location: FF_X49_Y30_N5
\cnt_min_high[2]~_emulated\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \t1|toggle~q\,
	asdata => \cnt_min_high[2]~4_combout\,
	clrn => \ALT_INV_cnt_min_high[2]~0clkctrl_outclk\,
	sload => VCC,
	ena => \process_9~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \cnt_min_high[2]~_emulated_q\);

-- Location: LCCOMB_X49_Y30_N4
\cnt_min_high[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[2]~3_combout\ = \cnt_min_high[2]~_emulated_q\ $ (\cnt_min_high[2]~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \cnt_min_high[2]~_emulated_q\,
	datad => \cnt_min_high[2]~1_combout\,
	combout => \cnt_min_high[2]~3_combout\);

-- Location: LCCOMB_X49_Y30_N10
\cnt_min_high[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \cnt_min_high[2]~2_combout\ = (\en~input_o\ & ((\cnt_sec_low[3]~28_combout\ & (\cnt_min_high~29_combout\)) # (!\cnt_sec_low[3]~28_combout\ & ((\cnt_min_high[2]~3_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high~29_combout\,
	datab => \en~input_o\,
	datac => \cnt_min_high[2]~3_combout\,
	datad => \cnt_sec_low[3]~28_combout\,
	combout => \cnt_min_high[2]~2_combout\);

-- Location: LCCOMB_X47_Y30_N28
\in_tim_min_high[0]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_high[0]~4_combout\ = !in_tim_min_high(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => in_tim_min_high(0),
	combout => \in_tim_min_high[0]~4_combout\);

-- Location: LCCOMB_X48_Y31_N12
\in_tim_min_high[0]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_high[0]~1_combout\ = (!\bt3|btn_delay~q\ & (\bt3|btn_sync~q\ & \current_state.MT1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \bt3|btn_delay~q\,
	datac => \bt3|btn_sync~q\,
	datad => \current_state.MT1~q\,
	combout => \in_tim_min_high[0]~1_combout\);

-- Location: FF_X47_Y30_N29
\in_tim_min_high[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_min_high[0]~4_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_min_high[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_high(0));

-- Location: LCCOMB_X47_Y30_N24
\in_tim_min_high~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_high~0_combout\ = (in_tim_min_high(1) & ((in_tim_min_high(2) $ (!in_tim_min_high(0))))) # (!in_tim_min_high(1) & (in_tim_min_high(2) & ((in_tim_min_high(3)) # (in_tim_min_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(3),
	datab => in_tim_min_high(1),
	datac => in_tim_min_high(2),
	datad => in_tim_min_high(0),
	combout => \in_tim_min_high~0_combout\);

-- Location: FF_X47_Y30_N25
\in_tim_min_high[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_min_high~0_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_min_high[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_high(2));

-- Location: LCCOMB_X47_Y30_N2
\in_tim_min_high~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_high~3_combout\ = (in_tim_min_high(1) & (((in_tim_min_high(0))))) # (!in_tim_min_high(1) & (!in_tim_min_high(0) & ((in_tim_min_high(3)) # (!in_tim_min_high(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(3),
	datab => in_tim_min_high(2),
	datac => in_tim_min_high(1),
	datad => in_tim_min_high(0),
	combout => \in_tim_min_high~3_combout\);

-- Location: FF_X47_Y30_N3
\in_tim_min_high[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_min_high~3_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_min_high[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_high(1));

-- Location: LCCOMB_X47_Y30_N26
\se5|seg[1]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \se5|seg[1]~4_combout\ = (in_tim_min_high(1) & !in_tim_min_high(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => in_tim_min_high(1),
	datad => in_tim_min_high(0),
	combout => \se5|seg[1]~4_combout\);

-- Location: LCCOMB_X47_Y30_N16
\in_tim_min_high[3]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_min_high[3]~2_combout\ = in_tim_min_high(3) $ (((\se5|seg[1]~4_combout\ & (\in_tim_min_high[0]~1_combout\ & in_tim_min_high(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se5|seg[1]~4_combout\,
	datab => \in_tim_min_high[0]~1_combout\,
	datac => in_tim_min_high(3),
	datad => in_tim_min_high(2),
	combout => \in_tim_min_high[3]~2_combout\);

-- Location: FF_X47_Y30_N17
\in_tim_min_high[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_min_high[3]~2_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_min_high(3));

-- Location: LCCOMB_X47_Y30_N0
\process_14~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_14~1_combout\ = (\cnt_min_high[2]~2_combout\ & (in_tim_min_high(2) & (in_tim_min_high(3) $ (!\cnt_min_high[3]~7_combout\)))) # (!\cnt_min_high[2]~2_combout\ & (!in_tim_min_high(2) & (in_tim_min_high(3) $ (!\cnt_min_high[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001001000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[2]~2_combout\,
	datab => in_tim_min_high(3),
	datac => \cnt_min_high[3]~7_combout\,
	datad => in_tim_min_high(2),
	combout => \process_14~1_combout\);

-- Location: LCCOMB_X47_Y30_N6
\process_14~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_14~0_combout\ = (\cnt_min_high[0]~17_combout\ & (!in_tim_min_high(0) & (\cnt_min_high[1]~12_combout\ $ (!in_tim_min_high(1))))) # (!\cnt_min_high[0]~17_combout\ & (in_tim_min_high(0) & (\cnt_min_high[1]~12_combout\ $ (!in_tim_min_high(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000000000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[0]~17_combout\,
	datab => in_tim_min_high(0),
	datac => \cnt_min_high[1]~12_combout\,
	datad => in_tim_min_high(1),
	combout => \process_14~0_combout\);

-- Location: LCCOMB_X48_Y31_N22
\in_tim_sec_high[0]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_high[0]~4_combout\ = !in_tim_sec_high(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => in_tim_sec_high(0),
	combout => \in_tim_sec_high[0]~4_combout\);

-- Location: LCCOMB_X48_Y31_N2
\in_tim_sec_high[0]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_high[0]~1_combout\ = (!\bt3|btn_delay~q\ & (\bt3|btn_sync~q\ & \current_state.ST1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \bt3|btn_delay~q\,
	datac => \bt3|btn_sync~q\,
	datad => \current_state.ST1~q\,
	combout => \in_tim_sec_high[0]~1_combout\);

-- Location: FF_X48_Y31_N23
\in_tim_sec_high[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_high[0]~4_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_sec_high[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_high(0));

-- Location: LCCOMB_X48_Y31_N16
\se7|seg[1]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \se7|seg[1]~4_combout\ = (in_tim_sec_high(1) & !in_tim_sec_high(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => in_tim_sec_high(1),
	datad => in_tim_sec_high(0),
	combout => \se7|seg[1]~4_combout\);

-- Location: LCCOMB_X48_Y31_N20
\in_tim_sec_high[3]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_high[3]~2_combout\ = in_tim_sec_high(3) $ (((in_tim_sec_high(2) & (\se7|seg[1]~4_combout\ & \in_tim_sec_high[0]~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => \se7|seg[1]~4_combout\,
	datac => in_tim_sec_high(3),
	datad => \in_tim_sec_high[0]~1_combout\,
	combout => \in_tim_sec_high[3]~2_combout\);

-- Location: FF_X48_Y31_N21
\in_tim_sec_high[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_high[3]~2_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_high(3));

-- Location: LCCOMB_X48_Y31_N26
\in_tim_sec_high~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_high~3_combout\ = (in_tim_sec_high(1) & (((in_tim_sec_high(0))))) # (!in_tim_sec_high(1) & (!in_tim_sec_high(0) & ((in_tim_sec_high(3)) # (!in_tim_sec_high(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => in_tim_sec_high(3),
	datac => in_tim_sec_high(1),
	datad => in_tim_sec_high(0),
	combout => \in_tim_sec_high~3_combout\);

-- Location: FF_X48_Y31_N27
\in_tim_sec_high[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_high~3_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_sec_high[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_high(1));

-- Location: LCCOMB_X48_Y31_N6
\in_tim_sec_high~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_high~0_combout\ = (in_tim_sec_high(1) & ((in_tim_sec_high(2) $ (!in_tim_sec_high(0))))) # (!in_tim_sec_high(1) & (in_tim_sec_high(2) & ((in_tim_sec_high(3)) # (in_tim_sec_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(1),
	datab => in_tim_sec_high(3),
	datac => in_tim_sec_high(2),
	datad => in_tim_sec_high(0),
	combout => \in_tim_sec_high~0_combout\);

-- Location: FF_X48_Y31_N7
\in_tim_sec_high[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_high~0_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_sec_high[0]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_high(2));

-- Location: LCCOMB_X48_Y31_N30
\process_14~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_14~3_combout\ = (in_tim_sec_high(2) & (\cnt_sec_high[2]~2_combout\ & (\cnt_sec_high[3]~7_combout\ $ (!in_tim_sec_high(3))))) # (!in_tim_sec_high(2) & (!\cnt_sec_high[2]~2_combout\ & (\cnt_sec_high[3]~7_combout\ $ (!in_tim_sec_high(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001000000001001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => \cnt_sec_high[2]~2_combout\,
	datac => \cnt_sec_high[3]~7_combout\,
	datad => in_tim_sec_high(3),
	combout => \process_14~3_combout\);

-- Location: LCCOMB_X48_Y31_N28
\process_14~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_14~2_combout\ = (in_tim_sec_high(1) & (\cnt_sec_high[1]~12_combout\ & (in_tim_sec_high(0) $ (\cnt_sec_high[0]~17_combout\)))) # (!in_tim_sec_high(1) & (!\cnt_sec_high[1]~12_combout\ & (in_tim_sec_high(0) $ (\cnt_sec_high[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100110010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(1),
	datab => \cnt_sec_high[1]~12_combout\,
	datac => in_tim_sec_high(0),
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \process_14~2_combout\);

-- Location: LCCOMB_X48_Y31_N0
\process_14~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_14~4_combout\ = (\process_14~1_combout\ & (\process_14~0_combout\ & (\process_14~3_combout\ & \process_14~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_14~1_combout\,
	datab => \process_14~0_combout\,
	datac => \process_14~3_combout\,
	datad => \process_14~2_combout\,
	combout => \process_14~4_combout\);

-- Location: LCCOMB_X48_Y32_N2
\in_tim_sec_low[0]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_low[0]~4_combout\ = !in_tim_sec_low(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => in_tim_sec_low(0),
	combout => \in_tim_sec_low[0]~4_combout\);

-- Location: LCCOMB_X50_Y34_N6
\in_tim_sec_low[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_low[0]~0_combout\ = (!\bt3|btn_delay~q\ & (\bt3|btn_sync~q\ & \current_state.ST0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt3|btn_delay~q\,
	datab => \bt3|btn_sync~q\,
	datad => \current_state.ST0~q\,
	combout => \in_tim_sec_low[0]~0_combout\);

-- Location: FF_X48_Y32_N3
\in_tim_sec_low[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_low[0]~4_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_sec_low[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_low(0));

-- Location: LCCOMB_X48_Y32_N0
\in_tim_sec_low[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_low[2]~1_combout\ = in_tim_sec_low(2) $ (((in_tim_sec_low(1) & (\in_tim_sec_low[0]~0_combout\ & !in_tim_sec_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(1),
	datab => \in_tim_sec_low[0]~0_combout\,
	datac => in_tim_sec_low(2),
	datad => in_tim_sec_low(0),
	combout => \in_tim_sec_low[2]~1_combout\);

-- Location: FF_X48_Y32_N1
\in_tim_sec_low[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_low[2]~1_combout\,
	clrn => \en~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_low(2));

-- Location: LCCOMB_X48_Y32_N10
\in_tim_sec_low~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_low~2_combout\ = (in_tim_sec_low(1) & (in_tim_sec_low(3) $ (((in_tim_sec_low(2) & !in_tim_sec_low(0)))))) # (!in_tim_sec_low(1) & (in_tim_sec_low(3) & ((in_tim_sec_low(2)) # (in_tim_sec_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(1),
	datab => in_tim_sec_low(2),
	datac => in_tim_sec_low(3),
	datad => in_tim_sec_low(0),
	combout => \in_tim_sec_low~2_combout\);

-- Location: FF_X48_Y32_N11
\in_tim_sec_low[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_low~2_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_sec_low[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_low(3));

-- Location: LCCOMB_X48_Y32_N6
\in_tim_sec_low~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \in_tim_sec_low~3_combout\ = (in_tim_sec_low(1) & (((in_tim_sec_low(0))))) # (!in_tim_sec_low(1) & (!in_tim_sec_low(0) & ((in_tim_sec_low(2)) # (!in_tim_sec_low(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(3),
	datab => in_tim_sec_low(2),
	datac => in_tim_sec_low(1),
	datad => in_tim_sec_low(0),
	combout => \in_tim_sec_low~3_combout\);

-- Location: FF_X48_Y32_N7
\in_tim_sec_low[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~input_o\,
	d => \in_tim_sec_low~3_combout\,
	clrn => \en~input_o\,
	ena => \in_tim_sec_low[0]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => in_tim_sec_low(1));

-- Location: LCCOMB_X48_Y32_N4
\process_14~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_14~7_combout\ = (\cnt_sec_low[0]~17_combout\ & (!in_tim_sec_low(0) & (\cnt_sec_low[1]~12_combout\ $ (!in_tim_sec_low(1))))) # (!\cnt_sec_low[0]~17_combout\ & (in_tim_sec_low(0) & (\cnt_sec_low[1]~12_combout\ $ (!in_tim_sec_low(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000000000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[0]~17_combout\,
	datab => in_tim_sec_low(0),
	datac => \cnt_sec_low[1]~12_combout\,
	datad => in_tim_sec_low(1),
	combout => \process_14~7_combout\);

-- Location: LCCOMB_X48_Y32_N24
\process_14~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_14~8_combout\ = (in_tim_sec_low(3) & (\cnt_sec_low[3]~7_combout\ & (\cnt_sec_low[2]~2_combout\ $ (!in_tim_sec_low(2))))) # (!in_tim_sec_low(3) & (!\cnt_sec_low[3]~7_combout\ & (\cnt_sec_low[2]~2_combout\ $ (!in_tim_sec_low(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000010000100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(3),
	datab => \cnt_sec_low[2]~2_combout\,
	datac => \cnt_sec_low[3]~7_combout\,
	datad => in_tim_sec_low(2),
	combout => \process_14~8_combout\);

-- Location: LCCOMB_X48_Y32_N26
\process_14~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \process_14~9_combout\ = (\process_14~6_combout\ & (\process_14~4_combout\ & (\process_14~7_combout\ & \process_14~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_14~6_combout\,
	datab => \process_14~4_combout\,
	datac => \process_14~7_combout\,
	datad => \process_14~8_combout\,
	combout => \process_14~9_combout\);

-- Location: LCCOMB_X49_Y34_N30
\time_trig~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \time_trig~2_combout\ = (\current_state.INC~q\ & ((\process_14~9_combout\) # ((\bt3|btn_sync~q\ & !\bt3|btn_delay~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \bt3|btn_sync~q\,
	datab => \process_14~9_combout\,
	datac => \current_state.INC~q\,
	datad => \bt3|btn_delay~q\,
	combout => \time_trig~2_combout\);

-- Location: LCCOMB_X49_Y34_N26
time_trig : cycloneive_lcell_comb
-- Equation(s):
-- \time_trig~combout\ = (\en~input_o\ & ((\time_trig~2_combout\ & (\process_14~9_combout\)) # (!\time_trig~2_combout\ & ((\time_trig~combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \process_14~9_combout\,
	datab => \en~input_o\,
	datac => \time_trig~combout\,
	datad => \time_trig~2_combout\,
	combout => \time_trig~combout\);

-- Location: LCCOMB_X53_Y33_N0
\t2|toggle~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \t2|toggle~0_combout\ = !\t2|toggle~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \t2|toggle~q\,
	combout => \t2|toggle~0_combout\);

-- Location: FF_X53_Y33_N1
\t2|toggle\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \t2|toggle~0_combout\,
	ena => \t1|Equal0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \t2|toggle~q\);

-- Location: LCCOMB_X47_Y34_N0
\led_flash~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \led_flash~0_combout\ = (\time_trig~combout\ & \t2|toggle~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \time_trig~combout\,
	datad => \t2|toggle~q\,
	combout => \led_flash~0_combout\);

-- Location: LCCOMB_X46_Y30_N24
\min_high~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~0_combout\ = (\cnt_min_high[1]~12_combout\ & (!\cnt_min_high[2]~2_combout\ & ((\cnt_min_high[3]~7_combout\)))) # (!\cnt_min_high[1]~12_combout\ & ((\cnt_min_high[2]~2_combout\ & (\cnt_min_high[0]~17_combout\ $ (!\cnt_min_high[3]~7_combout\))) # 
-- (!\cnt_min_high[2]~2_combout\ & (\cnt_min_high[0]~17_combout\ & !\cnt_min_high[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110001000010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[1]~12_combout\,
	datab => \cnt_min_high[2]~2_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \min_high~0_combout\);

-- Location: LCCOMB_X46_Y30_N26
\min_high~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~1_combout\ = (\min_high~0_combout\) # ((\t1|toggle~q\ & \current_state.M1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|toggle~q\,
	datac => \current_state.M1~q\,
	datad => \min_high~0_combout\,
	combout => \min_high~1_combout\);

-- Location: LCCOMB_X46_Y30_N30
\min_high~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~2_combout\ = (\cnt_min_high[2]~2_combout\ & (!\cnt_min_high[3]~7_combout\ & (\cnt_min_high[1]~12_combout\ $ (\cnt_min_high[0]~17_combout\)))) # (!\cnt_min_high[2]~2_combout\ & (\cnt_min_high[1]~12_combout\ & (\cnt_min_high[0]~17_combout\ & 
-- \cnt_min_high[3]~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000001001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[1]~12_combout\,
	datab => \cnt_min_high[2]~2_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \min_high~2_combout\);

-- Location: LCCOMB_X46_Y30_N12
\se1|seg[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se1|seg[1]~0_combout\ = (\cnt_min_high[2]~2_combout\ & (\cnt_min_high[3]~7_combout\ & ((\cnt_min_high[1]~12_combout\) # (!\cnt_min_high[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[1]~12_combout\,
	datab => \cnt_min_high[2]~2_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \se1|seg[1]~0_combout\);

-- Location: LCCOMB_X46_Y30_N8
\min_high~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~3_combout\ = (\min_high~2_combout\) # ((\se1|seg[1]~0_combout\) # ((\t1|toggle~q\ & \current_state.M1~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \min_high~2_combout\,
	datab => \t1|toggle~q\,
	datac => \current_state.M1~q\,
	datad => \se1|seg[1]~0_combout\,
	combout => \min_high~3_combout\);

-- Location: LCCOMB_X46_Y30_N18
\min_high~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~4_combout\ = (\cnt_min_high[1]~12_combout\ & (!\cnt_min_high[2]~2_combout\ & (!\cnt_min_high[0]~17_combout\ & !\cnt_min_high[3]~7_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[1]~12_combout\,
	datab => \cnt_min_high[2]~2_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \min_high~4_combout\);

-- Location: LCCOMB_X46_Y30_N28
\min_high~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~5_combout\ = (\se1|seg[1]~0_combout\) # ((\min_high~4_combout\) # ((\t1|toggle~q\ & \current_state.M1~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se1|seg[1]~0_combout\,
	datab => \t1|toggle~q\,
	datac => \current_state.M1~q\,
	datad => \min_high~4_combout\,
	combout => \min_high~5_combout\);

-- Location: LCCOMB_X46_Y30_N6
\se1|seg[3]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se1|seg[3]~1_combout\ = (\cnt_min_high[1]~12_combout\ & ((\cnt_min_high[2]~2_combout\ & (\cnt_min_high[0]~17_combout\)) # (!\cnt_min_high[2]~2_combout\ & (!\cnt_min_high[0]~17_combout\ & \cnt_min_high[3]~7_combout\)))) # (!\cnt_min_high[1]~12_combout\ & 
-- (!\cnt_min_high[3]~7_combout\ & (\cnt_min_high[2]~2_combout\ $ (\cnt_min_high[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001010010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[1]~12_combout\,
	datab => \cnt_min_high[2]~2_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \se1|seg[3]~1_combout\);

-- Location: LCCOMB_X46_Y30_N0
\min_high~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~6_combout\ = (\se1|seg[3]~1_combout\) # ((\t1|toggle~q\ & \current_state.M1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|toggle~q\,
	datac => \current_state.M1~q\,
	datad => \se1|seg[3]~1_combout\,
	combout => \min_high~6_combout\);

-- Location: LCCOMB_X46_Y30_N2
\se1|seg[4]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se1|seg[4]~2_combout\ = (\cnt_min_high[1]~12_combout\ & (((\cnt_min_high[0]~17_combout\ & !\cnt_min_high[3]~7_combout\)))) # (!\cnt_min_high[1]~12_combout\ & ((\cnt_min_high[2]~2_combout\ & ((!\cnt_min_high[3]~7_combout\))) # 
-- (!\cnt_min_high[2]~2_combout\ & (\cnt_min_high[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000011110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[1]~12_combout\,
	datab => \cnt_min_high[2]~2_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \se1|seg[4]~2_combout\);

-- Location: LCCOMB_X46_Y30_N4
\min_high~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~7_combout\ = (\se1|seg[4]~2_combout\) # ((\t1|toggle~q\ & \current_state.M1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|toggle~q\,
	datac => \current_state.M1~q\,
	datad => \se1|seg[4]~2_combout\,
	combout => \min_high~7_combout\);

-- Location: LCCOMB_X46_Y30_N22
\min_high~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~8_combout\ = (\cnt_min_high[1]~12_combout\ & (!\cnt_min_high[3]~7_combout\ & ((\cnt_min_high[0]~17_combout\) # (!\cnt_min_high[2]~2_combout\)))) # (!\cnt_min_high[1]~12_combout\ & (\cnt_min_high[0]~17_combout\ & (\cnt_min_high[2]~2_combout\ $ 
-- (!\cnt_min_high[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000010110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[1]~12_combout\,
	datab => \cnt_min_high[2]~2_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \min_high~8_combout\);

-- Location: LCCOMB_X46_Y30_N16
\min_high~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~9_combout\ = (\min_high~8_combout\) # ((\current_state.M1~q\ & \t1|toggle~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \min_high~8_combout\,
	datac => \current_state.M1~q\,
	datad => \t1|toggle~q\,
	combout => \min_high~9_combout\);

-- Location: LCCOMB_X46_Y30_N10
\se1|seg[6]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se1|seg[6]~3_combout\ = (\cnt_min_high[0]~17_combout\ & ((\cnt_min_high[3]~7_combout\) # (\cnt_min_high[1]~12_combout\ $ (\cnt_min_high[2]~2_combout\)))) # (!\cnt_min_high[0]~17_combout\ & ((\cnt_min_high[1]~12_combout\) # (\cnt_min_high[2]~2_combout\ $ 
-- (\cnt_min_high[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101101101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_high[1]~12_combout\,
	datab => \cnt_min_high[2]~2_combout\,
	datac => \cnt_min_high[0]~17_combout\,
	datad => \cnt_min_high[3]~7_combout\,
	combout => \se1|seg[6]~3_combout\);

-- Location: LCCOMB_X46_Y30_N20
\min_high~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_high~10_combout\ = ((\t1|toggle~q\ & \current_state.M1~q\)) # (!\se1|seg[6]~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|toggle~q\,
	datac => \current_state.M1~q\,
	datad => \se1|seg[6]~3_combout\,
	combout => \min_high~10_combout\);

-- Location: LCCOMB_X46_Y32_N30
\min_low~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~0_combout\ = (\cnt_min_low[3]~7_combout\ & ((\cnt_min_low[2]~2_combout\ & (\cnt_min_low[0]~17_combout\ & !\cnt_min_low[1]~12_combout\)) # (!\cnt_min_low[2]~2_combout\ & ((\cnt_min_low[1]~12_combout\))))) # (!\cnt_min_low[3]~7_combout\ & 
-- (!\cnt_min_low[1]~12_combout\ & (\cnt_min_low[2]~2_combout\ $ (\cnt_min_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001010010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[3]~7_combout\,
	datab => \cnt_min_low[2]~2_combout\,
	datac => \cnt_min_low[0]~17_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \min_low~0_combout\);

-- Location: LCCOMB_X49_Y31_N2
\min_low~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~1_combout\ = (\min_low~0_combout\) # ((\current_state.M0~q\ & \t1|toggle~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \current_state.M0~q\,
	datac => \t1|toggle~q\,
	datad => \min_low~0_combout\,
	combout => \min_low~1_combout\);

-- Location: LCCOMB_X46_Y32_N4
\se2|seg[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se2|seg[1]~0_combout\ = (\cnt_min_low[3]~7_combout\ & (\cnt_min_low[2]~2_combout\ & ((\cnt_min_low[1]~12_combout\) # (!\cnt_min_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[3]~7_combout\,
	datab => \cnt_min_low[1]~12_combout\,
	datac => \cnt_min_low[0]~17_combout\,
	datad => \cnt_min_low[2]~2_combout\,
	combout => \se2|seg[1]~0_combout\);

-- Location: LCCOMB_X46_Y32_N18
\min_low~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~2_combout\ = (\cnt_min_low[3]~7_combout\ & (\cnt_min_low[1]~12_combout\ & (\cnt_min_low[0]~17_combout\ & !\cnt_min_low[2]~2_combout\))) # (!\cnt_min_low[3]~7_combout\ & (\cnt_min_low[2]~2_combout\ & (\cnt_min_low[1]~12_combout\ $ 
-- (\cnt_min_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001010010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[3]~7_combout\,
	datab => \cnt_min_low[1]~12_combout\,
	datac => \cnt_min_low[0]~17_combout\,
	datad => \cnt_min_low[2]~2_combout\,
	combout => \min_low~2_combout\);

-- Location: LCCOMB_X46_Y32_N20
\min_low~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~3_combout\ = (\se2|seg[1]~0_combout\) # ((\min_low~2_combout\) # ((\t1|toggle~q\ & \current_state.M0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datab => \current_state.M0~q\,
	datac => \se2|seg[1]~0_combout\,
	datad => \min_low~2_combout\,
	combout => \min_low~3_combout\);

-- Location: LCCOMB_X46_Y32_N10
\min_low~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~4_combout\ = (!\cnt_min_low[3]~7_combout\ & (!\cnt_min_low[2]~2_combout\ & (!\cnt_min_low[0]~17_combout\ & \cnt_min_low[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[3]~7_combout\,
	datab => \cnt_min_low[2]~2_combout\,
	datac => \cnt_min_low[0]~17_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \min_low~4_combout\);

-- Location: LCCOMB_X46_Y32_N22
\min_low~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~5_combout\ = (\se2|seg[1]~0_combout\) # ((\min_low~4_combout\) # ((\t1|toggle~q\ & \current_state.M0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datab => \current_state.M0~q\,
	datac => \se2|seg[1]~0_combout\,
	datad => \min_low~4_combout\,
	combout => \min_low~5_combout\);

-- Location: LCCOMB_X46_Y32_N26
\se2|seg[3]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se2|seg[3]~1_combout\ = (\cnt_min_low[1]~12_combout\ & ((\cnt_min_low[2]~2_combout\ & ((\cnt_min_low[0]~17_combout\))) # (!\cnt_min_low[2]~2_combout\ & (\cnt_min_low[3]~7_combout\ & !\cnt_min_low[0]~17_combout\)))) # (!\cnt_min_low[1]~12_combout\ & 
-- (!\cnt_min_low[3]~7_combout\ & (\cnt_min_low[2]~2_combout\ $ (\cnt_min_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001000010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[3]~7_combout\,
	datab => \cnt_min_low[2]~2_combout\,
	datac => \cnt_min_low[0]~17_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \se2|seg[3]~1_combout\);

-- Location: LCCOMB_X49_Y31_N12
\min_low~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~6_combout\ = (\se2|seg[3]~1_combout\) # ((\current_state.M0~q\ & \t1|toggle~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \current_state.M0~q\,
	datac => \t1|toggle~q\,
	datad => \se2|seg[3]~1_combout\,
	combout => \min_low~6_combout\);

-- Location: LCCOMB_X48_Y32_N30
\se2|seg[4]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se2|seg[4]~2_combout\ = (\cnt_min_low[1]~12_combout\ & (\cnt_min_low[0]~17_combout\ & (!\cnt_min_low[3]~7_combout\))) # (!\cnt_min_low[1]~12_combout\ & ((\cnt_min_low[2]~2_combout\ & ((!\cnt_min_low[3]~7_combout\))) # (!\cnt_min_low[2]~2_combout\ & 
-- (\cnt_min_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001000111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~17_combout\,
	datab => \cnt_min_low[3]~7_combout\,
	datac => \cnt_min_low[2]~2_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \se2|seg[4]~2_combout\);

-- Location: LCCOMB_X49_Y31_N6
\min_low~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~7_combout\ = (\se2|seg[4]~2_combout\) # ((\current_state.M0~q\ & \t1|toggle~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \current_state.M0~q\,
	datac => \t1|toggle~q\,
	datad => \se2|seg[4]~2_combout\,
	combout => \min_low~7_combout\);

-- Location: LCCOMB_X46_Y32_N14
\min_low~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~8_combout\ = (\cnt_min_low[2]~2_combout\ & (\cnt_min_low[0]~17_combout\ & (\cnt_min_low[3]~7_combout\ $ (\cnt_min_low[1]~12_combout\)))) # (!\cnt_min_low[2]~2_combout\ & (!\cnt_min_low[3]~7_combout\ & ((\cnt_min_low[0]~17_combout\) # 
-- (\cnt_min_low[1]~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000110010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[3]~7_combout\,
	datab => \cnt_min_low[2]~2_combout\,
	datac => \cnt_min_low[0]~17_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \min_low~8_combout\);

-- Location: LCCOMB_X49_Y31_N10
\min_low~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~9_combout\ = (\min_low~8_combout\) # ((\t1|toggle~q\ & \current_state.M0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \min_low~8_combout\,
	datac => \t1|toggle~q\,
	datad => \current_state.M0~q\,
	combout => \min_low~9_combout\);

-- Location: LCCOMB_X48_Y32_N12
\se2|seg[6]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se2|seg[6]~3_combout\ = (\cnt_min_low[0]~17_combout\ & ((\cnt_min_low[3]~7_combout\) # (\cnt_min_low[2]~2_combout\ $ (\cnt_min_low[1]~12_combout\)))) # (!\cnt_min_low[0]~17_combout\ & ((\cnt_min_low[1]~12_combout\) # (\cnt_min_low[3]~7_combout\ $ 
-- (\cnt_min_low[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101111110111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_min_low[0]~17_combout\,
	datab => \cnt_min_low[3]~7_combout\,
	datac => \cnt_min_low[2]~2_combout\,
	datad => \cnt_min_low[1]~12_combout\,
	combout => \se2|seg[6]~3_combout\);

-- Location: LCCOMB_X49_Y31_N28
\min_low~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \min_low~10_combout\ = ((\t1|toggle~q\ & \current_state.M0~q\)) # (!\se2|seg[6]~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010101010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se2|seg[6]~3_combout\,
	datac => \t1|toggle~q\,
	datad => \current_state.M0~q\,
	combout => \min_low~10_combout\);

-- Location: LCCOMB_X59_Y12_N24
\sec_high~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~0_combout\ = (\cnt_sec_high[2]~2_combout\ & (!\cnt_sec_high[1]~12_combout\ & (\cnt_sec_high[3]~7_combout\ $ (!\cnt_sec_high[0]~17_combout\)))) # (!\cnt_sec_high[2]~2_combout\ & ((\cnt_sec_high[1]~12_combout\ & (\cnt_sec_high[3]~7_combout\)) # 
-- (!\cnt_sec_high[1]~12_combout\ & (!\cnt_sec_high[3]~7_combout\ & \cnt_sec_high[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000101000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[2]~2_combout\,
	datab => \cnt_sec_high[1]~12_combout\,
	datac => \cnt_sec_high[3]~7_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \sec_high~0_combout\);

-- Location: LCCOMB_X59_Y12_N2
\sec_high~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~1_combout\ = (\sec_high~0_combout\) # ((\current_state.S1~q\ & \t1|toggle~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \current_state.S1~q\,
	datac => \t1|toggle~q\,
	datad => \sec_high~0_combout\,
	combout => \sec_high~1_combout\);

-- Location: LCCOMB_X59_Y12_N12
\se3|seg[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se3|seg[1]~0_combout\ = (\cnt_sec_high[2]~2_combout\ & (\cnt_sec_high[3]~7_combout\ & ((\cnt_sec_high[1]~12_combout\) # (!\cnt_sec_high[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[2]~2_combout\,
	datab => \cnt_sec_high[1]~12_combout\,
	datac => \cnt_sec_high[3]~7_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \se3|seg[1]~0_combout\);

-- Location: LCCOMB_X59_Y12_N22
\sec_high~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~2_combout\ = (\cnt_sec_high[2]~2_combout\ & (!\cnt_sec_high[3]~7_combout\ & (\cnt_sec_high[1]~12_combout\ $ (\cnt_sec_high[0]~17_combout\)))) # (!\cnt_sec_high[2]~2_combout\ & (\cnt_sec_high[1]~12_combout\ & (\cnt_sec_high[3]~7_combout\ & 
-- \cnt_sec_high[0]~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100001000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[2]~2_combout\,
	datab => \cnt_sec_high[1]~12_combout\,
	datac => \cnt_sec_high[3]~7_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \sec_high~2_combout\);

-- Location: LCCOMB_X59_Y12_N8
\sec_high~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~3_combout\ = (\se3|seg[1]~0_combout\) # ((\sec_high~2_combout\) # ((\current_state.S1~q\ & \t1|toggle~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se3|seg[1]~0_combout\,
	datab => \current_state.S1~q\,
	datac => \sec_high~2_combout\,
	datad => \t1|toggle~q\,
	combout => \sec_high~3_combout\);

-- Location: LCCOMB_X59_Y12_N10
\sec_high~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~4_combout\ = (!\cnt_sec_high[2]~2_combout\ & (\cnt_sec_high[1]~12_combout\ & (!\cnt_sec_high[3]~7_combout\ & !\cnt_sec_high[0]~17_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[2]~2_combout\,
	datab => \cnt_sec_high[1]~12_combout\,
	datac => \cnt_sec_high[3]~7_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \sec_high~4_combout\);

-- Location: LCCOMB_X59_Y12_N28
\sec_high~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~5_combout\ = (\se3|seg[1]~0_combout\) # ((\sec_high~4_combout\) # ((\current_state.S1~q\ & \t1|toggle~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se3|seg[1]~0_combout\,
	datab => \sec_high~4_combout\,
	datac => \current_state.S1~q\,
	datad => \t1|toggle~q\,
	combout => \sec_high~5_combout\);

-- Location: LCCOMB_X59_Y12_N6
\se3|seg[3]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se3|seg[3]~1_combout\ = (\cnt_sec_high[1]~12_combout\ & ((\cnt_sec_high[2]~2_combout\ & ((\cnt_sec_high[0]~17_combout\))) # (!\cnt_sec_high[2]~2_combout\ & (\cnt_sec_high[3]~7_combout\ & !\cnt_sec_high[0]~17_combout\)))) # (!\cnt_sec_high[1]~12_combout\ 
-- & (!\cnt_sec_high[3]~7_combout\ & (\cnt_sec_high[2]~2_combout\ $ (\cnt_sec_high[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100101000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[2]~2_combout\,
	datab => \cnt_sec_high[1]~12_combout\,
	datac => \cnt_sec_high[3]~7_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \se3|seg[3]~1_combout\);

-- Location: LCCOMB_X59_Y12_N16
\sec_high~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~6_combout\ = (\se3|seg[3]~1_combout\) # ((\current_state.S1~q\ & \t1|toggle~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \current_state.S1~q\,
	datac => \t1|toggle~q\,
	datad => \se3|seg[3]~1_combout\,
	combout => \sec_high~6_combout\);

-- Location: LCCOMB_X59_Y12_N26
\se3|seg[4]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se3|seg[4]~2_combout\ = (\cnt_sec_high[1]~12_combout\ & (((!\cnt_sec_high[3]~7_combout\ & \cnt_sec_high[0]~17_combout\)))) # (!\cnt_sec_high[1]~12_combout\ & ((\cnt_sec_high[2]~2_combout\ & (!\cnt_sec_high[3]~7_combout\)) # (!\cnt_sec_high[2]~2_combout\ 
-- & ((\cnt_sec_high[0]~17_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[2]~2_combout\,
	datab => \cnt_sec_high[1]~12_combout\,
	datac => \cnt_sec_high[3]~7_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \se3|seg[4]~2_combout\);

-- Location: LCCOMB_X59_Y12_N20
\sec_high~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~7_combout\ = (\se3|seg[4]~2_combout\) # ((\current_state.S1~q\ & \t1|toggle~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se3|seg[4]~2_combout\,
	datab => \current_state.S1~q\,
	datac => \t1|toggle~q\,
	combout => \sec_high~7_combout\);

-- Location: LCCOMB_X59_Y12_N30
\sec_high~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~8_combout\ = (\cnt_sec_high[2]~2_combout\ & (\cnt_sec_high[0]~17_combout\ & (\cnt_sec_high[1]~12_combout\ $ (\cnt_sec_high[3]~7_combout\)))) # (!\cnt_sec_high[2]~2_combout\ & (!\cnt_sec_high[3]~7_combout\ & ((\cnt_sec_high[1]~12_combout\) # 
-- (\cnt_sec_high[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010110100000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[2]~2_combout\,
	datab => \cnt_sec_high[1]~12_combout\,
	datac => \cnt_sec_high[3]~7_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \sec_high~8_combout\);

-- Location: LCCOMB_X59_Y12_N0
\sec_high~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~9_combout\ = (\sec_high~8_combout\) # ((\t1|toggle~q\ & \current_state.S1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sec_high~8_combout\,
	datab => \t1|toggle~q\,
	datac => \current_state.S1~q\,
	combout => \sec_high~9_combout\);

-- Location: LCCOMB_X59_Y12_N18
\se3|seg[6]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se3|seg[6]~3_combout\ = (\cnt_sec_high[0]~17_combout\ & ((\cnt_sec_high[3]~7_combout\) # (\cnt_sec_high[2]~2_combout\ $ (\cnt_sec_high[1]~12_combout\)))) # (!\cnt_sec_high[0]~17_combout\ & ((\cnt_sec_high[1]~12_combout\) # (\cnt_sec_high[2]~2_combout\ $ 
-- (\cnt_sec_high[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011011011110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_high[2]~2_combout\,
	datab => \cnt_sec_high[1]~12_combout\,
	datac => \cnt_sec_high[3]~7_combout\,
	datad => \cnt_sec_high[0]~17_combout\,
	combout => \se3|seg[6]~3_combout\);

-- Location: LCCOMB_X59_Y12_N4
\sec_high~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_high~10_combout\ = ((\current_state.S1~q\ & \t1|toggle~q\)) # (!\se3|seg[6]~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \current_state.S1~q\,
	datac => \t1|toggle~q\,
	datad => \se3|seg[6]~3_combout\,
	combout => \sec_high~10_combout\);

-- Location: LCCOMB_X74_Y16_N0
\sec_low~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~0_combout\ = (\cnt_sec_low[2]~2_combout\ & (!\cnt_sec_low[1]~12_combout\ & (\cnt_sec_low[0]~17_combout\ $ (!\cnt_sec_low[3]~7_combout\)))) # (!\cnt_sec_low[2]~2_combout\ & ((\cnt_sec_low[3]~7_combout\ & ((\cnt_sec_low[1]~12_combout\))) # 
-- (!\cnt_sec_low[3]~7_combout\ & (\cnt_sec_low[0]~17_combout\ & !\cnt_sec_low[1]~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000010000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[2]~2_combout\,
	datab => \cnt_sec_low[0]~17_combout\,
	datac => \cnt_sec_low[3]~7_combout\,
	datad => \cnt_sec_low[1]~12_combout\,
	combout => \sec_low~0_combout\);

-- Location: LCCOMB_X74_Y16_N26
\sec_low~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~1_combout\ = (\sec_low~0_combout\) # ((\t1|toggle~q\ & \current_state.S0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|toggle~q\,
	datac => \current_state.S0~q\,
	datad => \sec_low~0_combout\,
	combout => \sec_low~1_combout\);

-- Location: LCCOMB_X74_Y16_N22
\sec_low~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~2_combout\ = (\cnt_sec_low[2]~2_combout\ & (!\cnt_sec_low[3]~7_combout\ & (\cnt_sec_low[0]~17_combout\ $ (\cnt_sec_low[1]~12_combout\)))) # (!\cnt_sec_low[2]~2_combout\ & (\cnt_sec_low[0]~17_combout\ & (\cnt_sec_low[3]~7_combout\ & 
-- \cnt_sec_low[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100001000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[2]~2_combout\,
	datab => \cnt_sec_low[0]~17_combout\,
	datac => \cnt_sec_low[3]~7_combout\,
	datad => \cnt_sec_low[1]~12_combout\,
	combout => \sec_low~2_combout\);

-- Location: LCCOMB_X74_Y16_N12
\se4|seg[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se4|seg[1]~0_combout\ = (\cnt_sec_low[2]~2_combout\ & (\cnt_sec_low[3]~7_combout\ & ((\cnt_sec_low[1]~12_combout\) # (!\cnt_sec_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[2]~2_combout\,
	datab => \cnt_sec_low[0]~17_combout\,
	datac => \cnt_sec_low[3]~7_combout\,
	datad => \cnt_sec_low[1]~12_combout\,
	combout => \se4|seg[1]~0_combout\);

-- Location: LCCOMB_X74_Y16_N24
\sec_low~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~3_combout\ = (\sec_low~2_combout\) # ((\se4|seg[1]~0_combout\) # ((\current_state.S0~q\ & \t1|toggle~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.S0~q\,
	datab => \t1|toggle~q\,
	datac => \sec_low~2_combout\,
	datad => \se4|seg[1]~0_combout\,
	combout => \sec_low~3_combout\);

-- Location: LCCOMB_X74_Y16_N2
\sec_low~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~4_combout\ = (!\cnt_sec_low[2]~2_combout\ & (!\cnt_sec_low[0]~17_combout\ & (!\cnt_sec_low[3]~7_combout\ & \cnt_sec_low[1]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[2]~2_combout\,
	datab => \cnt_sec_low[0]~17_combout\,
	datac => \cnt_sec_low[3]~7_combout\,
	datad => \cnt_sec_low[1]~12_combout\,
	combout => \sec_low~4_combout\);

-- Location: LCCOMB_X74_Y16_N4
\sec_low~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~5_combout\ = (\sec_low~4_combout\) # ((\se4|seg[1]~0_combout\) # ((\current_state.S0~q\ & \t1|toggle~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.S0~q\,
	datab => \sec_low~4_combout\,
	datac => \t1|toggle~q\,
	datad => \se4|seg[1]~0_combout\,
	combout => \sec_low~5_combout\);

-- Location: LCCOMB_X74_Y16_N30
\se4|seg[3]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se4|seg[3]~1_combout\ = (\cnt_sec_low[1]~12_combout\ & ((\cnt_sec_low[2]~2_combout\ & (\cnt_sec_low[0]~17_combout\)) # (!\cnt_sec_low[2]~2_combout\ & (!\cnt_sec_low[0]~17_combout\ & \cnt_sec_low[3]~7_combout\)))) # (!\cnt_sec_low[1]~12_combout\ & 
-- (!\cnt_sec_low[3]~7_combout\ & (\cnt_sec_low[2]~2_combout\ $ (\cnt_sec_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001100000000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[2]~2_combout\,
	datab => \cnt_sec_low[0]~17_combout\,
	datac => \cnt_sec_low[3]~7_combout\,
	datad => \cnt_sec_low[1]~12_combout\,
	combout => \se4|seg[3]~1_combout\);

-- Location: LCCOMB_X74_Y16_N16
\sec_low~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~6_combout\ = (\se4|seg[3]~1_combout\) # ((\current_state.S0~q\ & \t1|toggle~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.S0~q\,
	datab => \t1|toggle~q\,
	datad => \se4|seg[3]~1_combout\,
	combout => \sec_low~6_combout\);

-- Location: LCCOMB_X74_Y16_N18
\se4|seg[4]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se4|seg[4]~2_combout\ = (\cnt_sec_low[1]~12_combout\ & (((\cnt_sec_low[0]~17_combout\ & !\cnt_sec_low[3]~7_combout\)))) # (!\cnt_sec_low[1]~12_combout\ & ((\cnt_sec_low[2]~2_combout\ & ((!\cnt_sec_low[3]~7_combout\))) # (!\cnt_sec_low[2]~2_combout\ & 
-- (\cnt_sec_low[0]~17_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110001001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[2]~2_combout\,
	datab => \cnt_sec_low[0]~17_combout\,
	datac => \cnt_sec_low[3]~7_combout\,
	datad => \cnt_sec_low[1]~12_combout\,
	combout => \se4|seg[4]~2_combout\);

-- Location: LCCOMB_X74_Y16_N28
\sec_low~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~7_combout\ = (\se4|seg[4]~2_combout\) # ((\t1|toggle~q\ & \current_state.S0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|toggle~q\,
	datac => \current_state.S0~q\,
	datad => \se4|seg[4]~2_combout\,
	combout => \sec_low~7_combout\);

-- Location: LCCOMB_X74_Y16_N6
\sec_low~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~8_combout\ = (\cnt_sec_low[2]~2_combout\ & (\cnt_sec_low[0]~17_combout\ & (\cnt_sec_low[3]~7_combout\ $ (\cnt_sec_low[1]~12_combout\)))) # (!\cnt_sec_low[2]~2_combout\ & (!\cnt_sec_low[3]~7_combout\ & ((\cnt_sec_low[0]~17_combout\) # 
-- (\cnt_sec_low[1]~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110110000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[2]~2_combout\,
	datab => \cnt_sec_low[0]~17_combout\,
	datac => \cnt_sec_low[3]~7_combout\,
	datad => \cnt_sec_low[1]~12_combout\,
	combout => \sec_low~8_combout\);

-- Location: LCCOMB_X74_Y16_N8
\sec_low~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~9_combout\ = (\sec_low~8_combout\) # ((\t1|toggle~q\ & \current_state.S0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|toggle~q\,
	datac => \current_state.S0~q\,
	datad => \sec_low~8_combout\,
	combout => \sec_low~9_combout\);

-- Location: LCCOMB_X74_Y16_N10
\se4|seg[6]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se4|seg[6]~3_combout\ = (\cnt_sec_low[0]~17_combout\ & ((\cnt_sec_low[3]~7_combout\) # (\cnt_sec_low[2]~2_combout\ $ (\cnt_sec_low[1]~12_combout\)))) # (!\cnt_sec_low[0]~17_combout\ & ((\cnt_sec_low[1]~12_combout\) # (\cnt_sec_low[2]~2_combout\ $ 
-- (\cnt_sec_low[3]~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011111011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \cnt_sec_low[2]~2_combout\,
	datab => \cnt_sec_low[0]~17_combout\,
	datac => \cnt_sec_low[3]~7_combout\,
	datad => \cnt_sec_low[1]~12_combout\,
	combout => \se4|seg[6]~3_combout\);

-- Location: LCCOMB_X74_Y16_N20
\sec_low~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \sec_low~10_combout\ = ((\t1|toggle~q\ & \current_state.S0~q\)) # (!\se4|seg[6]~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \t1|toggle~q\,
	datac => \current_state.S0~q\,
	datad => \se4|seg[6]~3_combout\,
	combout => \sec_low~10_combout\);

-- Location: LCCOMB_X47_Y30_N12
\tim_min_high~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_high~0_combout\ = (in_tim_min_high(3) & ((in_tim_min_high(2) & (!in_tim_min_high(0) & !in_tim_min_high(1))) # (!in_tim_min_high(2) & ((in_tim_min_high(1)))))) # (!in_tim_min_high(3) & (!in_tim_min_high(1) & (in_tim_min_high(2) $ 
-- (!in_tim_min_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001001001001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(3),
	datab => in_tim_min_high(2),
	datac => in_tim_min_high(0),
	datad => in_tim_min_high(1),
	combout => \tim_min_high~0_combout\);

-- Location: LCCOMB_X56_Y32_N24
\tim_min_high~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_high~1_combout\ = (\tim_min_high~0_combout\) # ((\current_state.MT1~q\ & \t1|toggle~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \tim_min_high~0_combout\,
	datab => \current_state.MT1~q\,
	datac => \t1|toggle~q\,
	combout => \tim_min_high~1_combout\);

-- Location: LCCOMB_X47_Y30_N10
\se5|seg[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se5|seg[1]~0_combout\ = (in_tim_min_high(3) & (in_tim_min_high(2) & ((in_tim_min_high(0)) # (in_tim_min_high(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(3),
	datab => in_tim_min_high(2),
	datac => in_tim_min_high(0),
	datad => in_tim_min_high(1),
	combout => \se5|seg[1]~0_combout\);

-- Location: LCCOMB_X47_Y30_N20
\tim_min_high~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_high~2_combout\ = (in_tim_min_high(3) & (!in_tim_min_high(2) & (!in_tim_min_high(0) & in_tim_min_high(1)))) # (!in_tim_min_high(3) & (in_tim_min_high(2) & (in_tim_min_high(0) $ (!in_tim_min_high(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100001000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(3),
	datab => in_tim_min_high(2),
	datac => in_tim_min_high(0),
	datad => in_tim_min_high(1),
	combout => \tim_min_high~2_combout\);

-- Location: LCCOMB_X56_Y32_N26
\tim_min_high~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_high~3_combout\ = (\se5|seg[1]~0_combout\) # ((\tim_min_high~2_combout\) # ((\t1|toggle~q\ & \current_state.MT1~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datab => \current_state.MT1~q\,
	datac => \se5|seg[1]~0_combout\,
	datad => \tim_min_high~2_combout\,
	combout => \tim_min_high~3_combout\);

-- Location: LCCOMB_X47_Y30_N22
\tim_min_high~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_high~4_combout\ = (!in_tim_min_high(3) & (!in_tim_min_high(2) & (in_tim_min_high(0) & in_tim_min_high(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(3),
	datab => in_tim_min_high(2),
	datac => in_tim_min_high(0),
	datad => in_tim_min_high(1),
	combout => \tim_min_high~4_combout\);

-- Location: LCCOMB_X56_Y32_N4
\tim_min_high~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_high~5_combout\ = (\se5|seg[1]~0_combout\) # ((\tim_min_high~4_combout\) # ((\t1|toggle~q\ & \current_state.MT1~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datab => \se5|seg[1]~0_combout\,
	datac => \current_state.MT1~q\,
	datad => \tim_min_high~4_combout\,
	combout => \tim_min_high~5_combout\);

-- Location: LCCOMB_X47_Y30_N4
\se5|seg[3]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se5|seg[3]~1_combout\ = (in_tim_min_high(1) & ((in_tim_min_high(2) & ((!in_tim_min_high(0)))) # (!in_tim_min_high(2) & (in_tim_min_high(3) & in_tim_min_high(0))))) # (!in_tim_min_high(1) & (!in_tim_min_high(3) & (in_tim_min_high(2) $ 
-- (!in_tim_min_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010110001000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(3),
	datab => in_tim_min_high(2),
	datac => in_tim_min_high(0),
	datad => in_tim_min_high(1),
	combout => \se5|seg[3]~1_combout\);

-- Location: LCCOMB_X54_Y31_N14
\tim_min_high~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_high~6_combout\ = (\se5|seg[3]~1_combout\) # ((\current_state.MT1~q\ & \t1|toggle~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se5|seg[3]~1_combout\,
	datac => \current_state.MT1~q\,
	datad => \t1|toggle~q\,
	combout => \tim_min_high~6_combout\);

-- Location: LCCOMB_X47_Y30_N30
\se5|seg[4]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se5|seg[4]~2_combout\ = (in_tim_min_high(1) & (!in_tim_min_high(3) & ((!in_tim_min_high(0))))) # (!in_tim_min_high(1) & ((in_tim_min_high(2) & (!in_tim_min_high(3))) # (!in_tim_min_high(2) & ((!in_tim_min_high(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010101000111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(3),
	datab => in_tim_min_high(2),
	datac => in_tim_min_high(0),
	datad => in_tim_min_high(1),
	combout => \se5|seg[4]~2_combout\);

-- Location: LCCOMB_X56_Y32_N6
\tim_min_high~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_high~7_combout\ = (\se5|seg[4]~2_combout\) # ((\current_state.MT1~q\ & \t1|toggle~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se5|seg[4]~2_combout\,
	datab => \current_state.MT1~q\,
	datac => \t1|toggle~q\,
	combout => \tim_min_high~7_combout\);

-- Location: LCCOMB_X47_Y30_N8
\tim_min_high~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_high~8_combout\ = (in_tim_min_high(2) & ((in_tim_min_high(0)) # (in_tim_min_high(3) $ (!in_tim_min_high(1))))) # (!in_tim_min_high(2) & ((in_tim_min_high(3)) # ((in_tim_min_high(0) & !in_tim_min_high(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011110110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(3),
	datab => in_tim_min_high(2),
	datac => in_tim_min_high(0),
	datad => in_tim_min_high(1),
	combout => \tim_min_high~8_combout\);

-- Location: LCCOMB_X54_Y31_N8
\tim_min_high~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_high~9_combout\ = ((\current_state.MT1~q\ & \t1|toggle~q\)) # (!\tim_min_high~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010101010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \tim_min_high~8_combout\,
	datac => \current_state.MT1~q\,
	datad => \t1|toggle~q\,
	combout => \tim_min_high~9_combout\);

-- Location: LCCOMB_X47_Y30_N18
\se5|seg[6]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se5|seg[6]~3_combout\ = (in_tim_min_high(0) & ((in_tim_min_high(1)) # (in_tim_min_high(3) $ (in_tim_min_high(2))))) # (!in_tim_min_high(0) & ((in_tim_min_high(3)) # (in_tim_min_high(2) $ (in_tim_min_high(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101101101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_high(3),
	datab => in_tim_min_high(2),
	datac => in_tim_min_high(0),
	datad => in_tim_min_high(1),
	combout => \se5|seg[6]~3_combout\);

-- Location: LCCOMB_X54_Y31_N16
\tim_min_high~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_high~10_combout\ = ((\current_state.MT1~q\ & \t1|toggle~q\)) # (!\se5|seg[6]~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110101010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se5|seg[6]~3_combout\,
	datab => \current_state.MT1~q\,
	datad => \t1|toggle~q\,
	combout => \tim_min_high~10_combout\);

-- Location: LCCOMB_X47_Y31_N4
\tim_min_low~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_low~0_combout\ = (in_tim_min_low(2) & (!in_tim_min_low(1) & (in_tim_min_low(0) $ (in_tim_min_low(3))))) # (!in_tim_min_low(2) & ((in_tim_min_low(1) & ((in_tim_min_low(3)))) # (!in_tim_min_low(1) & (!in_tim_min_low(0) & !in_tim_min_low(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011010000001001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(0),
	datab => in_tim_min_low(2),
	datac => in_tim_min_low(1),
	datad => in_tim_min_low(3),
	combout => \tim_min_low~0_combout\);

-- Location: LCCOMB_X47_Y31_N18
\tim_min_low~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_low~1_combout\ = (\tim_min_low~0_combout\) # ((\t1|toggle~q\ & \current_state.MT0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \tim_min_low~0_combout\,
	datab => \t1|toggle~q\,
	datad => \current_state.MT0~q\,
	combout => \tim_min_low~1_combout\);

-- Location: LCCOMB_X47_Y31_N10
\tim_min_low~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_low~2_combout\ = (in_tim_min_low(2) & (!in_tim_min_low(3) & (in_tim_min_low(0) $ (!in_tim_min_low(1))))) # (!in_tim_min_low(2) & (!in_tim_min_low(0) & (in_tim_min_low(1) & in_tim_min_low(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000010000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(0),
	datab => in_tim_min_low(2),
	datac => in_tim_min_low(1),
	datad => in_tim_min_low(3),
	combout => \tim_min_low~2_combout\);

-- Location: LCCOMB_X47_Y31_N24
\se6|seg[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se6|seg[1]~0_combout\ = (in_tim_min_low(2) & (in_tim_min_low(3) & ((in_tim_min_low(0)) # (in_tim_min_low(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(0),
	datab => in_tim_min_low(2),
	datac => in_tim_min_low(1),
	datad => in_tim_min_low(3),
	combout => \se6|seg[1]~0_combout\);

-- Location: LCCOMB_X47_Y31_N16
\tim_min_low~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_low~3_combout\ = (\tim_min_low~2_combout\) # ((\se6|seg[1]~0_combout\) # ((\current_state.MT0~q\ & \t1|toggle~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.MT0~q\,
	datab => \tim_min_low~2_combout\,
	datac => \t1|toggle~q\,
	datad => \se6|seg[1]~0_combout\,
	combout => \tim_min_low~3_combout\);

-- Location: LCCOMB_X47_Y31_N28
\tim_min_low~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_low~4_combout\ = (in_tim_min_low(0) & (!in_tim_min_low(2) & (in_tim_min_low(1) & !in_tim_min_low(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(0),
	datab => in_tim_min_low(2),
	datac => in_tim_min_low(1),
	datad => in_tim_min_low(3),
	combout => \tim_min_low~4_combout\);

-- Location: LCCOMB_X47_Y31_N20
\tim_min_low~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_low~5_combout\ = (\tim_min_low~4_combout\) # ((\se6|seg[1]~0_combout\) # ((\current_state.MT0~q\ & \t1|toggle~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.MT0~q\,
	datab => \t1|toggle~q\,
	datac => \tim_min_low~4_combout\,
	datad => \se6|seg[1]~0_combout\,
	combout => \tim_min_low~5_combout\);

-- Location: LCCOMB_X47_Y31_N26
\se6|seg[3]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se6|seg[3]~1_combout\ = (in_tim_min_low(1) & ((in_tim_min_low(0) & (!in_tim_min_low(2) & in_tim_min_low(3))) # (!in_tim_min_low(0) & (in_tim_min_low(2))))) # (!in_tim_min_low(1) & (!in_tim_min_low(3) & (in_tim_min_low(0) $ (!in_tim_min_low(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000001001001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(0),
	datab => in_tim_min_low(2),
	datac => in_tim_min_low(1),
	datad => in_tim_min_low(3),
	combout => \se6|seg[3]~1_combout\);

-- Location: LCCOMB_X54_Y31_N18
\tim_min_low~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_low~6_combout\ = (\se6|seg[3]~1_combout\) # ((\t1|toggle~q\ & \current_state.MT0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datac => \se6|seg[3]~1_combout\,
	datad => \current_state.MT0~q\,
	combout => \tim_min_low~6_combout\);

-- Location: LCCOMB_X47_Y31_N8
\se6|seg[4]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se6|seg[4]~2_combout\ = (in_tim_min_low(1) & (!in_tim_min_low(0) & ((!in_tim_min_low(3))))) # (!in_tim_min_low(1) & ((in_tim_min_low(2) & ((!in_tim_min_low(3)))) # (!in_tim_min_low(2) & (!in_tim_min_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000101011101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(0),
	datab => in_tim_min_low(2),
	datac => in_tim_min_low(1),
	datad => in_tim_min_low(3),
	combout => \se6|seg[4]~2_combout\);

-- Location: LCCOMB_X54_Y31_N28
\tim_min_low~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_low~7_combout\ = (\se6|seg[4]~2_combout\) # ((\t1|toggle~q\ & \current_state.MT0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datac => \se6|seg[4]~2_combout\,
	datad => \current_state.MT0~q\,
	combout => \tim_min_low~7_combout\);

-- Location: LCCOMB_X47_Y31_N30
\tim_min_low~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_low~8_combout\ = (in_tim_min_low(0) & (!in_tim_min_low(2) & (in_tim_min_low(1) & !in_tim_min_low(3)))) # (!in_tim_min_low(0) & (in_tim_min_low(3) $ (((in_tim_min_low(1)) # (!in_tim_min_low(2))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010001110001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(0),
	datab => in_tim_min_low(2),
	datac => in_tim_min_low(1),
	datad => in_tim_min_low(3),
	combout => \tim_min_low~8_combout\);

-- Location: LCCOMB_X47_Y31_N12
\tim_min_low~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_low~9_combout\ = (\tim_min_low~8_combout\) # ((\t1|toggle~q\ & \current_state.MT0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \tim_min_low~8_combout\,
	datac => \t1|toggle~q\,
	datad => \current_state.MT0~q\,
	combout => \tim_min_low~9_combout\);

-- Location: LCCOMB_X47_Y31_N2
\se6|seg[6]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se6|seg[6]~3_combout\ = (in_tim_min_low(0) & ((in_tim_min_low(1)) # (in_tim_min_low(2) $ (in_tim_min_low(3))))) # (!in_tim_min_low(0) & ((in_tim_min_low(3)) # (in_tim_min_low(2) $ (in_tim_min_low(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011110111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_min_low(0),
	datab => in_tim_min_low(2),
	datac => in_tim_min_low(1),
	datad => in_tim_min_low(3),
	combout => \se6|seg[6]~3_combout\);

-- Location: LCCOMB_X54_Y31_N22
\tim_min_low~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_min_low~10_combout\ = ((\t1|toggle~q\ & \current_state.MT0~q\)) # (!\se6|seg[6]~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datac => \se6|seg[6]~3_combout\,
	datad => \current_state.MT0~q\,
	combout => \tim_min_low~10_combout\);

-- Location: LCCOMB_X48_Y31_N18
\tim_sec_high~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_high~0_combout\ = (in_tim_sec_high(2) & (!in_tim_sec_high(1) & (in_tim_sec_high(0) $ (in_tim_sec_high(3))))) # (!in_tim_sec_high(2) & ((in_tim_sec_high(1) & ((in_tim_sec_high(3)))) # (!in_tim_sec_high(1) & (!in_tim_sec_high(0) & 
-- !in_tim_sec_high(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100011000100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => in_tim_sec_high(1),
	datac => in_tim_sec_high(0),
	datad => in_tim_sec_high(3),
	combout => \tim_sec_high~0_combout\);

-- Location: LCCOMB_X56_Y32_N0
\tim_sec_high~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_high~1_combout\ = (\tim_sec_high~0_combout\) # ((\t1|toggle~q\ & \current_state.ST1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \tim_sec_high~0_combout\,
	datac => \t1|toggle~q\,
	datad => \current_state.ST1~q\,
	combout => \tim_sec_high~1_combout\);

-- Location: LCCOMB_X48_Y31_N10
\se7|seg[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se7|seg[1]~0_combout\ = (in_tim_sec_high(2) & (in_tim_sec_high(3) & ((in_tim_sec_high(1)) # (in_tim_sec_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => in_tim_sec_high(1),
	datac => in_tim_sec_high(0),
	datad => in_tim_sec_high(3),
	combout => \se7|seg[1]~0_combout\);

-- Location: LCCOMB_X53_Y31_N8
\tim_sec_high~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_high~2_combout\ = (in_tim_sec_high(2) & (!in_tim_sec_high(3) & (in_tim_sec_high(1) $ (!in_tim_sec_high(0))))) # (!in_tim_sec_high(2) & (in_tim_sec_high(3) & (in_tim_sec_high(1) & !in_tim_sec_high(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000001000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => in_tim_sec_high(3),
	datac => in_tim_sec_high(1),
	datad => in_tim_sec_high(0),
	combout => \tim_sec_high~2_combout\);

-- Location: LCCOMB_X54_Y31_N24
\tim_sec_high~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_high~3_combout\ = (\se7|seg[1]~0_combout\) # ((\tim_sec_high~2_combout\) # ((\t1|toggle~q\ & \current_state.ST1~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datab => \current_state.ST1~q\,
	datac => \se7|seg[1]~0_combout\,
	datad => \tim_sec_high~2_combout\,
	combout => \tim_sec_high~3_combout\);

-- Location: LCCOMB_X53_Y31_N2
\tim_sec_high~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_high~4_combout\ = (!in_tim_sec_high(2) & (!in_tim_sec_high(3) & (in_tim_sec_high(1) & in_tim_sec_high(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => in_tim_sec_high(3),
	datac => in_tim_sec_high(1),
	datad => in_tim_sec_high(0),
	combout => \tim_sec_high~4_combout\);

-- Location: LCCOMB_X54_Y31_N10
\tim_sec_high~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_high~5_combout\ = (\se7|seg[1]~0_combout\) # ((\tim_sec_high~4_combout\) # ((\t1|toggle~q\ & \current_state.ST1~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datab => \current_state.ST1~q\,
	datac => \se7|seg[1]~0_combout\,
	datad => \tim_sec_high~4_combout\,
	combout => \tim_sec_high~5_combout\);

-- Location: LCCOMB_X54_Y31_N12
\se7|seg[3]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se7|seg[3]~1_combout\ = (in_tim_sec_high(1) & ((in_tim_sec_high(0) & (in_tim_sec_high(3) & !in_tim_sec_high(2))) # (!in_tim_sec_high(0) & ((in_tim_sec_high(2)))))) # (!in_tim_sec_high(1) & (!in_tim_sec_high(3) & (in_tim_sec_high(0) $ 
-- (!in_tim_sec_high(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001101010000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(1),
	datab => in_tim_sec_high(3),
	datac => in_tim_sec_high(0),
	datad => in_tim_sec_high(2),
	combout => \se7|seg[3]~1_combout\);

-- Location: LCCOMB_X54_Y31_N30
\tim_sec_high~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_high~6_combout\ = (\se7|seg[3]~1_combout\) # ((\t1|toggle~q\ & \current_state.ST1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datab => \current_state.ST1~q\,
	datad => \se7|seg[3]~1_combout\,
	combout => \tim_sec_high~6_combout\);

-- Location: LCCOMB_X54_Y31_N0
\se7|seg[4]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se7|seg[4]~2_combout\ = (in_tim_sec_high(1) & (!in_tim_sec_high(3) & (!in_tim_sec_high(0)))) # (!in_tim_sec_high(1) & ((in_tim_sec_high(2) & (!in_tim_sec_high(3))) # (!in_tim_sec_high(2) & ((!in_tim_sec_high(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001001100000111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(1),
	datab => in_tim_sec_high(3),
	datac => in_tim_sec_high(0),
	datad => in_tim_sec_high(2),
	combout => \se7|seg[4]~2_combout\);

-- Location: LCCOMB_X54_Y31_N26
\tim_sec_high~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_high~7_combout\ = (\se7|seg[4]~2_combout\) # ((\t1|toggle~q\ & \current_state.ST1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datab => \se7|seg[4]~2_combout\,
	datad => \current_state.ST1~q\,
	combout => \tim_sec_high~7_combout\);

-- Location: LCCOMB_X53_Y31_N12
\tim_sec_high~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_high~8_combout\ = (in_tim_sec_high(2) & ((in_tim_sec_high(0)) # (in_tim_sec_high(3) $ (!in_tim_sec_high(1))))) # (!in_tim_sec_high(2) & ((in_tim_sec_high(3)) # ((!in_tim_sec_high(1) & in_tim_sec_high(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => in_tim_sec_high(3),
	datac => in_tim_sec_high(1),
	datad => in_tim_sec_high(0),
	combout => \tim_sec_high~8_combout\);

-- Location: LCCOMB_X54_Y31_N20
\tim_sec_high~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_high~9_combout\ = ((\t1|toggle~q\ & \current_state.ST1~q\)) # (!\tim_sec_high~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datab => \current_state.ST1~q\,
	datad => \tim_sec_high~8_combout\,
	combout => \tim_sec_high~9_combout\);

-- Location: LCCOMB_X48_Y31_N24
\se7|seg[6]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se7|seg[6]~3_combout\ = (in_tim_sec_high(0) & ((in_tim_sec_high(1)) # (in_tim_sec_high(2) $ (in_tim_sec_high(3))))) # (!in_tim_sec_high(0) & ((in_tim_sec_high(3)) # (in_tim_sec_high(2) $ (in_tim_sec_high(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101111111100110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_high(2),
	datab => in_tim_sec_high(1),
	datac => in_tim_sec_high(0),
	datad => in_tim_sec_high(3),
	combout => \se7|seg[6]~3_combout\);

-- Location: LCCOMB_X54_Y31_N6
\tim_sec_high~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_high~10_combout\ = ((\t1|toggle~q\ & \current_state.ST1~q\)) # (!\se7|seg[6]~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datac => \se7|seg[6]~3_combout\,
	datad => \current_state.ST1~q\,
	combout => \tim_sec_high~10_combout\);

-- Location: LCCOMB_X48_Y32_N22
\tim_sec_low~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_low~0_combout\ = (in_tim_sec_low(2) & (!in_tim_sec_low(1) & (in_tim_sec_low(0) $ (in_tim_sec_low(3))))) # (!in_tim_sec_low(2) & ((in_tim_sec_low(3) & ((in_tim_sec_low(1)))) # (!in_tim_sec_low(3) & (!in_tim_sec_low(0) & !in_tim_sec_low(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000001001001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(0),
	datab => in_tim_sec_low(2),
	datac => in_tim_sec_low(3),
	datad => in_tim_sec_low(1),
	combout => \tim_sec_low~0_combout\);

-- Location: LCCOMB_X56_Y32_N10
\tim_sec_low~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_low~1_combout\ = (\tim_sec_low~0_combout\) # ((\t1|toggle~q\ & \current_state.ST0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datac => \tim_sec_low~0_combout\,
	datad => \current_state.ST0~q\,
	combout => \tim_sec_low~1_combout\);

-- Location: LCCOMB_X49_Y32_N20
\tim_sec_low~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_low~2_combout\ = (in_tim_sec_low(3) & (in_tim_sec_low(1) & (!in_tim_sec_low(0) & !in_tim_sec_low(2)))) # (!in_tim_sec_low(3) & (in_tim_sec_low(2) & (in_tim_sec_low(1) $ (!in_tim_sec_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100100100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(1),
	datab => in_tim_sec_low(0),
	datac => in_tim_sec_low(3),
	datad => in_tim_sec_low(2),
	combout => \tim_sec_low~2_combout\);

-- Location: LCCOMB_X48_Y32_N20
\se8|seg[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \se8|seg[1]~0_combout\ = (in_tim_sec_low(2) & (in_tim_sec_low(3) & ((in_tim_sec_low(0)) # (in_tim_sec_low(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(0),
	datab => in_tim_sec_low(2),
	datac => in_tim_sec_low(3),
	datad => in_tim_sec_low(1),
	combout => \se8|seg[1]~0_combout\);

-- Location: LCCOMB_X56_Y32_N20
\tim_sec_low~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_low~3_combout\ = (\tim_sec_low~2_combout\) # ((\se8|seg[1]~0_combout\) # ((\t1|toggle~q\ & \current_state.ST0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datab => \tim_sec_low~2_combout\,
	datac => \se8|seg[1]~0_combout\,
	datad => \current_state.ST0~q\,
	combout => \tim_sec_low~3_combout\);

-- Location: LCCOMB_X48_Y32_N28
\tim_sec_low~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_low~4_combout\ = (in_tim_sec_low(0) & (!in_tim_sec_low(2) & (!in_tim_sec_low(3) & in_tim_sec_low(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(0),
	datab => in_tim_sec_low(2),
	datac => in_tim_sec_low(3),
	datad => in_tim_sec_low(1),
	combout => \tim_sec_low~4_combout\);

-- Location: LCCOMB_X56_Y32_N14
\tim_sec_low~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_low~5_combout\ = (\tim_sec_low~4_combout\) # ((\se8|seg[1]~0_combout\) # ((\t1|toggle~q\ & \current_state.ST0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datab => \tim_sec_low~4_combout\,
	datac => \se8|seg[1]~0_combout\,
	datad => \current_state.ST0~q\,
	combout => \tim_sec_low~5_combout\);

-- Location: LCCOMB_X48_Y32_N18
\se8|seg[3]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \se8|seg[3]~1_combout\ = (in_tim_sec_low(1) & ((in_tim_sec_low(0) & (!in_tim_sec_low(2) & in_tim_sec_low(3))) # (!in_tim_sec_low(0) & (in_tim_sec_low(2))))) # (!in_tim_sec_low(1) & (!in_tim_sec_low(3) & (in_tim_sec_low(0) $ (!in_tim_sec_low(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110010000001001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(0),
	datab => in_tim_sec_low(2),
	datac => in_tim_sec_low(3),
	datad => in_tim_sec_low(1),
	combout => \se8|seg[3]~1_combout\);

-- Location: LCCOMB_X56_Y32_N16
\tim_sec_low~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_low~6_combout\ = (\se8|seg[3]~1_combout\) # ((\t1|toggle~q\ & \current_state.ST0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \se8|seg[3]~1_combout\,
	datac => \t1|toggle~q\,
	datad => \current_state.ST0~q\,
	combout => \tim_sec_low~6_combout\);

-- Location: LCCOMB_X49_Y32_N24
\se8|seg[4]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \se8|seg[4]~2_combout\ = (in_tim_sec_low(1) & (!in_tim_sec_low(0) & (!in_tim_sec_low(3)))) # (!in_tim_sec_low(1) & ((in_tim_sec_low(2) & ((!in_tim_sec_low(3)))) # (!in_tim_sec_low(2) & (!in_tim_sec_low(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000011100010011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(1),
	datab => in_tim_sec_low(0),
	datac => in_tim_sec_low(3),
	datad => in_tim_sec_low(2),
	combout => \se8|seg[4]~2_combout\);

-- Location: LCCOMB_X56_Y32_N2
\tim_sec_low~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_low~7_combout\ = (\se8|seg[4]~2_combout\) # ((\t1|toggle~q\ & \current_state.ST0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \se8|seg[4]~2_combout\,
	datac => \t1|toggle~q\,
	datad => \current_state.ST0~q\,
	combout => \tim_sec_low~7_combout\);

-- Location: LCCOMB_X49_Y32_N6
\tim_sec_low~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_low~8_combout\ = (in_tim_sec_low(1) & (!in_tim_sec_low(3) & ((!in_tim_sec_low(2)) # (!in_tim_sec_low(0))))) # (!in_tim_sec_low(1) & (!in_tim_sec_low(0) & (in_tim_sec_low(3) $ (!in_tim_sec_low(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001001000001011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(1),
	datab => in_tim_sec_low(0),
	datac => in_tim_sec_low(3),
	datad => in_tim_sec_low(2),
	combout => \tim_sec_low~8_combout\);

-- Location: LCCOMB_X56_Y32_N12
\tim_sec_low~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_low~9_combout\ = (\tim_sec_low~8_combout\) # ((\t1|toggle~q\ & \current_state.ST0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \tim_sec_low~8_combout\,
	datac => \t1|toggle~q\,
	datad => \current_state.ST0~q\,
	combout => \tim_sec_low~9_combout\);

-- Location: LCCOMB_X48_Y32_N16
\se8|seg[6]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \se8|seg[6]~3_combout\ = (in_tim_sec_low(0) & ((in_tim_sec_low(1)) # (in_tim_sec_low(2) $ (in_tim_sec_low(3))))) # (!in_tim_sec_low(0) & ((in_tim_sec_low(3)) # (in_tim_sec_low(2) $ (in_tim_sec_low(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101101111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => in_tim_sec_low(0),
	datab => in_tim_sec_low(2),
	datac => in_tim_sec_low(3),
	datad => in_tim_sec_low(1),
	combout => \se8|seg[6]~3_combout\);

-- Location: LCCOMB_X56_Y32_N22
\tim_sec_low~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \tim_sec_low~10_combout\ = ((\t1|toggle~q\ & \current_state.ST0~q\)) # (!\se8|seg[6]~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \t1|toggle~q\,
	datac => \se8|seg[6]~3_combout\,
	datad => \current_state.ST0~q\,
	combout => \tim_sec_low~10_combout\);

ww_led1 <= \led1~output_o\;

ww_led2 <= \led2~output_o\;

ww_led3 <= \led3~output_o\;

ww_led4 <= \led4~output_o\;

ww_led5 <= \led5~output_o\;

ww_led6 <= \led6~output_o\;

ww_led7 <= \led7~output_o\;

ww_led8 <= \led8~output_o\;

ww_led9 <= \led9~output_o\;

ww_led10 <= \led10~output_o\;

ww_led_flash <= \led_flash~output_o\;

ww_min_high(0) <= \min_high[0]~output_o\;

ww_min_high(1) <= \min_high[1]~output_o\;

ww_min_high(2) <= \min_high[2]~output_o\;

ww_min_high(3) <= \min_high[3]~output_o\;

ww_min_high(4) <= \min_high[4]~output_o\;

ww_min_high(5) <= \min_high[5]~output_o\;

ww_min_high(6) <= \min_high[6]~output_o\;

ww_min_low(0) <= \min_low[0]~output_o\;

ww_min_low(1) <= \min_low[1]~output_o\;

ww_min_low(2) <= \min_low[2]~output_o\;

ww_min_low(3) <= \min_low[3]~output_o\;

ww_min_low(4) <= \min_low[4]~output_o\;

ww_min_low(5) <= \min_low[5]~output_o\;

ww_min_low(6) <= \min_low[6]~output_o\;

ww_sec_high(0) <= \sec_high[0]~output_o\;

ww_sec_high(1) <= \sec_high[1]~output_o\;

ww_sec_high(2) <= \sec_high[2]~output_o\;

ww_sec_high(3) <= \sec_high[3]~output_o\;

ww_sec_high(4) <= \sec_high[4]~output_o\;

ww_sec_high(5) <= \sec_high[5]~output_o\;

ww_sec_high(6) <= \sec_high[6]~output_o\;

ww_sec_low(0) <= \sec_low[0]~output_o\;

ww_sec_low(1) <= \sec_low[1]~output_o\;

ww_sec_low(2) <= \sec_low[2]~output_o\;

ww_sec_low(3) <= \sec_low[3]~output_o\;

ww_sec_low(4) <= \sec_low[4]~output_o\;

ww_sec_low(5) <= \sec_low[5]~output_o\;

ww_sec_low(6) <= \sec_low[6]~output_o\;

ww_tim_min_high(0) <= \tim_min_high[0]~output_o\;

ww_tim_min_high(1) <= \tim_min_high[1]~output_o\;

ww_tim_min_high(2) <= \tim_min_high[2]~output_o\;

ww_tim_min_high(3) <= \tim_min_high[3]~output_o\;

ww_tim_min_high(4) <= \tim_min_high[4]~output_o\;

ww_tim_min_high(5) <= \tim_min_high[5]~output_o\;

ww_tim_min_high(6) <= \tim_min_high[6]~output_o\;

ww_tim_min_low(0) <= \tim_min_low[0]~output_o\;

ww_tim_min_low(1) <= \tim_min_low[1]~output_o\;

ww_tim_min_low(2) <= \tim_min_low[2]~output_o\;

ww_tim_min_low(3) <= \tim_min_low[3]~output_o\;

ww_tim_min_low(4) <= \tim_min_low[4]~output_o\;

ww_tim_min_low(5) <= \tim_min_low[5]~output_o\;

ww_tim_min_low(6) <= \tim_min_low[6]~output_o\;

ww_tim_sec_high(0) <= \tim_sec_high[0]~output_o\;

ww_tim_sec_high(1) <= \tim_sec_high[1]~output_o\;

ww_tim_sec_high(2) <= \tim_sec_high[2]~output_o\;

ww_tim_sec_high(3) <= \tim_sec_high[3]~output_o\;

ww_tim_sec_high(4) <= \tim_sec_high[4]~output_o\;

ww_tim_sec_high(5) <= \tim_sec_high[5]~output_o\;

ww_tim_sec_high(6) <= \tim_sec_high[6]~output_o\;

ww_tim_sec_low(0) <= \tim_sec_low[0]~output_o\;

ww_tim_sec_low(1) <= \tim_sec_low[1]~output_o\;

ww_tim_sec_low(2) <= \tim_sec_low[2]~output_o\;

ww_tim_sec_low(3) <= \tim_sec_low[3]~output_o\;

ww_tim_sec_low(4) <= \tim_sec_low[4]~output_o\;

ww_tim_sec_low(5) <= \tim_sec_low[5]~output_o\;

ww_tim_sec_low(6) <= \tim_sec_low[6]~output_o\;
END structure;


