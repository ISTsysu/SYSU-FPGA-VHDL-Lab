library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;
entity freq_divider is
	generic(
		COUNT_MAX:natural);--声明一个COUNT_MAX，可以赋值、映射，是一个自然数
	port(
		clk_in:in std_logic;--输入的时钟信号
		clk_out:out std_logic);
end freq_divider;

architecture behav of freq_divider is
signal count:integer range 0 to COUNT_MAX-1;--限定count是整数类型，范围从0到COUNT_MAX-1
signal toggle:std_logic;--toggle是切换的意思
begin
	process(clk_in)
	begin
		if clk_in'event and clk_in='1' then
			if count=COUNT_MAX-1 then
				count<=0;
				toggle<='1' and not toggle;--这是相当于取反操作，每次执行togggle都进行取反
			else
				count<=count+1;
			end if;
		end if;
	end process;
	clk_out<=toggle;--把toggle作为输出，就是分频好之后的时钟
end behav;