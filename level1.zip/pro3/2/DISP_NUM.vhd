library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity DISP_NUM is
	port(clk:in std_logic;
			segdisp0:out std_logic_vector(6 downto 0);
			segdisp1:out std_logic_vector(6 downto 0);
			segdisp2:out std_logic_vector(6 downto 0);
			segdisp3:out std_logic_vector(6 downto 0);
			segdisp4:out std_logic_vector(6 downto 0);
			segdisp5:out std_logic_vector(6 downto 0);
			segdisp6:out std_logic_vector(6 downto 0);
			segdisp7:out std_logic_vector(6 downto 0));
end entity DISP_NUM;

architecture ex1 of DISP_NUM is
	signal disp:std_logic_vector(6 downto 0);
	signal num:integer range 0 to 15 := 0;
	signal counter:integer range 0 to 9999999 := 0;
	signal clk_di:std_logic;
begin
	process(clk)
	begin
		if rising_edge(clk) then
			if(counter = 9999999) then
				counter <= 0;
				clk_di <= not clk_di;
			else
				counter <= counter + 1;
			end if;
		end if;
	end process;
	
	process(clk_di)
	begin
		if rising_edge(clk_di) then
			if (num = 0) then
				disp <= "1000000";
				num <= num + 1;
			elsif (num = 1) then
				disp <= "1111001";
				num <= num + 1;
			elsif (num = 2) then
				disp <= "0100100";
				num <= num + 1;
			elsif (num = 3) then
				disp <= "0110000";
				num <= num + 1;
			elsif (num = 4) then
				disp <= "0011001";
				num <= num + 1;
			elsif (num = 5) then
				disp <= "0010010";
				num <= num + 1;
			elsif (num = 6) then
				disp <= "0000010";
				num <= num + 1;
			elsif (num = 7) then
				disp <= "1111000";
				num <= num + 1;
			elsif (num = 8) then
				disp <= "0000000";
				num <= num + 1;
			elsif (num = 9) then
				disp <= "0010000";
				num <= num + 1;
			elsif (num = 10) then
				disp <= "0001000";
				num <= num + 1;
			elsif (num = 11) then
				disp <= "0000011";
				num <= num + 1;
			elsif (num = 12) then
				disp <= "1000110";
				num <= num + 1;
			elsif (num = 13) then
				disp <= "0100001";
				num <= num + 1;
			elsif (num = 14) then
				disp <= "0000110";
				num <= num + 1;
			else
				disp <= "0001110";
				num <= 0;
			end if;
		end if;
	end process;
	segdisp0 <= disp;
	segdisp1 <= disp;
	segdisp2 <= disp;
	segdisp3 <= disp;
	segdisp4 <= disp;
	segdisp5 <= disp;
	segdisp6 <= disp;
	segdisp7 <= disp;
end architecture ex1;