library ieee;
use ieee.std_logic_1164.all;
--最高位为SW2，其次是sw1，0
entity DECODER_7seg is
	port(sw:in std_logic_vector(2 downto 0);
			segdisp0:out std_logic_vector(6 downto 0);
			segdisp1:out std_logic_vector(6 downto 0);
			segdisp2:out std_logic_vector(6 downto 0);
			segdisp3:out std_logic_vector(6 downto 0));
end entity DECODER_7seg;

architecture Behavioral of DECODER_7seg is
	signal QQ:std_logic_vector(2 downto 0);
	signal disp0, disp1, disp2, disp3:std_logic_vector(6 downto 0);
begin
	QQ <= sw;
	process(QQ)
	begin
		if((QQ = "000") or (QQ = "001") or (QQ = "010")) then
			disp0 <= "1000000";
			disp1 <= "1000111";
			disp2 <= "0000110";
			disp3 <= "0001001";
		else
			disp0 <= "0111111";
			disp1 <= "0111111";
			disp2 <= "0111111";
			disp3 <= "0111111";
		end if;
	end process;
	segdisp0 <= disp0;
	segdisp1 <= disp1;
	segdisp2 <= disp2;
	segdisp3 <= disp3;
end architecture Behavioral;