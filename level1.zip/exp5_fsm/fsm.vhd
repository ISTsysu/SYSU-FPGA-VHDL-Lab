library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_arith.all;
--clk_in为key0
--reset为sw0，低电平有效
--灯ledr8-0
--w为sw1
--z为LEDG0
--操作：
--sw0先低电平清0，再拉高，把sw1拨到1，按四下key0，最右边灯亮起
--sw0先低电平清0，再拉高，把sw1拨到0，按四下key0，最右边灯亮起
--完毕
entity fsm is
	port(
		clk_in,reset:in std_logic;
		w:in std_logic;
		z:out std_logic;
		led0:out std_logic;
		led1:out std_logic;
		led2:out std_logic;
		led3:out std_logic;
		led4:out std_logic;
		led5:out std_logic;
		led6:out std_logic;
		led7:out std_logic;
		led8:out std_logic
		);
end fsm;
architecture behav of fsm is
type STATES is (ss,s01,s02,s03,s04,s11,s12,s13,s14);
signal current_state,next_state:STATES;
signal clk:std_logic;
begin
	clk<=not clk_in;
	led0<='1' when current_state=ss else '0';
	led1<='1' when current_state=s01 else '0';
	led2<='1' when current_state=s02 else '0';
	led3<='1' when current_state=s03 else '0';
	led4<='1' when current_state=s04 else '0';
	led5<='1' when current_state=s11 else '0';
	led6<='1' when current_state=s12 else '0';
	led7<='1' when current_state=s13 else '0';
	led8<='1' when current_state=s14 else '0';
	process(current_state,w)
	begin
		case current_state is
			when ss=>
				if w='0' then
					next_state<=s01;
				elsif w='1' then
					next_state<=s11;
				else
					next_state<=ss;
				end if;
			when s01=>
				if w='0' then
					next_state<=s02;
				else
					next_state<=s11;
				end if;
			when s02=>
				if w='0' then
					next_state<=s03;
				else
					next_state<=s11;
				end if;
			when s03=>
				if w='0' then
					next_state<=s04;
				else
					next_state<=s11;
				end if;
			when s04=>
				if w='0' then
					next_state<=s04;
				else
					next_state<=s11;
				end if;
			when s11=>
				if w='1' then
					next_state<=s12;
				else
					next_state<=s01;
				end if;
			when s12=>
				if w='1' then
					next_state<=s13;
				else
					next_state<=s01;
				end if;
			when s13=>
				if w='1' then
					next_state<=s14;
				else
					next_state<=s01;
				end if;
			when s14=>
				if w='1' then
					next_state<=s14;
				else
					next_state<=s01;
				end if;
			when others=>null;
		end case;
	end process;
	
	process(clk,reset)
	begin
		if reset='0' then
			current_state<=ss;
		elsif clk'event and clk='1' then
			current_state<=next_state;
		end if;
	end process;
	
	z<='1' when current_state=s04 or current_state=s14 else '0';
end behav;