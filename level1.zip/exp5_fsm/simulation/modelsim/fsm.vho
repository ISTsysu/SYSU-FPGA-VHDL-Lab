-- Copyright (C) 1991-2015 Altera Corporation. All rights reserved.
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, the Altera Quartus II License Agreement,
-- the Altera MegaCore Function License Agreement, or other 
-- applicable license agreement, including, without limitation, 
-- that your use is for the sole purpose of programming logic 
-- devices manufactured by Altera and sold by Altera or its 
-- authorized distributors.  Please refer to the applicable 
-- agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 15.0.0 Build 145 04/22/2015 SJ Full Version"

-- DATE "12/16/2020 23:28:20"

-- 
-- Device: Altera EP4CE115F29C7 Package FBGA780
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIVE;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIVE.CYCLONEIVE_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	fsm IS
    PORT (
	clk_in : IN std_logic;
	reset : IN std_logic;
	w : IN std_logic;
	z : BUFFER std_logic;
	led0 : BUFFER std_logic;
	led1 : BUFFER std_logic;
	led2 : BUFFER std_logic;
	led3 : BUFFER std_logic;
	led4 : BUFFER std_logic;
	led5 : BUFFER std_logic;
	led6 : BUFFER std_logic;
	led7 : BUFFER std_logic;
	led8 : BUFFER std_logic
	);
END fsm;

-- Design Ports Information
-- z	=>  Location: PIN_E21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led0	=>  Location: PIN_G19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led1	=>  Location: PIN_F19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led2	=>  Location: PIN_E19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led3	=>  Location: PIN_F21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led4	=>  Location: PIN_F18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led5	=>  Location: PIN_E18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led6	=>  Location: PIN_J19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led7	=>  Location: PIN_H19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led8	=>  Location: PIN_J17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- w	=>  Location: PIN_AC28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk_in	=>  Location: PIN_M23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- reset	=>  Location: PIN_AB28,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF fsm IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk_in : std_logic;
SIGNAL ww_reset : std_logic;
SIGNAL ww_w : std_logic;
SIGNAL ww_z : std_logic;
SIGNAL ww_led0 : std_logic;
SIGNAL ww_led1 : std_logic;
SIGNAL ww_led2 : std_logic;
SIGNAL ww_led3 : std_logic;
SIGNAL ww_led4 : std_logic;
SIGNAL ww_led5 : std_logic;
SIGNAL ww_led6 : std_logic;
SIGNAL ww_led7 : std_logic;
SIGNAL ww_led8 : std_logic;
SIGNAL \z~output_o\ : std_logic;
SIGNAL \led0~output_o\ : std_logic;
SIGNAL \led1~output_o\ : std_logic;
SIGNAL \led2~output_o\ : std_logic;
SIGNAL \led3~output_o\ : std_logic;
SIGNAL \led4~output_o\ : std_logic;
SIGNAL \led5~output_o\ : std_logic;
SIGNAL \led6~output_o\ : std_logic;
SIGNAL \led7~output_o\ : std_logic;
SIGNAL \led8~output_o\ : std_logic;
SIGNAL \clk_in~input_o\ : std_logic;
SIGNAL \w~input_o\ : std_logic;
SIGNAL \Selector2~0_combout\ : std_logic;
SIGNAL \Selector2~1_combout\ : std_logic;
SIGNAL \reset~input_o\ : std_logic;
SIGNAL \current_state.s11~q\ : std_logic;
SIGNAL \next_state.s12~0_combout\ : std_logic;
SIGNAL \current_state.s12~q\ : std_logic;
SIGNAL \next_state.s13~0_combout\ : std_logic;
SIGNAL \current_state.s13~q\ : std_logic;
SIGNAL \next_state.s14~0_combout\ : std_logic;
SIGNAL \current_state.s14~q\ : std_logic;
SIGNAL \Selector0~0_combout\ : std_logic;
SIGNAL \Selector0~1_combout\ : std_logic;
SIGNAL \current_state.s01~q\ : std_logic;
SIGNAL \next_state.s02~0_combout\ : std_logic;
SIGNAL \current_state.s02~q\ : std_logic;
SIGNAL \next_state.s03~0_combout\ : std_logic;
SIGNAL \current_state.s03~q\ : std_logic;
SIGNAL \Selector1~0_combout\ : std_logic;
SIGNAL \current_state.s04~q\ : std_logic;
SIGNAL \z~0_combout\ : std_logic;
SIGNAL \current_state.ss~feeder_combout\ : std_logic;
SIGNAL \current_state.ss~q\ : std_logic;
SIGNAL \ALT_INV_clk_in~input_o\ : std_logic;
SIGNAL \ALT_INV_current_state.ss~q\ : std_logic;

BEGIN

ww_clk_in <= clk_in;
ww_reset <= reset;
ww_w <= w;
z <= ww_z;
led0 <= ww_led0;
led1 <= ww_led1;
led2 <= ww_led2;
led3 <= ww_led3;
led4 <= ww_led4;
led5 <= ww_led5;
led6 <= ww_led6;
led7 <= ww_led7;
led8 <= ww_led8;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
\ALT_INV_clk_in~input_o\ <= NOT \clk_in~input_o\;
\ALT_INV_current_state.ss~q\ <= NOT \current_state.ss~q\;

-- Location: IOOBUF_X107_Y73_N9
\z~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \z~0_combout\,
	devoe => ww_devoe,
	o => \z~output_o\);

-- Location: IOOBUF_X69_Y73_N16
\led0~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_current_state.ss~q\,
	devoe => ww_devoe,
	o => \led0~output_o\);

-- Location: IOOBUF_X94_Y73_N2
\led1~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.s01~q\,
	devoe => ww_devoe,
	o => \led1~output_o\);

-- Location: IOOBUF_X94_Y73_N9
\led2~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.s02~q\,
	devoe => ww_devoe,
	o => \led2~output_o\);

-- Location: IOOBUF_X107_Y73_N16
\led3~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.s03~q\,
	devoe => ww_devoe,
	o => \led3~output_o\);

-- Location: IOOBUF_X87_Y73_N16
\led4~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.s04~q\,
	devoe => ww_devoe,
	o => \led4~output_o\);

-- Location: IOOBUF_X87_Y73_N9
\led5~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.s11~q\,
	devoe => ww_devoe,
	o => \led5~output_o\);

-- Location: IOOBUF_X72_Y73_N9
\led6~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.s12~q\,
	devoe => ww_devoe,
	o => \led6~output_o\);

-- Location: IOOBUF_X72_Y73_N2
\led7~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.s13~q\,
	devoe => ww_devoe,
	o => \led7~output_o\);

-- Location: IOOBUF_X69_Y73_N2
\led8~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \current_state.s14~q\,
	devoe => ww_devoe,
	o => \led8~output_o\);

-- Location: IOIBUF_X115_Y40_N8
\clk_in~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk_in,
	o => \clk_in~input_o\);

-- Location: IOIBUF_X115_Y14_N1
\w~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_w,
	o => \w~input_o\);

-- Location: LCCOMB_X96_Y72_N16
\Selector2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector2~0_combout\ = (\w~input_o\ & (!\current_state.s11~q\ & (!\current_state.s14~q\ & !\current_state.s13~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \w~input_o\,
	datab => \current_state.s11~q\,
	datac => \current_state.s14~q\,
	datad => \current_state.s13~q\,
	combout => \Selector2~0_combout\);

-- Location: LCCOMB_X96_Y72_N4
\Selector2~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector2~1_combout\ = (!\current_state.s12~q\ & \Selector2~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \current_state.s12~q\,
	datad => \Selector2~0_combout\,
	combout => \Selector2~1_combout\);

-- Location: IOIBUF_X115_Y17_N1
\reset~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_reset,
	o => \reset~input_o\);

-- Location: FF_X96_Y72_N5
\current_state.s11\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk_in~input_o\,
	d => \Selector2~1_combout\,
	clrn => \reset~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.s11~q\);

-- Location: LCCOMB_X96_Y72_N22
\next_state.s12~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \next_state.s12~0_combout\ = (\w~input_o\ & \current_state.s11~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \w~input_o\,
	datad => \current_state.s11~q\,
	combout => \next_state.s12~0_combout\);

-- Location: FF_X96_Y72_N23
\current_state.s12\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk_in~input_o\,
	d => \next_state.s12~0_combout\,
	clrn => \reset~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.s12~q\);

-- Location: LCCOMB_X96_Y72_N12
\next_state.s13~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \next_state.s13~0_combout\ = (\w~input_o\ & \current_state.s12~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \w~input_o\,
	datac => \current_state.s12~q\,
	combout => \next_state.s13~0_combout\);

-- Location: FF_X96_Y72_N13
\current_state.s13\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk_in~input_o\,
	d => \next_state.s13~0_combout\,
	clrn => \reset~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.s13~q\);

-- Location: LCCOMB_X96_Y72_N14
\next_state.s14~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \next_state.s14~0_combout\ = (\w~input_o\ & ((\current_state.s14~q\) # (\current_state.s13~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \w~input_o\,
	datac => \current_state.s14~q\,
	datad => \current_state.s13~q\,
	combout => \next_state.s14~0_combout\);

-- Location: FF_X96_Y72_N15
\current_state.s14\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk_in~input_o\,
	d => \next_state.s14~0_combout\,
	clrn => \reset~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.s14~q\);

-- Location: LCCOMB_X96_Y72_N6
\Selector0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~0_combout\ = (\current_state.s01~q\) # ((\w~input_o\) # ((\current_state.s04~q\) # (\current_state.s03~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.s01~q\,
	datab => \w~input_o\,
	datac => \current_state.s04~q\,
	datad => \current_state.s03~q\,
	combout => \Selector0~0_combout\);

-- Location: LCCOMB_X96_Y72_N26
\Selector0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector0~1_combout\ = (!\current_state.s02~q\ & !\Selector0~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \current_state.s02~q\,
	datad => \Selector0~0_combout\,
	combout => \Selector0~1_combout\);

-- Location: FF_X96_Y72_N27
\current_state.s01\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk_in~input_o\,
	d => \Selector0~1_combout\,
	clrn => \reset~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.s01~q\);

-- Location: LCCOMB_X96_Y72_N20
\next_state.s02~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \next_state.s02~0_combout\ = (!\w~input_o\ & \current_state.s01~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \w~input_o\,
	datad => \current_state.s01~q\,
	combout => \next_state.s02~0_combout\);

-- Location: FF_X96_Y72_N21
\current_state.s02\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk_in~input_o\,
	d => \next_state.s02~0_combout\,
	clrn => \reset~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.s02~q\);

-- Location: LCCOMB_X96_Y72_N10
\next_state.s03~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \next_state.s03~0_combout\ = (!\w~input_o\ & \current_state.s02~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \w~input_o\,
	datac => \current_state.s02~q\,
	combout => \next_state.s03~0_combout\);

-- Location: FF_X96_Y72_N11
\current_state.s03\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk_in~input_o\,
	d => \next_state.s03~0_combout\,
	clrn => \reset~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.s03~q\);

-- Location: LCCOMB_X96_Y72_N8
\Selector1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Selector1~0_combout\ = (!\w~input_o\ & ((\current_state.s04~q\) # (\current_state.s03~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \w~input_o\,
	datac => \current_state.s04~q\,
	datad => \current_state.s03~q\,
	combout => \Selector1~0_combout\);

-- Location: FF_X96_Y72_N9
\current_state.s04\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk_in~input_o\,
	d => \Selector1~0_combout\,
	clrn => \reset~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.s04~q\);

-- Location: LCCOMB_X96_Y72_N28
\z~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \z~0_combout\ = (\current_state.s14~q\) # (\current_state.s04~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \current_state.s14~q\,
	datad => \current_state.s04~q\,
	combout => \z~0_combout\);

-- Location: LCCOMB_X114_Y40_N16
\current_state.ss~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \current_state.ss~feeder_combout\ = VCC

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \current_state.ss~feeder_combout\);

-- Location: FF_X114_Y40_N17
\current_state.ss\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \ALT_INV_clk_in~input_o\,
	d => \current_state.ss~feeder_combout\,
	clrn => \reset~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \current_state.ss~q\);

ww_z <= \z~output_o\;

ww_led0 <= \led0~output_o\;

ww_led1 <= \led1~output_o\;

ww_led2 <= \led2~output_o\;

ww_led3 <= \led3~output_o\;

ww_led4 <= \led4~output_o\;

ww_led5 <= \led5~output_o\;

ww_led6 <= \led6~output_o\;

ww_led7 <= \led7~output_o\;

ww_led8 <= \led8~output_o\;
END structure;


