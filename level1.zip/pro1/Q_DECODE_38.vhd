LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.NUMERIC_STD.ALL;
--G1,G2A,G2B分别是SW15,14,13;ABC分别SW0,1,2

ENTITY Q_DECODE_38 IS
PORT (
    A, B, C, G1, G2A, G2B : IN  STD_LOGIC;
    Y                      : OUT STD_LOGIC_VECTOR(7 DOWNTO 0)
);
END Q_DECODE_38;

ARCHITECTURE Behavioral OF Q_DECODE_38 IS
    SIGNAL indata : STD_LOGIC_VECTOR(2 DOWNTO 0);
BEGIN
    indata <= C & B & A;
    
    PROCESS(indata, G1, G2A, G2B)
    BEGIN
        IF (G1 = '1' AND G2A = '0' AND G2B = '0') THEN
            CASE indata IS
                WHEN "000"  => Y <= "11111110";
                WHEN "001"  => Y <= "11111101";
                WHEN "010"  => Y <= "11110111";
                WHEN "011"  => Y <= "11101111";
                WHEN "100"  => Y <= "11011111";
                WHEN "101"  => Y <= "10111111";
                WHEN "110"  => Y <= "01111111";
                WHEN "111"  => Y <= "11111111";
                WHEN OTHERS => Y <= "XXXXXXXX";
            END CASE;
        ELSE
            Y <= "11111111";
        END IF;
    END PROCESS;
END Behavioral;