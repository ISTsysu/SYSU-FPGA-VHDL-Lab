-- Copyright (C) 2023  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details, at
-- https://fpgasoftware.intel.com/eula.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 23.1std.0 Build 991 11/28/2023 SC Lite Edition"

-- DATE "05/29/2024 16:55:13"

-- 
-- Device: Altera EP4CE115F29C7 Package FBGA780
-- 

-- 
-- This VHDL file should be used for Questa Intel FPGA (VHDL) only
-- 

LIBRARY CYCLONEIVE;
LIBRARY IEEE;
USE CYCLONEIVE.CYCLONEIVE_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	hard_block IS
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic
	);
END hard_block;

-- Design Ports Information
-- ~ALTERA_ASDO_DATA1~	=>  Location: PIN_F4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_FLASH_nCE_nCSO~	=>  Location: PIN_E2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_DCLK~	=>  Location: PIN_P3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_DATA0~	=>  Location: PIN_N7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_nCEO~	=>  Location: PIN_P28,	 I/O Standard: 2.5 V,	 Current Strength: 8mA


ARCHITECTURE structure OF hard_block IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL \~ALTERA_ASDO_DATA1~~padout\ : std_logic;
SIGNAL \~ALTERA_FLASH_nCE_nCSO~~padout\ : std_logic;
SIGNAL \~ALTERA_DATA0~~padout\ : std_logic;
SIGNAL \~ALTERA_ASDO_DATA1~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_FLASH_nCE_nCSO~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_DATA0~~ibuf_o\ : std_logic;

BEGIN

ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
END structure;


LIBRARY ALTERA;
LIBRARY CYCLONEIVE;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIVE.CYCLONEIVE_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	top IS
    PORT (
	keyboard_clk : IN std_logic;
	keyboard_data : IN std_logic;
	clock_25Mhz : IN std_logic;
	reset : IN std_logic;
	read : IN std_logic;
	display02 : OUT std_logic_vector(6 DOWNTO 0);
	display01 : OUT std_logic_vector(6 DOWNTO 0)
	);
END top;

-- Design Ports Information
-- read	=>  Location: PIN_Y24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- display02[0]	=>  Location: PIN_AD17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- display02[1]	=>  Location: PIN_AE17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- display02[2]	=>  Location: PIN_AG17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- display02[3]	=>  Location: PIN_AH17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- display02[4]	=>  Location: PIN_AF17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- display02[5]	=>  Location: PIN_AG18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- display02[6]	=>  Location: PIN_AA14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- display01[0]	=>  Location: PIN_AA17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- display01[1]	=>  Location: PIN_AB16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- display01[2]	=>  Location: PIN_AA16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- display01[3]	=>  Location: PIN_AB17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- display01[4]	=>  Location: PIN_AB15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- display01[5]	=>  Location: PIN_AA15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- display01[6]	=>  Location: PIN_AC17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- reset	=>  Location: PIN_Y23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clock_25Mhz	=>  Location: PIN_AG14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- keyboard_data	=>  Location: PIN_H5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- keyboard_clk	=>  Location: PIN_G6,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF top IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_keyboard_clk : std_logic;
SIGNAL ww_keyboard_data : std_logic;
SIGNAL ww_clock_25Mhz : std_logic;
SIGNAL ww_reset : std_logic;
SIGNAL ww_read : std_logic;
SIGNAL ww_display02 : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_display01 : std_logic_vector(6 DOWNTO 0);
SIGNAL \KEY_BOARD|keyboard_clk_filtered~clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \clock_25Mhz~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \read~input_o\ : std_logic;
SIGNAL \display02[0]~output_o\ : std_logic;
SIGNAL \display02[1]~output_o\ : std_logic;
SIGNAL \display02[2]~output_o\ : std_logic;
SIGNAL \display02[3]~output_o\ : std_logic;
SIGNAL \display02[4]~output_o\ : std_logic;
SIGNAL \display02[5]~output_o\ : std_logic;
SIGNAL \display02[6]~output_o\ : std_logic;
SIGNAL \display01[0]~output_o\ : std_logic;
SIGNAL \display01[1]~output_o\ : std_logic;
SIGNAL \display01[2]~output_o\ : std_logic;
SIGNAL \display01[3]~output_o\ : std_logic;
SIGNAL \display01[4]~output_o\ : std_logic;
SIGNAL \display01[5]~output_o\ : std_logic;
SIGNAL \display01[6]~output_o\ : std_logic;
SIGNAL \clock_25Mhz~input_o\ : std_logic;
SIGNAL \clock_25Mhz~inputclkctrl_outclk\ : std_logic;
SIGNAL \keyboard_clk~input_o\ : std_logic;
SIGNAL \KEY_BOARD|filter[7]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|filter[6]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|filter[5]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|filter[4]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|filter[3]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|filter[2]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|keyboard_clk_filtered~1_combout\ : std_logic;
SIGNAL \KEY_BOARD|filter[1]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|keyboard_clk_filtered~2_combout\ : std_logic;
SIGNAL \KEY_BOARD|keyboard_clk_filtered~0_combout\ : std_logic;
SIGNAL \KEY_BOARD|keyboard_clk_filtered~3_combout\ : std_logic;
SIGNAL \KEY_BOARD|keyboard_clk_filtered~q\ : std_logic;
SIGNAL \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\ : std_logic;
SIGNAL \keyboard_data~input_o\ : std_logic;
SIGNAL \reset~input_o\ : std_logic;
SIGNAL \KEY_BOARD|INCNT~0_combout\ : std_logic;
SIGNAL \KEY_BOARD|INCNT[3]~1_combout\ : std_logic;
SIGNAL \KEY_BOARD|INCNT~2_combout\ : std_logic;
SIGNAL \KEY_BOARD|Add0~0_combout\ : std_logic;
SIGNAL \KEY_BOARD|INCNT~3_combout\ : std_logic;
SIGNAL \KEY_BOARD|Add0~1_combout\ : std_logic;
SIGNAL \KEY_BOARD|INCNT~4_combout\ : std_logic;
SIGNAL \KEY_BOARD|LessThan0~0_combout\ : std_logic;
SIGNAL \KEY_BOARD|READ_CHAR~0_combout\ : std_logic;
SIGNAL \KEY_BOARD|READ_CHAR~q\ : std_logic;
SIGNAL \KEY_BOARD|SHIFTIN[7]~0_combout\ : std_logic;
SIGNAL \KEY_BOARD|SHIFTIN[7]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|SHIFTIN[6]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|SHIFTIN[5]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|scan_code[7]~0_combout\ : std_logic;
SIGNAL \KEY_BOARD|scan_code[6]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|scan_code[7]~feeder_combout\ : std_logic;
SIGNAL \Mux13~0_combout\ : std_logic;
SIGNAL \Mux12~0_combout\ : std_logic;
SIGNAL \Mux11~0_combout\ : std_logic;
SIGNAL \Mux10~0_combout\ : std_logic;
SIGNAL \Mux9~0_combout\ : std_logic;
SIGNAL \Mux8~0_combout\ : std_logic;
SIGNAL \Mux7~0_combout\ : std_logic;
SIGNAL \KEY_BOARD|SHIFTIN[3]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|SHIFTIN[2]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|scan_code[2]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|SHIFTIN[1]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|scan_code[3]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|SHIFTIN[0]~feeder_combout\ : std_logic;
SIGNAL \KEY_BOARD|scan_code[0]~feeder_combout\ : std_logic;
SIGNAL \Mux6~0_combout\ : std_logic;
SIGNAL \Mux5~0_combout\ : std_logic;
SIGNAL \Mux4~0_combout\ : std_logic;
SIGNAL \Mux3~0_combout\ : std_logic;
SIGNAL \Mux2~0_combout\ : std_logic;
SIGNAL \Mux1~0_combout\ : std_logic;
SIGNAL \Mux0~0_combout\ : std_logic;
SIGNAL \KEY_BOARD|scan_code\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \KEY_BOARD|SHIFTIN\ : std_logic_vector(8 DOWNTO 0);
SIGNAL \KEY_BOARD|INCNT\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \KEY_BOARD|filter\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \ALT_INV_Mux0~0_combout\ : std_logic;
SIGNAL \ALT_INV_Mux7~0_combout\ : std_logic;

COMPONENT hard_block
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic);
END COMPONENT;

BEGIN

ww_keyboard_clk <= keyboard_clk;
ww_keyboard_data <= keyboard_data;
ww_clock_25Mhz <= clock_25Mhz;
ww_reset <= reset;
ww_read <= read;
display02 <= ww_display02;
display01 <= ww_display01;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\KEY_BOARD|keyboard_clk_filtered~clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \KEY_BOARD|keyboard_clk_filtered~q\);

\clock_25Mhz~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clock_25Mhz~input_o\);
\ALT_INV_Mux0~0_combout\ <= NOT \Mux0~0_combout\;
\ALT_INV_Mux7~0_combout\ <= NOT \Mux7~0_combout\;
auto_generated_inst : hard_block
PORT MAP (
	devoe => ww_devoe,
	devclrn => ww_devclrn,
	devpor => ww_devpor);

-- Location: IOOBUF_X74_Y0_N16
\display02[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux13~0_combout\,
	devoe => ww_devoe,
	o => \display02[0]~output_o\);

-- Location: IOOBUF_X67_Y0_N9
\display02[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux12~0_combout\,
	devoe => ww_devoe,
	o => \display02[1]~output_o\);

-- Location: IOOBUF_X62_Y0_N23
\display02[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux11~0_combout\,
	devoe => ww_devoe,
	o => \display02[2]~output_o\);

-- Location: IOOBUF_X62_Y0_N16
\display02[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux10~0_combout\,
	devoe => ww_devoe,
	o => \display02[3]~output_o\);

-- Location: IOOBUF_X67_Y0_N2
\display02[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux9~0_combout\,
	devoe => ww_devoe,
	o => \display02[4]~output_o\);

-- Location: IOOBUF_X69_Y0_N9
\display02[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux8~0_combout\,
	devoe => ww_devoe,
	o => \display02[5]~output_o\);

-- Location: IOOBUF_X54_Y0_N23
\display02[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_Mux7~0_combout\,
	devoe => ww_devoe,
	o => \display02[6]~output_o\);

-- Location: IOOBUF_X89_Y0_N23
\display01[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux6~0_combout\,
	devoe => ww_devoe,
	o => \display01[0]~output_o\);

-- Location: IOOBUF_X65_Y0_N2
\display01[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux5~0_combout\,
	devoe => ww_devoe,
	o => \display01[1]~output_o\);

-- Location: IOOBUF_X65_Y0_N9
\display01[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux4~0_combout\,
	devoe => ww_devoe,
	o => \display01[2]~output_o\);

-- Location: IOOBUF_X89_Y0_N16
\display01[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux3~0_combout\,
	devoe => ww_devoe,
	o => \display01[3]~output_o\);

-- Location: IOOBUF_X67_Y0_N16
\display01[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux2~0_combout\,
	devoe => ww_devoe,
	o => \display01[4]~output_o\);

-- Location: IOOBUF_X67_Y0_N23
\display01[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \Mux1~0_combout\,
	devoe => ww_devoe,
	o => \display01[5]~output_o\);

-- Location: IOOBUF_X74_Y0_N23
\display01[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \ALT_INV_Mux0~0_combout\,
	devoe => ww_devoe,
	o => \display01[6]~output_o\);

-- Location: IOIBUF_X58_Y0_N22
\clock_25Mhz~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clock_25Mhz,
	o => \clock_25Mhz~input_o\);

-- Location: CLKCTRL_G18
\clock_25Mhz~inputclkctrl\ : cycloneive_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clock_25Mhz~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clock_25Mhz~inputclkctrl_outclk\);

-- Location: IOIBUF_X0_Y67_N15
\keyboard_clk~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_keyboard_clk,
	o => \keyboard_clk~input_o\);

-- Location: LCCOMB_X1_Y36_N0
\KEY_BOARD|filter[7]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|filter[7]~feeder_combout\ = \keyboard_clk~input_o\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \keyboard_clk~input_o\,
	combout => \KEY_BOARD|filter[7]~feeder_combout\);

-- Location: FF_X1_Y36_N1
\KEY_BOARD|filter[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_25Mhz~inputclkctrl_outclk\,
	d => \KEY_BOARD|filter[7]~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|filter\(7));

-- Location: LCCOMB_X1_Y36_N16
\KEY_BOARD|filter[6]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|filter[6]~feeder_combout\ = \KEY_BOARD|filter\(7)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \KEY_BOARD|filter\(7),
	combout => \KEY_BOARD|filter[6]~feeder_combout\);

-- Location: FF_X1_Y36_N17
\KEY_BOARD|filter[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_25Mhz~inputclkctrl_outclk\,
	d => \KEY_BOARD|filter[6]~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|filter\(6));

-- Location: LCCOMB_X1_Y36_N22
\KEY_BOARD|filter[5]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|filter[5]~feeder_combout\ = \KEY_BOARD|filter\(6)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \KEY_BOARD|filter\(6),
	combout => \KEY_BOARD|filter[5]~feeder_combout\);

-- Location: FF_X1_Y36_N23
\KEY_BOARD|filter[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_25Mhz~inputclkctrl_outclk\,
	d => \KEY_BOARD|filter[5]~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|filter\(5));

-- Location: LCCOMB_X1_Y36_N26
\KEY_BOARD|filter[4]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|filter[4]~feeder_combout\ = \KEY_BOARD|filter\(5)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \KEY_BOARD|filter\(5),
	combout => \KEY_BOARD|filter[4]~feeder_combout\);

-- Location: FF_X1_Y36_N27
\KEY_BOARD|filter[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_25Mhz~inputclkctrl_outclk\,
	d => \KEY_BOARD|filter[4]~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|filter\(4));

-- Location: LCCOMB_X1_Y36_N20
\KEY_BOARD|filter[3]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|filter[3]~feeder_combout\ = \KEY_BOARD|filter\(4)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \KEY_BOARD|filter\(4),
	combout => \KEY_BOARD|filter[3]~feeder_combout\);

-- Location: FF_X1_Y36_N21
\KEY_BOARD|filter[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_25Mhz~inputclkctrl_outclk\,
	d => \KEY_BOARD|filter[3]~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|filter\(3));

-- Location: LCCOMB_X1_Y36_N24
\KEY_BOARD|filter[2]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|filter[2]~feeder_combout\ = \KEY_BOARD|filter\(3)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \KEY_BOARD|filter\(3),
	combout => \KEY_BOARD|filter[2]~feeder_combout\);

-- Location: FF_X1_Y36_N25
\KEY_BOARD|filter[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_25Mhz~inputclkctrl_outclk\,
	d => \KEY_BOARD|filter[2]~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|filter\(2));

-- Location: LCCOMB_X1_Y36_N8
\KEY_BOARD|keyboard_clk_filtered~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|keyboard_clk_filtered~1_combout\ = (\KEY_BOARD|keyboard_clk_filtered~q\ & ((\KEY_BOARD|filter\(3)) # ((\KEY_BOARD|filter\(5)) # (\KEY_BOARD|filter\(2))))) # (!\KEY_BOARD|keyboard_clk_filtered~q\ & (\KEY_BOARD|filter\(3) & (\KEY_BOARD|filter\(5) 
-- & \KEY_BOARD|filter\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|keyboard_clk_filtered~q\,
	datab => \KEY_BOARD|filter\(3),
	datac => \KEY_BOARD|filter\(5),
	datad => \KEY_BOARD|filter\(2),
	combout => \KEY_BOARD|keyboard_clk_filtered~1_combout\);

-- Location: LCCOMB_X1_Y36_N28
\KEY_BOARD|filter[1]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|filter[1]~feeder_combout\ = \KEY_BOARD|filter\(2)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \KEY_BOARD|filter\(2),
	combout => \KEY_BOARD|filter[1]~feeder_combout\);

-- Location: FF_X1_Y36_N29
\KEY_BOARD|filter[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_25Mhz~inputclkctrl_outclk\,
	d => \KEY_BOARD|filter[1]~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|filter\(1));

-- Location: FF_X1_Y36_N7
\KEY_BOARD|filter[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_25Mhz~inputclkctrl_outclk\,
	asdata => \KEY_BOARD|filter\(1),
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|filter\(0));

-- Location: LCCOMB_X1_Y36_N6
\KEY_BOARD|keyboard_clk_filtered~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|keyboard_clk_filtered~2_combout\ = (\KEY_BOARD|keyboard_clk_filtered~q\ & ((\KEY_BOARD|filter\(1)) # ((\KEY_BOARD|filter\(0)) # (\KEY_BOARD|filter\(6))))) # (!\KEY_BOARD|keyboard_clk_filtered~q\ & (\KEY_BOARD|filter\(1) & (\KEY_BOARD|filter\(0) 
-- & \KEY_BOARD|filter\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|keyboard_clk_filtered~q\,
	datab => \KEY_BOARD|filter\(1),
	datac => \KEY_BOARD|filter\(0),
	datad => \KEY_BOARD|filter\(6),
	combout => \KEY_BOARD|keyboard_clk_filtered~2_combout\);

-- Location: LCCOMB_X1_Y36_N18
\KEY_BOARD|keyboard_clk_filtered~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|keyboard_clk_filtered~0_combout\ = (\KEY_BOARD|filter\(7) & ((\KEY_BOARD|filter\(4)) # (!\KEY_BOARD|filter\(2)))) # (!\KEY_BOARD|filter\(7) & (\KEY_BOARD|filter\(4) & !\KEY_BOARD|filter\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \KEY_BOARD|filter\(7),
	datac => \KEY_BOARD|filter\(4),
	datad => \KEY_BOARD|filter\(2),
	combout => \KEY_BOARD|keyboard_clk_filtered~0_combout\);

-- Location: LCCOMB_X1_Y36_N10
\KEY_BOARD|keyboard_clk_filtered~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|keyboard_clk_filtered~3_combout\ = (\KEY_BOARD|keyboard_clk_filtered~q\ & ((\KEY_BOARD|keyboard_clk_filtered~1_combout\) # ((\KEY_BOARD|keyboard_clk_filtered~2_combout\) # (\KEY_BOARD|keyboard_clk_filtered~0_combout\)))) # 
-- (!\KEY_BOARD|keyboard_clk_filtered~q\ & (\KEY_BOARD|keyboard_clk_filtered~1_combout\ & (\KEY_BOARD|keyboard_clk_filtered~2_combout\ & \KEY_BOARD|keyboard_clk_filtered~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|keyboard_clk_filtered~q\,
	datab => \KEY_BOARD|keyboard_clk_filtered~1_combout\,
	datac => \KEY_BOARD|keyboard_clk_filtered~2_combout\,
	datad => \KEY_BOARD|keyboard_clk_filtered~0_combout\,
	combout => \KEY_BOARD|keyboard_clk_filtered~3_combout\);

-- Location: FF_X1_Y36_N31
\KEY_BOARD|keyboard_clk_filtered\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_25Mhz~inputclkctrl_outclk\,
	asdata => \KEY_BOARD|keyboard_clk_filtered~3_combout\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|keyboard_clk_filtered~q\);

-- Location: CLKCTRL_G4
\KEY_BOARD|keyboard_clk_filtered~clkctrl\ : cycloneive_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\);

-- Location: IOIBUF_X0_Y59_N22
\keyboard_data~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_keyboard_data,
	o => \keyboard_data~input_o\);

-- Location: IOIBUF_X115_Y14_N8
\reset~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_reset,
	o => \reset~input_o\);

-- Location: LCCOMB_X55_Y49_N4
\KEY_BOARD|INCNT~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|INCNT~0_combout\ = (!\reset~input_o\ & (!\KEY_BOARD|INCNT\(0) & \KEY_BOARD|LessThan0~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reset~input_o\,
	datac => \KEY_BOARD|INCNT\(0),
	datad => \KEY_BOARD|LessThan0~0_combout\,
	combout => \KEY_BOARD|INCNT~0_combout\);

-- Location: LCCOMB_X55_Y49_N14
\KEY_BOARD|INCNT[3]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|INCNT[3]~1_combout\ = (\reset~input_o\) # (\KEY_BOARD|READ_CHAR~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reset~input_o\,
	datad => \KEY_BOARD|READ_CHAR~q\,
	combout => \KEY_BOARD|INCNT[3]~1_combout\);

-- Location: FF_X55_Y49_N5
\KEY_BOARD|INCNT[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|INCNT~0_combout\,
	ena => \KEY_BOARD|INCNT[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|INCNT\(0));

-- Location: LCCOMB_X55_Y49_N22
\KEY_BOARD|INCNT~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|INCNT~2_combout\ = (!\reset~input_o\ & (\KEY_BOARD|LessThan0~0_combout\ & (\KEY_BOARD|INCNT\(1) $ (\KEY_BOARD|INCNT\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reset~input_o\,
	datab => \KEY_BOARD|LessThan0~0_combout\,
	datac => \KEY_BOARD|INCNT\(1),
	datad => \KEY_BOARD|INCNT\(0),
	combout => \KEY_BOARD|INCNT~2_combout\);

-- Location: FF_X55_Y49_N23
\KEY_BOARD|INCNT[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|INCNT~2_combout\,
	ena => \KEY_BOARD|INCNT[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|INCNT\(1));

-- Location: LCCOMB_X55_Y49_N30
\KEY_BOARD|Add0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|Add0~0_combout\ = \KEY_BOARD|INCNT\(2) $ (((\KEY_BOARD|INCNT\(1) & \KEY_BOARD|INCNT\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|INCNT\(2),
	datab => \KEY_BOARD|INCNT\(1),
	datad => \KEY_BOARD|INCNT\(0),
	combout => \KEY_BOARD|Add0~0_combout\);

-- Location: LCCOMB_X55_Y49_N8
\KEY_BOARD|INCNT~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|INCNT~3_combout\ = (!\reset~input_o\ & (\KEY_BOARD|Add0~0_combout\ & \KEY_BOARD|LessThan0~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reset~input_o\,
	datac => \KEY_BOARD|Add0~0_combout\,
	datad => \KEY_BOARD|LessThan0~0_combout\,
	combout => \KEY_BOARD|INCNT~3_combout\);

-- Location: FF_X55_Y49_N9
\KEY_BOARD|INCNT[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|INCNT~3_combout\,
	ena => \KEY_BOARD|INCNT[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|INCNT\(2));

-- Location: LCCOMB_X55_Y49_N10
\KEY_BOARD|Add0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|Add0~1_combout\ = \KEY_BOARD|INCNT\(3) $ (((\KEY_BOARD|INCNT\(2) & (\KEY_BOARD|INCNT\(1) & \KEY_BOARD|INCNT\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|INCNT\(2),
	datab => \KEY_BOARD|INCNT\(3),
	datac => \KEY_BOARD|INCNT\(1),
	datad => \KEY_BOARD|INCNT\(0),
	combout => \KEY_BOARD|Add0~1_combout\);

-- Location: LCCOMB_X55_Y49_N6
\KEY_BOARD|INCNT~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|INCNT~4_combout\ = (!\reset~input_o\ & (\KEY_BOARD|LessThan0~0_combout\ & \KEY_BOARD|Add0~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reset~input_o\,
	datab => \KEY_BOARD|LessThan0~0_combout\,
	datad => \KEY_BOARD|Add0~1_combout\,
	combout => \KEY_BOARD|INCNT~4_combout\);

-- Location: FF_X55_Y49_N7
\KEY_BOARD|INCNT[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|INCNT~4_combout\,
	ena => \KEY_BOARD|INCNT[3]~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|INCNT\(3));

-- Location: LCCOMB_X55_Y49_N24
\KEY_BOARD|LessThan0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|LessThan0~0_combout\ = ((!\KEY_BOARD|INCNT\(1) & (!\KEY_BOARD|INCNT\(0) & !\KEY_BOARD|INCNT\(2)))) # (!\KEY_BOARD|INCNT\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|INCNT\(1),
	datab => \KEY_BOARD|INCNT\(0),
	datac => \KEY_BOARD|INCNT\(2),
	datad => \KEY_BOARD|INCNT\(3),
	combout => \KEY_BOARD|LessThan0~0_combout\);

-- Location: LCCOMB_X54_Y49_N18
\KEY_BOARD|READ_CHAR~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|READ_CHAR~0_combout\ = (!\reset~input_o\ & ((\KEY_BOARD|READ_CHAR~q\ & ((\KEY_BOARD|LessThan0~0_combout\))) # (!\KEY_BOARD|READ_CHAR~q\ & (!\keyboard_data~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \keyboard_data~input_o\,
	datab => \KEY_BOARD|LessThan0~0_combout\,
	datac => \KEY_BOARD|READ_CHAR~q\,
	datad => \reset~input_o\,
	combout => \KEY_BOARD|READ_CHAR~0_combout\);

-- Location: FF_X54_Y49_N19
\KEY_BOARD|READ_CHAR\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|READ_CHAR~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|READ_CHAR~q\);

-- Location: LCCOMB_X54_Y49_N20
\KEY_BOARD|SHIFTIN[7]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|SHIFTIN[7]~0_combout\ = (!\reset~input_o\ & (\KEY_BOARD|READ_CHAR~q\ & \KEY_BOARD|LessThan0~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reset~input_o\,
	datab => \KEY_BOARD|READ_CHAR~q\,
	datad => \KEY_BOARD|LessThan0~0_combout\,
	combout => \KEY_BOARD|SHIFTIN[7]~0_combout\);

-- Location: FF_X54_Y49_N31
\KEY_BOARD|SHIFTIN[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	asdata => \keyboard_data~input_o\,
	sload => VCC,
	ena => \KEY_BOARD|SHIFTIN[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|SHIFTIN\(8));

-- Location: LCCOMB_X54_Y49_N24
\KEY_BOARD|SHIFTIN[7]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|SHIFTIN[7]~feeder_combout\ = \KEY_BOARD|SHIFTIN\(8)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \KEY_BOARD|SHIFTIN\(8),
	combout => \KEY_BOARD|SHIFTIN[7]~feeder_combout\);

-- Location: FF_X54_Y49_N25
\KEY_BOARD|SHIFTIN[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|SHIFTIN[7]~feeder_combout\,
	ena => \KEY_BOARD|SHIFTIN[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|SHIFTIN\(7));

-- Location: LCCOMB_X54_Y49_N26
\KEY_BOARD|SHIFTIN[6]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|SHIFTIN[6]~feeder_combout\ = \KEY_BOARD|SHIFTIN\(7)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \KEY_BOARD|SHIFTIN\(7),
	combout => \KEY_BOARD|SHIFTIN[6]~feeder_combout\);

-- Location: FF_X54_Y49_N27
\KEY_BOARD|SHIFTIN[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|SHIFTIN[6]~feeder_combout\,
	ena => \KEY_BOARD|SHIFTIN[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|SHIFTIN\(6));

-- Location: LCCOMB_X54_Y49_N0
\KEY_BOARD|SHIFTIN[5]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|SHIFTIN[5]~feeder_combout\ = \KEY_BOARD|SHIFTIN\(6)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \KEY_BOARD|SHIFTIN\(6),
	combout => \KEY_BOARD|SHIFTIN[5]~feeder_combout\);

-- Location: FF_X54_Y49_N1
\KEY_BOARD|SHIFTIN[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|SHIFTIN[5]~feeder_combout\,
	ena => \KEY_BOARD|SHIFTIN[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|SHIFTIN\(5));

-- Location: LCCOMB_X55_Y49_N12
\KEY_BOARD|scan_code[7]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|scan_code[7]~0_combout\ = (!\reset~input_o\ & (\KEY_BOARD|READ_CHAR~q\ & !\KEY_BOARD|LessThan0~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reset~input_o\,
	datab => \KEY_BOARD|READ_CHAR~q\,
	datad => \KEY_BOARD|LessThan0~0_combout\,
	combout => \KEY_BOARD|scan_code[7]~0_combout\);

-- Location: FF_X55_Y49_N15
\KEY_BOARD|scan_code[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	asdata => \KEY_BOARD|SHIFTIN\(5),
	sload => VCC,
	ena => \KEY_BOARD|scan_code[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|scan_code\(5));

-- Location: LCCOMB_X55_Y49_N0
\KEY_BOARD|scan_code[6]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|scan_code[6]~feeder_combout\ = \KEY_BOARD|SHIFTIN\(6)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \KEY_BOARD|SHIFTIN\(6),
	combout => \KEY_BOARD|scan_code[6]~feeder_combout\);

-- Location: FF_X55_Y49_N1
\KEY_BOARD|scan_code[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|scan_code[6]~feeder_combout\,
	ena => \KEY_BOARD|scan_code[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|scan_code\(6));

-- Location: LCCOMB_X55_Y49_N18
\KEY_BOARD|scan_code[7]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|scan_code[7]~feeder_combout\ = \KEY_BOARD|SHIFTIN\(7)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \KEY_BOARD|SHIFTIN\(7),
	combout => \KEY_BOARD|scan_code[7]~feeder_combout\);

-- Location: FF_X55_Y49_N19
\KEY_BOARD|scan_code[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|scan_code[7]~feeder_combout\,
	ena => \KEY_BOARD|scan_code[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|scan_code\(7));

-- Location: FF_X54_Y49_N21
\KEY_BOARD|SHIFTIN[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	asdata => \KEY_BOARD|SHIFTIN\(5),
	sload => VCC,
	ena => \KEY_BOARD|SHIFTIN[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|SHIFTIN\(4));

-- Location: FF_X55_Y49_N13
\KEY_BOARD|scan_code[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	asdata => \KEY_BOARD|SHIFTIN\(4),
	sload => VCC,
	ena => \KEY_BOARD|scan_code[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|scan_code\(4));

-- Location: LCCOMB_X55_Y45_N16
\Mux13~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux13~0_combout\ = (\KEY_BOARD|scan_code\(6) & (!\KEY_BOARD|scan_code\(5) & (\KEY_BOARD|scan_code\(7) $ (!\KEY_BOARD|scan_code\(4))))) # (!\KEY_BOARD|scan_code\(6) & (\KEY_BOARD|scan_code\(4) & (\KEY_BOARD|scan_code\(5) $ (!\KEY_BOARD|scan_code\(7)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000100000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|scan_code\(5),
	datab => \KEY_BOARD|scan_code\(6),
	datac => \KEY_BOARD|scan_code\(7),
	datad => \KEY_BOARD|scan_code\(4),
	combout => \Mux13~0_combout\);

-- Location: LCCOMB_X55_Y45_N6
\Mux12~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux12~0_combout\ = (\KEY_BOARD|scan_code\(5) & ((\KEY_BOARD|scan_code\(4) & ((\KEY_BOARD|scan_code\(7)))) # (!\KEY_BOARD|scan_code\(4) & (\KEY_BOARD|scan_code\(6))))) # (!\KEY_BOARD|scan_code\(5) & (\KEY_BOARD|scan_code\(6) & (\KEY_BOARD|scan_code\(7) $ 
-- (\KEY_BOARD|scan_code\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010011001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|scan_code\(5),
	datab => \KEY_BOARD|scan_code\(6),
	datac => \KEY_BOARD|scan_code\(7),
	datad => \KEY_BOARD|scan_code\(4),
	combout => \Mux12~0_combout\);

-- Location: LCCOMB_X55_Y45_N24
\Mux11~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux11~0_combout\ = (\KEY_BOARD|scan_code\(6) & (\KEY_BOARD|scan_code\(7) & ((\KEY_BOARD|scan_code\(5)) # (!\KEY_BOARD|scan_code\(4))))) # (!\KEY_BOARD|scan_code\(6) & (\KEY_BOARD|scan_code\(5) & (!\KEY_BOARD|scan_code\(7) & !\KEY_BOARD|scan_code\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000011000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|scan_code\(5),
	datab => \KEY_BOARD|scan_code\(6),
	datac => \KEY_BOARD|scan_code\(7),
	datad => \KEY_BOARD|scan_code\(4),
	combout => \Mux11~0_combout\);

-- Location: LCCOMB_X55_Y45_N26
\Mux10~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux10~0_combout\ = (\KEY_BOARD|scan_code\(5) & ((\KEY_BOARD|scan_code\(6) & ((\KEY_BOARD|scan_code\(4)))) # (!\KEY_BOARD|scan_code\(6) & (\KEY_BOARD|scan_code\(7) & !\KEY_BOARD|scan_code\(4))))) # (!\KEY_BOARD|scan_code\(5) & (!\KEY_BOARD|scan_code\(7) & 
-- (\KEY_BOARD|scan_code\(6) $ (\KEY_BOARD|scan_code\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100100100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|scan_code\(5),
	datab => \KEY_BOARD|scan_code\(6),
	datac => \KEY_BOARD|scan_code\(7),
	datad => \KEY_BOARD|scan_code\(4),
	combout => \Mux10~0_combout\);

-- Location: LCCOMB_X55_Y45_N0
\Mux9~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux9~0_combout\ = (\KEY_BOARD|scan_code\(5) & (((!\KEY_BOARD|scan_code\(7) & \KEY_BOARD|scan_code\(4))))) # (!\KEY_BOARD|scan_code\(5) & ((\KEY_BOARD|scan_code\(6) & (!\KEY_BOARD|scan_code\(7))) # (!\KEY_BOARD|scan_code\(6) & 
-- ((\KEY_BOARD|scan_code\(4))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111100000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|scan_code\(5),
	datab => \KEY_BOARD|scan_code\(6),
	datac => \KEY_BOARD|scan_code\(7),
	datad => \KEY_BOARD|scan_code\(4),
	combout => \Mux9~0_combout\);

-- Location: LCCOMB_X55_Y45_N30
\Mux8~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux8~0_combout\ = (\KEY_BOARD|scan_code\(5) & (!\KEY_BOARD|scan_code\(7) & ((\KEY_BOARD|scan_code\(4)) # (!\KEY_BOARD|scan_code\(6))))) # (!\KEY_BOARD|scan_code\(5) & (\KEY_BOARD|scan_code\(4) & (\KEY_BOARD|scan_code\(6) $ (!\KEY_BOARD|scan_code\(7)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100101100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|scan_code\(5),
	datab => \KEY_BOARD|scan_code\(6),
	datac => \KEY_BOARD|scan_code\(7),
	datad => \KEY_BOARD|scan_code\(4),
	combout => \Mux8~0_combout\);

-- Location: LCCOMB_X55_Y45_N12
\Mux7~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux7~0_combout\ = (\KEY_BOARD|scan_code\(4) & ((\KEY_BOARD|scan_code\(7)) # (\KEY_BOARD|scan_code\(5) $ (\KEY_BOARD|scan_code\(6))))) # (!\KEY_BOARD|scan_code\(4) & ((\KEY_BOARD|scan_code\(5)) # (\KEY_BOARD|scan_code\(6) $ (\KEY_BOARD|scan_code\(7)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011010111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|scan_code\(5),
	datab => \KEY_BOARD|scan_code\(6),
	datac => \KEY_BOARD|scan_code\(7),
	datad => \KEY_BOARD|scan_code\(4),
	combout => \Mux7~0_combout\);

-- Location: LCCOMB_X54_Y49_N28
\KEY_BOARD|SHIFTIN[3]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|SHIFTIN[3]~feeder_combout\ = \KEY_BOARD|SHIFTIN\(4)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \KEY_BOARD|SHIFTIN\(4),
	combout => \KEY_BOARD|SHIFTIN[3]~feeder_combout\);

-- Location: FF_X54_Y49_N29
\KEY_BOARD|SHIFTIN[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|SHIFTIN[3]~feeder_combout\,
	ena => \KEY_BOARD|SHIFTIN[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|SHIFTIN\(3));

-- Location: LCCOMB_X54_Y49_N22
\KEY_BOARD|SHIFTIN[2]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|SHIFTIN[2]~feeder_combout\ = \KEY_BOARD|SHIFTIN\(3)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \KEY_BOARD|SHIFTIN\(3),
	combout => \KEY_BOARD|SHIFTIN[2]~feeder_combout\);

-- Location: FF_X54_Y49_N23
\KEY_BOARD|SHIFTIN[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|SHIFTIN[2]~feeder_combout\,
	ena => \KEY_BOARD|SHIFTIN[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|SHIFTIN\(2));

-- Location: LCCOMB_X55_Y49_N20
\KEY_BOARD|scan_code[2]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|scan_code[2]~feeder_combout\ = \KEY_BOARD|SHIFTIN\(2)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \KEY_BOARD|SHIFTIN\(2),
	combout => \KEY_BOARD|scan_code[2]~feeder_combout\);

-- Location: FF_X55_Y49_N21
\KEY_BOARD|scan_code[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|scan_code[2]~feeder_combout\,
	ena => \KEY_BOARD|scan_code[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|scan_code\(2));

-- Location: LCCOMB_X54_Y49_N4
\KEY_BOARD|SHIFTIN[1]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|SHIFTIN[1]~feeder_combout\ = \KEY_BOARD|SHIFTIN\(2)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \KEY_BOARD|SHIFTIN\(2),
	combout => \KEY_BOARD|SHIFTIN[1]~feeder_combout\);

-- Location: FF_X54_Y49_N5
\KEY_BOARD|SHIFTIN[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|SHIFTIN[1]~feeder_combout\,
	ena => \KEY_BOARD|SHIFTIN[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|SHIFTIN\(1));

-- Location: FF_X55_Y49_N31
\KEY_BOARD|scan_code[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	asdata => \KEY_BOARD|SHIFTIN\(1),
	sload => VCC,
	ena => \KEY_BOARD|scan_code[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|scan_code\(1));

-- Location: LCCOMB_X55_Y49_N26
\KEY_BOARD|scan_code[3]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|scan_code[3]~feeder_combout\ = \KEY_BOARD|SHIFTIN\(3)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \KEY_BOARD|SHIFTIN\(3),
	combout => \KEY_BOARD|scan_code[3]~feeder_combout\);

-- Location: FF_X55_Y49_N27
\KEY_BOARD|scan_code[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|scan_code[3]~feeder_combout\,
	ena => \KEY_BOARD|scan_code[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|scan_code\(3));

-- Location: LCCOMB_X54_Y49_N14
\KEY_BOARD|SHIFTIN[0]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|SHIFTIN[0]~feeder_combout\ = \KEY_BOARD|SHIFTIN\(1)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \KEY_BOARD|SHIFTIN\(1),
	combout => \KEY_BOARD|SHIFTIN[0]~feeder_combout\);

-- Location: FF_X54_Y49_N15
\KEY_BOARD|SHIFTIN[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|SHIFTIN[0]~feeder_combout\,
	ena => \KEY_BOARD|SHIFTIN[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|SHIFTIN\(0));

-- Location: LCCOMB_X55_Y49_N28
\KEY_BOARD|scan_code[0]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \KEY_BOARD|scan_code[0]~feeder_combout\ = \KEY_BOARD|SHIFTIN\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \KEY_BOARD|SHIFTIN\(0),
	combout => \KEY_BOARD|scan_code[0]~feeder_combout\);

-- Location: FF_X55_Y49_N29
\KEY_BOARD|scan_code[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \KEY_BOARD|keyboard_clk_filtered~clkctrl_outclk\,
	d => \KEY_BOARD|scan_code[0]~feeder_combout\,
	ena => \KEY_BOARD|scan_code[7]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \KEY_BOARD|scan_code\(0));

-- Location: LCCOMB_X62_Y49_N16
\Mux6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux6~0_combout\ = (\KEY_BOARD|scan_code\(2) & (!\KEY_BOARD|scan_code\(1) & (\KEY_BOARD|scan_code\(3) $ (!\KEY_BOARD|scan_code\(0))))) # (!\KEY_BOARD|scan_code\(2) & (\KEY_BOARD|scan_code\(0) & (\KEY_BOARD|scan_code\(1) $ (!\KEY_BOARD|scan_code\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|scan_code\(2),
	datab => \KEY_BOARD|scan_code\(1),
	datac => \KEY_BOARD|scan_code\(3),
	datad => \KEY_BOARD|scan_code\(0),
	combout => \Mux6~0_combout\);

-- Location: LCCOMB_X62_Y49_N22
\Mux5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux5~0_combout\ = (\KEY_BOARD|scan_code\(1) & ((\KEY_BOARD|scan_code\(0) & ((\KEY_BOARD|scan_code\(3)))) # (!\KEY_BOARD|scan_code\(0) & (\KEY_BOARD|scan_code\(2))))) # (!\KEY_BOARD|scan_code\(1) & (\KEY_BOARD|scan_code\(2) & (\KEY_BOARD|scan_code\(3) $ 
-- (\KEY_BOARD|scan_code\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|scan_code\(2),
	datab => \KEY_BOARD|scan_code\(1),
	datac => \KEY_BOARD|scan_code\(3),
	datad => \KEY_BOARD|scan_code\(0),
	combout => \Mux5~0_combout\);

-- Location: LCCOMB_X62_Y49_N28
\Mux4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux4~0_combout\ = (\KEY_BOARD|scan_code\(2) & (\KEY_BOARD|scan_code\(3) & ((\KEY_BOARD|scan_code\(1)) # (!\KEY_BOARD|scan_code\(0))))) # (!\KEY_BOARD|scan_code\(2) & (\KEY_BOARD|scan_code\(1) & (!\KEY_BOARD|scan_code\(3) & !\KEY_BOARD|scan_code\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000010100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|scan_code\(2),
	datab => \KEY_BOARD|scan_code\(1),
	datac => \KEY_BOARD|scan_code\(3),
	datad => \KEY_BOARD|scan_code\(0),
	combout => \Mux4~0_combout\);

-- Location: LCCOMB_X62_Y49_N6
\Mux3~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux3~0_combout\ = (\KEY_BOARD|scan_code\(1) & ((\KEY_BOARD|scan_code\(2) & ((\KEY_BOARD|scan_code\(0)))) # (!\KEY_BOARD|scan_code\(2) & (\KEY_BOARD|scan_code\(3) & !\KEY_BOARD|scan_code\(0))))) # (!\KEY_BOARD|scan_code\(1) & (!\KEY_BOARD|scan_code\(3) & 
-- (\KEY_BOARD|scan_code\(2) $ (\KEY_BOARD|scan_code\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100101000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|scan_code\(2),
	datab => \KEY_BOARD|scan_code\(1),
	datac => \KEY_BOARD|scan_code\(3),
	datad => \KEY_BOARD|scan_code\(0),
	combout => \Mux3~0_combout\);

-- Location: LCCOMB_X62_Y49_N12
\Mux2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux2~0_combout\ = (\KEY_BOARD|scan_code\(1) & (((!\KEY_BOARD|scan_code\(3) & \KEY_BOARD|scan_code\(0))))) # (!\KEY_BOARD|scan_code\(1) & ((\KEY_BOARD|scan_code\(2) & (!\KEY_BOARD|scan_code\(3))) # (!\KEY_BOARD|scan_code\(2) & 
-- ((\KEY_BOARD|scan_code\(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|scan_code\(2),
	datab => \KEY_BOARD|scan_code\(1),
	datac => \KEY_BOARD|scan_code\(3),
	datad => \KEY_BOARD|scan_code\(0),
	combout => \Mux2~0_combout\);

-- Location: LCCOMB_X62_Y49_N30
\Mux1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux1~0_combout\ = (\KEY_BOARD|scan_code\(2) & (\KEY_BOARD|scan_code\(0) & (\KEY_BOARD|scan_code\(1) $ (\KEY_BOARD|scan_code\(3))))) # (!\KEY_BOARD|scan_code\(2) & (!\KEY_BOARD|scan_code\(3) & ((\KEY_BOARD|scan_code\(1)) # (\KEY_BOARD|scan_code\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010110100000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|scan_code\(2),
	datab => \KEY_BOARD|scan_code\(1),
	datac => \KEY_BOARD|scan_code\(3),
	datad => \KEY_BOARD|scan_code\(0),
	combout => \Mux1~0_combout\);

-- Location: LCCOMB_X62_Y49_N4
\Mux0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \Mux0~0_combout\ = (\KEY_BOARD|scan_code\(0) & ((\KEY_BOARD|scan_code\(3)) # (\KEY_BOARD|scan_code\(2) $ (\KEY_BOARD|scan_code\(1))))) # (!\KEY_BOARD|scan_code\(0) & ((\KEY_BOARD|scan_code\(1)) # (\KEY_BOARD|scan_code\(2) $ (\KEY_BOARD|scan_code\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011011011110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \KEY_BOARD|scan_code\(2),
	datab => \KEY_BOARD|scan_code\(1),
	datac => \KEY_BOARD|scan_code\(3),
	datad => \KEY_BOARD|scan_code\(0),
	combout => \Mux0~0_combout\);

-- Location: IOIBUF_X115_Y13_N1
\read~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_read,
	o => \read~input_o\);

ww_display02(0) <= \display02[0]~output_o\;

ww_display02(1) <= \display02[1]~output_o\;

ww_display02(2) <= \display02[2]~output_o\;

ww_display02(3) <= \display02[3]~output_o\;

ww_display02(4) <= \display02[4]~output_o\;

ww_display02(5) <= \display02[5]~output_o\;

ww_display02(6) <= \display02[6]~output_o\;

ww_display01(0) <= \display01[0]~output_o\;

ww_display01(1) <= \display01[1]~output_o\;

ww_display01(2) <= \display01[2]~output_o\;

ww_display01(3) <= \display01[3]~output_o\;

ww_display01(4) <= \display01[4]~output_o\;

ww_display01(5) <= \display01[5]~output_o\;

ww_display01(6) <= \display01[6]~output_o\;
END structure;


