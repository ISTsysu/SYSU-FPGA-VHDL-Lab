library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.STD_LOGIC_ARITH.all;
use IEEE.STD_LOGIC_UNSIGNED.all;

-- 顶层实体：连接键盘输入和数码管显示
entity top is
    port (
        keyboard_clk, keyboard_data, clock_50Mhz,  -- 键盘时钟、数据线和系统50MHz时钟
        reset, read : in std_logic;                 -- 复位和读取信号

        display02 : out std_logic_vector(6 downto 0);  -- 数码管高位显示
        display01 : out std_logic_vector(6 downto 0)   -- 数码管低位显示
    );
end top;

architecture rtl of top is
    signal scan_code : std_logic_vector(7 downto 0);   -- 键盘扫描码
    signal scan_ready : std_logic;                     -- 扫描完成标志
    signal clock_25Mhz : std_logic := '0';             -- 分频后的25MHz时钟

    -- 键盘控制器组件声明
    component keyboard
        port (
            keyboard_clk : in std_logic;
            keyboard_data : in std_logic;
            clock_25Mhz : in std_logic;
            reset : in std_logic;
            read : in std_logic;
            scan_code : out std_logic_vector(7 downto 0);
            scan_ready : out std_logic
        );
    end component;

begin
    -- 实例化键盘控制器
    KEY_BOARD : keyboard port map(
        keyboard_clk, keyboard_data, clock_25Mhz,
        reset, read, scan_code, scan_ready
    );
    
    -- 时钟分频进程：将50MHz分频为25MHz
    process(clock_50Mhz)
        variable counter : integer range 0 to 1;
    begin
        if rising_edge(clock_50Mhz) then
            counter := counter + 1;
            if counter = 1 then
                clock_25Mhz <= not clock_25Mhz;  -- 翻转生成25MHz时钟
                counter := 0;
            end if;
        end if;
    end process;

    -- 数码管显示解码进程
    process (scan_code)
    begin
        -- 解码扫描码低4位，控制低位数码管显示
        case scan_code(3 downto 0) is
            when "0000" => display01 <= "1000000"; -- 0
            when "0001" => display01 <= "1111001"; -- 1
            when "0010" => display01 <= "0100100"; -- 2
            when "0011" => display01 <= "0110000"; -- 3
            when "0100" => display01 <= "0011001"; -- 4
            when "0101" => display01 <= "0010010"; -- 5
            when "0110" => display01 <= "0000010"; -- 6
            when "0111" => display01 <= "1111000"; -- 7
            when "1000" => display01 <= "0000000"; -- 8
            when "1001" => display01 <= "0010000"; -- 9
            when "1010" => display01 <= "0001000"; -- A
            when "1011" => display01 <= "0000011"; -- b
            when "1100" => display01 <= "1000110"; -- C
            when "1101" => display01 <= "0100001"; -- d
            when "1110" => display01 <= "0000110"; -- E
            when "1111" => display01 <= "0001110"; -- F
            when others => display01 <= "1111111"; -- 默认熄灭
        end case;

        -- 解码扫描码高4位，控制高位数码管显示
        case scan_code(7 downto 4) is
            when "0000" => display02 <= "1000000"; -- 0
            when "0001" => display02 <= "1111001"; -- 1
            when "0010" => display02 <= "0100100"; -- 2
            when "0011" => display02 <= "0110000"; -- 3
            when "0100" => display02 <= "0011001"; -- 4
            when "0101" => display02 <= "0010010"; -- 5
            when "0110" => display02 <= "0000010"; -- 6
            when "0111" => display02 <= "1111000"; -- 7
            when "1000" => display02 <= "0000000"; -- 8
            when "1001" => display02 <= "0010000"; -- 9
            when "1010" => display02 <= "0001000"; -- A
            when "1011" => display02 <= "0000011"; -- b
            when "1100" => display02 <= "1000110"; -- C
            when "1101" => display02 <= "0100001"; -- d
            when "1110" => display02 <= "0000110"; -- E
            when "1111" => display02 <= "0001110"; -- F
            when others => display02 <= "1111111"; -- 默认熄灭
				--按键验证：
				--A/1C，B/32，C21；左边1/16，2/1E，3/26；小键盘0/70，1/69，2/72
        end case;
    end process;
end architecture rtl;