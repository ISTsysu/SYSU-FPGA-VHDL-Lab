LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;

-- PS/2键盘控制器实体
ENTITY keyboard IS
    PORT(
        -- 输入端口
        keyboard_clk   : IN  STD_LOGIC;  -- PS/2键盘时钟信号
        keyboard_data  : IN  STD_LOGIC;  -- PS/2键盘数据信号
        clock_25Mhz    : IN  STD_LOGIC;  -- 系统时钟（25MHz）
        reset          : IN  STD_LOGIC;  -- 复位信号
        read           : IN  STD_LOGIC;  -- 读取使能信号
        
        -- 输出端口
        scan_code      : OUT STD_LOGIC_VECTOR(7 DOWNTO 0);  -- 扫描码输出
        scan_ready     : OUT STD_LOGIC                      -- 扫描码就绪标志
    );
END keyboard;

-- 键盘控制器架构
ARCHITECTURE a OF keyboard IS
    -- 内部信号定义
    SIGNAL INCNT                 : STD_LOGIC_VECTOR(3 DOWNTO 0);   -- 接收位计数器
    SIGNAL SHIFTIN               : STD_LOGIC_VECTOR(8 DOWNTO 0);   -- 数据移位寄存器
    SIGNAL READ_CHAR             : STD_LOGIC;                      -- 字符接收标志
    SIGNAL INFLAG, ready_set     : STD_LOGIC;                      -- 状态标志
    SIGNAL keyboard_clk_filtered : STD_LOGIC;                      -- 滤波后的键盘时钟
    SIGNAL filter               : STD_LOGIC_VECTOR(7 DOWNTO 0);   -- 时钟滤波寄存器
BEGIN

    -- 扫描码就绪标志控制进程
    PROCESS (read, ready_set)
    BEGIN
        IF read = '1' THEN 
            scan_ready <= '0';  -- 当读取信号有效时清除就绪标志
        ELSIF ready_set'EVENT AND ready_set = '1' THEN
            scan_ready <= '1';  -- 当数据接收完成时设置就绪标志
        END IF;
    END PROCESS;

    -- 键盘时钟滤波进程（消抖处理）
    Clock_filter: PROCESS
    BEGIN
        WAIT UNTIL clock_25Mhz'EVENT AND clock_25Mhz = '1';
        -- 移位寄存器更新
        filter(6 DOWNTO 0) <= filter(7 DOWNTO 1);
        filter(7) <= keyboard_clk;
        
        -- 连续检测8个1或0时更新滤波后时钟
        IF filter = "11111111" THEN 
            keyboard_clk_filtered <= '1';
        ELSIF filter = "00000000" THEN 
            keyboard_clk_filtered <= '0';
        END IF;
    END PROCESS Clock_filter;

    -- PS/2数据接收进程
    PROCESS
    BEGIN
        WAIT UNTIL (KEYBOARD_CLK_filtered'EVENT AND KEYBOARD_CLK_filtered = '1');
        
        -- 复位处理
        IF RESET = '1' THEN
            INCNT <= "0000";
            READ_CHAR <= '0';
        ELSE
            -- 检测起始位（低电平）并开始接收数据
            IF KEYBOARD_DATA = '0' AND READ_CHAR = '0' THEN
                READ_CHAR <= '1';   -- 设置接收标志
                ready_set <= '0';   -- 清除就绪标志
            ELSE
                -- 正在接收数据
                IF READ_CHAR = '1' THEN
                    -- 接收9位数据（1起始位 + 8数据位）
                    IF INCNT < "1001" THEN
                        INCNT <= INCNT + 1;                          -- 计数器递增
                        SHIFTIN(7 DOWNTO 0) <= SHIFTIN(8 DOWNTO 1);  -- 数据右移
                        SHIFTIN(8) <= KEYBOARD_DATA;                 -- 移入新数据
                        ready_set <= '0';                             -- 保持就绪标志为低
                    -- 接收完成处理
                    ELSE
                        scan_code <= SHIFTIN(7 DOWNTO 0);  -- 输出扫描码（忽略起始位）
                        READ_CHAR <= '0';                 -- 清除接收标志
                        ready_set <= '1';                 -- 设置就绪标志
                        INCNT <= "0000";                  -- 复位计数器
                    END IF;
                END IF;
            END IF;
        END IF;
    END PROCESS;
END a;