library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- 顶层测试模块
entity vhdl2 is
    port(
        sys_clk    : in  std_logic;                                 -- 50 MHz 时钟
        sys_rst_n  : in  std_logic;                                 -- 复位，低有效
        remote_in  : in  std_logic;                                 -- 红外接收器输出
        seg        : out std_logic_vector(6 downto 0);              -- 七段数码管 a–g (低有效)
        an         : out std_logic_vector(3 downto 0)               -- 数码管位选 (低有效)
    );
end vhdl2;

architecture rtl of vhdl2 is
    signal data_byte   : std_logic_vector(7 downto 0);
    signal repeat_en   : std_logic;
    signal valid_flag  : std_logic;
    signal digit       : std_logic_vector(3 downto 0);
begin
    -- 实例化红外接收模块
    ir_rcv_u : entity work.infrared_rcv
        port map (
            sys_clk   => sys_clk,
            sys_rst_n => sys_rst_n,
            remote_in => remote_in,
            repeat_en => repeat_en,
            data      => data_byte
        );

    -- 有效信号检测：非全 0 或 重复码 即标记为“收到”
    proc_valid : process(sys_clk, sys_rst_n)
    begin
        if sys_rst_n = '0' then
            valid_flag <= '0';
        elsif rising_edge(sys_clk) then
            if (data_byte /= "00000000") or (repeat_en = '1') then
                valid_flag <= '1';
            else
                valid_flag <= '0';
            end if;
        end if;
    end process;

    -- 要显示的数码：收到 → “1”，否则 → “0”
    digit <= "0001" when valid_flag = '1' else "0000";

    -- 七段译码 (低有效：0点亮)
    proc_7seg : process(digit)
    begin
        case digit is
            when "0000" => seg <= "1000000";  -- 显示 “0”
            when "0001" => seg <= "1111001";  -- 显示 “1”
            when others => seg <= "1111111";  -- 熄灭
        end case;
    end process;

    -- 只使能最低位（如果板上只有一个数码管，可改为 "0000" 全选）
    an <= "1110";
    
end rtl;
