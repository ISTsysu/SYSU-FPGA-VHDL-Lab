-- Copyright (C) 2018  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 18.0.0 Build 614 04/24/2018 SJ Standard Edition"

-- DATE "05/30/2025 15:34:29"

-- 
-- Device: Altera EP4CE115F29C7 Package FBGA780
-- 

-- 
-- This VHDL file should be used for ModelSim (VHDL) only
-- 

LIBRARY CYCLONEIVE;
LIBRARY IEEE;
USE CYCLONEIVE.CYCLONEIVE_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	hard_block IS
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic
	);
END hard_block;

-- Design Ports Information
-- ~ALTERA_ASDO_DATA1~	=>  Location: PIN_F4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_FLASH_nCE_nCSO~	=>  Location: PIN_E2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_DCLK~	=>  Location: PIN_P3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_DATA0~	=>  Location: PIN_N7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_nCEO~	=>  Location: PIN_P28,	 I/O Standard: 2.5 V,	 Current Strength: 8mA


ARCHITECTURE structure OF hard_block IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL \~ALTERA_ASDO_DATA1~~padout\ : std_logic;
SIGNAL \~ALTERA_FLASH_nCE_nCSO~~padout\ : std_logic;
SIGNAL \~ALTERA_DATA0~~padout\ : std_logic;
SIGNAL \~ALTERA_ASDO_DATA1~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_FLASH_nCE_nCSO~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_DATA0~~ibuf_o\ : std_logic;

BEGIN

ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
END structure;


LIBRARY ALTERA;
LIBRARY CYCLONEIVE;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIVE.CYCLONEIVE_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	infrared IS
    PORT (
	sys_clk : IN std_logic;
	sys_rst_n_in : IN std_logic;
	remote_in : IN std_logic;
	segcode1out : BUFFER std_logic_vector(6 DOWNTO 0);
	segcode0out : BUFFER std_logic_vector(6 DOWNTO 0);
	led : BUFFER std_logic;
	leds_out : BUFFER std_logic_vector(11 DOWNTO 0)
	);
END infrared;

-- Design Ports Information
-- segcode1out[0]	=>  Location: PIN_V21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- segcode1out[1]	=>  Location: PIN_U21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- segcode1out[2]	=>  Location: PIN_AB20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- segcode1out[3]	=>  Location: PIN_AA21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- segcode1out[4]	=>  Location: PIN_AD24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- segcode1out[5]	=>  Location: PIN_AF23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- segcode1out[6]	=>  Location: PIN_Y19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- segcode0out[0]	=>  Location: PIN_AA25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- segcode0out[1]	=>  Location: PIN_AA26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- segcode0out[2]	=>  Location: PIN_Y25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- segcode0out[3]	=>  Location: PIN_W26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- segcode0out[4]	=>  Location: PIN_Y26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- segcode0out[5]	=>  Location: PIN_W27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- segcode0out[6]	=>  Location: PIN_W28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led	=>  Location: PIN_J16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_out[0]	=>  Location: PIN_G19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_out[1]	=>  Location: PIN_F19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_out[2]	=>  Location: PIN_E19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_out[3]	=>  Location: PIN_F21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_out[4]	=>  Location: PIN_F18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_out[5]	=>  Location: PIN_E18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_out[6]	=>  Location: PIN_J19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_out[7]	=>  Location: PIN_H19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_out[8]	=>  Location: PIN_J17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_out[9]	=>  Location: PIN_G17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_out[10]	=>  Location: PIN_J15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- leds_out[11]	=>  Location: PIN_H16,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sys_clk	=>  Location: PIN_Y2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sys_rst_n_in	=>  Location: PIN_Y23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- remote_in	=>  Location: PIN_Y15,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF infrared IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_sys_clk : std_logic;
SIGNAL ww_sys_rst_n_in : std_logic;
SIGNAL ww_remote_in : std_logic;
SIGNAL ww_segcode1out : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_segcode0out : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_led : std_logic;
SIGNAL ww_leds_out : std_logic_vector(11 DOWNTO 0);
SIGNAL \U3|Mux9_rtl_0|auto_generated|ram_block1a0_PORTAADDR_bus\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \U3|Mux9_rtl_0|auto_generated|ram_block1a0_PORTADATAOUT_bus\ : std_logic_vector(17 DOWNTO 0);
SIGNAL \sys_clk~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \U1|div_clk~clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \segcode1out[0]~output_o\ : std_logic;
SIGNAL \segcode1out[1]~output_o\ : std_logic;
SIGNAL \segcode1out[2]~output_o\ : std_logic;
SIGNAL \segcode1out[3]~output_o\ : std_logic;
SIGNAL \segcode1out[4]~output_o\ : std_logic;
SIGNAL \segcode1out[5]~output_o\ : std_logic;
SIGNAL \segcode1out[6]~output_o\ : std_logic;
SIGNAL \segcode0out[0]~output_o\ : std_logic;
SIGNAL \segcode0out[1]~output_o\ : std_logic;
SIGNAL \segcode0out[2]~output_o\ : std_logic;
SIGNAL \segcode0out[3]~output_o\ : std_logic;
SIGNAL \segcode0out[4]~output_o\ : std_logic;
SIGNAL \segcode0out[5]~output_o\ : std_logic;
SIGNAL \segcode0out[6]~output_o\ : std_logic;
SIGNAL \led~output_o\ : std_logic;
SIGNAL \leds_out[0]~output_o\ : std_logic;
SIGNAL \leds_out[1]~output_o\ : std_logic;
SIGNAL \leds_out[2]~output_o\ : std_logic;
SIGNAL \leds_out[3]~output_o\ : std_logic;
SIGNAL \leds_out[4]~output_o\ : std_logic;
SIGNAL \leds_out[5]~output_o\ : std_logic;
SIGNAL \leds_out[6]~output_o\ : std_logic;
SIGNAL \leds_out[7]~output_o\ : std_logic;
SIGNAL \leds_out[8]~output_o\ : std_logic;
SIGNAL \leds_out[9]~output_o\ : std_logic;
SIGNAL \leds_out[10]~output_o\ : std_logic;
SIGNAL \leds_out[11]~output_o\ : std_logic;
SIGNAL \sys_clk~input_o\ : std_logic;
SIGNAL \sys_clk~inputclkctrl_outclk\ : std_logic;
SIGNAL \U1|Add0~15\ : std_logic;
SIGNAL \U1|Add0~16_combout\ : std_logic;
SIGNAL \U1|Add0~17\ : std_logic;
SIGNAL \U1|Add0~18_combout\ : std_logic;
SIGNAL \U1|Add0~19\ : std_logic;
SIGNAL \U1|Add0~20_combout\ : std_logic;
SIGNAL \U1|div_cnt~4_combout\ : std_logic;
SIGNAL \U1|Add0~21\ : std_logic;
SIGNAL \U1|Add0~22_combout\ : std_logic;
SIGNAL \U1|div_cnt~5_combout\ : std_logic;
SIGNAL \U1|Equal0~2_combout\ : std_logic;
SIGNAL \U1|Add0~1\ : std_logic;
SIGNAL \U1|Add0~2_combout\ : std_logic;
SIGNAL \U1|Add0~3\ : std_logic;
SIGNAL \U1|Add0~4_combout\ : std_logic;
SIGNAL \U1|div_cnt~0_combout\ : std_logic;
SIGNAL \U1|Add0~5\ : std_logic;
SIGNAL \U1|Add0~6_combout\ : std_logic;
SIGNAL \U1|Add0~7\ : std_logic;
SIGNAL \U1|Add0~8_combout\ : std_logic;
SIGNAL \U1|div_cnt~2_combout\ : std_logic;
SIGNAL \U1|Add0~9\ : std_logic;
SIGNAL \U1|Add0~10_combout\ : std_logic;
SIGNAL \U1|div_cnt~3_combout\ : std_logic;
SIGNAL \U1|Add0~11\ : std_logic;
SIGNAL \U1|Add0~12_combout\ : std_logic;
SIGNAL \U1|Add0~13\ : std_logic;
SIGNAL \U1|Add0~14_combout\ : std_logic;
SIGNAL \U1|Equal0~1_combout\ : std_logic;
SIGNAL \U1|Add0~0_combout\ : std_logic;
SIGNAL \U1|div_cnt~1_combout\ : std_logic;
SIGNAL \U1|Equal0~0_combout\ : std_logic;
SIGNAL \U1|div_clk~0_combout\ : std_logic;
SIGNAL \U1|div_clk~feeder_combout\ : std_logic;
SIGNAL \U1|div_clk~q\ : std_logic;
SIGNAL \U1|div_clk~clkctrl_outclk\ : std_logic;
SIGNAL \remote_in~input_o\ : std_logic;
SIGNAL \sys_rst_n_in~input_o\ : std_logic;
SIGNAL \U1|remote_in_d0~0_combout\ : std_logic;
SIGNAL \U1|remote_in_d0~q\ : std_logic;
SIGNAL \U1|remote_in_d1~0_combout\ : std_logic;
SIGNAL \U1|remote_in_d1~q\ : std_logic;
SIGNAL \U1|pos_remote_in~combout\ : std_logic;
SIGNAL \U1|time_cnt[0]~8_combout\ : std_logic;
SIGNAL \U1|time_cnt[1]~11\ : std_logic;
SIGNAL \U1|time_cnt[2]~12_combout\ : std_logic;
SIGNAL \U1|time_cnt[2]~13\ : std_logic;
SIGNAL \U1|time_cnt[3]~14_combout\ : std_logic;
SIGNAL \U1|time_cnt[3]~15\ : std_logic;
SIGNAL \U1|time_cnt[4]~16_combout\ : std_logic;
SIGNAL \U1|time_cnt[4]~17\ : std_logic;
SIGNAL \U1|time_cnt[5]~19_combout\ : std_logic;
SIGNAL \U1|time_cnt[5]~20\ : std_logic;
SIGNAL \U1|time_cnt[6]~21_combout\ : std_logic;
SIGNAL \U1|time_cnt[6]~22\ : std_logic;
SIGNAL \U1|time_cnt[7]~23_combout\ : std_logic;
SIGNAL \U1|process_5~4_combout\ : std_logic;
SIGNAL \U1|process_5~3_combout\ : std_logic;
SIGNAL \U1|process_5~5_combout\ : std_logic;
SIGNAL \U1|LessThan5~0_combout\ : std_logic;
SIGNAL \U1|process_5~6_combout\ : std_logic;
SIGNAL \U1|process_5~1_combout\ : std_logic;
SIGNAL \U1|process_5~7_combout\ : std_logic;
SIGNAL \U1|process_5~8_combout\ : std_logic;
SIGNAL \U1|LessThan5~1_combout\ : std_logic;
SIGNAL \U1|process_5~9_combout\ : std_logic;
SIGNAL \U1|process_5~10_combout\ : std_logic;
SIGNAL \U1|Selector7~2_combout\ : std_logic;
SIGNAL \U1|Selector6~0_combout\ : std_logic;
SIGNAL \U1|time_done~q\ : std_logic;
SIGNAL \U1|Selector1~0_combout\ : std_logic;
SIGNAL \U1|Selector1~1_combout\ : std_logic;
SIGNAL \U1|current_state.st_start_low_9ms~q\ : std_logic;
SIGNAL \U1|Selector7~0_combout\ : std_logic;
SIGNAL \U1|Selector7~3_combout\ : std_logic;
SIGNAL \U1|error_en~q\ : std_logic;
SIGNAL \U1|Selector2~0_combout\ : std_logic;
SIGNAL \U1|current_state.st_start_judge~q\ : std_logic;
SIGNAL \U1|Selector7~1_combout\ : std_logic;
SIGNAL \U1|judge_flag~0_combout\ : std_logic;
SIGNAL \U1|judge_flag~q\ : std_logic;
SIGNAL \U1|Selector3~0_combout\ : std_logic;
SIGNAL \U1|Selector4~0_combout\ : std_logic;
SIGNAL \U1|current_state.st_repeat_code~q\ : std_logic;
SIGNAL \U1|repeat_en~0_combout\ : std_logic;
SIGNAL \U1|current_state~8_combout\ : std_logic;
SIGNAL \U1|data_cnt[0]~6_combout\ : std_logic;
SIGNAL \U1|data_cnt[0]~18_combout\ : std_logic;
SIGNAL \U1|data_cnt[0]~19_combout\ : std_logic;
SIGNAL \U1|data_cnt[0]~20_combout\ : std_logic;
SIGNAL \U1|data_cnt[0]~7\ : std_logic;
SIGNAL \U1|data_cnt[1]~8_combout\ : std_logic;
SIGNAL \U1|data_cnt[1]~9\ : std_logic;
SIGNAL \U1|data_cnt[2]~10_combout\ : std_logic;
SIGNAL \U1|data_cnt[2]~11\ : std_logic;
SIGNAL \U1|data_cnt[3]~12_combout\ : std_logic;
SIGNAL \U1|data_cnt[3]~13\ : std_logic;
SIGNAL \U1|data_cnt[4]~14_combout\ : std_logic;
SIGNAL \U1|data_cnt[4]~15\ : std_logic;
SIGNAL \U1|data_cnt[5]~16_combout\ : std_logic;
SIGNAL \U1|process_4~0_combout\ : std_logic;
SIGNAL \U1|process_4~1_combout\ : std_logic;
SIGNAL \U1|Selector3~1_combout\ : std_logic;
SIGNAL \U1|current_state.st_rec_data~q\ : std_logic;
SIGNAL \U1|current_state~7_combout\ : std_logic;
SIGNAL \U1|current_state~9_combout\ : std_logic;
SIGNAL \U1|current_state.st_idle~q\ : std_logic;
SIGNAL \U1|Selector5~1_combout\ : std_logic;
SIGNAL \U1|Selector5~0_combout\ : std_logic;
SIGNAL \U1|Selector5~2_combout\ : std_logic;
SIGNAL \U1|time_cnt_clr~q\ : std_logic;
SIGNAL \U1|time_cnt[5]~18_combout\ : std_logic;
SIGNAL \U1|time_cnt[0]~9\ : std_logic;
SIGNAL \U1|time_cnt[1]~10_combout\ : std_logic;
SIGNAL \U1|process_5~2_combout\ : std_logic;
SIGNAL \U1|process_5~0_combout\ : std_logic;
SIGNAL \U1|data_temp~14_combout\ : std_logic;
SIGNAL \U1|data_temp~1_combout\ : std_logic;
SIGNAL \U1|data_temp~13_combout\ : std_logic;
SIGNAL \U1|data_temp~15_combout\ : std_logic;
SIGNAL \U1|data_temp~16_combout\ : std_logic;
SIGNAL \U1|data_temp[12]~2_combout\ : std_logic;
SIGNAL \U1|data_temp[12]~3_combout\ : std_logic;
SIGNAL \U1|data_temp~18_combout\ : std_logic;
SIGNAL \U1|data_temp~20_combout\ : std_logic;
SIGNAL \U1|data_temp~9_combout\ : std_logic;
SIGNAL \U1|data_temp~10_combout\ : std_logic;
SIGNAL \U1|data_temp~5_combout\ : std_logic;
SIGNAL \U1|data_temp~6_combout\ : std_logic;
SIGNAL \U1|data_temp~12_combout\ : std_logic;
SIGNAL \U1|data_temp~11_combout\ : std_logic;
SIGNAL \U1|data_temp~17_combout\ : std_logic;
SIGNAL \U1|data_temp~19_combout\ : std_logic;
SIGNAL \U1|data~11_combout\ : std_logic;
SIGNAL \U1|data_temp~8_combout\ : std_logic;
SIGNAL \U1|data_temp~7_combout\ : std_logic;
SIGNAL \U1|data~4_combout\ : std_logic;
SIGNAL \U1|data~5_combout\ : std_logic;
SIGNAL \U1|Equal2~0_combout\ : std_logic;
SIGNAL \U1|data~6_combout\ : std_logic;
SIGNAL \U1|data_temp~4_combout\ : std_logic;
SIGNAL \U1|data_temp~0_combout\ : std_logic;
SIGNAL \U1|data~1_combout\ : std_logic;
SIGNAL \U1|data~2_combout\ : std_logic;
SIGNAL \U1|data~3_combout\ : std_logic;
SIGNAL \U1|data[7]~7_combout\ : std_logic;
SIGNAL \U1|data~12_combout\ : std_logic;
SIGNAL \U1|data~14_combout\ : std_logic;
SIGNAL \U1|data~13_combout\ : std_logic;
SIGNAL \U3|Mux2~1_combout\ : std_logic;
SIGNAL \U1|data~0_combout\ : std_logic;
SIGNAL \U1|data~10_combout\ : std_logic;
SIGNAL \U1|data~9_combout\ : std_logic;
SIGNAL \U1|data~8_combout\ : std_logic;
SIGNAL \U3|Mux2~0_combout\ : std_logic;
SIGNAL \U3|Mux2~2_combout\ : std_logic;
SIGNAL \U3|segcode1[0]~feeder_combout\ : std_logic;
SIGNAL \U3|segcode1[3]~feeder_combout\ : std_logic;
SIGNAL \U3|Mux1~1_combout\ : std_logic;
SIGNAL \U3|Mux1~0_combout\ : std_logic;
SIGNAL \U3|Mux1~2_combout\ : std_logic;
SIGNAL \U3|segcode1[4]~feeder_combout\ : std_logic;
SIGNAL \U3|segcode1[5]~feeder_combout\ : std_logic;
SIGNAL \U3|Mux9_rtl_0|auto_generated|ram_block1a6\ : std_logic;
SIGNAL \U3|Mux9_rtl_0|auto_generated|ram_block1a0~portadataout\ : std_logic;
SIGNAL \U3|Mux9_rtl_0|auto_generated|ram_block1a1\ : std_logic;
SIGNAL \U3|Mux9_rtl_0|auto_generated|ram_block1a2\ : std_logic;
SIGNAL \U3|Mux9_rtl_0|auto_generated|ram_block1a3\ : std_logic;
SIGNAL \U3|Mux9_rtl_0|auto_generated|ram_block1a4\ : std_logic;
SIGNAL \U3|Mux9_rtl_0|auto_generated|ram_block1a7\ : std_logic;
SIGNAL \U3|Mux9_rtl_0|auto_generated|ram_block1a5\ : std_logic;
SIGNAL \U1|repeat_en~q\ : std_logic;
SIGNAL \U2|repeat_en_d0~0_combout\ : std_logic;
SIGNAL \U2|repeat_en_d0~q\ : std_logic;
SIGNAL \U2|repeat_en_d1~0_combout\ : std_logic;
SIGNAL \U2|repeat_en_d1~q\ : std_logic;
SIGNAL \U2|led_cnt[0]~23_combout\ : std_logic;
SIGNAL \~GND~combout\ : std_logic;
SIGNAL \U2|leds_wire~0_combout\ : std_logic;
SIGNAL \U2|Equal0~6_combout\ : std_logic;
SIGNAL \U2|Equal0~5_combout\ : std_logic;
SIGNAL \U2|Equal0~1_combout\ : std_logic;
SIGNAL \U2|led_cnt[20]~65\ : std_logic;
SIGNAL \U2|led_cnt[21]~66_combout\ : std_logic;
SIGNAL \U2|led_cnt[21]~67\ : std_logic;
SIGNAL \U2|led_cnt[22]~68_combout\ : std_logic;
SIGNAL \U2|Equal0~2_combout\ : std_logic;
SIGNAL \U2|Equal0~3_combout\ : std_logic;
SIGNAL \U2|Equal0~0_combout\ : std_logic;
SIGNAL \U2|Equal0~4_combout\ : std_logic;
SIGNAL \U2|led_cnt[19]~45_combout\ : std_logic;
SIGNAL \U2|led_cnt[0]~24\ : std_logic;
SIGNAL \U2|led_cnt[1]~25_combout\ : std_logic;
SIGNAL \U2|led_cnt[1]~26\ : std_logic;
SIGNAL \U2|led_cnt[2]~27_combout\ : std_logic;
SIGNAL \U2|led_cnt[2]~28\ : std_logic;
SIGNAL \U2|led_cnt[3]~29_combout\ : std_logic;
SIGNAL \U2|led_cnt[3]~30\ : std_logic;
SIGNAL \U2|led_cnt[4]~31_combout\ : std_logic;
SIGNAL \U2|led_cnt[4]~32\ : std_logic;
SIGNAL \U2|led_cnt[5]~33_combout\ : std_logic;
SIGNAL \U2|led_cnt[5]~34\ : std_logic;
SIGNAL \U2|led_cnt[6]~35_combout\ : std_logic;
SIGNAL \U2|led_cnt[6]~36\ : std_logic;
SIGNAL \U2|led_cnt[7]~37_combout\ : std_logic;
SIGNAL \U2|led_cnt[7]~38\ : std_logic;
SIGNAL \U2|led_cnt[8]~39_combout\ : std_logic;
SIGNAL \U2|led_cnt[8]~40\ : std_logic;
SIGNAL \U2|led_cnt[9]~41_combout\ : std_logic;
SIGNAL \U2|led_cnt[9]~42\ : std_logic;
SIGNAL \U2|led_cnt[10]~43_combout\ : std_logic;
SIGNAL \U2|led_cnt[10]~44\ : std_logic;
SIGNAL \U2|led_cnt[11]~46_combout\ : std_logic;
SIGNAL \U2|led_cnt[11]~47\ : std_logic;
SIGNAL \U2|led_cnt[12]~48_combout\ : std_logic;
SIGNAL \U2|led_cnt[12]~49\ : std_logic;
SIGNAL \U2|led_cnt[13]~50_combout\ : std_logic;
SIGNAL \U2|led_cnt[13]~51\ : std_logic;
SIGNAL \U2|led_cnt[14]~52_combout\ : std_logic;
SIGNAL \U2|led_cnt[14]~53\ : std_logic;
SIGNAL \U2|led_cnt[15]~54_combout\ : std_logic;
SIGNAL \U2|led_cnt[15]~55\ : std_logic;
SIGNAL \U2|led_cnt[16]~56_combout\ : std_logic;
SIGNAL \U2|led_cnt[16]~57\ : std_logic;
SIGNAL \U2|led_cnt[17]~58_combout\ : std_logic;
SIGNAL \U2|led_cnt[17]~59\ : std_logic;
SIGNAL \U2|led_cnt[18]~60_combout\ : std_logic;
SIGNAL \U2|led_cnt[18]~61\ : std_logic;
SIGNAL \U2|led_cnt[19]~62_combout\ : std_logic;
SIGNAL \U2|led_cnt[19]~63\ : std_logic;
SIGNAL \U2|led_cnt[20]~64_combout\ : std_logic;
SIGNAL \U2|Equal0~8_combout\ : std_logic;
SIGNAL \U2|led~0_combout\ : std_logic;
SIGNAL \U2|led~1_combout\ : std_logic;
SIGNAL \U2|led~2_combout\ : std_logic;
SIGNAL \U2|Equal0~7_combout\ : std_logic;
SIGNAL \U2|led~3_combout\ : std_logic;
SIGNAL \U2|led~4_combout\ : std_logic;
SIGNAL \U2|led~q\ : std_logic;
SIGNAL \U2|Mux11~17_combout\ : std_logic;
SIGNAL \U2|Mux11~11_combout\ : std_logic;
SIGNAL \U2|Mux11~12_combout\ : std_logic;
SIGNAL \U2|Add1~2_combout\ : std_logic;
SIGNAL \U2|last_leds_wire[11]~0_combout\ : std_logic;
SIGNAL \U2|Add1~3_combout\ : std_logic;
SIGNAL \U2|Add1~5_combout\ : std_logic;
SIGNAL \U2|Add1~0_combout\ : std_logic;
SIGNAL \U2|Mux10~9_combout\ : std_logic;
SIGNAL \U2|Mux8~0_combout\ : std_logic;
SIGNAL \U2|Mux8~1_combout\ : std_logic;
SIGNAL \U2|Mux8~2_combout\ : std_logic;
SIGNAL \U2|Mux11~4_combout\ : std_logic;
SIGNAL \U2|Mux8~3_combout\ : std_logic;
SIGNAL \U2|Mux8~4_combout\ : std_logic;
SIGNAL \U2|Mux8~5_combout\ : std_logic;
SIGNAL \U2|Mux11~7_combout\ : std_logic;
SIGNAL \U2|Mux8~6_combout\ : std_logic;
SIGNAL \U2|Mux7~0_combout\ : std_logic;
SIGNAL \U2|Mux7~2_combout\ : std_logic;
SIGNAL \U2|Mux7~3_combout\ : std_logic;
SIGNAL \U2|Mux11~1_combout\ : std_logic;
SIGNAL \U2|Add1~15_combout\ : std_logic;
SIGNAL \U2|Mux7~1_combout\ : std_logic;
SIGNAL \U2|Mux7~4_combout\ : std_logic;
SIGNAL \U2|Mux7~5_combout\ : std_logic;
SIGNAL \U2|Mux10~11_combout\ : std_logic;
SIGNAL \U2|Mux7~7_combout\ : std_logic;
SIGNAL \U2|Mux6~7_combout\ : std_logic;
SIGNAL \U2|Mux5~1_combout\ : std_logic;
SIGNAL \U2|Mux5~2_combout\ : std_logic;
SIGNAL \U2|Mux5~0_combout\ : std_logic;
SIGNAL \U2|Mux5~3_combout\ : std_logic;
SIGNAL \U2|Mux5~4_combout\ : std_logic;
SIGNAL \U2|Mux5~5_combout\ : std_logic;
SIGNAL \U2|Mux5~6_combout\ : std_logic;
SIGNAL \U2|Add1~24_combout\ : std_logic;
SIGNAL \U2|Mux4~0_combout\ : std_logic;
SIGNAL \U2|Mux11~19_combout\ : std_logic;
SIGNAL \U2|Mux4~1_combout\ : std_logic;
SIGNAL \U2|Mux4~2_combout\ : std_logic;
SIGNAL \U2|Mux4~3_combout\ : std_logic;
SIGNAL \U2|Mux4~4_combout\ : std_logic;
SIGNAL \U2|Mux4~5_combout\ : std_logic;
SIGNAL \U2|Mux4~6_combout\ : std_logic;
SIGNAL \U2|Mux4~7_combout\ : std_logic;
SIGNAL \U2|Add1~27_combout\ : std_logic;
SIGNAL \U2|Mux3~4_combout\ : std_logic;
SIGNAL \U2|Mux3~5_combout\ : std_logic;
SIGNAL \U2|Mux3~6_combout\ : std_logic;
SIGNAL \U2|Mux3~7_combout\ : std_logic;
SIGNAL \U2|Mux3~8_combout\ : std_logic;
SIGNAL \U2|Mux2~3_combout\ : std_logic;
SIGNAL \U2|Mux2~4_combout\ : std_logic;
SIGNAL \U2|Mux2~5_combout\ : std_logic;
SIGNAL \U2|Mux2~6_combout\ : std_logic;
SIGNAL \U2|Mux2~7_combout\ : std_logic;
SIGNAL \U2|Mux2~8_combout\ : std_logic;
SIGNAL \U2|Mux1~12_combout\ : std_logic;
SIGNAL \U2|Mux0~3_combout\ : std_logic;
SIGNAL \U2|Mux0~5_combout\ : std_logic;
SIGNAL \U2|Mux0~12_combout\ : std_logic;
SIGNAL \U2|Mux0~13_combout\ : std_logic;
SIGNAL \U2|Mux0~11_combout\ : std_logic;
SIGNAL \U2|Mux0~4_combout\ : std_logic;
SIGNAL \U2|Mux0~6_combout\ : std_logic;
SIGNAL \U2|Add1~36_combout\ : std_logic;
SIGNAL \U2|Mux0~2_combout\ : std_logic;
SIGNAL \U2|Mux0~7_combout\ : std_logic;
SIGNAL \U2|Add1~7_combout\ : std_logic;
SIGNAL \U2|Add1~4\ : std_logic;
SIGNAL \U2|Add1~9\ : std_logic;
SIGNAL \U2|Add1~11\ : std_logic;
SIGNAL \U2|Add1~14\ : std_logic;
SIGNAL \U2|Add1~17\ : std_logic;
SIGNAL \U2|Add1~20\ : std_logic;
SIGNAL \U2|Add1~23\ : std_logic;
SIGNAL \U2|Add1~26\ : std_logic;
SIGNAL \U2|Add1~29\ : std_logic;
SIGNAL \U2|Add1~32\ : std_logic;
SIGNAL \U2|Add1~35\ : std_logic;
SIGNAL \U2|Add1~37_combout\ : std_logic;
SIGNAL \U2|Mux0~8_combout\ : std_logic;
SIGNAL \U2|Mux0~9_combout\ : std_logic;
SIGNAL \U2|Mux0~10_combout\ : std_logic;
SIGNAL \U2|Mux1~6_combout\ : std_logic;
SIGNAL \U2|Mux1~14_combout\ : std_logic;
SIGNAL \U2|Mux1~7_combout\ : std_logic;
SIGNAL \U2|Mux1~4_combout\ : std_logic;
SIGNAL \U2|Mux1~5_combout\ : std_logic;
SIGNAL \U2|Mux1~8_combout\ : std_logic;
SIGNAL \U2|Add1~33_combout\ : std_logic;
SIGNAL \U2|Mux1~9_combout\ : std_logic;
SIGNAL \U2|Add1~34_combout\ : std_logic;
SIGNAL \U2|Mux1~10_combout\ : std_logic;
SIGNAL \U2|Mux1~11_combout\ : std_logic;
SIGNAL \U2|Mux1~13_combout\ : std_logic;
SIGNAL \U2|Mux2~16_combout\ : std_logic;
SIGNAL \U2|Mux2~10_combout\ : std_logic;
SIGNAL \U2|Mux2~11_combout\ : std_logic;
SIGNAL \U2|Mux2~9_combout\ : std_logic;
SIGNAL \U2|Add1~30_combout\ : std_logic;
SIGNAL \U2|Mux2~12_combout\ : std_logic;
SIGNAL \U2|Mux10~15_combout\ : std_logic;
SIGNAL \U2|Add1~31_combout\ : std_logic;
SIGNAL \U2|Mux2~13_combout\ : std_logic;
SIGNAL \U2|Mux2~14_combout\ : std_logic;
SIGNAL \U2|Mux2~15_combout\ : std_logic;
SIGNAL \U2|Mux3~16_combout\ : std_logic;
SIGNAL \U2|Mux3~10_combout\ : std_logic;
SIGNAL \U2|Mux3~9_combout\ : std_logic;
SIGNAL \U2|Mux3~11_combout\ : std_logic;
SIGNAL \U2|Mux3~12_combout\ : std_logic;
SIGNAL \U2|Mux3~13_combout\ : std_logic;
SIGNAL \U2|Add1~28_combout\ : std_logic;
SIGNAL \U2|Mux3~17_combout\ : std_logic;
SIGNAL \U2|Mux3~14_combout\ : std_logic;
SIGNAL \U2|Mux3~15_combout\ : std_logic;
SIGNAL \U2|Mux2~2_combout\ : std_logic;
SIGNAL \U2|Mux4~8_combout\ : std_logic;
SIGNAL \U2|Mux4~9_combout\ : std_logic;
SIGNAL \U2|Mux4~10_combout\ : std_logic;
SIGNAL \U2|Add1~25_combout\ : std_logic;
SIGNAL \U2|Mux4~11_combout\ : std_logic;
SIGNAL \U2|Mux4~12_combout\ : std_logic;
SIGNAL \U2|Mux4~13_combout\ : std_logic;
SIGNAL \U2|Mux5~7_combout\ : std_logic;
SIGNAL \U2|Mux5~8_combout\ : std_logic;
SIGNAL \U2|Mux10~13_combout\ : std_logic;
SIGNAL \U2|Mux5~9_combout\ : std_logic;
SIGNAL \U2|Add1~21_combout\ : std_logic;
SIGNAL \U2|Add1~22_combout\ : std_logic;
SIGNAL \U2|Mux5~10_combout\ : std_logic;
SIGNAL \U2|Mux5~11_combout\ : std_logic;
SIGNAL \U2|Mux5~12_combout\ : std_logic;
SIGNAL \U2|Mux6~6_combout\ : std_logic;
SIGNAL \U2|Mux6~8_combout\ : std_logic;
SIGNAL \U2|Add1~18_combout\ : std_logic;
SIGNAL \U2|Add1~19_combout\ : std_logic;
SIGNAL \U2|Mux6~9_combout\ : std_logic;
SIGNAL \U2|Mux6~10_combout\ : std_logic;
SIGNAL \U2|Mux10~3_combout\ : std_logic;
SIGNAL \U2|Mux6~1_combout\ : std_logic;
SIGNAL \U2|Mux6~0_combout\ : std_logic;
SIGNAL \U2|Mux6~2_combout\ : std_logic;
SIGNAL \U2|Mux6~3_combout\ : std_logic;
SIGNAL \U2|Mux6~4_combout\ : std_logic;
SIGNAL \U2|Mux6~5_combout\ : std_logic;
SIGNAL \U2|Mux6~11_combout\ : std_logic;
SIGNAL \U2|Mux7~6_combout\ : std_logic;
SIGNAL \U2|Mux7~8_combout\ : std_logic;
SIGNAL \U2|Add1~16_combout\ : std_logic;
SIGNAL \U2|Mux7~9_combout\ : std_logic;
SIGNAL \U2|Mux7~10_combout\ : std_logic;
SIGNAL \U2|Mux7~11_combout\ : std_logic;
SIGNAL \U2|Mux8~7_combout\ : std_logic;
SIGNAL \U2|Mux8~8_combout\ : std_logic;
SIGNAL \U2|Mux8~9_combout\ : std_logic;
SIGNAL \U2|Add1~12_combout\ : std_logic;
SIGNAL \U2|Add1~13_combout\ : std_logic;
SIGNAL \U2|Mux8~10_combout\ : std_logic;
SIGNAL \U2|Mux8~11_combout\ : std_logic;
SIGNAL \U2|Mux8~12_combout\ : std_logic;
SIGNAL \U2|Mux9~9_combout\ : std_logic;
SIGNAL \U2|Mux9~10_combout\ : std_logic;
SIGNAL \U2|Mux9~11_combout\ : std_logic;
SIGNAL \U2|Mux9~12_combout\ : std_logic;
SIGNAL \U2|Add1~10_combout\ : std_logic;
SIGNAL \U2|Mux9~15_combout\ : std_logic;
SIGNAL \U2|Mux9~13_combout\ : std_logic;
SIGNAL \U2|Mux9~2_combout\ : std_logic;
SIGNAL \U2|Mux9~3_combout\ : std_logic;
SIGNAL \U2|Mux9~4_combout\ : std_logic;
SIGNAL \U2|Mux9~5_combout\ : std_logic;
SIGNAL \U2|Mux9~6_combout\ : std_logic;
SIGNAL \U2|Mux9~7_combout\ : std_logic;
SIGNAL \U2|Mux9~8_combout\ : std_logic;
SIGNAL \U2|Mux9~14_combout\ : std_logic;
SIGNAL \U2|Mux10~10_combout\ : std_logic;
SIGNAL \U2|Mux10~12_combout\ : std_logic;
SIGNAL \U2|Add1~6_combout\ : std_logic;
SIGNAL \U2|Mux10~14_combout\ : std_logic;
SIGNAL \U2|Add1~8_combout\ : std_logic;
SIGNAL \U2|Mux10~16_combout\ : std_logic;
SIGNAL \U2|Mux10~17_combout\ : std_logic;
SIGNAL \U2|Mux10~2_combout\ : std_logic;
SIGNAL \U2|Mux10~4_combout\ : std_logic;
SIGNAL \U2|Mux10~19_combout\ : std_logic;
SIGNAL \U2|Mux10~5_combout\ : std_logic;
SIGNAL \U2|Mux10~6_combout\ : std_logic;
SIGNAL \U2|Mux10~7_combout\ : std_logic;
SIGNAL \U2|Mux10~8_combout\ : std_logic;
SIGNAL \U2|Mux10~18_combout\ : std_logic;
SIGNAL \U2|Add1~1_combout\ : std_logic;
SIGNAL \U2|Mux11~9_combout\ : std_logic;
SIGNAL \U2|Mux11~10_combout\ : std_logic;
SIGNAL \U2|Mux11~13_combout\ : std_logic;
SIGNAL \U2|Mux11~14_combout\ : std_logic;
SIGNAL \U2|Mux11~15_combout\ : std_logic;
SIGNAL \U2|Mux11~16_combout\ : std_logic;
SIGNAL \U2|Mux11~0_combout\ : std_logic;
SIGNAL \U2|Mux11~3_combout\ : std_logic;
SIGNAL \U2|Mux11~5_combout\ : std_logic;
SIGNAL \U2|Mux11~2_combout\ : std_logic;
SIGNAL \U2|Mux11~6_combout\ : std_logic;
SIGNAL \U2|Mux11~8_combout\ : std_logic;
SIGNAL \U2|Mux11~18_combout\ : std_logic;
SIGNAL \U2|leds_wire\ : std_logic_vector(11 DOWNTO 0);
SIGNAL \U3|segcode1\ : std_logic_vector(6 DOWNTO 0);
SIGNAL \U2|led_cnt\ : std_logic_vector(22 DOWNTO 0);
SIGNAL \U1|data_cnt\ : std_logic_vector(5 DOWNTO 0);
SIGNAL \U1|data_temp\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \U1|time_cnt\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \U1|data\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \U2|last_leds_wire\ : std_logic_vector(11 DOWNTO 0);
SIGNAL \U1|div_cnt\ : std_logic_vector(11 DOWNTO 0);
SIGNAL \ALT_INV_sys_rst_n_in~input_o\ : std_logic;

COMPONENT hard_block
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic);
END COMPONENT;

BEGIN

ww_sys_clk <= sys_clk;
ww_sys_rst_n_in <= sys_rst_n_in;
ww_remote_in <= remote_in;
segcode1out <= ww_segcode1out;
segcode0out <= ww_segcode0out;
led <= ww_led;
leds_out <= ww_leds_out;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\U3|Mux9_rtl_0|auto_generated|ram_block1a0_PORTAADDR_bus\ <= (\U1|data\(7) & \U1|data\(6) & \U1|data\(5) & \U1|data\(4) & \U1|data\(3) & \U1|data\(2) & \U1|data\(1) & \U1|data\(0));

\U3|Mux9_rtl_0|auto_generated|ram_block1a0~portadataout\ <= \U3|Mux9_rtl_0|auto_generated|ram_block1a0_PORTADATAOUT_bus\(0);
\U3|Mux9_rtl_0|auto_generated|ram_block1a1\ <= \U3|Mux9_rtl_0|auto_generated|ram_block1a0_PORTADATAOUT_bus\(1);
\U3|Mux9_rtl_0|auto_generated|ram_block1a2\ <= \U3|Mux9_rtl_0|auto_generated|ram_block1a0_PORTADATAOUT_bus\(2);
\U3|Mux9_rtl_0|auto_generated|ram_block1a3\ <= \U3|Mux9_rtl_0|auto_generated|ram_block1a0_PORTADATAOUT_bus\(3);
\U3|Mux9_rtl_0|auto_generated|ram_block1a4\ <= \U3|Mux9_rtl_0|auto_generated|ram_block1a0_PORTADATAOUT_bus\(4);
\U3|Mux9_rtl_0|auto_generated|ram_block1a5\ <= \U3|Mux9_rtl_0|auto_generated|ram_block1a0_PORTADATAOUT_bus\(5);
\U3|Mux9_rtl_0|auto_generated|ram_block1a6\ <= \U3|Mux9_rtl_0|auto_generated|ram_block1a0_PORTADATAOUT_bus\(6);
\U3|Mux9_rtl_0|auto_generated|ram_block1a7\ <= \U3|Mux9_rtl_0|auto_generated|ram_block1a0_PORTADATAOUT_bus\(7);

\sys_clk~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \sys_clk~input_o\);

\U1|div_clk~clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \U1|div_clk~q\);
\ALT_INV_sys_rst_n_in~input_o\ <= NOT \sys_rst_n_in~input_o\;
auto_generated_inst : hard_block
PORT MAP (
	devoe => ww_devoe,
	devclrn => ww_devclrn,
	devpor => ww_devpor);

-- Location: IOOBUF_X115_Y25_N16
\segcode1out[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U3|segcode1\(0),
	devoe => ww_devoe,
	o => \segcode1out[0]~output_o\);

-- Location: IOOBUF_X115_Y29_N2
\segcode1out[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \segcode1out[1]~output_o\);

-- Location: IOOBUF_X100_Y0_N2
\segcode1out[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \segcode1out[2]~output_o\);

-- Location: IOOBUF_X111_Y0_N2
\segcode1out[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U3|segcode1\(3),
	devoe => ww_devoe,
	o => \segcode1out[3]~output_o\);

-- Location: IOOBUF_X105_Y0_N23
\segcode1out[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U3|segcode1\(4),
	devoe => ww_devoe,
	o => \segcode1out[4]~output_o\);

-- Location: IOOBUF_X105_Y0_N9
\segcode1out[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U3|segcode1\(5),
	devoe => ww_devoe,
	o => \segcode1out[5]~output_o\);

-- Location: IOOBUF_X105_Y0_N2
\segcode1out[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U3|Mux9_rtl_0|auto_generated|ram_block1a6\,
	devoe => ww_devoe,
	o => \segcode1out[6]~output_o\);

-- Location: IOOBUF_X115_Y17_N9
\segcode0out[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U3|Mux9_rtl_0|auto_generated|ram_block1a0~portadataout\,
	devoe => ww_devoe,
	o => \segcode0out[0]~output_o\);

-- Location: IOOBUF_X115_Y16_N2
\segcode0out[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U3|Mux9_rtl_0|auto_generated|ram_block1a1\,
	devoe => ww_devoe,
	o => \segcode0out[1]~output_o\);

-- Location: IOOBUF_X115_Y19_N9
\segcode0out[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U3|Mux9_rtl_0|auto_generated|ram_block1a2\,
	devoe => ww_devoe,
	o => \segcode0out[2]~output_o\);

-- Location: IOOBUF_X115_Y19_N2
\segcode0out[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U3|Mux9_rtl_0|auto_generated|ram_block1a3\,
	devoe => ww_devoe,
	o => \segcode0out[3]~output_o\);

-- Location: IOOBUF_X115_Y18_N2
\segcode0out[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U3|Mux9_rtl_0|auto_generated|ram_block1a4\,
	devoe => ww_devoe,
	o => \segcode0out[4]~output_o\);

-- Location: IOOBUF_X115_Y20_N2
\segcode0out[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U3|Mux9_rtl_0|auto_generated|ram_block1a7\,
	devoe => ww_devoe,
	o => \segcode0out[5]~output_o\);

-- Location: IOOBUF_X115_Y21_N16
\segcode0out[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U3|Mux9_rtl_0|auto_generated|ram_block1a5\,
	devoe => ww_devoe,
	o => \segcode0out[6]~output_o\);

-- Location: IOOBUF_X65_Y73_N16
\led~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|led~q\,
	devoe => ww_devoe,
	o => \led~output_o\);

-- Location: IOOBUF_X69_Y73_N16
\leds_out[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|leds_wire\(0),
	devoe => ww_devoe,
	o => \leds_out[0]~output_o\);

-- Location: IOOBUF_X94_Y73_N2
\leds_out[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|leds_wire\(1),
	devoe => ww_devoe,
	o => \leds_out[1]~output_o\);

-- Location: IOOBUF_X94_Y73_N9
\leds_out[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|leds_wire\(2),
	devoe => ww_devoe,
	o => \leds_out[2]~output_o\);

-- Location: IOOBUF_X107_Y73_N16
\leds_out[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|leds_wire\(3),
	devoe => ww_devoe,
	o => \leds_out[3]~output_o\);

-- Location: IOOBUF_X87_Y73_N16
\leds_out[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|leds_wire\(4),
	devoe => ww_devoe,
	o => \leds_out[4]~output_o\);

-- Location: IOOBUF_X87_Y73_N9
\leds_out[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|leds_wire\(5),
	devoe => ww_devoe,
	o => \leds_out[5]~output_o\);

-- Location: IOOBUF_X72_Y73_N9
\leds_out[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|leds_wire\(6),
	devoe => ww_devoe,
	o => \leds_out[6]~output_o\);

-- Location: IOOBUF_X72_Y73_N2
\leds_out[7]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|leds_wire\(7),
	devoe => ww_devoe,
	o => \leds_out[7]~output_o\);

-- Location: IOOBUF_X69_Y73_N2
\leds_out[8]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|leds_wire\(8),
	devoe => ww_devoe,
	o => \leds_out[8]~output_o\);

-- Location: IOOBUF_X83_Y73_N23
\leds_out[9]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|leds_wire\(9),
	devoe => ww_devoe,
	o => \leds_out[9]~output_o\);

-- Location: IOOBUF_X60_Y73_N23
\leds_out[10]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|leds_wire\(10),
	devoe => ww_devoe,
	o => \leds_out[10]~output_o\);

-- Location: IOOBUF_X65_Y73_N23
\leds_out[11]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|leds_wire\(11),
	devoe => ww_devoe,
	o => \leds_out[11]~output_o\);

-- Location: IOIBUF_X0_Y36_N15
\sys_clk~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sys_clk,
	o => \sys_clk~input_o\);

-- Location: CLKCTRL_G4
\sys_clk~inputclkctrl\ : cycloneive_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \sys_clk~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \sys_clk~inputclkctrl_outclk\);

-- Location: LCCOMB_X55_Y72_N18
\U1|Add0~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Add0~14_combout\ = (\U1|div_cnt\(7) & (!\U1|Add0~13\)) # (!\U1|div_cnt\(7) & ((\U1|Add0~13\) # (GND)))
-- \U1|Add0~15\ = CARRY((!\U1|Add0~13\) # (!\U1|div_cnt\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U1|div_cnt\(7),
	datad => VCC,
	cin => \U1|Add0~13\,
	combout => \U1|Add0~14_combout\,
	cout => \U1|Add0~15\);

-- Location: LCCOMB_X55_Y72_N20
\U1|Add0~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Add0~16_combout\ = (\U1|div_cnt\(8) & (\U1|Add0~15\ $ (GND))) # (!\U1|div_cnt\(8) & (!\U1|Add0~15\ & VCC))
-- \U1|Add0~17\ = CARRY((\U1|div_cnt\(8) & !\U1|Add0~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U1|div_cnt\(8),
	datad => VCC,
	cin => \U1|Add0~15\,
	combout => \U1|Add0~16_combout\,
	cout => \U1|Add0~17\);

-- Location: FF_X55_Y72_N21
\U1|div_cnt[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U1|Add0~16_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|div_cnt\(8));

-- Location: LCCOMB_X55_Y72_N22
\U1|Add0~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Add0~18_combout\ = (\U1|div_cnt\(9) & (!\U1|Add0~17\)) # (!\U1|div_cnt\(9) & ((\U1|Add0~17\) # (GND)))
-- \U1|Add0~19\ = CARRY((!\U1|Add0~17\) # (!\U1|div_cnt\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U1|div_cnt\(9),
	datad => VCC,
	cin => \U1|Add0~17\,
	combout => \U1|Add0~18_combout\,
	cout => \U1|Add0~19\);

-- Location: FF_X55_Y72_N23
\U1|div_cnt[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U1|Add0~18_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|div_cnt\(9));

-- Location: LCCOMB_X55_Y72_N24
\U1|Add0~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Add0~20_combout\ = (\U1|div_cnt\(10) & (\U1|Add0~19\ $ (GND))) # (!\U1|div_cnt\(10) & (!\U1|Add0~19\ & VCC))
-- \U1|Add0~21\ = CARRY((\U1|div_cnt\(10) & !\U1|Add0~19\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U1|div_cnt\(10),
	datad => VCC,
	cin => \U1|Add0~19\,
	combout => \U1|Add0~20_combout\,
	cout => \U1|Add0~21\);

-- Location: LCCOMB_X55_Y72_N2
\U1|div_cnt~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|div_cnt~4_combout\ = (\U1|Add0~20_combout\ & (((!\U1|Equal0~0_combout\) # (!\U1|Equal0~2_combout\)) # (!\U1|Equal0~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|Equal0~1_combout\,
	datab => \U1|Equal0~2_combout\,
	datac => \U1|Equal0~0_combout\,
	datad => \U1|Add0~20_combout\,
	combout => \U1|div_cnt~4_combout\);

-- Location: FF_X55_Y72_N3
\U1|div_cnt[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U1|div_cnt~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|div_cnt\(10));

-- Location: LCCOMB_X55_Y72_N26
\U1|Add0~22\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Add0~22_combout\ = \U1|Add0~21\ $ (\U1|div_cnt\(11))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \U1|div_cnt\(11),
	cin => \U1|Add0~21\,
	combout => \U1|Add0~22_combout\);

-- Location: LCCOMB_X56_Y72_N26
\U1|div_cnt~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|div_cnt~5_combout\ = (\U1|Add0~22_combout\ & (((!\U1|Equal0~1_combout\) # (!\U1|Equal0~2_combout\)) # (!\U1|Equal0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|Equal0~0_combout\,
	datab => \U1|Equal0~2_combout\,
	datac => \U1|Add0~22_combout\,
	datad => \U1|Equal0~1_combout\,
	combout => \U1|div_cnt~5_combout\);

-- Location: FF_X56_Y72_N27
\U1|div_cnt[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U1|div_cnt~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|div_cnt\(11));

-- Location: LCCOMB_X56_Y72_N28
\U1|Equal0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Equal0~2_combout\ = (\U1|div_cnt\(10) & (!\U1|div_cnt\(9) & (\U1|div_cnt\(11) & !\U1|div_cnt\(8))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|div_cnt\(10),
	datab => \U1|div_cnt\(9),
	datac => \U1|div_cnt\(11),
	datad => \U1|div_cnt\(8),
	combout => \U1|Equal0~2_combout\);

-- Location: LCCOMB_X55_Y72_N4
\U1|Add0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Add0~0_combout\ = \U1|div_cnt\(0) $ (VCC)
-- \U1|Add0~1\ = CARRY(\U1|div_cnt\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|div_cnt\(0),
	datad => VCC,
	combout => \U1|Add0~0_combout\,
	cout => \U1|Add0~1\);

-- Location: LCCOMB_X55_Y72_N6
\U1|Add0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Add0~2_combout\ = (\U1|div_cnt\(1) & (!\U1|Add0~1\)) # (!\U1|div_cnt\(1) & ((\U1|Add0~1\) # (GND)))
-- \U1|Add0~3\ = CARRY((!\U1|Add0~1\) # (!\U1|div_cnt\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U1|div_cnt\(1),
	datad => VCC,
	cin => \U1|Add0~1\,
	combout => \U1|Add0~2_combout\,
	cout => \U1|Add0~3\);

-- Location: FF_X55_Y72_N7
\U1|div_cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U1|Add0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|div_cnt\(1));

-- Location: LCCOMB_X55_Y72_N8
\U1|Add0~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Add0~4_combout\ = (\U1|div_cnt\(2) & (\U1|Add0~3\ $ (GND))) # (!\U1|div_cnt\(2) & (!\U1|Add0~3\ & VCC))
-- \U1|Add0~5\ = CARRY((\U1|div_cnt\(2) & !\U1|Add0~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U1|div_cnt\(2),
	datad => VCC,
	cin => \U1|Add0~3\,
	combout => \U1|Add0~4_combout\,
	cout => \U1|Add0~5\);

-- Location: LCCOMB_X56_Y72_N2
\U1|div_cnt~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|div_cnt~0_combout\ = (\U1|Add0~4_combout\ & (((!\U1|Equal0~1_combout\) # (!\U1|Equal0~2_combout\)) # (!\U1|Equal0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|Equal0~0_combout\,
	datab => \U1|Equal0~2_combout\,
	datac => \U1|Equal0~1_combout\,
	datad => \U1|Add0~4_combout\,
	combout => \U1|div_cnt~0_combout\);

-- Location: FF_X56_Y72_N3
\U1|div_cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U1|div_cnt~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|div_cnt\(2));

-- Location: LCCOMB_X55_Y72_N10
\U1|Add0~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Add0~6_combout\ = (\U1|div_cnt\(3) & (!\U1|Add0~5\)) # (!\U1|div_cnt\(3) & ((\U1|Add0~5\) # (GND)))
-- \U1|Add0~7\ = CARRY((!\U1|Add0~5\) # (!\U1|div_cnt\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U1|div_cnt\(3),
	datad => VCC,
	cin => \U1|Add0~5\,
	combout => \U1|Add0~6_combout\,
	cout => \U1|Add0~7\);

-- Location: FF_X55_Y72_N11
\U1|div_cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U1|Add0~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|div_cnt\(3));

-- Location: LCCOMB_X55_Y72_N12
\U1|Add0~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Add0~8_combout\ = (\U1|div_cnt\(4) & (\U1|Add0~7\ $ (GND))) # (!\U1|div_cnt\(4) & (!\U1|Add0~7\ & VCC))
-- \U1|Add0~9\ = CARRY((\U1|div_cnt\(4) & !\U1|Add0~7\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U1|div_cnt\(4),
	datad => VCC,
	cin => \U1|Add0~7\,
	combout => \U1|Add0~8_combout\,
	cout => \U1|Add0~9\);

-- Location: LCCOMB_X55_Y72_N30
\U1|div_cnt~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|div_cnt~2_combout\ = (\U1|Add0~8_combout\ & (((!\U1|Equal0~2_combout\) # (!\U1|Equal0~0_combout\)) # (!\U1|Equal0~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|Add0~8_combout\,
	datab => \U1|Equal0~1_combout\,
	datac => \U1|Equal0~0_combout\,
	datad => \U1|Equal0~2_combout\,
	combout => \U1|div_cnt~2_combout\);

-- Location: FF_X55_Y72_N31
\U1|div_cnt[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U1|div_cnt~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|div_cnt\(4));

-- Location: LCCOMB_X55_Y72_N14
\U1|Add0~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Add0~10_combout\ = (\U1|div_cnt\(5) & (!\U1|Add0~9\)) # (!\U1|div_cnt\(5) & ((\U1|Add0~9\) # (GND)))
-- \U1|Add0~11\ = CARRY((!\U1|Add0~9\) # (!\U1|div_cnt\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U1|div_cnt\(5),
	datad => VCC,
	cin => \U1|Add0~9\,
	combout => \U1|Add0~10_combout\,
	cout => \U1|Add0~11\);

-- Location: LCCOMB_X55_Y72_N28
\U1|div_cnt~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|div_cnt~3_combout\ = (\U1|Add0~10_combout\ & (((!\U1|Equal0~2_combout\) # (!\U1|Equal0~0_combout\)) # (!\U1|Equal0~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|Equal0~1_combout\,
	datab => \U1|Equal0~0_combout\,
	datac => \U1|Add0~10_combout\,
	datad => \U1|Equal0~2_combout\,
	combout => \U1|div_cnt~3_combout\);

-- Location: FF_X55_Y72_N29
\U1|div_cnt[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U1|div_cnt~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|div_cnt\(5));

-- Location: LCCOMB_X55_Y72_N16
\U1|Add0~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Add0~12_combout\ = (\U1|div_cnt\(6) & (\U1|Add0~11\ $ (GND))) # (!\U1|div_cnt\(6) & (!\U1|Add0~11\ & VCC))
-- \U1|Add0~13\ = CARRY((\U1|div_cnt\(6) & !\U1|Add0~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U1|div_cnt\(6),
	datad => VCC,
	cin => \U1|Add0~11\,
	combout => \U1|Add0~12_combout\,
	cout => \U1|Add0~13\);

-- Location: FF_X55_Y72_N17
\U1|div_cnt[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U1|Add0~12_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|div_cnt\(6));

-- Location: FF_X55_Y72_N19
\U1|div_cnt[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U1|Add0~14_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|div_cnt\(7));

-- Location: LCCOMB_X56_Y72_N10
\U1|Equal0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Equal0~1_combout\ = (!\U1|div_cnt\(7) & (\U1|div_cnt\(5) & (!\U1|div_cnt\(6) & \U1|div_cnt\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|div_cnt\(7),
	datab => \U1|div_cnt\(5),
	datac => \U1|div_cnt\(6),
	datad => \U1|div_cnt\(4),
	combout => \U1|Equal0~1_combout\);

-- Location: LCCOMB_X55_Y72_N0
\U1|div_cnt~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|div_cnt~1_combout\ = (\U1|Add0~0_combout\ & (((!\U1|Equal0~2_combout\) # (!\U1|Equal0~0_combout\)) # (!\U1|Equal0~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|Equal0~1_combout\,
	datab => \U1|Equal0~0_combout\,
	datac => \U1|Add0~0_combout\,
	datad => \U1|Equal0~2_combout\,
	combout => \U1|div_cnt~1_combout\);

-- Location: FF_X55_Y72_N1
\U1|div_cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U1|div_cnt~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|div_cnt\(0));

-- Location: LCCOMB_X56_Y72_N12
\U1|Equal0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Equal0~0_combout\ = (!\U1|div_cnt\(0) & (\U1|div_cnt\(2) & (!\U1|div_cnt\(1) & !\U1|div_cnt\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|div_cnt\(0),
	datab => \U1|div_cnt\(2),
	datac => \U1|div_cnt\(1),
	datad => \U1|div_cnt\(3),
	combout => \U1|Equal0~0_combout\);

-- Location: LCCOMB_X56_Y72_N18
\U1|div_clk~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|div_clk~0_combout\ = \U1|div_clk~q\ $ (((\U1|Equal0~0_combout\ & (\U1|Equal0~2_combout\ & \U1|Equal0~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|Equal0~0_combout\,
	datab => \U1|Equal0~2_combout\,
	datac => \U1|div_clk~q\,
	datad => \U1|Equal0~1_combout\,
	combout => \U1|div_clk~0_combout\);

-- Location: LCCOMB_X56_Y72_N22
\U1|div_clk~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|div_clk~feeder_combout\ = \U1|div_clk~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|div_clk~0_combout\,
	combout => \U1|div_clk~feeder_combout\);

-- Location: FF_X56_Y72_N23
\U1|div_clk\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U1|div_clk~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|div_clk~q\);

-- Location: CLKCTRL_G14
\U1|div_clk~clkctrl\ : cycloneive_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \U1|div_clk~clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \U1|div_clk~clkctrl_outclk\);

-- Location: IOIBUF_X56_Y0_N1
\remote_in~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_remote_in,
	o => \remote_in~input_o\);

-- Location: IOIBUF_X115_Y14_N8
\sys_rst_n_in~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sys_rst_n_in,
	o => \sys_rst_n_in~input_o\);

-- Location: LCCOMB_X105_Y16_N4
\U1|remote_in_d0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|remote_in_d0~0_combout\ = (\remote_in~input_o\ & \sys_rst_n_in~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \remote_in~input_o\,
	datad => \sys_rst_n_in~input_o\,
	combout => \U1|remote_in_d0~0_combout\);

-- Location: FF_X105_Y16_N5
\U1|remote_in_d0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|remote_in_d0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|remote_in_d0~q\);

-- Location: LCCOMB_X105_Y16_N2
\U1|remote_in_d1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|remote_in_d1~0_combout\ = (\U1|remote_in_d0~q\ & \sys_rst_n_in~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|remote_in_d0~q\,
	datad => \sys_rst_n_in~input_o\,
	combout => \U1|remote_in_d1~0_combout\);

-- Location: FF_X105_Y16_N3
\U1|remote_in_d1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|remote_in_d1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|remote_in_d1~q\);

-- Location: LCCOMB_X105_Y16_N12
\U1|pos_remote_in\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|pos_remote_in~combout\ = (\U1|remote_in_d0~q\ & !\U1|remote_in_d1~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|remote_in_d0~q\,
	datad => \U1|remote_in_d1~q\,
	combout => \U1|pos_remote_in~combout\);

-- Location: LCCOMB_X107_Y16_N8
\U1|time_cnt[0]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|time_cnt[0]~8_combout\ = \U1|time_cnt\(0) $ (VCC)
-- \U1|time_cnt[0]~9\ = CARRY(\U1|time_cnt\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|time_cnt\(0),
	datad => VCC,
	combout => \U1|time_cnt[0]~8_combout\,
	cout => \U1|time_cnt[0]~9\);

-- Location: LCCOMB_X107_Y16_N10
\U1|time_cnt[1]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|time_cnt[1]~10_combout\ = (\U1|time_cnt\(1) & (!\U1|time_cnt[0]~9\)) # (!\U1|time_cnt\(1) & ((\U1|time_cnt[0]~9\) # (GND)))
-- \U1|time_cnt[1]~11\ = CARRY((!\U1|time_cnt[0]~9\) # (!\U1|time_cnt\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U1|time_cnt\(1),
	datad => VCC,
	cin => \U1|time_cnt[0]~9\,
	combout => \U1|time_cnt[1]~10_combout\,
	cout => \U1|time_cnt[1]~11\);

-- Location: LCCOMB_X107_Y16_N12
\U1|time_cnt[2]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|time_cnt[2]~12_combout\ = (\U1|time_cnt\(2) & (\U1|time_cnt[1]~11\ $ (GND))) # (!\U1|time_cnt\(2) & (!\U1|time_cnt[1]~11\ & VCC))
-- \U1|time_cnt[2]~13\ = CARRY((\U1|time_cnt\(2) & !\U1|time_cnt[1]~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U1|time_cnt\(2),
	datad => VCC,
	cin => \U1|time_cnt[1]~11\,
	combout => \U1|time_cnt[2]~12_combout\,
	cout => \U1|time_cnt[2]~13\);

-- Location: FF_X107_Y16_N13
\U1|time_cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|time_cnt[2]~12_combout\,
	sclr => \U1|time_cnt[5]~18_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|time_cnt\(2));

-- Location: LCCOMB_X107_Y16_N14
\U1|time_cnt[3]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|time_cnt[3]~14_combout\ = (\U1|time_cnt\(3) & (!\U1|time_cnt[2]~13\)) # (!\U1|time_cnt\(3) & ((\U1|time_cnt[2]~13\) # (GND)))
-- \U1|time_cnt[3]~15\ = CARRY((!\U1|time_cnt[2]~13\) # (!\U1|time_cnt\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U1|time_cnt\(3),
	datad => VCC,
	cin => \U1|time_cnt[2]~13\,
	combout => \U1|time_cnt[3]~14_combout\,
	cout => \U1|time_cnt[3]~15\);

-- Location: FF_X107_Y16_N15
\U1|time_cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|time_cnt[3]~14_combout\,
	sclr => \U1|time_cnt[5]~18_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|time_cnt\(3));

-- Location: LCCOMB_X107_Y16_N16
\U1|time_cnt[4]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|time_cnt[4]~16_combout\ = (\U1|time_cnt\(4) & (\U1|time_cnt[3]~15\ $ (GND))) # (!\U1|time_cnt\(4) & (!\U1|time_cnt[3]~15\ & VCC))
-- \U1|time_cnt[4]~17\ = CARRY((\U1|time_cnt\(4) & !\U1|time_cnt[3]~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U1|time_cnt\(4),
	datad => VCC,
	cin => \U1|time_cnt[3]~15\,
	combout => \U1|time_cnt[4]~16_combout\,
	cout => \U1|time_cnt[4]~17\);

-- Location: FF_X107_Y16_N17
\U1|time_cnt[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|time_cnt[4]~16_combout\,
	sclr => \U1|time_cnt[5]~18_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|time_cnt\(4));

-- Location: LCCOMB_X107_Y16_N18
\U1|time_cnt[5]~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|time_cnt[5]~19_combout\ = (\U1|time_cnt\(5) & (!\U1|time_cnt[4]~17\)) # (!\U1|time_cnt\(5) & ((\U1|time_cnt[4]~17\) # (GND)))
-- \U1|time_cnt[5]~20\ = CARRY((!\U1|time_cnt[4]~17\) # (!\U1|time_cnt\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U1|time_cnt\(5),
	datad => VCC,
	cin => \U1|time_cnt[4]~17\,
	combout => \U1|time_cnt[5]~19_combout\,
	cout => \U1|time_cnt[5]~20\);

-- Location: FF_X107_Y16_N19
\U1|time_cnt[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|time_cnt[5]~19_combout\,
	sclr => \U1|time_cnt[5]~18_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|time_cnt\(5));

-- Location: LCCOMB_X107_Y16_N20
\U1|time_cnt[6]~21\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|time_cnt[6]~21_combout\ = (\U1|time_cnt\(6) & (\U1|time_cnt[5]~20\ $ (GND))) # (!\U1|time_cnt\(6) & (!\U1|time_cnt[5]~20\ & VCC))
-- \U1|time_cnt[6]~22\ = CARRY((\U1|time_cnt\(6) & !\U1|time_cnt[5]~20\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U1|time_cnt\(6),
	datad => VCC,
	cin => \U1|time_cnt[5]~20\,
	combout => \U1|time_cnt[6]~21_combout\,
	cout => \U1|time_cnt[6]~22\);

-- Location: FF_X107_Y16_N21
\U1|time_cnt[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|time_cnt[6]~21_combout\,
	sclr => \U1|time_cnt[5]~18_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|time_cnt\(6));

-- Location: LCCOMB_X107_Y16_N22
\U1|time_cnt[7]~23\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|time_cnt[7]~23_combout\ = \U1|time_cnt[6]~22\ $ (\U1|time_cnt\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \U1|time_cnt\(7),
	cin => \U1|time_cnt[6]~22\,
	combout => \U1|time_cnt[7]~23_combout\);

-- Location: FF_X107_Y16_N23
\U1|time_cnt[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|time_cnt[7]~23_combout\,
	sclr => \U1|time_cnt[5]~18_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|time_cnt\(7));

-- Location: LCCOMB_X107_Y16_N26
\U1|process_5~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|process_5~4_combout\ = (!\U1|time_cnt\(5) & (!\U1|time_cnt\(7) & (\U1|time_cnt\(6) & !\U1|time_cnt\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|time_cnt\(5),
	datab => \U1|time_cnt\(7),
	datac => \U1|time_cnt\(6),
	datad => \U1|time_cnt\(4),
	combout => \U1|process_5~4_combout\);

-- Location: LCCOMB_X108_Y16_N28
\U1|process_5~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|process_5~3_combout\ = (\U1|time_cnt\(2) & (!\U1|time_cnt\(3) & ((\U1|time_cnt\(0)) # (\U1|time_cnt\(1))))) # (!\U1|time_cnt\(2) & (((\U1|time_cnt\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|time_cnt\(0),
	datab => \U1|time_cnt\(2),
	datac => \U1|time_cnt\(3),
	datad => \U1|time_cnt\(1),
	combout => \U1|process_5~3_combout\);

-- Location: LCCOMB_X108_Y16_N18
\U1|process_5~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|process_5~5_combout\ = (\U1|process_5~4_combout\ & \U1|process_5~3_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|process_5~4_combout\,
	datad => \U1|process_5~3_combout\,
	combout => \U1|process_5~5_combout\);

-- Location: LCCOMB_X107_Y16_N24
\U1|LessThan5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|LessThan5~0_combout\ = (\U1|time_cnt\(0) & \U1|time_cnt\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|time_cnt\(0),
	datad => \U1|time_cnt\(2),
	combout => \U1|LessThan5~0_combout\);

-- Location: LCCOMB_X108_Y16_N8
\U1|process_5~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|process_5~6_combout\ = (\U1|time_cnt\(2) & ((\U1|time_cnt\(0) & (!\U1|time_cnt\(3))) # (!\U1|time_cnt\(0) & ((\U1|time_cnt\(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010101000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|time_cnt\(2),
	datab => \U1|time_cnt\(0),
	datac => \U1|time_cnt\(3),
	datad => \U1|time_cnt\(1),
	combout => \U1|process_5~6_combout\);

-- Location: LCCOMB_X107_Y16_N6
\U1|process_5~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|process_5~1_combout\ = (!\U1|time_cnt\(6) & (!\U1|time_cnt\(7) & !\U1|time_cnt\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|time_cnt\(6),
	datac => \U1|time_cnt\(7),
	datad => \U1|time_cnt\(5),
	combout => \U1|process_5~1_combout\);

-- Location: LCCOMB_X108_Y16_N10
\U1|process_5~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|process_5~7_combout\ = ((\U1|time_cnt\(3) & ((\U1|time_cnt\(4)) # (!\U1|time_cnt\(1))))) # (!\U1|process_5~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111101001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|time_cnt\(1),
	datab => \U1|time_cnt\(3),
	datac => \U1|process_5~1_combout\,
	datad => \U1|time_cnt\(4),
	combout => \U1|process_5~7_combout\);

-- Location: LCCOMB_X108_Y16_N4
\U1|process_5~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|process_5~8_combout\ = (\U1|process_5~6_combout\) # ((\U1|process_5~7_combout\) # ((!\U1|time_cnt\(4) & !\U1|LessThan5~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|time_cnt\(4),
	datab => \U1|LessThan5~0_combout\,
	datac => \U1|process_5~6_combout\,
	datad => \U1|process_5~7_combout\,
	combout => \U1|process_5~8_combout\);

-- Location: LCCOMB_X107_Y16_N30
\U1|LessThan5~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|LessThan5~1_combout\ = (\U1|time_cnt\(4)) # ((\U1|time_cnt\(3)) # ((\U1|time_cnt\(1) & \U1|LessThan5~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|time_cnt\(1),
	datab => \U1|time_cnt\(4),
	datac => \U1|time_cnt\(3),
	datad => \U1|LessThan5~0_combout\,
	combout => \U1|LessThan5~1_combout\);

-- Location: LCCOMB_X107_Y16_N28
\U1|process_5~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|process_5~9_combout\ = (\U1|time_cnt\(5) & ((\U1|time_cnt\(0)) # ((\U1|time_cnt\(2)) # (\U1|time_cnt\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|time_cnt\(0),
	datab => \U1|time_cnt\(5),
	datac => \U1|time_cnt\(2),
	datad => \U1|time_cnt\(1),
	combout => \U1|process_5~9_combout\);

-- Location: LCCOMB_X107_Y16_N2
\U1|process_5~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|process_5~10_combout\ = (!\U1|LessThan5~1_combout\ & (!\U1|time_cnt\(7) & (!\U1|time_cnt\(6) & \U1|process_5~9_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|LessThan5~1_combout\,
	datab => \U1|time_cnt\(7),
	datac => \U1|time_cnt\(6),
	datad => \U1|process_5~9_combout\,
	combout => \U1|process_5~10_combout\);

-- Location: LCCOMB_X108_Y16_N30
\U1|Selector7~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Selector7~2_combout\ = (\U1|process_5~8_combout\ & !\U1|process_5~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|process_5~8_combout\,
	datad => \U1|process_5~10_combout\,
	combout => \U1|Selector7~2_combout\);

-- Location: LCCOMB_X108_Y16_N24
\U1|Selector6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Selector6~0_combout\ = (\U1|Selector7~1_combout\ & (((\U1|process_5~5_combout\ & \U1|Selector7~0_combout\)) # (!\U1|Selector7~2_combout\))) # (!\U1|Selector7~1_combout\ & (\U1|process_5~5_combout\ & ((\U1|Selector7~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|Selector7~1_combout\,
	datab => \U1|process_5~5_combout\,
	datac => \U1|Selector7~2_combout\,
	datad => \U1|Selector7~0_combout\,
	combout => \U1|Selector6~0_combout\);

-- Location: FF_X108_Y16_N25
\U1|time_done\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|Selector6~0_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|time_done~q\);

-- Location: LCCOMB_X109_Y16_N10
\U1|Selector1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Selector1~0_combout\ = (\U1|current_state.st_start_low_9ms~q\ & (!\U1|error_en~q\ & !\U1|time_done~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|current_state.st_start_low_9ms~q\,
	datac => \U1|error_en~q\,
	datad => \U1|time_done~q\,
	combout => \U1|Selector1~0_combout\);

-- Location: LCCOMB_X109_Y16_N12
\U1|Selector1~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Selector1~1_combout\ = (\U1|Selector1~0_combout\) # ((!\U1|remote_in_d0~q\ & !\U1|current_state.st_idle~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|remote_in_d0~q\,
	datac => \U1|current_state.st_idle~q\,
	datad => \U1|Selector1~0_combout\,
	combout => \U1|Selector1~1_combout\);

-- Location: FF_X109_Y16_N13
\U1|current_state.st_start_low_9ms\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|Selector1~1_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|current_state.st_start_low_9ms~q\);

-- Location: LCCOMB_X109_Y16_N26
\U1|Selector7~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Selector7~0_combout\ = (\U1|remote_in_d0~q\ & (!\U1|remote_in_d1~q\ & \U1|current_state.st_start_low_9ms~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|remote_in_d0~q\,
	datac => \U1|remote_in_d1~q\,
	datad => \U1|current_state.st_start_low_9ms~q\,
	combout => \U1|Selector7~0_combout\);

-- Location: LCCOMB_X108_Y16_N26
\U1|Selector7~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Selector7~3_combout\ = (\U1|Selector7~1_combout\ & ((\U1|Selector7~2_combout\) # ((!\U1|process_5~5_combout\ & \U1|Selector7~0_combout\)))) # (!\U1|Selector7~1_combout\ & (!\U1|process_5~5_combout\ & ((\U1|Selector7~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011001110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|Selector7~1_combout\,
	datab => \U1|process_5~5_combout\,
	datac => \U1|Selector7~2_combout\,
	datad => \U1|Selector7~0_combout\,
	combout => \U1|Selector7~3_combout\);

-- Location: FF_X108_Y16_N27
\U1|error_en\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|Selector7~3_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|error_en~q\);

-- Location: LCCOMB_X109_Y16_N4
\U1|Selector2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Selector2~0_combout\ = (\U1|time_done~q\ & (((\U1|current_state.st_start_low_9ms~q\)))) # (!\U1|time_done~q\ & (!\U1|error_en~q\ & (\U1|current_state.st_start_judge~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|error_en~q\,
	datab => \U1|time_done~q\,
	datac => \U1|current_state.st_start_judge~q\,
	datad => \U1|current_state.st_start_low_9ms~q\,
	combout => \U1|Selector2~0_combout\);

-- Location: FF_X109_Y16_N5
\U1|current_state.st_start_judge\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|Selector2~0_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|current_state.st_start_judge~q\);

-- Location: LCCOMB_X109_Y16_N20
\U1|Selector7~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Selector7~1_combout\ = (\U1|current_state.st_start_judge~q\ & (\U1|remote_in_d1~q\ & !\U1|remote_in_d0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|current_state.st_start_judge~q\,
	datac => \U1|remote_in_d1~q\,
	datad => \U1|remote_in_d0~q\,
	combout => \U1|Selector7~1_combout\);

-- Location: LCCOMB_X108_Y16_N6
\U1|judge_flag~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|judge_flag~0_combout\ = (\U1|Selector7~1_combout\ & (((\U1|judge_flag~q\ & !\U1|process_5~10_combout\)) # (!\U1|process_5~8_combout\))) # (!\U1|Selector7~1_combout\ & (((\U1|judge_flag~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111001011110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|Selector7~1_combout\,
	datab => \U1|process_5~8_combout\,
	datac => \U1|judge_flag~q\,
	datad => \U1|process_5~10_combout\,
	combout => \U1|judge_flag~0_combout\);

-- Location: FF_X108_Y16_N7
\U1|judge_flag\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|judge_flag~0_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|judge_flag~q\);

-- Location: LCCOMB_X108_Y16_N12
\U1|Selector3~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Selector3~0_combout\ = (\U1|time_done~q\ & \U1|current_state.st_start_judge~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|time_done~q\,
	datad => \U1|current_state.st_start_judge~q\,
	combout => \U1|Selector3~0_combout\);

-- Location: LCCOMB_X108_Y16_N20
\U1|Selector4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Selector4~0_combout\ = (\U1|judge_flag~q\ & ((\U1|Selector3~0_combout\) # ((!\U1|pos_remote_in~combout\ & \U1|current_state.st_repeat_code~q\)))) # (!\U1|judge_flag~q\ & (!\U1|pos_remote_in~combout\ & (\U1|current_state.st_repeat_code~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|judge_flag~q\,
	datab => \U1|pos_remote_in~combout\,
	datac => \U1|current_state.st_repeat_code~q\,
	datad => \U1|Selector3~0_combout\,
	combout => \U1|Selector4~0_combout\);

-- Location: FF_X108_Y16_N21
\U1|current_state.st_repeat_code\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|Selector4~0_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|current_state.st_repeat_code~q\);

-- Location: LCCOMB_X106_Y16_N28
\U1|repeat_en~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|repeat_en~0_combout\ = (!\U1|remote_in_d1~q\ & (\U1|remote_in_d0~q\ & \U1|current_state.st_repeat_code~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|remote_in_d1~q\,
	datab => \U1|remote_in_d0~q\,
	datad => \U1|current_state.st_repeat_code~q\,
	combout => \U1|repeat_en~0_combout\);

-- Location: LCCOMB_X105_Y16_N26
\U1|current_state~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|current_state~8_combout\ = ((\U1|repeat_en~0_combout\) # ((\U1|remote_in_d0~q\ & !\U1|current_state.st_idle~q\))) # (!\sys_rst_n_in~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111101011101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sys_rst_n_in~input_o\,
	datab => \U1|remote_in_d0~q\,
	datac => \U1|current_state.st_idle~q\,
	datad => \U1|repeat_en~0_combout\,
	combout => \U1|current_state~8_combout\);

-- Location: LCCOMB_X103_Y16_N20
\U1|data_cnt[0]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_cnt[0]~6_combout\ = \U1|data_cnt\(0) $ (VCC)
-- \U1|data_cnt[0]~7\ = CARRY(\U1|data_cnt\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|data_cnt\(0),
	datad => VCC,
	combout => \U1|data_cnt[0]~6_combout\,
	cout => \U1|data_cnt[0]~7\);

-- Location: LCCOMB_X103_Y16_N14
\U1|data_cnt[0]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_cnt[0]~18_combout\ = ((!\U1|remote_in_d1~q\ & \U1|remote_in_d0~q\)) # (!\sys_rst_n_in~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111101010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sys_rst_n_in~input_o\,
	datac => \U1|remote_in_d1~q\,
	datad => \U1|remote_in_d0~q\,
	combout => \U1|data_cnt[0]~18_combout\);

-- Location: LCCOMB_X103_Y16_N12
\U1|data_cnt[0]~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_cnt[0]~19_combout\ = (\U1|remote_in_d1~q\ & !\U1|remote_in_d0~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|remote_in_d1~q\,
	datad => \U1|remote_in_d0~q\,
	combout => \U1|data_cnt[0]~19_combout\);

-- Location: LCCOMB_X103_Y16_N18
\U1|data_cnt[0]~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_cnt[0]~20_combout\ = ((\U1|current_state.st_rec_data~q\ & ((\U1|process_4~1_combout\) # (\U1|data_cnt[0]~19_combout\)))) # (!\sys_rst_n_in~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110111010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sys_rst_n_in~input_o\,
	datab => \U1|current_state.st_rec_data~q\,
	datac => \U1|process_4~1_combout\,
	datad => \U1|data_cnt[0]~19_combout\,
	combout => \U1|data_cnt[0]~20_combout\);

-- Location: FF_X103_Y16_N21
\U1|data_cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_cnt[0]~6_combout\,
	sclr => \U1|data_cnt[0]~18_combout\,
	ena => \U1|data_cnt[0]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_cnt\(0));

-- Location: LCCOMB_X103_Y16_N22
\U1|data_cnt[1]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_cnt[1]~8_combout\ = (\U1|data_cnt\(1) & (!\U1|data_cnt[0]~7\)) # (!\U1|data_cnt\(1) & ((\U1|data_cnt[0]~7\) # (GND)))
-- \U1|data_cnt[1]~9\ = CARRY((!\U1|data_cnt[0]~7\) # (!\U1|data_cnt\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data_cnt\(1),
	datad => VCC,
	cin => \U1|data_cnt[0]~7\,
	combout => \U1|data_cnt[1]~8_combout\,
	cout => \U1|data_cnt[1]~9\);

-- Location: FF_X103_Y16_N23
\U1|data_cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_cnt[1]~8_combout\,
	sclr => \U1|data_cnt[0]~18_combout\,
	ena => \U1|data_cnt[0]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_cnt\(1));

-- Location: LCCOMB_X103_Y16_N24
\U1|data_cnt[2]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_cnt[2]~10_combout\ = (\U1|data_cnt\(2) & (\U1|data_cnt[1]~9\ $ (GND))) # (!\U1|data_cnt\(2) & (!\U1|data_cnt[1]~9\ & VCC))
-- \U1|data_cnt[2]~11\ = CARRY((\U1|data_cnt\(2) & !\U1|data_cnt[1]~9\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data_cnt\(2),
	datad => VCC,
	cin => \U1|data_cnt[1]~9\,
	combout => \U1|data_cnt[2]~10_combout\,
	cout => \U1|data_cnt[2]~11\);

-- Location: FF_X103_Y16_N25
\U1|data_cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_cnt[2]~10_combout\,
	sclr => \U1|data_cnt[0]~18_combout\,
	ena => \U1|data_cnt[0]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_cnt\(2));

-- Location: LCCOMB_X103_Y16_N26
\U1|data_cnt[3]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_cnt[3]~12_combout\ = (\U1|data_cnt\(3) & (!\U1|data_cnt[2]~11\)) # (!\U1|data_cnt\(3) & ((\U1|data_cnt[2]~11\) # (GND)))
-- \U1|data_cnt[3]~13\ = CARRY((!\U1|data_cnt[2]~11\) # (!\U1|data_cnt\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U1|data_cnt\(3),
	datad => VCC,
	cin => \U1|data_cnt[2]~11\,
	combout => \U1|data_cnt[3]~12_combout\,
	cout => \U1|data_cnt[3]~13\);

-- Location: FF_X103_Y16_N27
\U1|data_cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_cnt[3]~12_combout\,
	sclr => \U1|data_cnt[0]~18_combout\,
	ena => \U1|data_cnt[0]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_cnt\(3));

-- Location: LCCOMB_X103_Y16_N28
\U1|data_cnt[4]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_cnt[4]~14_combout\ = (\U1|data_cnt\(4) & (\U1|data_cnt[3]~13\ $ (GND))) # (!\U1|data_cnt\(4) & (!\U1|data_cnt[3]~13\ & VCC))
-- \U1|data_cnt[4]~15\ = CARRY((\U1|data_cnt\(4) & !\U1|data_cnt[3]~13\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data_cnt\(4),
	datad => VCC,
	cin => \U1|data_cnt[3]~13\,
	combout => \U1|data_cnt[4]~14_combout\,
	cout => \U1|data_cnt[4]~15\);

-- Location: FF_X103_Y16_N29
\U1|data_cnt[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_cnt[4]~14_combout\,
	sclr => \U1|data_cnt[0]~18_combout\,
	ena => \U1|data_cnt[0]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_cnt\(4));

-- Location: LCCOMB_X103_Y16_N30
\U1|data_cnt[5]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_cnt[5]~16_combout\ = \U1|data_cnt[4]~15\ $ (\U1|data_cnt\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \U1|data_cnt\(5),
	cin => \U1|data_cnt[4]~15\,
	combout => \U1|data_cnt[5]~16_combout\);

-- Location: FF_X103_Y16_N31
\U1|data_cnt[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_cnt[5]~16_combout\,
	sclr => \U1|data_cnt[0]~18_combout\,
	ena => \U1|data_cnt[0]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_cnt\(5));

-- Location: LCCOMB_X103_Y16_N16
\U1|process_4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|process_4~0_combout\ = (\U1|data_cnt\(5) & (!\U1|data_cnt\(4) & (!\U1|data_cnt\(3) & !\U1|data_cnt\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data_cnt\(5),
	datab => \U1|data_cnt\(4),
	datac => \U1|data_cnt\(3),
	datad => \U1|data_cnt\(2),
	combout => \U1|process_4~0_combout\);

-- Location: LCCOMB_X106_Y16_N14
\U1|process_4~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|process_4~1_combout\ = (\U1|pos_remote_in~combout\ & (!\U1|data_cnt\(0) & (!\U1|data_cnt\(1) & \U1|process_4~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|pos_remote_in~combout\,
	datab => \U1|data_cnt\(0),
	datac => \U1|data_cnt\(1),
	datad => \U1|process_4~0_combout\,
	combout => \U1|process_4~1_combout\);

-- Location: LCCOMB_X105_Y16_N24
\U1|Selector3~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Selector3~1_combout\ = (\U1|Selector3~0_combout\ & (((!\U1|process_4~1_combout\ & \U1|current_state.st_rec_data~q\)) # (!\U1|judge_flag~q\))) # (!\U1|Selector3~0_combout\ & (!\U1|process_4~1_combout\ & (\U1|current_state.st_rec_data~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000010111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|Selector3~0_combout\,
	datab => \U1|process_4~1_combout\,
	datac => \U1|current_state.st_rec_data~q\,
	datad => \U1|judge_flag~q\,
	combout => \U1|Selector3~1_combout\);

-- Location: FF_X105_Y16_N25
\U1|current_state.st_rec_data\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|Selector3~1_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|current_state.st_rec_data~q\);

-- Location: LCCOMB_X109_Y16_N24
\U1|current_state~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|current_state~7_combout\ = (\U1|error_en~q\ & (!\U1|time_done~q\ & ((\U1|current_state.st_start_judge~q\) # (\U1|current_state.st_start_low_9ms~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|error_en~q\,
	datab => \U1|time_done~q\,
	datac => \U1|current_state.st_start_judge~q\,
	datad => \U1|current_state.st_start_low_9ms~q\,
	combout => \U1|current_state~7_combout\);

-- Location: LCCOMB_X105_Y16_N8
\U1|current_state~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|current_state~9_combout\ = (!\U1|current_state~8_combout\ & (!\U1|current_state~7_combout\ & ((!\U1|process_4~1_combout\) # (!\U1|current_state.st_rec_data~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|current_state~8_combout\,
	datab => \U1|current_state.st_rec_data~q\,
	datac => \U1|process_4~1_combout\,
	datad => \U1|current_state~7_combout\,
	combout => \U1|current_state~9_combout\);

-- Location: FF_X105_Y16_N9
\U1|current_state.st_idle\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|current_state~9_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|current_state.st_idle~q\);

-- Location: LCCOMB_X109_Y16_N8
\U1|Selector5~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Selector5~1_combout\ = (\U1|current_state.st_rec_data~q\ & (\U1|remote_in_d1~q\ $ (((\U1|remote_in_d0~q\))))) # (!\U1|current_state.st_rec_data~q\ & (\U1|remote_in_d1~q\ & (\U1|current_state.st_start_judge~q\ & !\U1|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001011001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|current_state.st_rec_data~q\,
	datab => \U1|remote_in_d1~q\,
	datac => \U1|current_state.st_start_judge~q\,
	datad => \U1|remote_in_d0~q\,
	combout => \U1|Selector5~1_combout\);

-- Location: LCCOMB_X109_Y16_N18
\U1|Selector5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Selector5~0_combout\ = (!\U1|remote_in_d1~q\ & (\U1|remote_in_d0~q\ & ((\U1|current_state.st_start_low_9ms~q\) # (\U1|current_state.st_repeat_code~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|current_state.st_start_low_9ms~q\,
	datab => \U1|current_state.st_repeat_code~q\,
	datac => \U1|remote_in_d1~q\,
	datad => \U1|remote_in_d0~q\,
	combout => \U1|Selector5~0_combout\);

-- Location: LCCOMB_X109_Y16_N22
\U1|Selector5~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Selector5~2_combout\ = (\U1|Selector5~1_combout\) # ((\U1|Selector5~0_combout\) # ((!\U1|current_state.st_idle~q\ & \U1|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|current_state.st_idle~q\,
	datab => \U1|remote_in_d0~q\,
	datac => \U1|Selector5~1_combout\,
	datad => \U1|Selector5~0_combout\,
	combout => \U1|Selector5~2_combout\);

-- Location: FF_X109_Y16_N23
\U1|time_cnt_clr\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|Selector5~2_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|time_cnt_clr~q\);

-- Location: LCCOMB_X108_Y16_N14
\U1|time_cnt[5]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|time_cnt[5]~18_combout\ = (\U1|time_cnt_clr~q\) # (!\sys_rst_n_in~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \sys_rst_n_in~input_o\,
	datad => \U1|time_cnt_clr~q\,
	combout => \U1|time_cnt[5]~18_combout\);

-- Location: FF_X107_Y16_N9
\U1|time_cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|time_cnt[0]~8_combout\,
	sclr => \U1|time_cnt[5]~18_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|time_cnt\(0));

-- Location: FF_X107_Y16_N11
\U1|time_cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|time_cnt[1]~10_combout\,
	sclr => \U1|time_cnt[5]~18_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|time_cnt\(1));

-- Location: LCCOMB_X107_Y16_N4
\U1|process_5~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|process_5~2_combout\ = (\U1|process_5~1_combout\ & ((\U1|time_cnt\(1)) # (\U1|time_cnt\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|time_cnt\(1),
	datac => \U1|time_cnt\(2),
	datad => \U1|process_5~1_combout\,
	combout => \U1|process_5~2_combout\);

-- Location: LCCOMB_X107_Y16_N0
\U1|process_5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|process_5~0_combout\ = (\U1|time_cnt\(4)) # (!\U1|time_cnt\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|time_cnt\(3),
	datad => \U1|time_cnt\(4),
	combout => \U1|process_5~0_combout\);

-- Location: LCCOMB_X106_Y16_N2
\U1|data_temp~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~14_combout\ = (\U1|process_5~2_combout\ & (\U1|LessThan5~1_combout\ & ((\U1|data_temp\(15)) # (!\U1|process_5~0_combout\)))) # (!\U1|process_5~2_combout\ & (((\U1|data_temp\(15)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010100100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|process_5~2_combout\,
	datab => \U1|process_5~0_combout\,
	datac => \U1|LessThan5~1_combout\,
	datad => \U1|data_temp\(15),
	combout => \U1|data_temp~14_combout\);

-- Location: LCCOMB_X105_Y16_N14
\U1|data_temp~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~1_combout\ = (!\U1|remote_in_d0~q\ & (\U1|remote_in_d1~q\ & (\U1|data_cnt\(4) & !\U1|data_cnt\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|remote_in_d0~q\,
	datab => \U1|remote_in_d1~q\,
	datac => \U1|data_cnt\(4),
	datad => \U1|data_cnt\(5),
	combout => \U1|data_temp~1_combout\);

-- Location: LCCOMB_X105_Y16_N28
\U1|data_temp~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~13_combout\ = (\U1|current_state.st_rec_data~q\ & ((\U1|data_temp~1_combout\) # (\U1|process_4~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|data_temp~1_combout\,
	datac => \U1|process_4~1_combout\,
	datad => \U1|current_state.st_rec_data~q\,
	combout => \U1|data_temp~13_combout\);

-- Location: LCCOMB_X105_Y16_N18
\U1|data_temp~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~15_combout\ = (\U1|data_temp~13_combout\ & (!\U1|pos_remote_in~combout\ & (\U1|data_temp~14_combout\))) # (!\U1|data_temp~13_combout\ & (((\U1|data_temp\(15)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|pos_remote_in~combout\,
	datab => \U1|data_temp~14_combout\,
	datac => \U1|data_temp\(15),
	datad => \U1|data_temp~13_combout\,
	combout => \U1|data_temp~15_combout\);

-- Location: FF_X105_Y16_N19
\U1|data_temp[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_temp~15_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(15));

-- Location: LCCOMB_X105_Y16_N6
\U1|data_temp~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~16_combout\ = (\sys_rst_n_in~input_o\ & (\U1|data_temp\(15) & ((\U1|remote_in_d1~q\) # (!\U1|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sys_rst_n_in~input_o\,
	datab => \U1|remote_in_d1~q\,
	datac => \U1|remote_in_d0~q\,
	datad => \U1|data_temp\(15),
	combout => \U1|data_temp~16_combout\);

-- Location: LCCOMB_X106_Y16_N0
\U1|data_temp[12]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp[12]~2_combout\ = (((\U1|process_5~0_combout\ & \U1|LessThan5~1_combout\)) # (!\U1|data_temp~1_combout\)) # (!\U1|process_5~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101010111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|process_5~2_combout\,
	datab => \U1|process_5~0_combout\,
	datac => \U1|LessThan5~1_combout\,
	datad => \U1|data_temp~1_combout\,
	combout => \U1|data_temp[12]~2_combout\);

-- Location: LCCOMB_X106_Y16_N16
\U1|data_temp[12]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp[12]~3_combout\ = ((\U1|current_state.st_rec_data~q\ & ((\U1|process_4~1_combout\) # (!\U1|data_temp[12]~2_combout\)))) # (!\sys_rst_n_in~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101010111011101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sys_rst_n_in~input_o\,
	datab => \U1|current_state.st_rec_data~q\,
	datac => \U1|process_4~1_combout\,
	datad => \U1|data_temp[12]~2_combout\,
	combout => \U1|data_temp[12]~3_combout\);

-- Location: FF_X106_Y16_N27
\U1|data_temp[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	asdata => \U1|data_temp~16_combout\,
	sload => VCC,
	ena => \U1|data_temp[12]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(14));

-- Location: LCCOMB_X106_Y16_N24
\U1|data_temp~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~18_combout\ = (\U1|data_temp\(14) & (\sys_rst_n_in~input_o\ & ((\U1|remote_in_d1~q\) # (!\U1|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|remote_in_d1~q\,
	datab => \U1|data_temp\(14),
	datac => \U1|remote_in_d0~q\,
	datad => \sys_rst_n_in~input_o\,
	combout => \U1|data_temp~18_combout\);

-- Location: FF_X106_Y16_N25
\U1|data_temp[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_temp~18_combout\,
	ena => \U1|data_temp[12]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(13));

-- Location: LCCOMB_X106_Y16_N18
\U1|data_temp~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~20_combout\ = (\U1|data_temp\(13) & (\sys_rst_n_in~input_o\ & ((\U1|remote_in_d1~q\) # (!\U1|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|remote_in_d1~q\,
	datab => \U1|data_temp\(13),
	datac => \U1|remote_in_d0~q\,
	datad => \sys_rst_n_in~input_o\,
	combout => \U1|data_temp~20_combout\);

-- Location: FF_X106_Y16_N19
\U1|data_temp[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_temp~20_combout\,
	ena => \U1|data_temp[12]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(12));

-- Location: LCCOMB_X106_Y16_N30
\U1|data_temp~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~9_combout\ = (\U1|data_temp\(12) & (\sys_rst_n_in~input_o\ & ((\U1|remote_in_d1~q\) # (!\U1|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|remote_in_d1~q\,
	datab => \U1|data_temp\(12),
	datac => \U1|remote_in_d0~q\,
	datad => \sys_rst_n_in~input_o\,
	combout => \U1|data_temp~9_combout\);

-- Location: FF_X106_Y16_N31
\U1|data_temp[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_temp~9_combout\,
	ena => \U1|data_temp[12]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(11));

-- Location: LCCOMB_X106_Y16_N8
\U1|data_temp~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~10_combout\ = (\U1|data_temp\(11) & (\sys_rst_n_in~input_o\ & ((\U1|remote_in_d1~q\) # (!\U1|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|remote_in_d1~q\,
	datab => \U1|remote_in_d0~q\,
	datac => \U1|data_temp\(11),
	datad => \sys_rst_n_in~input_o\,
	combout => \U1|data_temp~10_combout\);

-- Location: FF_X106_Y16_N9
\U1|data_temp[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_temp~10_combout\,
	ena => \U1|data_temp[12]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(10));

-- Location: LCCOMB_X105_Y16_N16
\U1|data_temp~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~5_combout\ = (\sys_rst_n_in~input_o\ & (\U1|data_temp\(10) & ((\U1|remote_in_d1~q\) # (!\U1|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sys_rst_n_in~input_o\,
	datab => \U1|remote_in_d0~q\,
	datac => \U1|data_temp\(10),
	datad => \U1|remote_in_d1~q\,
	combout => \U1|data_temp~5_combout\);

-- Location: FF_X105_Y16_N17
\U1|data_temp[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_temp~5_combout\,
	ena => \U1|data_temp[12]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(9));

-- Location: LCCOMB_X106_Y16_N20
\U1|data_temp~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~6_combout\ = (\U1|data_temp\(9) & (\sys_rst_n_in~input_o\ & ((\U1|remote_in_d1~q\) # (!\U1|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|remote_in_d1~q\,
	datab => \U1|remote_in_d0~q\,
	datac => \U1|data_temp\(9),
	datad => \sys_rst_n_in~input_o\,
	combout => \U1|data_temp~6_combout\);

-- Location: FF_X106_Y16_N21
\U1|data_temp[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_temp~6_combout\,
	ena => \U1|data_temp[12]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(8));

-- Location: LCCOMB_X106_Y16_N12
\U1|data_temp~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~12_combout\ = (\U1|data_temp\(8) & (\sys_rst_n_in~input_o\ & ((\U1|remote_in_d1~q\) # (!\U1|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|remote_in_d1~q\,
	datab => \U1|remote_in_d0~q\,
	datac => \U1|data_temp\(8),
	datad => \sys_rst_n_in~input_o\,
	combout => \U1|data_temp~12_combout\);

-- Location: FF_X106_Y16_N13
\U1|data_temp[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_temp~12_combout\,
	ena => \U1|data_temp[12]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(7));

-- Location: LCCOMB_X105_Y19_N0
\U1|data_temp~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~11_combout\ = (\sys_rst_n_in~input_o\ & (\U1|data_temp\(7) & ((\U1|remote_in_d1~q\) # (!\U1|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sys_rst_n_in~input_o\,
	datab => \U1|remote_in_d1~q\,
	datac => \U1|remote_in_d0~q\,
	datad => \U1|data_temp\(7),
	combout => \U1|data_temp~11_combout\);

-- Location: FF_X106_Y19_N25
\U1|data_temp[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	asdata => \U1|data_temp~11_combout\,
	sload => VCC,
	ena => \U1|data_temp[12]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(6));

-- Location: LCCOMB_X105_Y19_N18
\U1|data_temp~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~17_combout\ = (\U1|data_temp\(6) & (\sys_rst_n_in~input_o\ & ((\U1|remote_in_d1~q\) # (!\U1|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data_temp\(6),
	datab => \U1|remote_in_d0~q\,
	datac => \U1|remote_in_d1~q\,
	datad => \sys_rst_n_in~input_o\,
	combout => \U1|data_temp~17_combout\);

-- Location: FF_X106_Y16_N11
\U1|data_temp[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	asdata => \U1|data_temp~17_combout\,
	sload => VCC,
	ena => \U1|data_temp[12]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(5));

-- Location: LCCOMB_X105_Y19_N28
\U1|data_temp~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~19_combout\ = (\U1|data_temp\(5) & (\sys_rst_n_in~input_o\ & ((\U1|remote_in_d1~q\) # (!\U1|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|remote_in_d0~q\,
	datab => \U1|data_temp\(5),
	datac => \U1|remote_in_d1~q\,
	datad => \sys_rst_n_in~input_o\,
	combout => \U1|data_temp~19_combout\);

-- Location: FF_X106_Y19_N23
\U1|data_temp[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	asdata => \U1|data_temp~19_combout\,
	sload => VCC,
	ena => \U1|data_temp[12]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(4));

-- Location: LCCOMB_X105_Y19_N2
\U1|data~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data~11_combout\ = (\U1|data_temp\(4) & \sys_rst_n_in~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|data_temp\(4),
	datad => \sys_rst_n_in~input_o\,
	combout => \U1|data~11_combout\);

-- Location: LCCOMB_X105_Y19_N10
\U1|data_temp~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~8_combout\ = (\sys_rst_n_in~input_o\ & (\U1|data_temp\(4) & ((\U1|remote_in_d1~q\) # (!\U1|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sys_rst_n_in~input_o\,
	datab => \U1|remote_in_d1~q\,
	datac => \U1|remote_in_d0~q\,
	datad => \U1|data_temp\(4),
	combout => \U1|data_temp~8_combout\);

-- Location: FF_X106_Y16_N5
\U1|data_temp[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	asdata => \U1|data_temp~8_combout\,
	sload => VCC,
	ena => \U1|data_temp[12]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(3));

-- Location: LCCOMB_X106_Y16_N6
\U1|data_temp~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~7_combout\ = (\U1|data_temp\(3) & (\sys_rst_n_in~input_o\ & ((\U1|remote_in_d1~q\) # (!\U1|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|remote_in_d1~q\,
	datab => \U1|data_temp\(3),
	datac => \U1|remote_in_d0~q\,
	datad => \sys_rst_n_in~input_o\,
	combout => \U1|data_temp~7_combout\);

-- Location: FF_X106_Y16_N7
\U1|data_temp[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_temp~7_combout\,
	ena => \U1|data_temp[12]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(2));

-- Location: LCCOMB_X106_Y16_N22
\U1|data~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data~4_combout\ = (\U1|data_temp\(11) & ((\U1|data_temp\(3)) # (\U1|data_temp\(10) $ (!\U1|data_temp\(2))))) # (!\U1|data_temp\(11) & ((\U1|data_temp\(10) $ (!\U1|data_temp\(2))) # (!\U1|data_temp\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100110011111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data_temp\(11),
	datab => \U1|data_temp\(3),
	datac => \U1|data_temp\(10),
	datad => \U1|data_temp\(2),
	combout => \U1|data~4_combout\);

-- Location: LCCOMB_X106_Y19_N14
\U1|data~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data~5_combout\ = (\U1|data_temp\(15) & ((\U1|data_temp\(7)) # (\U1|data_temp\(6) $ (!\U1|data_temp\(14))))) # (!\U1|data_temp\(15) & ((\U1|data_temp\(6) $ (!\U1|data_temp\(14))) # (!\U1|data_temp\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110110110111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data_temp\(15),
	datab => \U1|data_temp\(6),
	datac => \U1|data_temp\(7),
	datad => \U1|data_temp\(14),
	combout => \U1|data~5_combout\);

-- Location: LCCOMB_X106_Y19_N24
\U1|Equal2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|Equal2~0_combout\ = \U1|data_temp\(4) $ (\U1|data_temp\(12))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data_temp\(4),
	datad => \U1|data_temp\(12),
	combout => \U1|Equal2~0_combout\);

-- Location: LCCOMB_X106_Y19_N8
\U1|data~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data~6_combout\ = (\U1|data~5_combout\) # ((\U1|data_temp\(5) $ (!\U1|data_temp\(13))) # (!\U1|Equal2~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data_temp\(5),
	datab => \U1|data_temp\(13),
	datac => \U1|data~5_combout\,
	datad => \U1|Equal2~0_combout\,
	combout => \U1|data~6_combout\);

-- Location: LCCOMB_X105_Y16_N10
\U1|data_temp~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~4_combout\ = (\U1|data_temp\(2) & (\sys_rst_n_in~input_o\ & ((\U1|remote_in_d1~q\) # (!\U1|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data_temp\(2),
	datab => \U1|remote_in_d1~q\,
	datac => \U1|remote_in_d0~q\,
	datad => \sys_rst_n_in~input_o\,
	combout => \U1|data_temp~4_combout\);

-- Location: FF_X105_Y16_N11
\U1|data_temp[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	d => \U1|data_temp~4_combout\,
	ena => \U1|data_temp[12]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(1));

-- Location: LCCOMB_X105_Y16_N0
\U1|data_temp~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data_temp~0_combout\ = (\sys_rst_n_in~input_o\ & (\U1|data_temp\(1) & ((\U1|remote_in_d1~q\) # (!\U1|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sys_rst_n_in~input_o\,
	datab => \U1|remote_in_d1~q\,
	datac => \U1|remote_in_d0~q\,
	datad => \U1|data_temp\(1),
	combout => \U1|data_temp~0_combout\);

-- Location: FF_X106_Y16_N29
\U1|data_temp[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	asdata => \U1|data_temp~0_combout\,
	sload => VCC,
	ena => \U1|data_temp[12]~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data_temp\(0));

-- Location: LCCOMB_X105_Y16_N30
\U1|data~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data~1_combout\ = (\U1|data_temp\(1) & ((\U1|data_temp\(9)) # (\U1|data_temp\(8) $ (!\U1|data_temp\(0))))) # (!\U1|data_temp\(1) & ((\U1|data_temp\(8) $ (!\U1|data_temp\(0))) # (!\U1|data_temp\(9))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100110011111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data_temp\(1),
	datab => \U1|data_temp\(9),
	datac => \U1|data_temp\(8),
	datad => \U1|data_temp\(0),
	combout => \U1|data~1_combout\);

-- Location: LCCOMB_X105_Y16_N20
\U1|data~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data~2_combout\ = ((\U1|data_cnt\(1)) # (\U1|data_cnt\(0))) # (!\U1|current_state.st_rec_data~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|current_state.st_rec_data~q\,
	datac => \U1|data_cnt\(1),
	datad => \U1|data_cnt\(0),
	combout => \U1|data~2_combout\);

-- Location: LCCOMB_X105_Y16_N22
\U1|data~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data~3_combout\ = (\U1|data~1_combout\) # (((\U1|data~2_combout\) # (!\U1|process_4~0_combout\)) # (!\U1|pos_remote_in~combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data~1_combout\,
	datab => \U1|pos_remote_in~combout\,
	datac => \U1|process_4~0_combout\,
	datad => \U1|data~2_combout\,
	combout => \U1|data~3_combout\);

-- Location: LCCOMB_X106_Y19_N18
\U1|data[7]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data[7]~7_combout\ = ((!\U1|data~4_combout\ & (!\U1|data~6_combout\ & !\U1|data~3_combout\))) # (!\sys_rst_n_in~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010101010111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sys_rst_n_in~input_o\,
	datab => \U1|data~4_combout\,
	datac => \U1|data~6_combout\,
	datad => \U1|data~3_combout\,
	combout => \U1|data[7]~7_combout\);

-- Location: FF_X106_Y19_N21
\U1|data[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	asdata => \U1|data~11_combout\,
	sload => VCC,
	ena => \U1|data[7]~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data\(4));

-- Location: LCCOMB_X105_Y19_N4
\U1|data~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data~12_combout\ = (\sys_rst_n_in~input_o\ & \U1|data_temp\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sys_rst_n_in~input_o\,
	datac => \U1|data_temp\(5),
	combout => \U1|data~12_combout\);

-- Location: FF_X106_Y19_N11
\U1|data[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	asdata => \U1|data~12_combout\,
	sload => VCC,
	ena => \U1|data[7]~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data\(5));

-- Location: LCCOMB_X105_Y19_N8
\U1|data~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data~14_combout\ = (\sys_rst_n_in~input_o\ & \U1|data_temp\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sys_rst_n_in~input_o\,
	datad => \U1|data_temp\(7),
	combout => \U1|data~14_combout\);

-- Location: FF_X106_Y19_N27
\U1|data[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	asdata => \U1|data~14_combout\,
	sload => VCC,
	ena => \U1|data[7]~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data\(7));

-- Location: LCCOMB_X105_Y19_N26
\U1|data~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data~13_combout\ = (\U1|data_temp\(6) & \sys_rst_n_in~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|data_temp\(6),
	datad => \sys_rst_n_in~input_o\,
	combout => \U1|data~13_combout\);

-- Location: FF_X106_Y19_N1
\U1|data[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	asdata => \U1|data~13_combout\,
	sload => VCC,
	ena => \U1|data[7]~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data\(6));

-- Location: LCCOMB_X106_Y19_N6
\U3|Mux2~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U3|Mux2~1_combout\ = (!\U1|data\(7) & !\U1|data\(6))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(7),
	datad => \U1|data\(6),
	combout => \U3|Mux2~1_combout\);

-- Location: LCCOMB_X106_Y16_N10
\U1|data~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data~0_combout\ = (\sys_rst_n_in~input_o\ & \U1|data_temp\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sys_rst_n_in~input_o\,
	datad => \U1|data_temp\(0),
	combout => \U1|data~0_combout\);

-- Location: FF_X106_Y19_N17
\U1|data[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	asdata => \U1|data~0_combout\,
	sload => VCC,
	ena => \U1|data[7]~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data\(0));

-- Location: LCCOMB_X106_Y16_N4
\U1|data~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data~10_combout\ = (\U1|data_temp\(3) & \sys_rst_n_in~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|data_temp\(3),
	datad => \sys_rst_n_in~input_o\,
	combout => \U1|data~10_combout\);

-- Location: FF_X106_Y19_N3
\U1|data[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	asdata => \U1|data~10_combout\,
	sload => VCC,
	ena => \U1|data[7]~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data\(3));

-- Location: LCCOMB_X106_Y16_N26
\U1|data~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data~9_combout\ = (\sys_rst_n_in~input_o\ & \U1|data_temp\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sys_rst_n_in~input_o\,
	datad => \U1|data_temp\(2),
	combout => \U1|data~9_combout\);

-- Location: FF_X106_Y19_N5
\U1|data[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	asdata => \U1|data~9_combout\,
	sload => VCC,
	ena => \U1|data[7]~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data\(2));

-- Location: LCCOMB_X105_Y19_N24
\U1|data~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|data~8_combout\ = (\sys_rst_n_in~input_o\ & \U1|data_temp\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \sys_rst_n_in~input_o\,
	datad => \U1|data_temp\(1),
	combout => \U1|data~8_combout\);

-- Location: FF_X106_Y19_N7
\U1|data[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	asdata => \U1|data~8_combout\,
	sload => VCC,
	ena => \U1|data[7]~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|data\(1));

-- Location: LCCOMB_X107_Y18_N14
\U3|Mux2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U3|Mux2~0_combout\ = (\U1|data\(3) & (\U1|data\(1) $ (((\U1|data\(0) & \U1|data\(2))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(0),
	datab => \U1|data\(3),
	datac => \U1|data\(2),
	datad => \U1|data\(1),
	combout => \U3|Mux2~0_combout\);

-- Location: LCCOMB_X108_Y18_N6
\U3|Mux2~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U3|Mux2~2_combout\ = (\U1|data\(4)) # ((\U1|data\(5)) # ((\U3|Mux2~0_combout\) # (!\U3|Mux2~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(4),
	datab => \U1|data\(5),
	datac => \U3|Mux2~1_combout\,
	datad => \U3|Mux2~0_combout\,
	combout => \U3|Mux2~2_combout\);

-- Location: LCCOMB_X108_Y18_N18
\U3|segcode1[0]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \U3|segcode1[0]~feeder_combout\ = \U3|Mux2~2_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \U3|Mux2~2_combout\,
	combout => \U3|segcode1[0]~feeder_combout\);

-- Location: FF_X108_Y18_N19
\U3|segcode1[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U3|segcode1[0]~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U3|segcode1\(0));

-- Location: LCCOMB_X108_Y18_N8
\U3|segcode1[3]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \U3|segcode1[3]~feeder_combout\ = \U3|Mux2~2_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \U3|Mux2~2_combout\,
	combout => \U3|segcode1[3]~feeder_combout\);

-- Location: FF_X108_Y18_N9
\U3|segcode1[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U3|segcode1[3]~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U3|segcode1\(3));

-- Location: LCCOMB_X106_Y18_N14
\U3|Mux1~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U3|Mux1~1_combout\ = (!\U1|data\(1) & ((\U1|data\(3) & ((\U1|data\(0)) # (\U1|data\(2)))) # (!\U1|data\(3) & (\U1|data\(0) & \U1|data\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(1),
	datab => \U1|data\(3),
	datac => \U1|data\(0),
	datad => \U1|data\(2),
	combout => \U3|Mux1~1_combout\);

-- Location: LCCOMB_X107_Y21_N16
\U3|Mux1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U3|Mux1~0_combout\ = (!\U1|data\(6) & (\U1|data\(4) & !\U1|data\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(6),
	datab => \U1|data\(4),
	datac => \U1|data\(7),
	combout => \U3|Mux1~0_combout\);

-- Location: LCCOMB_X106_Y17_N28
\U3|Mux1~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U3|Mux1~2_combout\ = (!\U1|data\(5) & (!\U3|Mux1~1_combout\ & \U3|Mux1~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datac => \U3|Mux1~1_combout\,
	datad => \U3|Mux1~0_combout\,
	combout => \U3|Mux1~2_combout\);

-- Location: LCCOMB_X106_Y17_N0
\U3|segcode1[4]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \U3|segcode1[4]~feeder_combout\ = \U3|Mux1~2_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \U3|Mux1~2_combout\,
	combout => \U3|segcode1[4]~feeder_combout\);

-- Location: FF_X106_Y17_N1
\U3|segcode1[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U3|segcode1[4]~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U3|segcode1\(4));

-- Location: LCCOMB_X106_Y17_N6
\U3|segcode1[5]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \U3|segcode1[5]~feeder_combout\ = \U3|Mux1~2_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \U3|Mux1~2_combout\,
	combout => \U3|segcode1[5]~feeder_combout\);

-- Location: FF_X106_Y17_N7
\U3|segcode1[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U3|segcode1[5]~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U3|segcode1\(5));

-- Location: M9K_X104_Y19_N0
\U3|Mux9_rtl_0|auto_generated|ram_block1a0\ : cycloneive_ram_block
-- pragma translate_off
GENERIC MAP (
	mem_init2 => X"00024000900024000900024000900024000900024000900024000900024000900024000900024000900024000900024000900024000900024000900024000900",
	mem_init1 => X"02400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090",
	mem_init0 => X"002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090002400090013800460002400090010C0048000240040003E000420002400590034000C4003E40060001380009000240066000240009001400040003E000420014800590034000C4003E40060",
	data_interleave_offset_in_bits => 1,
	data_interleave_width_in_bits => 1,
	init_file => "infrared.infrared0.rtl.mif",
	init_file_layout => "port_a",
	logical_ram_name => "segment:U3|altsyncram:Mux9_rtl_0|altsyncram_dpv:auto_generated|ALTSYNCRAM",
	operation_mode => "rom",
	port_a_address_clear => "none",
	port_a_address_width => 8,
	port_a_byte_enable_clock => "none",
	port_a_data_out_clear => "none",
	port_a_data_out_clock => "none",
	port_a_data_width => 18,
	port_a_first_address => 0,
	port_a_first_bit_number => 0,
	port_a_last_address => 255,
	port_a_logical_ram_depth => 256,
	port_a_logical_ram_width => 8,
	port_a_read_during_write_mode => "new_data_with_nbe_read",
	port_a_write_enable_clock => "none",
	port_b_address_width => 8,
	port_b_data_width => 18,
	ram_block_type => "M9K")
-- pragma translate_on
PORT MAP (
	portare => VCC,
	clk0 => \sys_clk~inputclkctrl_outclk\,
	portaaddr => \U3|Mux9_rtl_0|auto_generated|ram_block1a0_PORTAADDR_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	portadataout => \U3|Mux9_rtl_0|auto_generated|ram_block1a0_PORTADATAOUT_bus\);

-- Location: FF_X106_Y18_N13
\U1|repeat_en\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|div_clk~clkctrl_outclk\,
	asdata => \U1|repeat_en~0_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|repeat_en~q\);

-- Location: LCCOMB_X107_Y18_N4
\U2|repeat_en_d0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|repeat_en_d0~0_combout\ = (\U1|repeat_en~q\ & \sys_rst_n_in~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|repeat_en~q\,
	datad => \sys_rst_n_in~input_o\,
	combout => \U2|repeat_en_d0~0_combout\);

-- Location: FF_X107_Y18_N5
\U2|repeat_en_d0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|repeat_en_d0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|repeat_en_d0~q\);

-- Location: LCCOMB_X107_Y18_N2
\U2|repeat_en_d1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|repeat_en_d1~0_combout\ = (\U2|repeat_en_d0~q\ & \sys_rst_n_in~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U2|repeat_en_d0~q\,
	datad => \sys_rst_n_in~input_o\,
	combout => \U2|repeat_en_d1~0_combout\);

-- Location: FF_X107_Y18_N3
\U2|repeat_en_d1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|repeat_en_d1~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|repeat_en_d1~q\);

-- Location: LCCOMB_X111_Y18_N10
\U2|led_cnt[0]~23\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[0]~23_combout\ = \U2|led_cnt\(0) $ (VCC)
-- \U2|led_cnt[0]~24\ = CARRY(\U2|led_cnt\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(0),
	datad => VCC,
	combout => \U2|led_cnt[0]~23_combout\,
	cout => \U2|led_cnt[0]~24\);

-- Location: LCCOMB_X110_Y18_N28
\~GND\ : cycloneive_lcell_comb
-- Equation(s):
-- \~GND~combout\ = GND

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \~GND~combout\);

-- Location: LCCOMB_X107_Y18_N26
\U2|leds_wire~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|leds_wire~0_combout\ = ((\U2|repeat_en_d0~q\ & !\U2|repeat_en_d1~q\)) # (!\sys_rst_n_in~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \sys_rst_n_in~input_o\,
	datac => \U2|repeat_en_d0~q\,
	datad => \U2|repeat_en_d1~q\,
	combout => \U2|leds_wire~0_combout\);

-- Location: LCCOMB_X111_Y17_N26
\U2|Equal0~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Equal0~6_combout\ = (!\U2|led_cnt\(19) & (!\U2|led_cnt\(18) & !\U2|led_cnt\(17)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(19),
	datac => \U2|led_cnt\(18),
	datad => \U2|led_cnt\(17),
	combout => \U2|Equal0~6_combout\);

-- Location: LCCOMB_X110_Y18_N6
\U2|Equal0~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Equal0~5_combout\ = (!\U2|led_cnt\(9) & (!\U2|led_cnt\(16) & (!\U2|led_cnt\(15) & !\U2|led_cnt\(14))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(9),
	datab => \U2|led_cnt\(16),
	datac => \U2|led_cnt\(15),
	datad => \U2|led_cnt\(14),
	combout => \U2|Equal0~5_combout\);

-- Location: LCCOMB_X111_Y18_N0
\U2|Equal0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Equal0~1_combout\ = (!\U2|led_cnt\(6) & (!\U2|led_cnt\(7) & (!\U2|led_cnt\(8) & !\U2|led_cnt\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(6),
	datab => \U2|led_cnt\(7),
	datac => \U2|led_cnt\(8),
	datad => \U2|led_cnt\(0),
	combout => \U2|Equal0~1_combout\);

-- Location: LCCOMB_X111_Y17_N18
\U2|led_cnt[20]~64\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[20]~64_combout\ = (\U2|led_cnt\(20) & ((GND) # (!\U2|led_cnt[19]~63\))) # (!\U2|led_cnt\(20) & (\U2|led_cnt[19]~63\ $ (GND)))
-- \U2|led_cnt[20]~65\ = CARRY((\U2|led_cnt\(20)) # (!\U2|led_cnt[19]~63\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(20),
	datad => VCC,
	cin => \U2|led_cnt[19]~63\,
	combout => \U2|led_cnt[20]~64_combout\,
	cout => \U2|led_cnt[20]~65\);

-- Location: LCCOMB_X111_Y17_N20
\U2|led_cnt[21]~66\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[21]~66_combout\ = (\U2|led_cnt\(21) & (\U2|led_cnt[20]~65\ & VCC)) # (!\U2|led_cnt\(21) & (!\U2|led_cnt[20]~65\))
-- \U2|led_cnt[21]~67\ = CARRY((!\U2|led_cnt\(21) & !\U2|led_cnt[20]~65\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(21),
	datad => VCC,
	cin => \U2|led_cnt[20]~65\,
	combout => \U2|led_cnt[21]~66_combout\,
	cout => \U2|led_cnt[21]~67\);

-- Location: FF_X111_Y17_N21
\U2|led_cnt[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[21]~66_combout\,
	asdata => \~GND~combout\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(21));

-- Location: LCCOMB_X111_Y17_N22
\U2|led_cnt[22]~68\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[22]~68_combout\ = \U2|led_cnt\(22) $ (\U2|led_cnt[21]~67\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(22),
	cin => \U2|led_cnt[21]~67\,
	combout => \U2|led_cnt[22]~68_combout\);

-- Location: FF_X111_Y17_N23
\U2|led_cnt[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[22]~68_combout\,
	asdata => \sys_rst_n_in~input_o\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(22));

-- Location: LCCOMB_X111_Y18_N2
\U2|Equal0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Equal0~2_combout\ = (!\U2|led_cnt\(1) & (!\U2|led_cnt\(21) & (!\U2|led_cnt\(22) & !\U2|led_cnt\(20))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(1),
	datab => \U2|led_cnt\(21),
	datac => \U2|led_cnt\(22),
	datad => \U2|led_cnt\(20),
	combout => \U2|Equal0~2_combout\);

-- Location: LCCOMB_X111_Y18_N8
\U2|Equal0~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Equal0~3_combout\ = (!\U2|led_cnt\(5) & (!\U2|led_cnt\(3) & (!\U2|led_cnt\(2) & !\U2|led_cnt\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(5),
	datab => \U2|led_cnt\(3),
	datac => \U2|led_cnt\(2),
	datad => \U2|led_cnt\(4),
	combout => \U2|Equal0~3_combout\);

-- Location: LCCOMB_X111_Y17_N28
\U2|Equal0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Equal0~0_combout\ = (!\U2|led_cnt\(11) & (!\U2|led_cnt\(12) & (!\U2|led_cnt\(13) & !\U2|led_cnt\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(11),
	datab => \U2|led_cnt\(12),
	datac => \U2|led_cnt\(13),
	datad => \U2|led_cnt\(10),
	combout => \U2|Equal0~0_combout\);

-- Location: LCCOMB_X111_Y18_N6
\U2|Equal0~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Equal0~4_combout\ = (\U2|Equal0~1_combout\ & (\U2|Equal0~2_combout\ & (\U2|Equal0~3_combout\ & \U2|Equal0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Equal0~1_combout\,
	datab => \U2|Equal0~2_combout\,
	datac => \U2|Equal0~3_combout\,
	datad => \U2|Equal0~0_combout\,
	combout => \U2|Equal0~4_combout\);

-- Location: LCCOMB_X111_Y18_N4
\U2|led_cnt[19]~45\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[19]~45_combout\ = (\U2|leds_wire~0_combout\) # (((!\U2|Equal0~4_combout\) # (!\U2|Equal0~5_combout\)) # (!\U2|Equal0~6_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire~0_combout\,
	datab => \U2|Equal0~6_combout\,
	datac => \U2|Equal0~5_combout\,
	datad => \U2|Equal0~4_combout\,
	combout => \U2|led_cnt[19]~45_combout\);

-- Location: FF_X111_Y18_N11
\U2|led_cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[0]~23_combout\,
	asdata => \~GND~combout\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(0));

-- Location: LCCOMB_X111_Y18_N12
\U2|led_cnt[1]~25\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[1]~25_combout\ = (\U2|led_cnt\(1) & (\U2|led_cnt[0]~24\ & VCC)) # (!\U2|led_cnt\(1) & (!\U2|led_cnt[0]~24\))
-- \U2|led_cnt[1]~26\ = CARRY((!\U2|led_cnt\(1) & !\U2|led_cnt[0]~24\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(1),
	datad => VCC,
	cin => \U2|led_cnt[0]~24\,
	combout => \U2|led_cnt[1]~25_combout\,
	cout => \U2|led_cnt[1]~26\);

-- Location: FF_X111_Y18_N13
\U2|led_cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[1]~25_combout\,
	asdata => \~GND~combout\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(1));

-- Location: LCCOMB_X111_Y18_N14
\U2|led_cnt[2]~27\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[2]~27_combout\ = (\U2|led_cnt\(2) & ((GND) # (!\U2|led_cnt[1]~26\))) # (!\U2|led_cnt\(2) & (\U2|led_cnt[1]~26\ $ (GND)))
-- \U2|led_cnt[2]~28\ = CARRY((\U2|led_cnt\(2)) # (!\U2|led_cnt[1]~26\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(2),
	datad => VCC,
	cin => \U2|led_cnt[1]~26\,
	combout => \U2|led_cnt[2]~27_combout\,
	cout => \U2|led_cnt[2]~28\);

-- Location: FF_X111_Y18_N15
\U2|led_cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[2]~27_combout\,
	asdata => \~GND~combout\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(2));

-- Location: LCCOMB_X111_Y18_N16
\U2|led_cnt[3]~29\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[3]~29_combout\ = (\U2|led_cnt\(3) & (\U2|led_cnt[2]~28\ & VCC)) # (!\U2|led_cnt\(3) & (!\U2|led_cnt[2]~28\))
-- \U2|led_cnt[3]~30\ = CARRY((!\U2|led_cnt\(3) & !\U2|led_cnt[2]~28\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(3),
	datad => VCC,
	cin => \U2|led_cnt[2]~28\,
	combout => \U2|led_cnt[3]~29_combout\,
	cout => \U2|led_cnt[3]~30\);

-- Location: FF_X111_Y18_N17
\U2|led_cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[3]~29_combout\,
	asdata => \~GND~combout\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(3));

-- Location: LCCOMB_X111_Y18_N18
\U2|led_cnt[4]~31\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[4]~31_combout\ = (\U2|led_cnt\(4) & ((GND) # (!\U2|led_cnt[3]~30\))) # (!\U2|led_cnt\(4) & (\U2|led_cnt[3]~30\ $ (GND)))
-- \U2|led_cnt[4]~32\ = CARRY((\U2|led_cnt\(4)) # (!\U2|led_cnt[3]~30\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(4),
	datad => VCC,
	cin => \U2|led_cnt[3]~30\,
	combout => \U2|led_cnt[4]~31_combout\,
	cout => \U2|led_cnt[4]~32\);

-- Location: FF_X111_Y18_N19
\U2|led_cnt[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[4]~31_combout\,
	asdata => \~GND~combout\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(4));

-- Location: LCCOMB_X111_Y18_N20
\U2|led_cnt[5]~33\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[5]~33_combout\ = (\U2|led_cnt\(5) & (\U2|led_cnt[4]~32\ & VCC)) # (!\U2|led_cnt\(5) & (!\U2|led_cnt[4]~32\))
-- \U2|led_cnt[5]~34\ = CARRY((!\U2|led_cnt\(5) & !\U2|led_cnt[4]~32\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(5),
	datad => VCC,
	cin => \U2|led_cnt[4]~32\,
	combout => \U2|led_cnt[5]~33_combout\,
	cout => \U2|led_cnt[5]~34\);

-- Location: FF_X111_Y18_N21
\U2|led_cnt[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[5]~33_combout\,
	asdata => \~GND~combout\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(5));

-- Location: LCCOMB_X111_Y18_N22
\U2|led_cnt[6]~35\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[6]~35_combout\ = (\U2|led_cnt\(6) & ((GND) # (!\U2|led_cnt[5]~34\))) # (!\U2|led_cnt\(6) & (\U2|led_cnt[5]~34\ $ (GND)))
-- \U2|led_cnt[6]~36\ = CARRY((\U2|led_cnt\(6)) # (!\U2|led_cnt[5]~34\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101010101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(6),
	datad => VCC,
	cin => \U2|led_cnt[5]~34\,
	combout => \U2|led_cnt[6]~35_combout\,
	cout => \U2|led_cnt[6]~36\);

-- Location: FF_X111_Y18_N23
\U2|led_cnt[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[6]~35_combout\,
	asdata => \sys_rst_n_in~input_o\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(6));

-- Location: LCCOMB_X111_Y18_N24
\U2|led_cnt[7]~37\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[7]~37_combout\ = (\U2|led_cnt\(7) & (\U2|led_cnt[6]~36\ & VCC)) # (!\U2|led_cnt\(7) & (!\U2|led_cnt[6]~36\))
-- \U2|led_cnt[7]~38\ = CARRY((!\U2|led_cnt\(7) & !\U2|led_cnt[6]~36\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(7),
	datad => VCC,
	cin => \U2|led_cnt[6]~36\,
	combout => \U2|led_cnt[7]~37_combout\,
	cout => \U2|led_cnt[7]~38\);

-- Location: FF_X111_Y18_N25
\U2|led_cnt[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[7]~37_combout\,
	asdata => \~GND~combout\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(7));

-- Location: LCCOMB_X111_Y18_N26
\U2|led_cnt[8]~39\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[8]~39_combout\ = (\U2|led_cnt\(8) & ((GND) # (!\U2|led_cnt[7]~38\))) # (!\U2|led_cnt\(8) & (\U2|led_cnt[7]~38\ $ (GND)))
-- \U2|led_cnt[8]~40\ = CARRY((\U2|led_cnt\(8)) # (!\U2|led_cnt[7]~38\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101010101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(8),
	datad => VCC,
	cin => \U2|led_cnt[7]~38\,
	combout => \U2|led_cnt[8]~39_combout\,
	cout => \U2|led_cnt[8]~40\);

-- Location: FF_X111_Y18_N27
\U2|led_cnt[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[8]~39_combout\,
	asdata => \sys_rst_n_in~input_o\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(8));

-- Location: LCCOMB_X111_Y18_N28
\U2|led_cnt[9]~41\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[9]~41_combout\ = (\U2|led_cnt\(9) & (\U2|led_cnt[8]~40\ & VCC)) # (!\U2|led_cnt\(9) & (!\U2|led_cnt[8]~40\))
-- \U2|led_cnt[9]~42\ = CARRY((!\U2|led_cnt\(9) & !\U2|led_cnt[8]~40\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(9),
	datad => VCC,
	cin => \U2|led_cnt[8]~40\,
	combout => \U2|led_cnt[9]~41_combout\,
	cout => \U2|led_cnt[9]~42\);

-- Location: FF_X111_Y18_N29
\U2|led_cnt[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[9]~41_combout\,
	asdata => \sys_rst_n_in~input_o\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(9));

-- Location: LCCOMB_X111_Y18_N30
\U2|led_cnt[10]~43\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[10]~43_combout\ = (\U2|led_cnt\(10) & ((GND) # (!\U2|led_cnt[9]~42\))) # (!\U2|led_cnt\(10) & (\U2|led_cnt[9]~42\ $ (GND)))
-- \U2|led_cnt[10]~44\ = CARRY((\U2|led_cnt\(10)) # (!\U2|led_cnt[9]~42\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101010101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(10),
	datad => VCC,
	cin => \U2|led_cnt[9]~42\,
	combout => \U2|led_cnt[10]~43_combout\,
	cout => \U2|led_cnt[10]~44\);

-- Location: FF_X111_Y18_N31
\U2|led_cnt[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[10]~43_combout\,
	asdata => \~GND~combout\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(10));

-- Location: LCCOMB_X111_Y17_N0
\U2|led_cnt[11]~46\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[11]~46_combout\ = (\U2|led_cnt\(11) & (\U2|led_cnt[10]~44\ & VCC)) # (!\U2|led_cnt\(11) & (!\U2|led_cnt[10]~44\))
-- \U2|led_cnt[11]~47\ = CARRY((!\U2|led_cnt\(11) & !\U2|led_cnt[10]~44\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(11),
	datad => VCC,
	cin => \U2|led_cnt[10]~44\,
	combout => \U2|led_cnt[11]~46_combout\,
	cout => \U2|led_cnt[11]~47\);

-- Location: FF_X111_Y17_N1
\U2|led_cnt[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[11]~46_combout\,
	asdata => \sys_rst_n_in~input_o\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(11));

-- Location: LCCOMB_X111_Y17_N2
\U2|led_cnt[12]~48\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[12]~48_combout\ = (\U2|led_cnt\(12) & ((GND) # (!\U2|led_cnt[11]~47\))) # (!\U2|led_cnt\(12) & (\U2|led_cnt[11]~47\ $ (GND)))
-- \U2|led_cnt[12]~49\ = CARRY((\U2|led_cnt\(12)) # (!\U2|led_cnt[11]~47\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(12),
	datad => VCC,
	cin => \U2|led_cnt[11]~47\,
	combout => \U2|led_cnt[12]~48_combout\,
	cout => \U2|led_cnt[12]~49\);

-- Location: FF_X111_Y17_N3
\U2|led_cnt[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[12]~48_combout\,
	asdata => \~GND~combout\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(12));

-- Location: LCCOMB_X111_Y17_N4
\U2|led_cnt[13]~50\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[13]~50_combout\ = (\U2|led_cnt\(13) & (\U2|led_cnt[12]~49\ & VCC)) # (!\U2|led_cnt\(13) & (!\U2|led_cnt[12]~49\))
-- \U2|led_cnt[13]~51\ = CARRY((!\U2|led_cnt\(13) & !\U2|led_cnt[12]~49\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(13),
	datad => VCC,
	cin => \U2|led_cnt[12]~49\,
	combout => \U2|led_cnt[13]~50_combout\,
	cout => \U2|led_cnt[13]~51\);

-- Location: FF_X111_Y17_N5
\U2|led_cnt[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[13]~50_combout\,
	asdata => \~GND~combout\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(13));

-- Location: LCCOMB_X111_Y17_N6
\U2|led_cnt[14]~52\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[14]~52_combout\ = (\U2|led_cnt\(14) & ((GND) # (!\U2|led_cnt[13]~51\))) # (!\U2|led_cnt\(14) & (\U2|led_cnt[13]~51\ $ (GND)))
-- \U2|led_cnt[14]~53\ = CARRY((\U2|led_cnt\(14)) # (!\U2|led_cnt[13]~51\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101010101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(14),
	datad => VCC,
	cin => \U2|led_cnt[13]~51\,
	combout => \U2|led_cnt[14]~52_combout\,
	cout => \U2|led_cnt[14]~53\);

-- Location: FF_X111_Y17_N7
\U2|led_cnt[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[14]~52_combout\,
	asdata => \sys_rst_n_in~input_o\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(14));

-- Location: LCCOMB_X111_Y17_N8
\U2|led_cnt[15]~54\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[15]~54_combout\ = (\U2|led_cnt\(15) & (\U2|led_cnt[14]~53\ & VCC)) # (!\U2|led_cnt\(15) & (!\U2|led_cnt[14]~53\))
-- \U2|led_cnt[15]~55\ = CARRY((!\U2|led_cnt\(15) & !\U2|led_cnt[14]~53\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(15),
	datad => VCC,
	cin => \U2|led_cnt[14]~53\,
	combout => \U2|led_cnt[15]~54_combout\,
	cout => \U2|led_cnt[15]~55\);

-- Location: FF_X111_Y17_N9
\U2|led_cnt[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[15]~54_combout\,
	asdata => \~GND~combout\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(15));

-- Location: LCCOMB_X111_Y17_N10
\U2|led_cnt[16]~56\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[16]~56_combout\ = (\U2|led_cnt\(16) & ((GND) # (!\U2|led_cnt[15]~55\))) # (!\U2|led_cnt\(16) & (\U2|led_cnt[15]~55\ $ (GND)))
-- \U2|led_cnt[16]~57\ = CARRY((\U2|led_cnt\(16)) # (!\U2|led_cnt[15]~55\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101010101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(16),
	datad => VCC,
	cin => \U2|led_cnt[15]~55\,
	combout => \U2|led_cnt[16]~56_combout\,
	cout => \U2|led_cnt[16]~57\);

-- Location: FF_X111_Y17_N11
\U2|led_cnt[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[16]~56_combout\,
	asdata => \~GND~combout\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(16));

-- Location: LCCOMB_X111_Y17_N12
\U2|led_cnt[17]~58\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[17]~58_combout\ = (\U2|led_cnt\(17) & (\U2|led_cnt[16]~57\ & VCC)) # (!\U2|led_cnt\(17) & (!\U2|led_cnt[16]~57\))
-- \U2|led_cnt[17]~59\ = CARRY((!\U2|led_cnt\(17) & !\U2|led_cnt[16]~57\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(17),
	datad => VCC,
	cin => \U2|led_cnt[16]~57\,
	combout => \U2|led_cnt[17]~58_combout\,
	cout => \U2|led_cnt[17]~59\);

-- Location: FF_X111_Y17_N13
\U2|led_cnt[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[17]~58_combout\,
	asdata => \~GND~combout\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(17));

-- Location: LCCOMB_X111_Y17_N14
\U2|led_cnt[18]~60\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[18]~60_combout\ = (\U2|led_cnt\(18) & ((GND) # (!\U2|led_cnt[17]~59\))) # (!\U2|led_cnt\(18) & (\U2|led_cnt[17]~59\ $ (GND)))
-- \U2|led_cnt[18]~61\ = CARRY((\U2|led_cnt\(18)) # (!\U2|led_cnt[17]~59\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(18),
	datad => VCC,
	cin => \U2|led_cnt[17]~59\,
	combout => \U2|led_cnt[18]~60_combout\,
	cout => \U2|led_cnt[18]~61\);

-- Location: FF_X111_Y17_N15
\U2|led_cnt[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[18]~60_combout\,
	asdata => \sys_rst_n_in~input_o\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(18));

-- Location: LCCOMB_X111_Y17_N16
\U2|led_cnt[19]~62\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led_cnt[19]~62_combout\ = (\U2|led_cnt\(19) & (\U2|led_cnt[18]~61\ & VCC)) # (!\U2|led_cnt\(19) & (!\U2|led_cnt[18]~61\))
-- \U2|led_cnt[19]~63\ = CARRY((!\U2|led_cnt\(19) & !\U2|led_cnt[18]~61\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(19),
	datad => VCC,
	cin => \U2|led_cnt[18]~61\,
	combout => \U2|led_cnt[19]~62_combout\,
	cout => \U2|led_cnt[19]~63\);

-- Location: FF_X111_Y17_N17
\U2|led_cnt[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[19]~62_combout\,
	asdata => \sys_rst_n_in~input_o\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(19));

-- Location: FF_X111_Y17_N19
\U2|led_cnt[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led_cnt[20]~64_combout\,
	asdata => \~GND~combout\,
	sload => \U2|leds_wire~0_combout\,
	ena => \U2|led_cnt[19]~45_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led_cnt\(20));

-- Location: LCCOMB_X111_Y17_N30
\U2|Equal0~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Equal0~8_combout\ = (!\U2|led_cnt\(20) & (!\U2|led_cnt\(22) & !\U2|led_cnt\(21)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|led_cnt\(20),
	datac => \U2|led_cnt\(22),
	datad => \U2|led_cnt\(21),
	combout => \U2|Equal0~8_combout\);

-- Location: LCCOMB_X110_Y18_N30
\U2|led~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led~0_combout\ = (\U2|led_cnt\(9) & ((\U2|led_cnt\(7)) # ((\U2|led_cnt\(6)) # (\U2|led_cnt\(8)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(7),
	datab => \U2|led_cnt\(6),
	datac => \U2|led_cnt\(8),
	datad => \U2|led_cnt\(9),
	combout => \U2|led~0_combout\);

-- Location: LCCOMB_X110_Y18_N20
\U2|led~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led~1_combout\ = (\U2|led_cnt\(15)) # ((\U2|led_cnt\(14) & ((\U2|led~0_combout\) # (!\U2|Equal0~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led~0_combout\,
	datab => \U2|led_cnt\(15),
	datac => \U2|Equal0~0_combout\,
	datad => \U2|led_cnt\(14),
	combout => \U2|led~1_combout\);

-- Location: LCCOMB_X111_Y17_N24
\U2|led~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led~2_combout\ = (\U2|led_cnt\(16) & (\U2|led_cnt\(19) & (\U2|led_cnt\(18) & \U2|led_cnt\(17))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|led_cnt\(16),
	datab => \U2|led_cnt\(19),
	datac => \U2|led_cnt\(18),
	datad => \U2|led_cnt\(17),
	combout => \U2|led~2_combout\);

-- Location: LCCOMB_X110_Y18_N16
\U2|Equal0~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Equal0~7_combout\ = (\U2|Equal0~5_combout\ & (\U2|Equal0~6_combout\ & \U2|Equal0~4_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Equal0~5_combout\,
	datac => \U2|Equal0~6_combout\,
	datad => \U2|Equal0~4_combout\,
	combout => \U2|Equal0~7_combout\);

-- Location: LCCOMB_X110_Y18_N18
\U2|led~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led~3_combout\ = ((\U2|Equal0~7_combout\) # ((\U2|led~1_combout\ & \U2|led~2_combout\))) # (!\U2|Equal0~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Equal0~8_combout\,
	datab => \U2|led~1_combout\,
	datac => \U2|led~2_combout\,
	datad => \U2|Equal0~7_combout\,
	combout => \U2|led~3_combout\);

-- Location: LCCOMB_X110_Y18_N24
\U2|led~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|led~4_combout\ = (\U2|repeat_en_d1~q\ & (((\U2|led~q\ & \U2|led~3_combout\)))) # (!\U2|repeat_en_d1~q\ & ((\U2|repeat_en_d0~q\) # ((\U2|led~q\ & \U2|led~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|repeat_en_d1~q\,
	datab => \U2|repeat_en_d0~q\,
	datac => \U2|led~q\,
	datad => \U2|led~3_combout\,
	combout => \U2|led~4_combout\);

-- Location: FF_X110_Y18_N25
\U2|led\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|led~4_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|led~q\);

-- Location: LCCOMB_X107_Y21_N8
\U2|Mux11~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~17_combout\ = (\U1|data\(3) & (!\U1|data\(7) & !\U1|data\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(3),
	datab => \U1|data\(7),
	datad => \U1|data\(6),
	combout => \U2|Mux11~17_combout\);

-- Location: LCCOMB_X107_Y21_N12
\U2|Mux11~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~11_combout\ = (\U1|data\(2) & ((\U1|data\(4)) # ((!\U1|data\(0)) # (!\U1|data\(1))))) # (!\U1|data\(2) & (!\U1|data\(4) & (\U1|data\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001101010111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(2),
	datab => \U1|data\(4),
	datac => \U1|data\(1),
	datad => \U1|data\(0),
	combout => \U2|Mux11~11_combout\);

-- Location: LCCOMB_X107_Y21_N22
\U2|Mux11~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~12_combout\ = (\U1|data\(4) & (((\U2|Mux11~11_combout\)))) # (!\U1|data\(4) & (\U2|leds_wire\(0) & ((\U1|data\(5)) # (\U2|Mux11~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U1|data\(4),
	datac => \U2|leds_wire\(0),
	datad => \U2|Mux11~11_combout\,
	combout => \U2|Mux11~12_combout\);

-- Location: LCCOMB_X107_Y19_N26
\U2|Add1~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~2_combout\ = (\U1|data\(3) & (\U1|data\(1) & (\U1|data\(0) & \U1|data\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(3),
	datab => \U1|data\(1),
	datac => \U1|data\(0),
	datad => \U1|data\(4),
	combout => \U2|Add1~2_combout\);

-- Location: LCCOMB_X107_Y18_N6
\U2|last_leds_wire[11]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|last_leds_wire[11]~0_combout\ = (\sys_rst_n_in~input_o\ & (\U2|repeat_en_d0~q\ & !\U2|repeat_en_d1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \sys_rst_n_in~input_o\,
	datac => \U2|repeat_en_d0~q\,
	datad => \U2|repeat_en_d1~q\,
	combout => \U2|last_leds_wire[11]~0_combout\);

-- Location: FF_X107_Y19_N25
\U2|last_leds_wire[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	asdata => \U2|leds_wire\(0),
	sload => VCC,
	ena => \U2|last_leds_wire[11]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|last_leds_wire\(0));

-- Location: LCCOMB_X107_Y19_N0
\U2|Add1~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~3_combout\ = (\U2|Add1~2_combout\ & (\U2|last_leds_wire\(0) $ (VCC))) # (!\U2|Add1~2_combout\ & (\U2|last_leds_wire\(0) & VCC))
-- \U2|Add1~4\ = CARRY((\U2|Add1~2_combout\ & \U2|last_leds_wire\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Add1~2_combout\,
	datab => \U2|last_leds_wire\(0),
	datad => VCC,
	combout => \U2|Add1~3_combout\,
	cout => \U2|Add1~4\);

-- Location: LCCOMB_X107_Y21_N4
\U2|Add1~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~5_combout\ = (\U1|data\(5) & (\U2|leds_wire\(0))) # (!\U1|data\(5) & ((\U2|Add1~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datac => \U2|leds_wire\(0),
	datad => \U2|Add1~3_combout\,
	combout => \U2|Add1~5_combout\);

-- Location: LCCOMB_X107_Y21_N2
\U2|Add1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~0_combout\ = (\U2|leds_wire\(0) & \U1|data\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U2|leds_wire\(0),
	datad => \U1|data\(5),
	combout => \U2|Add1~0_combout\);

-- Location: LCCOMB_X106_Y19_N4
\U2|Mux10~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~9_combout\ = (\U1|data\(2)) # (\U1|data\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|data\(2),
	datad => \U1|data\(0),
	combout => \U2|Mux10~9_combout\);

-- Location: LCCOMB_X108_Y18_N28
\U2|Mux8~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux8~0_combout\ = (\U1|data\(5) & (\U2|leds_wire\(3))) # (!\U1|data\(5) & ((\U1|data\(0) & (\U2|leds_wire\(3) & !\U1|data\(1))) # (!\U1|data\(0) & ((\U1|data\(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U2|leds_wire\(3),
	datac => \U1|data\(0),
	datad => \U1|data\(1),
	combout => \U2|Mux8~0_combout\);

-- Location: LCCOMB_X107_Y18_N28
\U2|Mux8~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux8~1_combout\ = (\U1|data\(4) & (((\U1|data\(5))))) # (!\U1|data\(4) & (!\U1|data\(5) & ((\U1|data\(0)) # (\U1|data\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001111000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(0),
	datab => \U1|data\(4),
	datac => \U1|data\(5),
	datad => \U1|data\(1),
	combout => \U2|Mux8~1_combout\);

-- Location: LCCOMB_X108_Y18_N30
\U2|Mux8~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux8~2_combout\ = (\U1|data\(5) & ((\U2|Mux8~1_combout\ & (\U1|data\(2))) # (!\U2|Mux8~1_combout\ & ((\U2|leds_wire\(3)))))) # (!\U1|data\(5) & (\U1|data\(2) & ((!\U2|Mux8~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(2),
	datab => \U2|leds_wire\(3),
	datac => \U1|data\(5),
	datad => \U2|Mux8~1_combout\,
	combout => \U2|Mux8~2_combout\);

-- Location: LCCOMB_X107_Y18_N24
\U2|Mux11~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~4_combout\ = \U1|data\(0) $ (\U1|data\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|data\(0),
	datad => \U1|data\(1),
	combout => \U2|Mux11~4_combout\);

-- Location: LCCOMB_X108_Y18_N24
\U2|Mux8~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux8~3_combout\ = (\U1|data\(1) & (\U2|last_leds_wire\(3))) # (!\U1|data\(1) & ((\U2|last_leds_wire\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|data\(1),
	datac => \U2|last_leds_wire\(3),
	datad => \U2|last_leds_wire\(2),
	combout => \U2|Mux8~3_combout\);

-- Location: LCCOMB_X108_Y18_N2
\U2|Mux8~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux8~4_combout\ = (\U2|Mux11~4_combout\ & (\U2|leds_wire\(3))) # (!\U2|Mux11~4_combout\ & ((\U1|data\(5) & (\U2|leds_wire\(3))) # (!\U1|data\(5) & ((\U2|Mux8~3_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(3),
	datab => \U2|Mux11~4_combout\,
	datac => \U1|data\(5),
	datad => \U2|Mux8~3_combout\,
	combout => \U2|Mux8~4_combout\);

-- Location: LCCOMB_X108_Y18_N4
\U2|Mux8~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux8~5_combout\ = (\U1|data\(4) & ((\U2|Mux8~2_combout\ & ((\U2|Mux8~4_combout\))) # (!\U2|Mux8~2_combout\ & (\U2|Mux8~0_combout\)))) # (!\U1|data\(4) & (((\U2|Mux8~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(4),
	datab => \U2|Mux8~0_combout\,
	datac => \U2|Mux8~2_combout\,
	datad => \U2|Mux8~4_combout\,
	combout => \U2|Mux8~5_combout\);

-- Location: LCCOMB_X107_Y21_N20
\U2|Mux11~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~7_combout\ = (!\U1|data\(3) & (!\U1|data\(7) & !\U1|data\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(3),
	datac => \U1|data\(7),
	datad => \U1|data\(6),
	combout => \U2|Mux11~7_combout\);

-- Location: LCCOMB_X108_Y18_N22
\U2|Mux8~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux8~6_combout\ = (\U3|Mux2~1_combout\ & (((\U2|Mux8~5_combout\ & \U2|Mux11~7_combout\)))) # (!\U3|Mux2~1_combout\ & ((\U2|leds_wire\(3)) # ((\U2|Mux8~5_combout\ & \U2|Mux11~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U3|Mux2~1_combout\,
	datab => \U2|leds_wire\(3),
	datac => \U2|Mux8~5_combout\,
	datad => \U2|Mux11~7_combout\,
	combout => \U2|Mux8~6_combout\);

-- Location: LCCOMB_X106_Y18_N2
\U2|Mux7~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux7~0_combout\ = (\U1|data\(5) & (\U2|leds_wire\(4))) # (!\U1|data\(5) & ((\U1|data\(0) & (\U2|leds_wire\(4) & !\U1|data\(1))) # (!\U1|data\(0) & ((\U1|data\(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(4),
	datab => \U1|data\(0),
	datac => \U1|data\(5),
	datad => \U1|data\(1),
	combout => \U2|Mux7~0_combout\);

-- Location: LCCOMB_X106_Y18_N18
\U2|Mux7~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux7~2_combout\ = (\U1|data\(1) & ((\U2|last_leds_wire\(4)))) # (!\U1|data\(1) & (\U2|last_leds_wire\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|last_leds_wire\(3),
	datac => \U1|data\(1),
	datad => \U2|last_leds_wire\(4),
	combout => \U2|Mux7~2_combout\);

-- Location: LCCOMB_X106_Y18_N8
\U2|Mux7~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux7~3_combout\ = (\U2|Mux11~4_combout\ & (\U2|leds_wire\(4))) # (!\U2|Mux11~4_combout\ & ((\U1|data\(5) & (\U2|leds_wire\(4))) # (!\U1|data\(5) & ((\U2|Mux7~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(4),
	datab => \U2|Mux11~4_combout\,
	datac => \U1|data\(5),
	datad => \U2|Mux7~2_combout\,
	combout => \U2|Mux7~3_combout\);

-- Location: LCCOMB_X106_Y18_N24
\U2|Mux11~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~1_combout\ = (\U1|data\(0) & (!\U1|data\(5) & !\U1|data\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|data\(0),
	datac => \U1|data\(5),
	datad => \U1|data\(1),
	combout => \U2|Mux11~1_combout\);

-- Location: LCCOMB_X107_Y18_N16
\U2|Add1~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~15_combout\ = (\U1|data\(5) & \U2|leds_wire\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|data\(5),
	datad => \U2|leds_wire\(4),
	combout => \U2|Add1~15_combout\);

-- Location: LCCOMB_X106_Y18_N28
\U2|Mux7~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux7~1_combout\ = (\U1|data\(4) & (((\U1|data\(2))))) # (!\U1|data\(4) & ((\U2|Add1~15_combout\) # ((\U2|Mux11~1_combout\ & \U1|data\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(4),
	datab => \U2|Mux11~1_combout\,
	datac => \U1|data\(2),
	datad => \U2|Add1~15_combout\,
	combout => \U2|Mux7~1_combout\);

-- Location: LCCOMB_X106_Y18_N10
\U2|Mux7~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux7~4_combout\ = (\U1|data\(4) & ((\U2|Mux7~1_combout\ & ((\U2|Mux7~3_combout\))) # (!\U2|Mux7~1_combout\ & (\U2|Mux7~0_combout\)))) # (!\U1|data\(4) & (((\U2|Mux7~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(4),
	datab => \U2|Mux7~0_combout\,
	datac => \U2|Mux7~3_combout\,
	datad => \U2|Mux7~1_combout\,
	combout => \U2|Mux7~4_combout\);

-- Location: LCCOMB_X107_Y18_N22
\U2|Mux7~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux7~5_combout\ = (\U2|Mux11~7_combout\ & ((\U2|Mux7~4_combout\) # ((\U2|leds_wire\(4) & !\U3|Mux2~1_combout\)))) # (!\U2|Mux11~7_combout\ & (\U2|leds_wire\(4) & (!\U3|Mux2~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux11~7_combout\,
	datab => \U2|leds_wire\(4),
	datac => \U3|Mux2~1_combout\,
	datad => \U2|Mux7~4_combout\,
	combout => \U2|Mux7~5_combout\);

-- Location: LCCOMB_X106_Y19_N20
\U2|Mux10~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~11_combout\ = (\U1|data\(1) & (((\U1|data\(4)) # (!\U1|data\(0))) # (!\U1|data\(2)))) # (!\U1|data\(1) & (\U1|data\(2) & (!\U1|data\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010011010101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(1),
	datab => \U1|data\(2),
	datac => \U1|data\(4),
	datad => \U1|data\(0),
	combout => \U2|Mux10~11_combout\);

-- Location: LCCOMB_X107_Y18_N30
\U2|Mux7~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux7~7_combout\ = (\U1|data\(4) & (((\U2|Mux10~11_combout\)))) # (!\U1|data\(4) & (\U2|leds_wire\(4) & ((\U2|Mux10~11_combout\) # (\U1|data\(5)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110010011100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(4),
	datab => \U2|leds_wire\(4),
	datac => \U2|Mux10~11_combout\,
	datad => \U1|data\(5),
	combout => \U2|Mux7~7_combout\);

-- Location: LCCOMB_X106_Y20_N12
\U2|Mux6~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux6~7_combout\ = (\U1|data\(4) & (\U2|Mux10~11_combout\)) # (!\U1|data\(4) & (\U2|leds_wire\(5) & ((\U2|Mux10~11_combout\) # (\U1|data\(5)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux10~11_combout\,
	datab => \U1|data\(4),
	datac => \U2|leds_wire\(5),
	datad => \U1|data\(5),
	combout => \U2|Mux6~7_combout\);

-- Location: LCCOMB_X106_Y21_N0
\U2|Mux5~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux5~1_combout\ = (\U1|data\(5) & (\U2|leds_wire\(6))) # (!\U1|data\(5) & ((\U1|data\(0) & (\U2|leds_wire\(6) & !\U1|data\(1))) # (!\U1|data\(0) & ((\U1|data\(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(6),
	datab => \U1|data\(0),
	datac => \U1|data\(5),
	datad => \U1|data\(1),
	combout => \U2|Mux5~1_combout\);

-- Location: LCCOMB_X106_Y21_N30
\U2|Mux5~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux5~2_combout\ = (\U1|data\(2) & (((\U1|data\(4))))) # (!\U1|data\(2) & (\U2|Mux5~1_combout\ & ((\U1|data\(5)) # (\U1|data\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U1|data\(2),
	datac => \U1|data\(4),
	datad => \U2|Mux5~1_combout\,
	combout => \U2|Mux5~2_combout\);

-- Location: LCCOMB_X106_Y21_N14
\U2|Mux5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux5~0_combout\ = (\U1|data\(5) & (\U2|leds_wire\(6))) # (!\U1|data\(5) & (((\U1|data\(0) & \U1|data\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(6),
	datab => \U1|data\(0),
	datac => \U1|data\(5),
	datad => \U1|data\(1),
	combout => \U2|Mux5~0_combout\);

-- Location: LCCOMB_X106_Y21_N4
\U2|Mux5~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux5~3_combout\ = (\U1|data\(1) & (\U2|last_leds_wire\(6))) # (!\U1|data\(1) & ((\U2|last_leds_wire\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(1),
	datac => \U2|last_leds_wire\(6),
	datad => \U2|last_leds_wire\(5),
	combout => \U2|Mux5~3_combout\);

-- Location: LCCOMB_X106_Y21_N6
\U2|Mux5~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux5~4_combout\ = (\U1|data\(5) & (\U2|leds_wire\(6))) # (!\U1|data\(5) & ((\U2|Mux11~4_combout\ & (\U2|leds_wire\(6))) # (!\U2|Mux11~4_combout\ & ((\U2|Mux5~3_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(6),
	datab => \U1|data\(5),
	datac => \U2|Mux5~3_combout\,
	datad => \U2|Mux11~4_combout\,
	combout => \U2|Mux5~4_combout\);

-- Location: LCCOMB_X106_Y21_N24
\U2|Mux5~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux5~5_combout\ = (\U2|Mux5~2_combout\ & (((\U2|Mux5~4_combout\)) # (!\U1|data\(2)))) # (!\U2|Mux5~2_combout\ & (\U1|data\(2) & (\U2|Mux5~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101001100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux5~2_combout\,
	datab => \U1|data\(2),
	datac => \U2|Mux5~0_combout\,
	datad => \U2|Mux5~4_combout\,
	combout => \U2|Mux5~5_combout\);

-- Location: LCCOMB_X106_Y21_N26
\U2|Mux5~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux5~6_combout\ = (\U2|leds_wire\(6) & (((\U2|Mux11~7_combout\ & \U2|Mux5~5_combout\)) # (!\U3|Mux2~1_combout\))) # (!\U2|leds_wire\(6) & (((\U2|Mux11~7_combout\ & \U2|Mux5~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(6),
	datab => \U3|Mux2~1_combout\,
	datac => \U2|Mux11~7_combout\,
	datad => \U2|Mux5~5_combout\,
	combout => \U2|Mux5~6_combout\);

-- Location: LCCOMB_X109_Y19_N20
\U2|Add1~24\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~24_combout\ = (\U2|leds_wire\(7) & \U1|data\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|leds_wire\(7),
	datad => \U1|data\(5),
	combout => \U2|Add1~24_combout\);

-- Location: LCCOMB_X106_Y19_N16
\U2|Mux4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux4~0_combout\ = (\U1|data\(1) & (\U2|last_leds_wire\(7))) # (!\U1|data\(1) & ((\U2|last_leds_wire\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(1),
	datab => \U2|last_leds_wire\(7),
	datad => \U2|last_leds_wire\(6),
	combout => \U2|Mux4~0_combout\);

-- Location: LCCOMB_X111_Y19_N22
\U2|Mux11~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~19_combout\ = (!\U1|data\(5) & \U1|data\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|data\(5),
	datad => \U1|data\(1),
	combout => \U2|Mux11~19_combout\);

-- Location: LCCOMB_X110_Y19_N8
\U2|Mux4~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux4~1_combout\ = (\U1|data\(2) & (!\U2|Mux11~4_combout\ & (\U2|Mux4~0_combout\))) # (!\U1|data\(2) & (\U2|Mux11~4_combout\ & ((\U2|Mux11~19_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110010000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(2),
	datab => \U2|Mux11~4_combout\,
	datac => \U2|Mux4~0_combout\,
	datad => \U2|Mux11~19_combout\,
	combout => \U2|Mux4~1_combout\);

-- Location: LCCOMB_X110_Y19_N10
\U2|Mux4~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux4~2_combout\ = (\U2|Mux11~4_combout\ & (((\U2|leds_wire\(7)) # (\U2|Mux4~1_combout\)))) # (!\U2|Mux11~4_combout\ & ((\U1|data\(5) & (\U2|leds_wire\(7))) # (!\U1|data\(5) & ((\U2|Mux4~1_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U2|leds_wire\(7),
	datac => \U2|Mux4~1_combout\,
	datad => \U2|Mux11~4_combout\,
	combout => \U2|Mux4~2_combout\);

-- Location: LCCOMB_X110_Y19_N0
\U2|Mux4~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux4~3_combout\ = (\U2|Mux11~7_combout\ & ((\U1|data\(4) & ((\U2|Mux4~2_combout\))) # (!\U1|data\(4) & (\U2|Add1~24_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Add1~24_combout\,
	datab => \U1|data\(4),
	datac => \U2|Mux11~7_combout\,
	datad => \U2|Mux4~2_combout\,
	combout => \U2|Mux4~3_combout\);

-- Location: LCCOMB_X110_Y19_N30
\U2|Mux4~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux4~4_combout\ = (\U2|leds_wire\(7) & ((\U1|data\(7)) # (\U1|data\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|leds_wire\(7),
	datac => \U1|data\(7),
	datad => \U1|data\(6),
	combout => \U2|Mux4~4_combout\);

-- Location: LCCOMB_X109_Y19_N14
\U2|Mux4~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux4~5_combout\ = (\U2|leds_wire\(7) & ((\U1|data\(5)) # (\U1|data\(1) $ (\U1|data\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110001001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(1),
	datab => \U2|leds_wire\(7),
	datac => \U1|data\(2),
	datad => \U1|data\(5),
	combout => \U2|Mux4~5_combout\);

-- Location: LCCOMB_X109_Y19_N10
\U2|Mux4~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux4~6_combout\ = (\U1|data\(2) & (!\U2|leds_wire\(7) & ((!\U1|data\(1))))) # (!\U1|data\(2) & (\U1|data\(1) & ((!\U1|data\(5)) # (!\U2|leds_wire\(7)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001010100100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(2),
	datab => \U2|leds_wire\(7),
	datac => \U1|data\(5),
	datad => \U1|data\(1),
	combout => \U2|Mux4~6_combout\);

-- Location: LCCOMB_X109_Y19_N8
\U2|Mux4~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux4~7_combout\ = (\U1|data\(5) & (((\U2|leds_wire\(7))))) # (!\U1|data\(5) & ((\U1|data\(2) & (\U2|leds_wire\(7) & !\U1|data\(1))) # (!\U1|data\(2) & ((\U1|data\(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100010111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(2),
	datab => \U2|leds_wire\(7),
	datac => \U1|data\(5),
	datad => \U1|data\(1),
	combout => \U2|Mux4~7_combout\);

-- Location: LCCOMB_X111_Y19_N30
\U2|Add1~27\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~27_combout\ = (\U1|data\(5) & \U2|leds_wire\(8))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|data\(5),
	datad => \U2|leds_wire\(8),
	combout => \U2|Add1~27_combout\);

-- Location: LCCOMB_X111_Y19_N12
\U2|Mux3~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux3~4_combout\ = (\U1|data\(1) & ((\U2|last_leds_wire\(8)))) # (!\U1|data\(1) & (\U2|last_leds_wire\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(1),
	datac => \U2|last_leds_wire\(7),
	datad => \U2|last_leds_wire\(8),
	combout => \U2|Mux3~4_combout\);

-- Location: LCCOMB_X111_Y19_N6
\U2|Mux3~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux3~5_combout\ = (\U1|data\(2) & (((!\U2|Mux11~4_combout\ & \U2|Mux3~4_combout\)))) # (!\U1|data\(2) & (\U2|Mux11~19_combout\ & (\U2|Mux11~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010110000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux11~19_combout\,
	datab => \U1|data\(2),
	datac => \U2|Mux11~4_combout\,
	datad => \U2|Mux3~4_combout\,
	combout => \U2|Mux3~5_combout\);

-- Location: LCCOMB_X111_Y19_N20
\U2|Mux3~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux3~6_combout\ = (\U2|Mux11~4_combout\ & ((\U2|leds_wire\(8)) # ((\U2|Mux3~5_combout\)))) # (!\U2|Mux11~4_combout\ & ((\U1|data\(5) & (\U2|leds_wire\(8))) # (!\U1|data\(5) & ((\U2|Mux3~5_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(8),
	datab => \U1|data\(5),
	datac => \U2|Mux11~4_combout\,
	datad => \U2|Mux3~5_combout\,
	combout => \U2|Mux3~6_combout\);

-- Location: LCCOMB_X111_Y19_N24
\U2|Mux3~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux3~7_combout\ = (\U2|Mux11~7_combout\ & ((\U1|data\(4) & ((\U2|Mux3~6_combout\))) # (!\U1|data\(4) & (\U2|Add1~27_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100100001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(4),
	datab => \U2|Mux11~7_combout\,
	datac => \U2|Add1~27_combout\,
	datad => \U2|Mux3~6_combout\,
	combout => \U2|Mux3~7_combout\);

-- Location: LCCOMB_X111_Y19_N26
\U2|Mux3~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux3~8_combout\ = (\U2|leds_wire\(8) & ((\U1|data\(7)) # (\U1|data\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|leds_wire\(8),
	datac => \U1|data\(7),
	datad => \U1|data\(6),
	combout => \U2|Mux3~8_combout\);

-- Location: LCCOMB_X109_Y19_N16
\U2|Mux2~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux2~3_combout\ = (!\U1|data\(5) & ((\U1|data\(1) & (\U2|last_leds_wire\(9))) # (!\U1|data\(1) & ((\U2|last_leds_wire\(8))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U2|last_leds_wire\(9),
	datac => \U2|last_leds_wire\(8),
	datad => \U1|data\(1),
	combout => \U2|Mux2~3_combout\);

-- Location: LCCOMB_X110_Y19_N16
\U2|Mux2~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux2~4_combout\ = (\U2|leds_wire\(9) & \U1|data\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U2|leds_wire\(9),
	datad => \U1|data\(5),
	combout => \U2|Mux2~4_combout\);

-- Location: LCCOMB_X110_Y19_N14
\U2|Mux2~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux2~5_combout\ = (\U2|Mux11~4_combout\ & (\U1|data\(2))) # (!\U2|Mux11~4_combout\ & ((\U2|Mux2~4_combout\) # ((\U1|data\(2) & \U2|Mux2~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(2),
	datab => \U2|Mux11~4_combout\,
	datac => \U2|Mux2~3_combout\,
	datad => \U2|Mux2~4_combout\,
	combout => \U2|Mux2~5_combout\);

-- Location: LCCOMB_X110_Y19_N12
\U2|Mux2~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux2~6_combout\ = (\U2|Mux11~4_combout\ & ((\U2|leds_wire\(9)) # ((!\U2|Mux2~5_combout\ & \U2|Mux11~19_combout\)))) # (!\U2|Mux11~4_combout\ & (((\U2|Mux2~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011110010111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(9),
	datab => \U2|Mux11~4_combout\,
	datac => \U2|Mux2~5_combout\,
	datad => \U2|Mux11~19_combout\,
	combout => \U2|Mux2~6_combout\);

-- Location: LCCOMB_X110_Y19_N2
\U2|Mux2~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux2~7_combout\ = (\U2|Mux11~7_combout\ & ((\U1|data\(4) & (\U2|Mux2~6_combout\)) # (!\U1|data\(4) & ((\U2|Mux2~4_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux2~6_combout\,
	datab => \U1|data\(4),
	datac => \U2|Mux11~7_combout\,
	datad => \U2|Mux2~4_combout\,
	combout => \U2|Mux2~7_combout\);

-- Location: LCCOMB_X110_Y19_N4
\U2|Mux2~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux2~8_combout\ = (\U2|leds_wire\(9) & ((\U1|data\(7)) # (\U1|data\(6))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|leds_wire\(9),
	datac => \U1|data\(7),
	datad => \U1|data\(6),
	combout => \U2|Mux2~8_combout\);

-- Location: LCCOMB_X105_Y19_N12
\U2|Mux1~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux1~12_combout\ = (\U1|data\(3) & ((\U1|data\(2) & ((!\U1|data\(1)) # (!\U1|data\(0)))) # (!\U1|data\(2) & ((\U1|data\(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010101010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(3),
	datab => \U1|data\(0),
	datac => \U1|data\(2),
	datad => \U1|data\(1),
	combout => \U2|Mux1~12_combout\);

-- Location: LCCOMB_X105_Y19_N22
\U2|Mux0~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux0~3_combout\ = ((!\U1|data\(4) & ((\U2|Mux1~12_combout\) # (\U1|data\(5))))) # (!\U3|Mux2~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux1~12_combout\,
	datab => \U1|data\(5),
	datac => \U1|data\(4),
	datad => \U3|Mux2~1_combout\,
	combout => \U2|Mux0~3_combout\);

-- Location: LCCOMB_X108_Y19_N16
\U2|Mux0~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux0~5_combout\ = (\U1|data\(2) & ((\U1|data\(3)) # (!\U2|last_leds_wire\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|data\(2),
	datac => \U2|last_leds_wire\(10),
	datad => \U1|data\(3),
	combout => \U2|Mux0~5_combout\);

-- Location: LCCOMB_X108_Y19_N4
\U2|Mux0~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux0~12_combout\ = (\U1|data\(5) & (((\U2|leds_wire\(11))))) # (!\U1|data\(5) & ((\U2|Mux0~5_combout\ & (\U2|leds_wire\(11) & \U1|data\(3))) # (!\U2|Mux0~5_combout\ & ((!\U1|data\(3))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000010110001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U2|Mux0~5_combout\,
	datac => \U2|leds_wire\(11),
	datad => \U1|data\(3),
	combout => \U2|Mux0~12_combout\);

-- Location: LCCOMB_X108_Y19_N26
\U2|Mux0~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux0~13_combout\ = (\U2|Mux0~12_combout\) # ((!\U1|data\(5) & (\U2|last_leds_wire\(0) & !\U2|Mux0~5_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U2|last_leds_wire\(0),
	datac => \U2|Mux0~12_combout\,
	datad => \U2|Mux0~5_combout\,
	combout => \U2|Mux0~13_combout\);

-- Location: LCCOMB_X109_Y19_N26
\U2|Mux0~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux0~11_combout\ = (\U1|data\(3) & (!\U1|data\(5) & (\U2|last_leds_wire\(10) & !\U1|data\(2)))) # (!\U1|data\(3) & (((\U1|data\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111101000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U2|last_leds_wire\(10),
	datac => \U1|data\(3),
	datad => \U1|data\(2),
	combout => \U2|Mux0~11_combout\);

-- Location: LCCOMB_X108_Y19_N18
\U2|Mux0~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux0~4_combout\ = (\U2|Mux0~11_combout\ & (((\U2|leds_wire\(11)) # (\U1|data\(3))))) # (!\U2|Mux0~11_combout\ & ((\U1|data\(5) & (\U2|leds_wire\(11))) # (!\U1|data\(5) & ((!\U1|data\(3))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110011110001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U2|Mux0~11_combout\,
	datac => \U2|leds_wire\(11),
	datad => \U1|data\(3),
	combout => \U2|Mux0~4_combout\);

-- Location: LCCOMB_X108_Y19_N22
\U2|Mux0~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux0~6_combout\ = (\U1|data\(0) & (\U1|data\(1))) # (!\U1|data\(0) & ((\U1|data\(1) & ((\U2|Mux0~4_combout\))) # (!\U1|data\(1) & (\U2|Mux0~13_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(0),
	datab => \U1|data\(1),
	datac => \U2|Mux0~13_combout\,
	datad => \U2|Mux0~4_combout\,
	combout => \U2|Mux0~6_combout\);

-- Location: LCCOMB_X108_Y19_N12
\U2|Add1~36\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~36_combout\ = (\U2|leds_wire\(11) & \U1|data\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(11),
	datad => \U1|data\(5),
	combout => \U2|Add1~36_combout\);

-- Location: LCCOMB_X108_Y19_N0
\U2|Mux0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux0~2_combout\ = (\U1|data\(3) & !\U1|data\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|data\(3),
	datad => \U1|data\(5),
	combout => \U2|Mux0~2_combout\);

-- Location: LCCOMB_X107_Y21_N26
\U2|Mux0~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux0~7_combout\ = (!\U1|data\(5) & (\U2|last_leds_wire\(11) & (\U1|data\(2) & !\U1|data\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U2|last_leds_wire\(11),
	datac => \U1|data\(2),
	datad => \U1|data\(3),
	combout => \U2|Mux0~7_combout\);

-- Location: LCCOMB_X107_Y19_N24
\U2|Add1~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~7_combout\ = (\U1|data\(2) & \U2|Add1~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|data\(2),
	datad => \U2|Add1~2_combout\,
	combout => \U2|Add1~7_combout\);

-- Location: LCCOMB_X107_Y19_N2
\U2|Add1~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~8_combout\ = (\U2|last_leds_wire\(1) & ((\U2|Add1~7_combout\ & (\U2|Add1~4\ & VCC)) # (!\U2|Add1~7_combout\ & (!\U2|Add1~4\)))) # (!\U2|last_leds_wire\(1) & ((\U2|Add1~7_combout\ & (!\U2|Add1~4\)) # (!\U2|Add1~7_combout\ & ((\U2|Add1~4\) # 
-- (GND)))))
-- \U2|Add1~9\ = CARRY((\U2|last_leds_wire\(1) & (!\U2|Add1~7_combout\ & !\U2|Add1~4\)) # (!\U2|last_leds_wire\(1) & ((!\U2|Add1~4\) # (!\U2|Add1~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(1),
	datab => \U2|Add1~7_combout\,
	datad => VCC,
	cin => \U2|Add1~4\,
	combout => \U2|Add1~8_combout\,
	cout => \U2|Add1~9\);

-- Location: LCCOMB_X107_Y19_N4
\U2|Add1~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~10_combout\ = ((\U2|last_leds_wire\(2) $ (\U2|Add1~7_combout\ $ (!\U2|Add1~9\)))) # (GND)
-- \U2|Add1~11\ = CARRY((\U2|last_leds_wire\(2) & ((\U2|Add1~7_combout\) # (!\U2|Add1~9\))) # (!\U2|last_leds_wire\(2) & (\U2|Add1~7_combout\ & !\U2|Add1~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(2),
	datab => \U2|Add1~7_combout\,
	datad => VCC,
	cin => \U2|Add1~9\,
	combout => \U2|Add1~10_combout\,
	cout => \U2|Add1~11\);

-- Location: LCCOMB_X107_Y19_N6
\U2|Add1~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~13_combout\ = (\U2|last_leds_wire\(3) & ((\U2|Add1~7_combout\ & (\U2|Add1~11\ & VCC)) # (!\U2|Add1~7_combout\ & (!\U2|Add1~11\)))) # (!\U2|last_leds_wire\(3) & ((\U2|Add1~7_combout\ & (!\U2|Add1~11\)) # (!\U2|Add1~7_combout\ & ((\U2|Add1~11\) # 
-- (GND)))))
-- \U2|Add1~14\ = CARRY((\U2|last_leds_wire\(3) & (!\U2|Add1~7_combout\ & !\U2|Add1~11\)) # (!\U2|last_leds_wire\(3) & ((!\U2|Add1~11\) # (!\U2|Add1~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(3),
	datab => \U2|Add1~7_combout\,
	datad => VCC,
	cin => \U2|Add1~11\,
	combout => \U2|Add1~13_combout\,
	cout => \U2|Add1~14\);

-- Location: LCCOMB_X107_Y19_N8
\U2|Add1~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~16_combout\ = ((\U2|last_leds_wire\(4) $ (\U2|Add1~7_combout\ $ (!\U2|Add1~14\)))) # (GND)
-- \U2|Add1~17\ = CARRY((\U2|last_leds_wire\(4) & ((\U2|Add1~7_combout\) # (!\U2|Add1~14\))) # (!\U2|last_leds_wire\(4) & (\U2|Add1~7_combout\ & !\U2|Add1~14\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(4),
	datab => \U2|Add1~7_combout\,
	datad => VCC,
	cin => \U2|Add1~14\,
	combout => \U2|Add1~16_combout\,
	cout => \U2|Add1~17\);

-- Location: LCCOMB_X107_Y19_N10
\U2|Add1~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~19_combout\ = (\U2|last_leds_wire\(5) & ((\U2|Add1~7_combout\ & (\U2|Add1~17\ & VCC)) # (!\U2|Add1~7_combout\ & (!\U2|Add1~17\)))) # (!\U2|last_leds_wire\(5) & ((\U2|Add1~7_combout\ & (!\U2|Add1~17\)) # (!\U2|Add1~7_combout\ & ((\U2|Add1~17\) # 
-- (GND)))))
-- \U2|Add1~20\ = CARRY((\U2|last_leds_wire\(5) & (!\U2|Add1~7_combout\ & !\U2|Add1~17\)) # (!\U2|last_leds_wire\(5) & ((!\U2|Add1~17\) # (!\U2|Add1~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(5),
	datab => \U2|Add1~7_combout\,
	datad => VCC,
	cin => \U2|Add1~17\,
	combout => \U2|Add1~19_combout\,
	cout => \U2|Add1~20\);

-- Location: LCCOMB_X107_Y19_N12
\U2|Add1~22\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~22_combout\ = ((\U2|last_leds_wire\(6) $ (\U2|Add1~7_combout\ $ (!\U2|Add1~20\)))) # (GND)
-- \U2|Add1~23\ = CARRY((\U2|last_leds_wire\(6) & ((\U2|Add1~7_combout\) # (!\U2|Add1~20\))) # (!\U2|last_leds_wire\(6) & (\U2|Add1~7_combout\ & !\U2|Add1~20\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(6),
	datab => \U2|Add1~7_combout\,
	datad => VCC,
	cin => \U2|Add1~20\,
	combout => \U2|Add1~22_combout\,
	cout => \U2|Add1~23\);

-- Location: LCCOMB_X107_Y19_N14
\U2|Add1~25\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~25_combout\ = (\U2|Add1~7_combout\ & ((\U2|last_leds_wire\(7) & (\U2|Add1~23\ & VCC)) # (!\U2|last_leds_wire\(7) & (!\U2|Add1~23\)))) # (!\U2|Add1~7_combout\ & ((\U2|last_leds_wire\(7) & (!\U2|Add1~23\)) # (!\U2|last_leds_wire\(7) & 
-- ((\U2|Add1~23\) # (GND)))))
-- \U2|Add1~26\ = CARRY((\U2|Add1~7_combout\ & (!\U2|last_leds_wire\(7) & !\U2|Add1~23\)) # (!\U2|Add1~7_combout\ & ((!\U2|Add1~23\) # (!\U2|last_leds_wire\(7)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Add1~7_combout\,
	datab => \U2|last_leds_wire\(7),
	datad => VCC,
	cin => \U2|Add1~23\,
	combout => \U2|Add1~25_combout\,
	cout => \U2|Add1~26\);

-- Location: LCCOMB_X107_Y19_N16
\U2|Add1~28\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~28_combout\ = ((\U2|last_leds_wire\(8) $ (\U2|Add1~7_combout\ $ (!\U2|Add1~26\)))) # (GND)
-- \U2|Add1~29\ = CARRY((\U2|last_leds_wire\(8) & ((\U2|Add1~7_combout\) # (!\U2|Add1~26\))) # (!\U2|last_leds_wire\(8) & (\U2|Add1~7_combout\ & !\U2|Add1~26\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(8),
	datab => \U2|Add1~7_combout\,
	datad => VCC,
	cin => \U2|Add1~26\,
	combout => \U2|Add1~28_combout\,
	cout => \U2|Add1~29\);

-- Location: LCCOMB_X107_Y19_N18
\U2|Add1~31\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~31_combout\ = (\U2|Add1~7_combout\ & ((\U2|last_leds_wire\(9) & (\U2|Add1~29\ & VCC)) # (!\U2|last_leds_wire\(9) & (!\U2|Add1~29\)))) # (!\U2|Add1~7_combout\ & ((\U2|last_leds_wire\(9) & (!\U2|Add1~29\)) # (!\U2|last_leds_wire\(9) & 
-- ((\U2|Add1~29\) # (GND)))))
-- \U2|Add1~32\ = CARRY((\U2|Add1~7_combout\ & (!\U2|last_leds_wire\(9) & !\U2|Add1~29\)) # (!\U2|Add1~7_combout\ & ((!\U2|Add1~29\) # (!\U2|last_leds_wire\(9)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Add1~7_combout\,
	datab => \U2|last_leds_wire\(9),
	datad => VCC,
	cin => \U2|Add1~29\,
	combout => \U2|Add1~31_combout\,
	cout => \U2|Add1~32\);

-- Location: LCCOMB_X107_Y19_N20
\U2|Add1~34\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~34_combout\ = ((\U2|last_leds_wire\(10) $ (\U2|Add1~7_combout\ $ (!\U2|Add1~32\)))) # (GND)
-- \U2|Add1~35\ = CARRY((\U2|last_leds_wire\(10) & ((\U2|Add1~7_combout\) # (!\U2|Add1~32\))) # (!\U2|last_leds_wire\(10) & (\U2|Add1~7_combout\ & !\U2|Add1~32\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(10),
	datab => \U2|Add1~7_combout\,
	datad => VCC,
	cin => \U2|Add1~32\,
	combout => \U2|Add1~34_combout\,
	cout => \U2|Add1~35\);

-- Location: LCCOMB_X107_Y19_N22
\U2|Add1~37\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~37_combout\ = \U2|Add1~7_combout\ $ (\U2|Add1~35\ $ (\U2|last_leds_wire\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100111100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|Add1~7_combout\,
	datad => \U2|last_leds_wire\(11),
	cin => \U2|Add1~35\,
	combout => \U2|Add1~37_combout\);

-- Location: LCCOMB_X108_Y19_N10
\U2|Mux0~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux0~8_combout\ = (\U2|Add1~36_combout\) # ((\U2|Mux0~7_combout\) # ((\U2|Mux0~2_combout\ & \U2|Add1~37_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Add1~36_combout\,
	datab => \U2|Mux0~2_combout\,
	datac => \U2|Mux0~7_combout\,
	datad => \U2|Add1~37_combout\,
	combout => \U2|Mux0~8_combout\);

-- Location: LCCOMB_X108_Y19_N28
\U2|Mux0~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux0~9_combout\ = (\U1|data\(0) & ((\U2|Mux0~6_combout\ & ((\U2|Mux0~8_combout\))) # (!\U2|Mux0~6_combout\ & (\U2|leds_wire\(11))))) # (!\U1|data\(0) & (((\U2|Mux0~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(0),
	datab => \U2|leds_wire\(11),
	datac => \U2|Mux0~6_combout\,
	datad => \U2|Mux0~8_combout\,
	combout => \U2|Mux0~9_combout\);

-- Location: LCCOMB_X108_Y19_N30
\U2|Mux0~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux0~10_combout\ = (\U3|Mux1~0_combout\ & ((\U2|Mux0~9_combout\) # ((\U2|Mux0~3_combout\ & \U2|leds_wire\(11))))) # (!\U3|Mux1~0_combout\ & (\U2|Mux0~3_combout\ & (\U2|leds_wire\(11))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U3|Mux1~0_combout\,
	datab => \U2|Mux0~3_combout\,
	datac => \U2|leds_wire\(11),
	datad => \U2|Mux0~9_combout\,
	combout => \U2|Mux0~10_combout\);

-- Location: FF_X108_Y19_N31
\U2|leds_wire[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|Mux0~10_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	ena => \U2|leds_wire~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|leds_wire\(11));

-- Location: FF_X107_Y21_N9
\U2|last_leds_wire[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	asdata => \U2|leds_wire\(11),
	sload => VCC,
	ena => \U2|last_leds_wire[11]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|last_leds_wire\(11));

-- Location: LCCOMB_X107_Y21_N28
\U2|Mux1~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux1~6_combout\ = (\U1|data\(3) & ((\U2|last_leds_wire\(11)) # (\U1|data\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(3),
	datac => \U2|last_leds_wire\(11),
	datad => \U1|data\(2),
	combout => \U2|Mux1~6_combout\);

-- Location: LCCOMB_X108_Y19_N2
\U2|Mux1~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux1~14_combout\ = (\U1|data\(2) & ((\U2|Mux1~6_combout\) # ((!\U1|data\(5) & \U2|last_leds_wire\(9)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U1|data\(2),
	datac => \U2|last_leds_wire\(9),
	datad => \U2|Mux1~6_combout\,
	combout => \U2|Mux1~14_combout\);

-- Location: LCCOMB_X108_Y19_N8
\U2|Mux1~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux1~7_combout\ = (\U2|Mux1~14_combout\ & (((\U2|leds_wire\(10)) # (!\U2|Mux1~6_combout\)))) # (!\U2|Mux1~14_combout\ & ((\U1|data\(5) & (\U2|leds_wire\(10))) # (!\U1|data\(5) & ((\U2|Mux1~6_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U2|leds_wire\(10),
	datac => \U2|Mux1~6_combout\,
	datad => \U2|Mux1~14_combout\,
	combout => \U2|Mux1~7_combout\);

-- Location: LCCOMB_X109_Y19_N18
\U2|Mux1~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux1~4_combout\ = (\U1|data\(2) & (((\U2|last_leds_wire\(11)) # (!\U1|data\(3))))) # (!\U1|data\(2) & (\U2|last_leds_wire\(9) & (\U1|data\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101001001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(2),
	datab => \U2|last_leds_wire\(9),
	datac => \U1|data\(3),
	datad => \U2|last_leds_wire\(11),
	combout => \U2|Mux1~4_combout\);

-- Location: LCCOMB_X109_Y19_N4
\U2|Mux1~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux1~5_combout\ = (\U1|data\(5) & (\U2|leds_wire\(10))) # (!\U1|data\(5) & ((\U1|data\(3) & ((\U2|Mux1~4_combout\))) # (!\U1|data\(3) & ((\U2|leds_wire\(10)) # (!\U2|Mux1~4_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U2|leds_wire\(10),
	datac => \U1|data\(3),
	datad => \U2|Mux1~4_combout\,
	combout => \U2|Mux1~5_combout\);

-- Location: LCCOMB_X108_Y19_N14
\U2|Mux1~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux1~8_combout\ = (\U1|data\(0) & (\U1|data\(1))) # (!\U1|data\(0) & ((\U1|data\(1) & ((\U2|Mux1~5_combout\))) # (!\U1|data\(1) & (\U2|Mux1~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110010011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(0),
	datab => \U1|data\(1),
	datac => \U2|Mux1~7_combout\,
	datad => \U2|Mux1~5_combout\,
	combout => \U2|Mux1~8_combout\);

-- Location: LCCOMB_X109_Y19_N30
\U2|Add1~33\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~33_combout\ = (\U1|data\(5) & \U2|leds_wire\(10))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|data\(5),
	datad => \U2|leds_wire\(10),
	combout => \U2|Add1~33_combout\);

-- Location: LCCOMB_X109_Y19_N12
\U2|Mux1~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux1~9_combout\ = (!\U1|data\(5) & (!\U1|data\(3) & ((\U2|last_leds_wire\(10)) # (!\U1|data\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(2),
	datab => \U2|last_leds_wire\(10),
	datac => \U1|data\(5),
	datad => \U1|data\(3),
	combout => \U2|Mux1~9_combout\);

-- Location: LCCOMB_X108_Y19_N6
\U2|Mux1~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux1~10_combout\ = (\U2|Add1~33_combout\) # ((\U2|Mux1~9_combout\) # ((\U2|Mux0~2_combout\ & \U2|Add1~34_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Add1~33_combout\,
	datab => \U2|Mux0~2_combout\,
	datac => \U2|Mux1~9_combout\,
	datad => \U2|Add1~34_combout\,
	combout => \U2|Mux1~10_combout\);

-- Location: LCCOMB_X108_Y19_N24
\U2|Mux1~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux1~11_combout\ = (\U1|data\(0) & ((\U2|Mux1~8_combout\ & ((\U2|Mux1~10_combout\))) # (!\U2|Mux1~8_combout\ & (\U2|leds_wire\(10))))) # (!\U1|data\(0) & (((\U2|Mux1~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(0),
	datab => \U2|leds_wire\(10),
	datac => \U2|Mux1~8_combout\,
	datad => \U2|Mux1~10_combout\,
	combout => \U2|Mux1~11_combout\);

-- Location: LCCOMB_X108_Y19_N20
\U2|Mux1~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux1~13_combout\ = (\U3|Mux1~0_combout\ & ((\U2|Mux1~11_combout\) # ((\U2|Mux0~3_combout\ & \U2|leds_wire\(10))))) # (!\U3|Mux1~0_combout\ & (\U2|Mux0~3_combout\ & (\U2|leds_wire\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U3|Mux1~0_combout\,
	datab => \U2|Mux0~3_combout\,
	datac => \U2|leds_wire\(10),
	datad => \U2|Mux1~11_combout\,
	combout => \U2|Mux1~13_combout\);

-- Location: FF_X108_Y19_N21
\U2|leds_wire[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|Mux1~13_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	ena => \U2|leds_wire~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|leds_wire\(10));

-- Location: FF_X109_Y19_N21
\U2|last_leds_wire[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	asdata => \U2|leds_wire\(10),
	sload => VCC,
	ena => \U2|last_leds_wire[11]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|last_leds_wire\(10));

-- Location: LCCOMB_X105_Y19_N14
\U2|Mux2~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux2~16_combout\ = (\U1|data\(5) & (((\U2|leds_wire\(9))))) # (!\U1|data\(5) & ((\U2|Mux10~9_combout\ & ((\U2|leds_wire\(9)))) # (!\U2|Mux10~9_combout\ & (\U2|last_leds_wire\(10)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(10),
	datab => \U1|data\(5),
	datac => \U2|Mux10~9_combout\,
	datad => \U2|leds_wire\(9),
	combout => \U2|Mux2~16_combout\);

-- Location: LCCOMB_X105_Y19_N16
\U2|Mux2~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux2~10_combout\ = (\U2|leds_wire\(9) & ((\U1|data\(2)) # (\U1|data\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|data\(2),
	datac => \U1|data\(5),
	datad => \U2|leds_wire\(9),
	combout => \U2|Mux2~10_combout\);

-- Location: LCCOMB_X105_Y19_N6
\U2|Mux2~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux2~11_combout\ = (\U1|data\(1) & (\U1|data\(4))) # (!\U1|data\(1) & ((\U1|data\(4) & (\U2|Mux2~16_combout\)) # (!\U1|data\(4) & ((\U2|Mux2~10_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101100111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(1),
	datab => \U1|data\(4),
	datac => \U2|Mux2~16_combout\,
	datad => \U2|Mux2~10_combout\,
	combout => \U2|Mux2~11_combout\);

-- Location: LCCOMB_X110_Y19_N26
\U2|Mux2~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux2~9_combout\ = (\U2|leds_wire\(9)) # ((\U1|data\(0) & (!\U1|data\(5) & \U1|data\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(0),
	datab => \U1|data\(5),
	datac => \U2|leds_wire\(9),
	datad => \U1|data\(2),
	combout => \U2|Mux2~9_combout\);

-- Location: LCCOMB_X109_Y19_N2
\U2|Add1~30\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~30_combout\ = (\U2|last_leds_wire\(10) & !\U1|data\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|last_leds_wire\(10),
	datad => \U1|data\(5),
	combout => \U2|Add1~30_combout\);

-- Location: LCCOMB_X109_Y19_N0
\U2|Mux2~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux2~12_combout\ = (!\U1|data\(0) & ((\U1|data\(2) & ((\U2|Add1~30_combout\))) # (!\U1|data\(2) & (\U2|Mux2~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(2),
	datab => \U2|Mux2~2_combout\,
	datac => \U1|data\(0),
	datad => \U2|Add1~30_combout\,
	combout => \U2|Mux2~12_combout\);

-- Location: LCCOMB_X106_Y19_N2
\U2|Mux10~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~15_combout\ = (\U1|data\(0) & !\U1|data\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|data\(0),
	datad => \U1|data\(5),
	combout => \U2|Mux10~15_combout\);

-- Location: LCCOMB_X110_Y19_N20
\U2|Mux2~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux2~13_combout\ = (\U2|Mux2~12_combout\) # ((\U2|Mux2~4_combout\) # ((\U2|Mux10~15_combout\ & \U2|Add1~31_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux2~12_combout\,
	datab => \U2|Mux2~4_combout\,
	datac => \U2|Mux10~15_combout\,
	datad => \U2|Add1~31_combout\,
	combout => \U2|Mux2~13_combout\);

-- Location: LCCOMB_X110_Y19_N6
\U2|Mux2~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux2~14_combout\ = (\U2|Mux2~11_combout\ & (((\U2|Mux2~13_combout\)) # (!\U1|data\(1)))) # (!\U2|Mux2~11_combout\ & (\U1|data\(1) & (\U2|Mux2~9_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101001100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux2~11_combout\,
	datab => \U1|data\(1),
	datac => \U2|Mux2~9_combout\,
	datad => \U2|Mux2~13_combout\,
	combout => \U2|Mux2~14_combout\);

-- Location: LCCOMB_X110_Y19_N22
\U2|Mux2~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux2~15_combout\ = (\U2|Mux2~7_combout\) # ((\U2|Mux2~8_combout\) # ((\U2|Mux11~17_combout\ & \U2|Mux2~14_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux11~17_combout\,
	datab => \U2|Mux2~7_combout\,
	datac => \U2|Mux2~8_combout\,
	datad => \U2|Mux2~14_combout\,
	combout => \U2|Mux2~15_combout\);

-- Location: FF_X110_Y19_N23
\U2|leds_wire[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|Mux2~15_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	ena => \U2|leds_wire~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|leds_wire\(9));

-- Location: FF_X107_Y19_N19
\U2|last_leds_wire[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	asdata => \U2|leds_wire\(9),
	sload => VCC,
	ena => \U2|last_leds_wire[11]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|last_leds_wire\(9));

-- Location: LCCOMB_X111_Y19_N28
\U2|Mux3~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux3~16_combout\ = (\U1|data\(5) & (((\U2|leds_wire\(8))))) # (!\U1|data\(5) & ((\U2|Mux10~9_combout\ & (\U2|leds_wire\(8))) # (!\U2|Mux10~9_combout\ & ((\U2|last_leds_wire\(9))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U2|Mux10~9_combout\,
	datac => \U2|leds_wire\(8),
	datad => \U2|last_leds_wire\(9),
	combout => \U2|Mux3~16_combout\);

-- Location: LCCOMB_X111_Y19_N14
\U2|Mux3~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux3~10_combout\ = (\U1|data\(2) & (\U2|leds_wire\(8))) # (!\U1|data\(2) & ((\U1|data\(5) & (\U2|leds_wire\(8))) # (!\U1|data\(5) & ((\U1|data\(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(8),
	datab => \U1|data\(2),
	datac => \U1|data\(5),
	datad => \U1|data\(0),
	combout => \U2|Mux3~10_combout\);

-- Location: LCCOMB_X111_Y19_N16
\U2|Mux3~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux3~9_combout\ = (\U2|leds_wire\(8) & (((\U1|data\(5)) # (!\U1|data\(0))) # (!\U1|data\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(8),
	datab => \U1|data\(2),
	datac => \U1|data\(5),
	datad => \U1|data\(0),
	combout => \U2|Mux3~9_combout\);

-- Location: LCCOMB_X111_Y19_N8
\U2|Mux3~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux3~11_combout\ = (\U1|data\(1) & (((\U1|data\(4)) # (\U2|Mux3~9_combout\)))) # (!\U1|data\(1) & (\U2|Mux3~10_combout\ & (!\U1|data\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111010100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(1),
	datab => \U2|Mux3~10_combout\,
	datac => \U1|data\(4),
	datad => \U2|Mux3~9_combout\,
	combout => \U2|Mux3~11_combout\);

-- Location: LCCOMB_X111_Y19_N2
\U2|Mux3~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux3~12_combout\ = (\U1|data\(2) & ((\U2|last_leds_wire\(9)))) # (!\U1|data\(2) & (\U2|last_leds_wire\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|data\(2),
	datac => \U2|last_leds_wire\(7),
	datad => \U2|last_leds_wire\(9),
	combout => \U2|Mux3~12_combout\);

-- Location: LCCOMB_X111_Y19_N4
\U2|Mux3~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux3~13_combout\ = (\U1|data\(5) & (((\U2|leds_wire\(8))))) # (!\U1|data\(5) & (!\U1|data\(0) & ((\U2|Mux3~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100010111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(0),
	datab => \U2|leds_wire\(8),
	datac => \U1|data\(5),
	datad => \U2|Mux3~12_combout\,
	combout => \U2|Mux3~13_combout\);

-- Location: LCCOMB_X111_Y19_N10
\U2|Mux3~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux3~17_combout\ = (\U2|Mux3~13_combout\) # ((\U1|data\(0) & (!\U1|data\(5) & \U2|Add1~28_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(0),
	datab => \U1|data\(5),
	datac => \U2|Mux3~13_combout\,
	datad => \U2|Add1~28_combout\,
	combout => \U2|Mux3~17_combout\);

-- Location: LCCOMB_X111_Y19_N18
\U2|Mux3~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux3~14_combout\ = (\U1|data\(4) & ((\U2|Mux3~11_combout\ & ((\U2|Mux3~17_combout\))) # (!\U2|Mux3~11_combout\ & (\U2|Mux3~16_combout\)))) # (!\U1|data\(4) & (((\U2|Mux3~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(4),
	datab => \U2|Mux3~16_combout\,
	datac => \U2|Mux3~11_combout\,
	datad => \U2|Mux3~17_combout\,
	combout => \U2|Mux3~14_combout\);

-- Location: LCCOMB_X111_Y19_N0
\U2|Mux3~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux3~15_combout\ = (\U2|Mux3~7_combout\) # ((\U2|Mux3~8_combout\) # ((\U2|Mux11~17_combout\ & \U2|Mux3~14_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux11~17_combout\,
	datab => \U2|Mux3~7_combout\,
	datac => \U2|Mux3~8_combout\,
	datad => \U2|Mux3~14_combout\,
	combout => \U2|Mux3~15_combout\);

-- Location: FF_X111_Y19_N1
\U2|leds_wire[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|Mux3~15_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	ena => \U2|leds_wire~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|leds_wire\(8));

-- Location: FF_X107_Y19_N17
\U2|last_leds_wire[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	asdata => \U2|leds_wire\(8),
	sload => VCC,
	ena => \U2|last_leds_wire[11]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|last_leds_wire\(8));

-- Location: LCCOMB_X109_Y19_N24
\U2|Mux2~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux2~2_combout\ = (\U2|last_leds_wire\(8) & !\U1|data\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U2|last_leds_wire\(8),
	datad => \U1|data\(5),
	combout => \U2|Mux2~2_combout\);

-- Location: LCCOMB_X109_Y19_N22
\U2|Mux4~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux4~8_combout\ = (\U2|Mux4~6_combout\ & (\U2|last_leds_wire\(6) & (\U2|Mux4~7_combout\))) # (!\U2|Mux4~6_combout\ & (((\U2|Mux4~7_combout\) # (\U2|Mux2~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101010111010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux4~6_combout\,
	datab => \U2|last_leds_wire\(6),
	datac => \U2|Mux4~7_combout\,
	datad => \U2|Mux2~2_combout\,
	combout => \U2|Mux4~8_combout\);

-- Location: LCCOMB_X109_Y19_N28
\U2|Mux4~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux4~9_combout\ = (\U2|leds_wire\(7)) # ((!\U1|data\(2) & (!\U1|data\(5) & !\U1|data\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(2),
	datab => \U2|leds_wire\(7),
	datac => \U1|data\(5),
	datad => \U1|data\(1),
	combout => \U2|Mux4~9_combout\);

-- Location: LCCOMB_X109_Y19_N6
\U2|Mux4~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux4~10_combout\ = (\U1|data\(0) & (\U1|data\(4))) # (!\U1|data\(0) & ((\U1|data\(4) & (\U2|Mux4~8_combout\)) # (!\U1|data\(4) & ((\U2|Mux4~9_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101100111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(0),
	datab => \U1|data\(4),
	datac => \U2|Mux4~8_combout\,
	datad => \U2|Mux4~9_combout\,
	combout => \U2|Mux4~10_combout\);

-- Location: LCCOMB_X110_Y19_N24
\U2|Mux4~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux4~11_combout\ = (\U1|data\(1) & ((\U1|data\(5) & (\U2|leds_wire\(7))) # (!\U1|data\(5) & ((\U2|Add1~25_combout\))))) # (!\U1|data\(1) & (\U2|leds_wire\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111011000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(1),
	datab => \U2|leds_wire\(7),
	datac => \U1|data\(5),
	datad => \U2|Add1~25_combout\,
	combout => \U2|Mux4~11_combout\);

-- Location: LCCOMB_X110_Y19_N18
\U2|Mux4~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux4~12_combout\ = (\U1|data\(0) & ((\U2|Mux4~10_combout\ & ((\U2|Mux4~11_combout\))) # (!\U2|Mux4~10_combout\ & (\U2|Mux4~5_combout\)))) # (!\U1|data\(0) & (((\U2|Mux4~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(0),
	datab => \U2|Mux4~5_combout\,
	datac => \U2|Mux4~10_combout\,
	datad => \U2|Mux4~11_combout\,
	combout => \U2|Mux4~12_combout\);

-- Location: LCCOMB_X110_Y19_N28
\U2|Mux4~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux4~13_combout\ = (\U2|Mux4~3_combout\) # ((\U2|Mux4~4_combout\) # ((\U2|Mux11~17_combout\ & \U2|Mux4~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux11~17_combout\,
	datab => \U2|Mux4~3_combout\,
	datac => \U2|Mux4~4_combout\,
	datad => \U2|Mux4~12_combout\,
	combout => \U2|Mux4~13_combout\);

-- Location: FF_X110_Y19_N29
\U2|leds_wire[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|Mux4~13_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	ena => \U2|leds_wire~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|leds_wire\(7));

-- Location: FF_X107_Y19_N15
\U2|last_leds_wire[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	asdata => \U2|leds_wire\(7),
	sload => VCC,
	ena => \U2|last_leds_wire[11]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|last_leds_wire\(7));

-- Location: LCCOMB_X106_Y19_N10
\U2|Mux5~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux5~7_combout\ = (\U2|Mux10~9_combout\ & (((\U2|leds_wire\(6))))) # (!\U2|Mux10~9_combout\ & ((\U1|data\(5) & ((\U2|leds_wire\(6)))) # (!\U1|data\(5) & (\U2|last_leds_wire\(7)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux10~9_combout\,
	datab => \U2|last_leds_wire\(7),
	datac => \U1|data\(5),
	datad => \U2|leds_wire\(6),
	combout => \U2|Mux5~7_combout\);

-- Location: LCCOMB_X106_Y19_N12
\U2|Mux5~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux5~8_combout\ = (\U1|data\(4) & (((\U2|Mux10~11_combout\)))) # (!\U1|data\(4) & (\U2|leds_wire\(6) & ((\U1|data\(5)) # (\U2|Mux10~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U2|Mux10~11_combout\,
	datac => \U1|data\(4),
	datad => \U2|leds_wire\(6),
	combout => \U2|Mux5~8_combout\);

-- Location: LCCOMB_X106_Y19_N28
\U2|Mux10~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~13_combout\ = (!\U1|data\(0) & !\U1|data\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|data\(0),
	datad => \U1|data\(5),
	combout => \U2|Mux10~13_combout\);

-- Location: LCCOMB_X106_Y19_N30
\U2|Mux5~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux5~9_combout\ = (\U2|Mux10~13_combout\ & ((\U1|data\(2) & ((\U2|last_leds_wire\(7)))) # (!\U1|data\(2) & (\U2|last_leds_wire\(5)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(5),
	datab => \U1|data\(2),
	datac => \U2|last_leds_wire\(7),
	datad => \U2|Mux10~13_combout\,
	combout => \U2|Mux5~9_combout\);

-- Location: LCCOMB_X106_Y21_N28
\U2|Add1~21\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~21_combout\ = (\U1|data\(5) & \U2|leds_wire\(6))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|data\(5),
	datad => \U2|leds_wire\(6),
	combout => \U2|Add1~21_combout\);

-- Location: LCCOMB_X107_Y19_N28
\U2|Mux5~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux5~10_combout\ = (\U2|Mux5~9_combout\) # ((\U2|Add1~21_combout\) # ((\U2|Mux10~15_combout\ & \U2|Add1~22_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux10~15_combout\,
	datab => \U2|Mux5~9_combout\,
	datac => \U2|Add1~21_combout\,
	datad => \U2|Add1~22_combout\,
	combout => \U2|Mux5~10_combout\);

-- Location: LCCOMB_X107_Y19_N30
\U2|Mux5~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux5~11_combout\ = (\U2|Mux5~8_combout\ & (((\U2|Mux5~10_combout\) # (!\U1|data\(4))))) # (!\U2|Mux5~8_combout\ & (\U2|Mux5~7_combout\ & (\U1|data\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110000101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux5~7_combout\,
	datab => \U2|Mux5~8_combout\,
	datac => \U1|data\(4),
	datad => \U2|Mux5~10_combout\,
	combout => \U2|Mux5~11_combout\);

-- Location: LCCOMB_X106_Y21_N2
\U2|Mux5~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux5~12_combout\ = (\U2|Mux5~6_combout\) # ((\U2|Mux11~17_combout\ & \U2|Mux5~11_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux11~17_combout\,
	datac => \U2|Mux5~6_combout\,
	datad => \U2|Mux5~11_combout\,
	combout => \U2|Mux5~12_combout\);

-- Location: FF_X106_Y21_N3
\U2|leds_wire[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|Mux5~12_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	ena => \U2|leds_wire~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|leds_wire\(6));

-- Location: FF_X107_Y19_N13
\U2|last_leds_wire[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	asdata => \U2|leds_wire\(6),
	sload => VCC,
	ena => \U2|last_leds_wire[11]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|last_leds_wire\(6));

-- Location: LCCOMB_X106_Y20_N30
\U2|Mux6~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux6~6_combout\ = (\U2|Mux10~9_combout\ & (\U2|leds_wire\(5))) # (!\U2|Mux10~9_combout\ & ((\U1|data\(5) & (\U2|leds_wire\(5))) # (!\U1|data\(5) & ((\U2|last_leds_wire\(6))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(5),
	datab => \U2|last_leds_wire\(6),
	datac => \U2|Mux10~9_combout\,
	datad => \U1|data\(5),
	combout => \U2|Mux6~6_combout\);

-- Location: LCCOMB_X107_Y20_N4
\U2|Mux6~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux6~8_combout\ = (\U2|Mux10~13_combout\ & ((\U1|data\(2) & (\U2|last_leds_wire\(6))) # (!\U1|data\(2) & ((\U2|last_leds_wire\(4))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(2),
	datab => \U2|last_leds_wire\(6),
	datac => \U2|Mux10~13_combout\,
	datad => \U2|last_leds_wire\(4),
	combout => \U2|Mux6~8_combout\);

-- Location: LCCOMB_X106_Y20_N28
\U2|Add1~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~18_combout\ = (\U2|leds_wire\(5) & \U1|data\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(5),
	datad => \U1|data\(5),
	combout => \U2|Add1~18_combout\);

-- Location: LCCOMB_X106_Y20_N2
\U2|Mux6~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux6~9_combout\ = (\U2|Mux6~8_combout\) # ((\U2|Add1~18_combout\) # ((\U2|Mux10~15_combout\ & \U2|Add1~19_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux6~8_combout\,
	datab => \U2|Add1~18_combout\,
	datac => \U2|Mux10~15_combout\,
	datad => \U2|Add1~19_combout\,
	combout => \U2|Mux6~9_combout\);

-- Location: LCCOMB_X106_Y20_N4
\U2|Mux6~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux6~10_combout\ = (\U2|Mux6~7_combout\ & (((\U2|Mux6~9_combout\)) # (!\U1|data\(4)))) # (!\U2|Mux6~7_combout\ & (\U1|data\(4) & (\U2|Mux6~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101001100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux6~7_combout\,
	datab => \U1|data\(4),
	datac => \U2|Mux6~6_combout\,
	datad => \U2|Mux6~9_combout\,
	combout => \U2|Mux6~10_combout\);

-- Location: LCCOMB_X107_Y20_N8
\U2|Mux10~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~3_combout\ = (!\U1|data\(0) & (!\U1|data\(5) & \U1|data\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|data\(0),
	datac => \U1|data\(5),
	datad => \U1|data\(1),
	combout => \U2|Mux10~3_combout\);

-- Location: LCCOMB_X106_Y20_N6
\U2|Mux6~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux6~1_combout\ = (\U1|data\(4) & (\U1|data\(2))) # (!\U1|data\(4) & ((\U2|Add1~18_combout\) # ((\U1|data\(2) & \U2|Mux10~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(2),
	datab => \U1|data\(4),
	datac => \U2|Mux10~3_combout\,
	datad => \U2|Add1~18_combout\,
	combout => \U2|Mux6~1_combout\);

-- Location: LCCOMB_X106_Y20_N14
\U2|Mux6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux6~0_combout\ = (\U1|data\(5) & (\U2|leds_wire\(5))) # (!\U1|data\(5) & ((\U1|data\(1) & ((!\U1|data\(0)))) # (!\U1|data\(1) & (\U2|leds_wire\(5) & \U1|data\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(5),
	datab => \U1|data\(1),
	datac => \U1|data\(0),
	datad => \U1|data\(5),
	combout => \U2|Mux6~0_combout\);

-- Location: LCCOMB_X106_Y19_N22
\U2|Mux6~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux6~2_combout\ = (\U1|data\(1) & ((\U2|last_leds_wire\(5)))) # (!\U1|data\(1) & (\U2|last_leds_wire\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(1),
	datab => \U2|last_leds_wire\(4),
	datad => \U2|last_leds_wire\(5),
	combout => \U2|Mux6~2_combout\);

-- Location: LCCOMB_X106_Y20_N0
\U2|Mux6~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux6~3_combout\ = (\U1|data\(5) & (\U2|leds_wire\(5))) # (!\U1|data\(5) & ((\U2|Mux11~4_combout\ & (\U2|leds_wire\(5))) # (!\U2|Mux11~4_combout\ & ((\U2|Mux6~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U2|leds_wire\(5),
	datac => \U2|Mux11~4_combout\,
	datad => \U2|Mux6~2_combout\,
	combout => \U2|Mux6~3_combout\);

-- Location: LCCOMB_X106_Y20_N18
\U2|Mux6~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux6~4_combout\ = (\U2|Mux6~1_combout\ & (((\U2|Mux6~3_combout\)) # (!\U1|data\(4)))) # (!\U2|Mux6~1_combout\ & (\U1|data\(4) & (\U2|Mux6~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101001100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux6~1_combout\,
	datab => \U1|data\(4),
	datac => \U2|Mux6~0_combout\,
	datad => \U2|Mux6~3_combout\,
	combout => \U2|Mux6~4_combout\);

-- Location: LCCOMB_X106_Y20_N24
\U2|Mux6~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux6~5_combout\ = (\U2|leds_wire\(5) & (((\U2|Mux11~7_combout\ & \U2|Mux6~4_combout\)) # (!\U3|Mux2~1_combout\))) # (!\U2|leds_wire\(5) & (\U2|Mux11~7_combout\ & ((\U2|Mux6~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(5),
	datab => \U2|Mux11~7_combout\,
	datac => \U3|Mux2~1_combout\,
	datad => \U2|Mux6~4_combout\,
	combout => \U2|Mux6~5_combout\);

-- Location: LCCOMB_X106_Y20_N22
\U2|Mux6~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux6~11_combout\ = (\U2|Mux6~5_combout\) # ((\U2|Mux11~17_combout\ & \U2|Mux6~10_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|Mux11~17_combout\,
	datac => \U2|Mux6~10_combout\,
	datad => \U2|Mux6~5_combout\,
	combout => \U2|Mux6~11_combout\);

-- Location: FF_X106_Y20_N23
\U2|leds_wire[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|Mux6~11_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	ena => \U2|leds_wire~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|leds_wire\(5));

-- Location: FF_X107_Y19_N11
\U2|last_leds_wire[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	asdata => \U2|leds_wire\(5),
	sload => VCC,
	ena => \U2|last_leds_wire[11]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|last_leds_wire\(5));

-- Location: LCCOMB_X107_Y18_N0
\U2|Mux7~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux7~6_combout\ = (\U1|data\(5) & (((\U2|leds_wire\(4))))) # (!\U1|data\(5) & ((\U2|Mux10~9_combout\ & ((\U2|leds_wire\(4)))) # (!\U2|Mux10~9_combout\ & (\U2|last_leds_wire\(5)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(5),
	datab => \U2|leds_wire\(4),
	datac => \U1|data\(5),
	datad => \U2|Mux10~9_combout\,
	combout => \U2|Mux7~6_combout\);

-- Location: LCCOMB_X107_Y18_N8
\U2|Mux7~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux7~8_combout\ = (\U2|Mux10~13_combout\ & ((\U1|data\(2) & ((\U2|last_leds_wire\(5)))) # (!\U1|data\(2) & (\U2|last_leds_wire\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(3),
	datab => \U2|last_leds_wire\(5),
	datac => \U1|data\(2),
	datad => \U2|Mux10~13_combout\,
	combout => \U2|Mux7~8_combout\);

-- Location: LCCOMB_X107_Y18_N18
\U2|Mux7~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux7~9_combout\ = (\U2|Add1~15_combout\) # ((\U2|Mux7~8_combout\) # ((\U2|Mux10~15_combout\ & \U2|Add1~16_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux10~15_combout\,
	datab => \U2|Add1~15_combout\,
	datac => \U2|Mux7~8_combout\,
	datad => \U2|Add1~16_combout\,
	combout => \U2|Mux7~9_combout\);

-- Location: LCCOMB_X107_Y18_N12
\U2|Mux7~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux7~10_combout\ = (\U2|Mux7~7_combout\ & (((\U2|Mux7~9_combout\) # (!\U1|data\(4))))) # (!\U2|Mux7~7_combout\ & (\U2|Mux7~6_combout\ & (\U1|data\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101001001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux7~7_combout\,
	datab => \U2|Mux7~6_combout\,
	datac => \U1|data\(4),
	datad => \U2|Mux7~9_combout\,
	combout => \U2|Mux7~10_combout\);

-- Location: LCCOMB_X107_Y18_N20
\U2|Mux7~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux7~11_combout\ = (\U2|Mux7~5_combout\) # ((\U2|Mux11~17_combout\ & \U2|Mux7~10_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|Mux11~17_combout\,
	datac => \U2|Mux7~5_combout\,
	datad => \U2|Mux7~10_combout\,
	combout => \U2|Mux7~11_combout\);

-- Location: FF_X107_Y18_N21
\U2|leds_wire[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|Mux7~11_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	ena => \U2|leds_wire~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|leds_wire\(4));

-- Location: FF_X107_Y19_N9
\U2|last_leds_wire[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	asdata => \U2|leds_wire\(4),
	sload => VCC,
	ena => \U2|last_leds_wire[11]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|last_leds_wire\(4));

-- Location: LCCOMB_X108_Y18_N16
\U2|Mux8~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux8~7_combout\ = (\U1|data\(5) & (((\U2|leds_wire\(3))))) # (!\U1|data\(5) & ((\U2|Mux10~9_combout\ & ((\U2|leds_wire\(3)))) # (!\U2|Mux10~9_combout\ & (\U2|last_leds_wire\(4)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(4),
	datab => \U2|leds_wire\(3),
	datac => \U1|data\(5),
	datad => \U2|Mux10~9_combout\,
	combout => \U2|Mux8~7_combout\);

-- Location: LCCOMB_X108_Y18_N26
\U2|Mux8~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux8~8_combout\ = (\U1|data\(4) & (((\U2|Mux10~11_combout\)))) # (!\U1|data\(4) & (\U2|leds_wire\(3) & ((\U1|data\(5)) # (\U2|Mux10~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(4),
	datab => \U1|data\(5),
	datac => \U2|Mux10~11_combout\,
	datad => \U2|leds_wire\(3),
	combout => \U2|Mux8~8_combout\);

-- Location: LCCOMB_X107_Y18_N10
\U2|Mux8~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux8~9_combout\ = (\U2|Mux10~13_combout\ & ((\U1|data\(2) & ((\U2|last_leds_wire\(4)))) # (!\U1|data\(2) & (\U2|last_leds_wire\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(2),
	datab => \U1|data\(2),
	datac => \U2|last_leds_wire\(4),
	datad => \U2|Mux10~13_combout\,
	combout => \U2|Mux8~9_combout\);

-- Location: LCCOMB_X108_Y18_N0
\U2|Add1~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~12_combout\ = (\U1|data\(5) & \U2|leds_wire\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|data\(5),
	datad => \U2|leds_wire\(3),
	combout => \U2|Add1~12_combout\);

-- Location: LCCOMB_X108_Y18_N10
\U2|Mux8~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux8~10_combout\ = (\U2|Mux8~9_combout\) # ((\U2|Add1~12_combout\) # ((\U2|Add1~13_combout\ & \U2|Mux10~15_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux8~9_combout\,
	datab => \U2|Add1~12_combout\,
	datac => \U2|Add1~13_combout\,
	datad => \U2|Mux10~15_combout\,
	combout => \U2|Mux8~10_combout\);

-- Location: LCCOMB_X108_Y18_N12
\U2|Mux8~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux8~11_combout\ = (\U1|data\(4) & ((\U2|Mux8~8_combout\ & ((\U2|Mux8~10_combout\))) # (!\U2|Mux8~8_combout\ & (\U2|Mux8~7_combout\)))) # (!\U1|data\(4) & (((\U2|Mux8~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(4),
	datab => \U2|Mux8~7_combout\,
	datac => \U2|Mux8~8_combout\,
	datad => \U2|Mux8~10_combout\,
	combout => \U2|Mux8~11_combout\);

-- Location: LCCOMB_X108_Y18_N20
\U2|Mux8~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux8~12_combout\ = (\U2|Mux8~6_combout\) # ((\U2|Mux11~17_combout\ & \U2|Mux8~11_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|Mux11~17_combout\,
	datac => \U2|Mux8~6_combout\,
	datad => \U2|Mux8~11_combout\,
	combout => \U2|Mux8~12_combout\);

-- Location: FF_X108_Y18_N21
\U2|leds_wire[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|Mux8~12_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	ena => \U2|leds_wire~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|leds_wire\(3));

-- Location: FF_X107_Y19_N7
\U2|last_leds_wire[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	asdata => \U2|leds_wire\(3),
	sload => VCC,
	ena => \U2|last_leds_wire[11]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|last_leds_wire\(3));

-- Location: LCCOMB_X105_Y19_N20
\U2|Mux9~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux9~9_combout\ = (\U2|Mux10~9_combout\ & (\U2|leds_wire\(2))) # (!\U2|Mux10~9_combout\ & ((\U1|data\(5) & (\U2|leds_wire\(2))) # (!\U1|data\(5) & ((\U2|last_leds_wire\(3))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(2),
	datab => \U2|Mux10~9_combout\,
	datac => \U1|data\(5),
	datad => \U2|last_leds_wire\(3),
	combout => \U2|Mux9~9_combout\);

-- Location: LCCOMB_X105_Y19_N30
\U2|Mux9~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux9~10_combout\ = (\U1|data\(4) & (\U2|Mux10~11_combout\)) # (!\U1|data\(4) & (\U2|leds_wire\(2) & ((\U2|Mux10~11_combout\) # (\U1|data\(5)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux10~11_combout\,
	datab => \U1|data\(4),
	datac => \U1|data\(5),
	datad => \U2|leds_wire\(2),
	combout => \U2|Mux9~10_combout\);

-- Location: LCCOMB_X106_Y19_N26
\U2|Mux9~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux9~11_combout\ = (\U1|data\(2) & (\U2|last_leds_wire\(3))) # (!\U1|data\(2) & ((\U2|last_leds_wire\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(3),
	datab => \U1|data\(2),
	datad => \U2|last_leds_wire\(1),
	combout => \U2|Mux9~11_combout\);

-- Location: LCCOMB_X106_Y20_N26
\U2|Mux9~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux9~12_combout\ = (\U1|data\(5) & (\U2|leds_wire\(2))) # (!\U1|data\(5) & (((!\U1|data\(0) & \U2|Mux9~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U2|leds_wire\(2),
	datac => \U1|data\(0),
	datad => \U2|Mux9~11_combout\,
	combout => \U2|Mux9~12_combout\);

-- Location: LCCOMB_X106_Y20_N10
\U2|Mux9~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux9~15_combout\ = (\U2|Mux9~12_combout\) # ((!\U1|data\(5) & (\U1|data\(0) & \U2|Add1~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U1|data\(0),
	datac => \U2|Mux9~12_combout\,
	datad => \U2|Add1~10_combout\,
	combout => \U2|Mux9~15_combout\);

-- Location: LCCOMB_X106_Y20_N8
\U2|Mux9~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux9~13_combout\ = (\U1|data\(4) & ((\U2|Mux9~10_combout\ & ((\U2|Mux9~15_combout\))) # (!\U2|Mux9~10_combout\ & (\U2|Mux9~9_combout\)))) # (!\U1|data\(4) & (((\U2|Mux9~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100000111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux9~9_combout\,
	datab => \U1|data\(4),
	datac => \U2|Mux9~10_combout\,
	datad => \U2|Mux9~15_combout\,
	combout => \U2|Mux9~13_combout\);

-- Location: LCCOMB_X106_Y18_N30
\U2|Mux9~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux9~2_combout\ = (\U1|data\(5) & (((\U2|leds_wire\(2))))) # (!\U1|data\(5) & ((\U1|data\(1) & (!\U1|data\(0))) # (!\U1|data\(1) & (\U1|data\(0) & \U2|leds_wire\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(1),
	datab => \U1|data\(0),
	datac => \U1|data\(5),
	datad => \U2|leds_wire\(2),
	combout => \U2|Mux9~2_combout\);

-- Location: LCCOMB_X106_Y18_N20
\U2|Mux9~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux9~3_combout\ = (\U1|data\(5) & (((\U2|leds_wire\(2))))) # (!\U1|data\(5) & (\U1|data\(1) & (\U1|data\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(1),
	datab => \U1|data\(0),
	datac => \U1|data\(5),
	datad => \U2|leds_wire\(2),
	combout => \U2|Mux9~3_combout\);

-- Location: LCCOMB_X106_Y18_N26
\U2|Mux9~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux9~4_combout\ = (\U1|data\(4) & (\U1|data\(2))) # (!\U1|data\(4) & (\U2|Mux9~3_combout\ & ((\U1|data\(5)) # (!\U1|data\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101100110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(4),
	datab => \U1|data\(2),
	datac => \U1|data\(5),
	datad => \U2|Mux9~3_combout\,
	combout => \U2|Mux9~4_combout\);

-- Location: LCCOMB_X106_Y18_N16
\U2|Mux9~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux9~5_combout\ = (\U1|data\(1) & (\U1|data\(0) & ((\U2|last_leds_wire\(2))))) # (!\U1|data\(1) & (!\U1|data\(0) & (\U2|last_leds_wire\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001100000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(1),
	datab => \U1|data\(0),
	datac => \U2|last_leds_wire\(1),
	datad => \U2|last_leds_wire\(2),
	combout => \U2|Mux9~5_combout\);

-- Location: LCCOMB_X106_Y18_N6
\U2|Mux9~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux9~6_combout\ = (\U1|data\(5) & (((\U2|leds_wire\(2))))) # (!\U1|data\(5) & ((\U2|Mux9~5_combout\) # ((\U2|Mux11~4_combout\ & \U2|leds_wire\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datab => \U2|Mux11~4_combout\,
	datac => \U2|leds_wire\(2),
	datad => \U2|Mux9~5_combout\,
	combout => \U2|Mux9~6_combout\);

-- Location: LCCOMB_X106_Y18_N0
\U2|Mux9~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux9~7_combout\ = (\U1|data\(4) & ((\U2|Mux9~4_combout\ & ((\U2|Mux9~6_combout\))) # (!\U2|Mux9~4_combout\ & (\U2|Mux9~2_combout\)))) # (!\U1|data\(4) & (((\U2|Mux9~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100000111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux9~2_combout\,
	datab => \U1|data\(4),
	datac => \U2|Mux9~4_combout\,
	datad => \U2|Mux9~6_combout\,
	combout => \U2|Mux9~7_combout\);

-- Location: LCCOMB_X106_Y20_N16
\U2|Mux9~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux9~8_combout\ = (\U3|Mux2~1_combout\ & (((\U2|Mux9~7_combout\ & \U2|Mux11~7_combout\)))) # (!\U3|Mux2~1_combout\ & ((\U2|leds_wire\(2)) # ((\U2|Mux9~7_combout\ & \U2|Mux11~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U3|Mux2~1_combout\,
	datab => \U2|leds_wire\(2),
	datac => \U2|Mux9~7_combout\,
	datad => \U2|Mux11~7_combout\,
	combout => \U2|Mux9~8_combout\);

-- Location: LCCOMB_X106_Y20_N20
\U2|Mux9~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux9~14_combout\ = (\U2|Mux9~8_combout\) # ((\U2|Mux11~17_combout\ & \U2|Mux9~13_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|Mux11~17_combout\,
	datac => \U2|Mux9~13_combout\,
	datad => \U2|Mux9~8_combout\,
	combout => \U2|Mux9~14_combout\);

-- Location: FF_X106_Y20_N21
\U2|leds_wire[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|Mux9~14_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	ena => \U2|leds_wire~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|leds_wire\(2));

-- Location: FF_X107_Y19_N5
\U2|last_leds_wire[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	asdata => \U2|leds_wire\(2),
	sload => VCC,
	ena => \U2|last_leds_wire[11]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|last_leds_wire\(2));

-- Location: LCCOMB_X107_Y20_N22
\U2|Mux10~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~10_combout\ = (\U2|Mux10~9_combout\ & (((\U2|leds_wire\(1))))) # (!\U2|Mux10~9_combout\ & ((\U1|data\(5) & ((\U2|leds_wire\(1)))) # (!\U1|data\(5) & (\U2|last_leds_wire\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|last_leds_wire\(2),
	datab => \U2|Mux10~9_combout\,
	datac => \U1|data\(5),
	datad => \U2|leds_wire\(1),
	combout => \U2|Mux10~10_combout\);

-- Location: LCCOMB_X107_Y20_N16
\U2|Mux10~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~12_combout\ = (\U1|data\(4) & (((\U2|Mux10~11_combout\)))) # (!\U1|data\(4) & (\U2|leds_wire\(1) & ((\U1|data\(5)) # (\U2|Mux10~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(1),
	datab => \U1|data\(4),
	datac => \U1|data\(5),
	datad => \U2|Mux10~11_combout\,
	combout => \U2|Mux10~12_combout\);

-- Location: LCCOMB_X107_Y20_N6
\U2|Add1~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~6_combout\ = (\U1|data\(5) & \U2|leds_wire\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \U1|data\(5),
	datad => \U2|leds_wire\(1),
	combout => \U2|Add1~6_combout\);

-- Location: LCCOMB_X107_Y20_N14
\U2|Mux10~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~14_combout\ = (\U2|Mux10~13_combout\ & ((\U1|data\(2) & (\U2|last_leds_wire\(2))) # (!\U1|data\(2) & ((\U2|last_leds_wire\(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100010010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(2),
	datab => \U2|Mux10~13_combout\,
	datac => \U2|last_leds_wire\(2),
	datad => \U2|last_leds_wire\(0),
	combout => \U2|Mux10~14_combout\);

-- Location: LCCOMB_X107_Y20_N28
\U2|Mux10~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~16_combout\ = (\U2|Add1~6_combout\) # ((\U2|Mux10~14_combout\) # ((\U2|Mux10~15_combout\ & \U2|Add1~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Add1~6_combout\,
	datab => \U2|Mux10~14_combout\,
	datac => \U2|Mux10~15_combout\,
	datad => \U2|Add1~8_combout\,
	combout => \U2|Mux10~16_combout\);

-- Location: LCCOMB_X107_Y20_N30
\U2|Mux10~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~17_combout\ = (\U2|Mux10~12_combout\ & (((\U2|Mux10~16_combout\) # (!\U1|data\(4))))) # (!\U2|Mux10~12_combout\ & (\U2|Mux10~10_combout\ & (\U1|data\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110000101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux10~10_combout\,
	datab => \U2|Mux10~12_combout\,
	datac => \U1|data\(4),
	datad => \U2|Mux10~16_combout\,
	combout => \U2|Mux10~17_combout\);

-- Location: LCCOMB_X107_Y20_N18
\U2|Mux10~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~2_combout\ = (\U1|data\(5) & (\U2|leds_wire\(1))) # (!\U1|data\(5) & ((\U1|data\(0) & (\U2|leds_wire\(1) & !\U1|data\(1))) # (!\U1|data\(0) & ((\U1|data\(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(1),
	datab => \U1|data\(0),
	datac => \U1|data\(5),
	datad => \U1|data\(1),
	combout => \U2|Mux10~2_combout\);

-- Location: LCCOMB_X107_Y20_N24
\U2|Mux10~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~4_combout\ = (\U1|data\(4) & (\U1|data\(2))) # (!\U1|data\(4) & ((\U2|Add1~6_combout\) # ((!\U1|data\(2) & \U2|Mux10~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101110011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(2),
	datab => \U1|data\(4),
	datac => \U2|Mux10~3_combout\,
	datad => \U2|Add1~6_combout\,
	combout => \U2|Mux10~4_combout\);

-- Location: LCCOMB_X107_Y20_N26
\U2|Mux10~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~19_combout\ = (\U2|leds_wire\(1) & ((\U1|data\(5)) # (\U1|data\(0) $ (\U1|data\(1))))) # (!\U2|leds_wire\(1) & ((\U1|data\(1) & (!\U1|data\(0))) # (!\U1|data\(1) & ((\U1|data\(5))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011001111111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(1),
	datab => \U1|data\(0),
	datac => \U1|data\(5),
	datad => \U1|data\(1),
	combout => \U2|Mux10~19_combout\);

-- Location: LCCOMB_X107_Y20_N10
\U2|Mux10~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~5_combout\ = (\U1|data\(1) & (((\U2|Add1~1_combout\)))) # (!\U1|data\(1) & (\U2|last_leds_wire\(0) & (!\U1|data\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(1),
	datab => \U2|last_leds_wire\(0),
	datac => \U1|data\(0),
	datad => \U2|Add1~1_combout\,
	combout => \U2|Mux10~5_combout\);

-- Location: LCCOMB_X107_Y20_N20
\U2|Mux10~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~6_combout\ = (\U2|Mux10~19_combout\ & (\U2|leds_wire\(1))) # (!\U2|Mux10~19_combout\ & ((\U2|Mux10~5_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(1),
	datac => \U2|Mux10~19_combout\,
	datad => \U2|Mux10~5_combout\,
	combout => \U2|Mux10~6_combout\);

-- Location: LCCOMB_X107_Y20_N2
\U2|Mux10~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~7_combout\ = (\U2|Mux10~4_combout\ & (((\U2|Mux10~6_combout\) # (!\U1|data\(4))))) # (!\U2|Mux10~4_combout\ & (\U2|Mux10~2_combout\ & (\U1|data\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110000101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux10~2_combout\,
	datab => \U2|Mux10~4_combout\,
	datac => \U1|data\(4),
	datad => \U2|Mux10~6_combout\,
	combout => \U2|Mux10~7_combout\);

-- Location: LCCOMB_X107_Y20_N0
\U2|Mux10~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~8_combout\ = (\U2|leds_wire\(1) & (((\U2|Mux11~7_combout\ & \U2|Mux10~7_combout\)) # (!\U3|Mux2~1_combout\))) # (!\U2|leds_wire\(1) & (((\U2|Mux11~7_combout\ & \U2|Mux10~7_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(1),
	datab => \U3|Mux2~1_combout\,
	datac => \U2|Mux11~7_combout\,
	datad => \U2|Mux10~7_combout\,
	combout => \U2|Mux10~8_combout\);

-- Location: LCCOMB_X107_Y20_N12
\U2|Mux10~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux10~18_combout\ = (\U2|Mux10~8_combout\) # ((\U2|Mux11~17_combout\ & \U2|Mux10~17_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|Mux11~17_combout\,
	datac => \U2|Mux10~17_combout\,
	datad => \U2|Mux10~8_combout\,
	combout => \U2|Mux10~18_combout\);

-- Location: FF_X107_Y20_N13
\U2|leds_wire[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|Mux10~18_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	ena => \U2|leds_wire~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|leds_wire\(1));

-- Location: FF_X107_Y19_N3
\U2|last_leds_wire[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	asdata => \U2|leds_wire\(1),
	sload => VCC,
	ena => \U2|last_leds_wire[11]~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|last_leds_wire\(1));

-- Location: LCCOMB_X106_Y19_N0
\U2|Add1~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Add1~1_combout\ = (!\U1|data\(5) & \U2|last_leds_wire\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(5),
	datad => \U2|last_leds_wire\(1),
	combout => \U2|Add1~1_combout\);

-- Location: LCCOMB_X107_Y21_N6
\U2|Mux11~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~9_combout\ = (\U1|data\(0) & (\U1|data\(1))) # (!\U1|data\(0) & ((\U2|Add1~0_combout\) # ((!\U1|data\(1) & \U2|Add1~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011011100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(1),
	datab => \U2|Add1~0_combout\,
	datac => \U2|Add1~1_combout\,
	datad => \U1|data\(0),
	combout => \U2|Mux11~9_combout\);

-- Location: LCCOMB_X107_Y21_N14
\U2|Mux11~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~10_combout\ = (\U1|data\(0) & ((\U2|Mux11~9_combout\ & ((\U2|Add1~5_combout\))) # (!\U2|Mux11~9_combout\ & (\U2|leds_wire\(0))))) # (!\U1|data\(0) & (((\U2|Mux11~9_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(0),
	datab => \U1|data\(0),
	datac => \U2|Add1~5_combout\,
	datad => \U2|Mux11~9_combout\,
	combout => \U2|Mux11~10_combout\);

-- Location: LCCOMB_X107_Y21_N0
\U2|Mux11~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~13_combout\ = (\U1|data\(1) & ((!\U1|data\(5)) # (!\U1|data\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|data\(0),
	datac => \U1|data\(1),
	datad => \U1|data\(5),
	combout => \U2|Mux11~13_combout\);

-- Location: LCCOMB_X107_Y21_N18
\U2|Mux11~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~14_combout\ = (\U1|data\(0) & (((\U2|Add1~3_combout\)))) # (!\U1|data\(0) & ((\U2|Add1~0_combout\) # ((\U2|Add1~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111001010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|data\(0),
	datab => \U2|Add1~0_combout\,
	datac => \U2|Add1~1_combout\,
	datad => \U2|Add1~3_combout\,
	combout => \U2|Mux11~14_combout\);

-- Location: LCCOMB_X107_Y21_N24
\U2|Mux11~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~15_combout\ = (\U2|Mux11~13_combout\ & ((\U2|Mux11~14_combout\))) # (!\U2|Mux11~13_combout\ & (\U2|leds_wire\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|Mux11~13_combout\,
	datac => \U2|leds_wire\(0),
	datad => \U2|Mux11~14_combout\,
	combout => \U2|Mux11~15_combout\);

-- Location: LCCOMB_X107_Y21_N10
\U2|Mux11~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~16_combout\ = (\U2|Mux11~12_combout\ & (((\U2|Mux11~15_combout\)) # (!\U1|data\(4)))) # (!\U2|Mux11~12_combout\ & (\U1|data\(4) & (\U2|Mux11~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101001100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux11~12_combout\,
	datab => \U1|data\(4),
	datac => \U2|Mux11~10_combout\,
	datad => \U2|Mux11~15_combout\,
	combout => \U2|Mux11~16_combout\);

-- Location: LCCOMB_X106_Y21_N12
\U2|Mux11~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~0_combout\ = (\U1|data\(5) & (\U2|leds_wire\(0))) # (!\U1|data\(5) & ((\U1|data\(0) & (\U2|leds_wire\(0) & !\U1|data\(1))) # (!\U1|data\(0) & ((\U1|data\(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|leds_wire\(0),
	datab => \U1|data\(0),
	datac => \U1|data\(5),
	datad => \U1|data\(1),
	combout => \U2|Mux11~0_combout\);

-- Location: LCCOMB_X107_Y21_N30
\U2|Mux11~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~3_combout\ = (\U1|data\(1) & ((\U2|last_leds_wire\(0)))) # (!\U1|data\(1) & (\U2|last_leds_wire\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U1|data\(1),
	datac => \U2|last_leds_wire\(11),
	datad => \U2|last_leds_wire\(0),
	combout => \U2|Mux11~3_combout\);

-- Location: LCCOMB_X106_Y21_N8
\U2|Mux11~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~5_combout\ = (\U1|data\(5) & (((\U2|leds_wire\(0))))) # (!\U1|data\(5) & ((\U2|Mux11~4_combout\ & ((\U2|leds_wire\(0)))) # (!\U2|Mux11~4_combout\ & (\U2|Mux11~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux11~3_combout\,
	datab => \U2|leds_wire\(0),
	datac => \U1|data\(5),
	datad => \U2|Mux11~4_combout\,
	combout => \U2|Mux11~5_combout\);

-- Location: LCCOMB_X106_Y21_N10
\U2|Mux11~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~2_combout\ = (\U1|data\(4) & (((\U1|data\(2))))) # (!\U1|data\(4) & ((\U2|Add1~0_combout\) # ((\U2|Mux11~1_combout\ & !\U1|data\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux11~1_combout\,
	datab => \U1|data\(2),
	datac => \U1|data\(4),
	datad => \U2|Add1~0_combout\,
	combout => \U2|Mux11~2_combout\);

-- Location: LCCOMB_X106_Y21_N22
\U2|Mux11~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~6_combout\ = (\U1|data\(4) & ((\U2|Mux11~2_combout\ & ((\U2|Mux11~5_combout\))) # (!\U2|Mux11~2_combout\ & (\U2|Mux11~0_combout\)))) # (!\U1|data\(4) & (((\U2|Mux11~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux11~0_combout\,
	datab => \U1|data\(4),
	datac => \U2|Mux11~5_combout\,
	datad => \U2|Mux11~2_combout\,
	combout => \U2|Mux11~6_combout\);

-- Location: LCCOMB_X106_Y21_N20
\U2|Mux11~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~8_combout\ = (\U2|Mux11~7_combout\ & ((\U2|Mux11~6_combout\) # ((\U2|leds_wire\(0) & !\U3|Mux2~1_combout\)))) # (!\U2|Mux11~7_combout\ & (\U2|leds_wire\(0) & ((!\U3|Mux2~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux11~7_combout\,
	datab => \U2|leds_wire\(0),
	datac => \U2|Mux11~6_combout\,
	datad => \U3|Mux2~1_combout\,
	combout => \U2|Mux11~8_combout\);

-- Location: LCCOMB_X106_Y21_N16
\U2|Mux11~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Mux11~18_combout\ = (\U2|Mux11~8_combout\) # ((\U2|Mux11~17_combout\ & \U2|Mux11~16_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|Mux11~17_combout\,
	datac => \U2|Mux11~16_combout\,
	datad => \U2|Mux11~8_combout\,
	combout => \U2|Mux11~18_combout\);

-- Location: FF_X106_Y21_N17
\U2|leds_wire[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \U2|Mux11~18_combout\,
	sclr => \ALT_INV_sys_rst_n_in~input_o\,
	ena => \U2|leds_wire~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|leds_wire\(0));

ww_segcode1out(0) <= \segcode1out[0]~output_o\;

ww_segcode1out(1) <= \segcode1out[1]~output_o\;

ww_segcode1out(2) <= \segcode1out[2]~output_o\;

ww_segcode1out(3) <= \segcode1out[3]~output_o\;

ww_segcode1out(4) <= \segcode1out[4]~output_o\;

ww_segcode1out(5) <= \segcode1out[5]~output_o\;

ww_segcode1out(6) <= \segcode1out[6]~output_o\;

ww_segcode0out(0) <= \segcode0out[0]~output_o\;

ww_segcode0out(1) <= \segcode0out[1]~output_o\;

ww_segcode0out(2) <= \segcode0out[2]~output_o\;

ww_segcode0out(3) <= \segcode0out[3]~output_o\;

ww_segcode0out(4) <= \segcode0out[4]~output_o\;

ww_segcode0out(5) <= \segcode0out[5]~output_o\;

ww_segcode0out(6) <= \segcode0out[6]~output_o\;

ww_led <= \led~output_o\;

ww_leds_out(0) <= \leds_out[0]~output_o\;

ww_leds_out(1) <= \leds_out[1]~output_o\;

ww_leds_out(2) <= \leds_out[2]~output_o\;

ww_leds_out(3) <= \leds_out[3]~output_o\;

ww_leds_out(4) <= \leds_out[4]~output_o\;

ww_leds_out(5) <= \leds_out[5]~output_o\;

ww_leds_out(6) <= \leds_out[6]~output_o\;

ww_leds_out(7) <= \leds_out[7]~output_o\;

ww_leds_out(8) <= \leds_out[8]~output_o\;

ww_leds_out(9) <= \leds_out[9]~output_o\;

ww_leds_out(10) <= \leds_out[10]~output_o\;

ww_leds_out(11) <= \leds_out[11]~output_o\;
END structure;


