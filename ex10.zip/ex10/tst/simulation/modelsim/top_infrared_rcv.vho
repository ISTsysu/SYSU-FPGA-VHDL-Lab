-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.0.0 Build 156 04/24/2013 SJ Full Version"

-- DATE "06/07/2024 22:09:37"

-- 
-- Device: Altera EP4CE115F29C7 Package FBGA780
-- 

-- 
-- This VHDL file should be used for ModelSim (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIVE;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIVE.CYCLONEIVE_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	top_infrared_rcv IS
    PORT (
	sys_clk : IN std_logic;
	sys_rst_n : IN std_logic;
	remote_in : IN std_logic;
	sel : OUT std_logic_vector(5 DOWNTO 0);
	seg_led : OUT std_logic_vector(7 DOWNTO 0);
	led : OUT std_logic
	);
END top_infrared_rcv;

-- Design Ports Information
-- sel[0]	=>  Location: PIN_W27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sel[1]	=>  Location: PIN_W25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sel[2]	=>  Location: PIN_V27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sel[3]	=>  Location: PIN_W26,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sel[4]	=>  Location: PIN_Y25,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sel[5]	=>  Location: PIN_W28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- seg_led[0]	=>  Location: PIN_V21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- seg_led[1]	=>  Location: PIN_U21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- seg_led[2]	=>  Location: PIN_AB20,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- seg_led[3]	=>  Location: PIN_AA21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- seg_led[4]	=>  Location: PIN_AD24,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- seg_led[5]	=>  Location: PIN_AF23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- seg_led[6]	=>  Location: PIN_Y19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- seg_led[7]	=>  Location: PIN_D4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- led	=>  Location: PIN_G19,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sys_rst_n	=>  Location: PIN_Y23,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sys_clk	=>  Location: PIN_Y2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- remote_in	=>  Location: PIN_Y15,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF top_infrared_rcv IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_sys_clk : std_logic;
SIGNAL ww_sys_rst_n : std_logic;
SIGNAL ww_remote_in : std_logic;
SIGNAL ww_sel : std_logic_vector(5 DOWNTO 0);
SIGNAL ww_seg_led : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_led : std_logic;
SIGNAL \sys_clk~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \u_remote_rcv|div_clk~clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \u_seg_led|dri_clk~clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \u_led_ctrl|led_cnt[14]~53_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[16]~57_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[1]~0_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[1]~1\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[2]~2_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[2]~3\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[3]~4_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[3]~5\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[4]~7_cout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[1]~0_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[1]~1\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[2]~2_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[2]~3\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[3]~4_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[3]~5\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[4]~7_cout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[1]~0_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[1]~1\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[2]~2_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[2]~3\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[3]~4_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[3]~5\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[4]~7_cout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[1]~0_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[1]~1\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[2]~2_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[2]~3\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[3]~4_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[3]~5\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[4]~7_cout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[1]~1_cout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[2]~3_cout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[3]~5_cout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[4]~7_cout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[0]~0_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[1]~0_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[1]~1\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[2]~2_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[2]~3\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[3]~4_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[3]~5\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[4]~7_cout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[1]~2_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[1]~3\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[2]~4_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[2]~5\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[3]~6_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[3]~7\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[4]~9_cout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[4]~4_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[6]~8_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[3]~4_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[2]~2_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[3]~4_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[2]~2_combout\ : std_logic;
SIGNAL \u_seg_led|cnt0[4]~21_combout\ : std_logic;
SIGNAL \u_seg_led|cnt0[9]~31_combout\ : std_logic;
SIGNAL \u_seg_led|cnt0[11]~36\ : std_logic;
SIGNAL \u_seg_led|cnt0[12]~37_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_cnt[1]~10_combout\ : std_logic;
SIGNAL \u_remote_rcv|Add0~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|Add0~1\ : std_logic;
SIGNAL \u_remote_rcv|Add0~2_combout\ : std_logic;
SIGNAL \u_remote_rcv|Add0~3\ : std_logic;
SIGNAL \u_remote_rcv|Add0~4_combout\ : std_logic;
SIGNAL \u_remote_rcv|Add0~5\ : std_logic;
SIGNAL \u_remote_rcv|Add0~6_combout\ : std_logic;
SIGNAL \u_remote_rcv|Add0~7\ : std_logic;
SIGNAL \u_remote_rcv|Add0~8_combout\ : std_logic;
SIGNAL \u_remote_rcv|Add0~9\ : std_logic;
SIGNAL \u_remote_rcv|Add0~10_combout\ : std_logic;
SIGNAL \u_remote_rcv|Add0~11\ : std_logic;
SIGNAL \u_remote_rcv|Add0~12_combout\ : std_logic;
SIGNAL \u_remote_rcv|Add0~13\ : std_logic;
SIGNAL \u_remote_rcv|Add0~14_combout\ : std_logic;
SIGNAL \u_remote_rcv|Add0~15\ : std_logic;
SIGNAL \u_remote_rcv|Add0~16_combout\ : std_logic;
SIGNAL \u_remote_rcv|Add0~17\ : std_logic;
SIGNAL \u_remote_rcv|Add0~18_combout\ : std_logic;
SIGNAL \u_remote_rcv|Add0~19\ : std_logic;
SIGNAL \u_remote_rcv|Add0~20_combout\ : std_logic;
SIGNAL \u_remote_rcv|Add0~21\ : std_logic;
SIGNAL \u_remote_rcv|Add0~22_combout\ : std_logic;
SIGNAL \u_led_ctrl|Equal0~5_combout\ : std_logic;
SIGNAL \u_led_ctrl|Equal0~6_combout\ : std_logic;
SIGNAL \u_led_ctrl|Equal0~8_combout\ : std_logic;
SIGNAL \u_seg_led|Mux1~0_combout\ : std_logic;
SIGNAL \u_seg_led|Mux1~1_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[78]~36_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[78]~37_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~38_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~39_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~40_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~41_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[75]~42_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[75]~43_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[83]~44_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~45_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~46_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~47_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[80]~48_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[80]~49_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[88]~50_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~51_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~52_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~53_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[85]~54_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[85]~55_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[93]~56_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[92]~57_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[91]~58_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[91]~59_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[90]~60_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[90]~61_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[93]~0_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[93]~1_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~2_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~3_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~4_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~5_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~6_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~7_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[95]~8_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|StageOut[150]~0_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|StageOut[149]~2_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|StageOut[148]~5_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|StageOut[147]~6_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|StageOut[146]~8_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|StageOut[145]~10_combout\ : std_logic;
SIGNAL \u_seg_led|num~2_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[96]~9_combout\ : std_logic;
SIGNAL \u_seg_led|WideOr3~combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[98]~10_combout\ : std_logic;
SIGNAL \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[97]~11_combout\ : std_logic;
SIGNAL \u_seg_led|num~3_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[78]~36_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~38_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~40_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[75]~42_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~47_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[80]~48_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[88]~50_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~51_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~53_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[85]~55_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[90]~56_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[93]~58_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~59_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~60_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[97]~63_combout\ : std_logic;
SIGNAL \u_seg_led|num~4_combout\ : std_logic;
SIGNAL \u_remote_rcv|div_clk~q\ : std_logic;
SIGNAL \u_remote_rcv|data[7]~1_combout\ : std_logic;
SIGNAL \u_remote_rcv|Selector3~1_combout\ : std_logic;
SIGNAL \u_remote_rcv|Equal0~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|Equal0~1_combout\ : std_logic;
SIGNAL \u_remote_rcv|Equal0~2_combout\ : std_logic;
SIGNAL \u_remote_rcv|div_clk~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|always5~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp~7_combout\ : std_logic;
SIGNAL \u_remote_rcv|always5~3_combout\ : std_logic;
SIGNAL \u_remote_rcv|always5~10_combout\ : std_logic;
SIGNAL \u_remote_rcv|div_cnt~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|div_cnt~1_combout\ : std_logic;
SIGNAL \u_remote_rcv|div_cnt~2_combout\ : std_logic;
SIGNAL \u_remote_rcv|div_cnt~3_combout\ : std_logic;
SIGNAL \u_remote_rcv|div_cnt~4_combout\ : std_logic;
SIGNAL \u_remote_rcv|div_cnt~5_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[88]~62_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[93]~63_combout\ : std_logic;
SIGNAL \u_seg_led|num~5_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[83]~64_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~65_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~66_combout\ : std_logic;
SIGNAL \u_seg_led|Div0|auto_generated|divider|divider|StageOut[92]~67_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[83]~67_combout\ : std_logic;
SIGNAL \u_remote_rcv|div_clk~clkctrl_outclk\ : std_logic;
SIGNAL \u_seg_led|num[0]~feeder_combout\ : std_logic;
SIGNAL \u_remote_rcv|data[0]~feeder_combout\ : std_logic;
SIGNAL \u_remote_rcv|div_clk~feeder_combout\ : std_logic;
SIGNAL \sel[0]~output_o\ : std_logic;
SIGNAL \sel[1]~output_o\ : std_logic;
SIGNAL \sel[2]~output_o\ : std_logic;
SIGNAL \sel[3]~output_o\ : std_logic;
SIGNAL \sel[4]~output_o\ : std_logic;
SIGNAL \sel[5]~output_o\ : std_logic;
SIGNAL \seg_led[0]~output_o\ : std_logic;
SIGNAL \seg_led[1]~output_o\ : std_logic;
SIGNAL \seg_led[2]~output_o\ : std_logic;
SIGNAL \seg_led[3]~output_o\ : std_logic;
SIGNAL \seg_led[4]~output_o\ : std_logic;
SIGNAL \seg_led[5]~output_o\ : std_logic;
SIGNAL \seg_led[6]~output_o\ : std_logic;
SIGNAL \seg_led[7]~output_o\ : std_logic;
SIGNAL \led~output_o\ : std_logic;
SIGNAL \u_seg_led|clk_cnt[3]~1_combout\ : std_logic;
SIGNAL \sys_rst_n~input_o\ : std_logic;
SIGNAL \u_seg_led|clk_cnt~0_combout\ : std_logic;
SIGNAL \u_seg_led|clk_cnt~3_combout\ : std_logic;
SIGNAL \u_seg_led|clk_cnt[1]~2_combout\ : std_logic;
SIGNAL \u_seg_led|Equal0~0_combout\ : std_logic;
SIGNAL \u_seg_led|dri_clk~0_combout\ : std_logic;
SIGNAL \u_seg_led|dri_clk~feeder_combout\ : std_logic;
SIGNAL \u_seg_led|dri_clk~q\ : std_logic;
SIGNAL \u_seg_led|dri_clk~clkctrl_outclk\ : std_logic;
SIGNAL \u_seg_led|cnt_sel~0_combout\ : std_logic;
SIGNAL \u_seg_led|cnt0[0]~14\ : std_logic;
SIGNAL \u_seg_led|cnt0[1]~15_combout\ : std_logic;
SIGNAL \u_seg_led|cnt0[1]~16\ : std_logic;
SIGNAL \u_seg_led|cnt0[2]~18\ : std_logic;
SIGNAL \u_seg_led|cnt0[3]~19_combout\ : std_logic;
SIGNAL \u_seg_led|cnt0[3]~20\ : std_logic;
SIGNAL \u_seg_led|cnt0[4]~22\ : std_logic;
SIGNAL \u_seg_led|cnt0[5]~23_combout\ : std_logic;
SIGNAL \u_seg_led|cnt0[5]~24\ : std_logic;
SIGNAL \u_seg_led|cnt0[6]~25_combout\ : std_logic;
SIGNAL \u_seg_led|cnt0[6]~26\ : std_logic;
SIGNAL \u_seg_led|cnt0[7]~27_combout\ : std_logic;
SIGNAL \u_seg_led|cnt0[7]~28\ : std_logic;
SIGNAL \u_seg_led|cnt0[8]~29_combout\ : std_logic;
SIGNAL \u_seg_led|cnt0[8]~30\ : std_logic;
SIGNAL \u_seg_led|cnt0[9]~32\ : std_logic;
SIGNAL \u_seg_led|cnt0[10]~33_combout\ : std_logic;
SIGNAL \u_seg_led|cnt0[10]~34\ : std_logic;
SIGNAL \u_seg_led|cnt0[11]~35_combout\ : std_logic;
SIGNAL \u_seg_led|cnt0[2]~17_combout\ : std_logic;
SIGNAL \u_seg_led|cnt0[0]~13_combout\ : std_logic;
SIGNAL \u_seg_led|LessThan0~0_combout\ : std_logic;
SIGNAL \u_seg_led|LessThan0~1_combout\ : std_logic;
SIGNAL \u_seg_led|LessThan0~2_combout\ : std_logic;
SIGNAL \u_seg_led|LessThan0~3_combout\ : std_logic;
SIGNAL \u_seg_led|flag~q\ : std_logic;
SIGNAL \u_seg_led|cnt_sel~2_combout\ : std_logic;
SIGNAL \u_seg_led|cnt_sel~1_combout\ : std_logic;
SIGNAL \u_seg_led|Decoder0~0_combout\ : std_logic;
SIGNAL \u_seg_led|Decoder0~1_combout\ : std_logic;
SIGNAL \u_seg_led|Decoder0~2_combout\ : std_logic;
SIGNAL \u_seg_led|Decoder0~3_combout\ : std_logic;
SIGNAL \u_seg_led|Decoder0~4_combout\ : std_logic;
SIGNAL \u_seg_led|Decoder0~5_combout\ : std_logic;
SIGNAL \u_seg_led|num[13]~feeder_combout\ : std_logic;
SIGNAL \remote_in~input_o\ : std_logic;
SIGNAL \u_remote_rcv|remote_in_d0~q\ : std_logic;
SIGNAL \u_remote_rcv|remote_in_d1~q\ : std_logic;
SIGNAL \u_remote_rcv|data_temp~2_combout\ : std_logic;
SIGNAL \u_remote_rcv|pos_remote_in~combout\ : std_logic;
SIGNAL \u_remote_rcv|data_cnt[0]~8_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_cnt[5]~20_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_cnt[0]~9\ : std_logic;
SIGNAL \u_remote_rcv|data_cnt[1]~11\ : std_logic;
SIGNAL \u_remote_rcv|data_cnt[2]~13\ : std_logic;
SIGNAL \u_remote_rcv|data_cnt[3]~15\ : std_logic;
SIGNAL \u_remote_rcv|data_cnt[4]~16_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_cnt[2]~12_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_cnt[3]~14_combout\ : std_logic;
SIGNAL \u_remote_rcv|Equal1~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp[7]~3_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_cnt[4]~17\ : std_logic;
SIGNAL \u_remote_rcv|data_cnt[5]~18_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp[15]~4_combout\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt[0]~8_combout\ : std_logic;
SIGNAL \u_remote_rcv|Selector3~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt[4]~17\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt[5]~18_combout\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt[5]~19\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt[6]~21\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt[7]~22_combout\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt[2]~12_combout\ : std_logic;
SIGNAL \u_remote_rcv|always5~4_combout\ : std_logic;
SIGNAL \u_remote_rcv|always5~5_combout\ : std_logic;
SIGNAL \u_remote_rcv|always5~6_combout\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt[6]~20_combout\ : std_logic;
SIGNAL \u_remote_rcv|always5~1_combout\ : std_logic;
SIGNAL \u_remote_rcv|always5~7_combout\ : std_logic;
SIGNAL \u_remote_rcv|always5~8_combout\ : std_logic;
SIGNAL \u_remote_rcv|judge_flag~1_combout\ : std_logic;
SIGNAL \u_remote_rcv|judge_flag~q\ : std_logic;
SIGNAL \u_remote_rcv|Selector3~2_combout\ : std_logic;
SIGNAL \u_remote_rcv|cur_state.st_rec_data~q\ : std_logic;
SIGNAL \u_remote_rcv|Selector5~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|Selector4~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|cur_state.st_repeat_code~q\ : std_logic;
SIGNAL \u_remote_rcv|Selector5~1_combout\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt[3]~14_combout\ : std_logic;
SIGNAL \u_remote_rcv|always5~9_combout\ : std_logic;
SIGNAL \u_remote_rcv|judge_flag~2_combout\ : std_logic;
SIGNAL \u_remote_rcv|Selector7~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|Selector7~1_combout\ : std_logic;
SIGNAL \u_remote_rcv|error_en~q\ : std_logic;
SIGNAL \u_remote_rcv|Selector6~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|Selector6~2_combout\ : std_logic;
SIGNAL \u_remote_rcv|time_done~q\ : std_logic;
SIGNAL \u_remote_rcv|Selector0~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|Selector0~1_combout\ : std_logic;
SIGNAL \u_remote_rcv|cur_state.st_idle~q\ : std_logic;
SIGNAL \u_remote_rcv|Selector1~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|Selector1~1_combout\ : std_logic;
SIGNAL \u_remote_rcv|cur_state.st_start_low_9ms~q\ : std_logic;
SIGNAL \u_remote_rcv|Selector6~1_combout\ : std_logic;
SIGNAL \u_remote_rcv|Selector2~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|cur_state.st_start_judge~q\ : std_logic;
SIGNAL \u_remote_rcv|judge_flag~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|Selector5~2_combout\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt_clr~q\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt[0]~9\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt[1]~10_combout\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt[1]~11\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt[2]~13\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt[3]~15\ : std_logic;
SIGNAL \u_remote_rcv|time_cnt[4]~16_combout\ : std_logic;
SIGNAL \u_remote_rcv|LessThan5~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|LessThan5~1_combout\ : std_logic;
SIGNAL \u_remote_rcv|always5~2_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp[7]~5_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp[7]~6_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp~20_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp~18_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp~16_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp~14_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp~12_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp~10_combout\ : std_logic;
SIGNAL \u_remote_rcv|data[1]~feeder_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp[15]~21_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp[15]~23_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp[15]~22_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp~19_combout\ : std_logic;
SIGNAL \u_remote_rcv|data[7]~3_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp~17_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp~15_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp~13_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp~11_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp~9_combout\ : std_logic;
SIGNAL \u_remote_rcv|data_temp~8_combout\ : std_logic;
SIGNAL \u_remote_rcv|data[7]~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|data[7]~2_combout\ : std_logic;
SIGNAL \u_remote_rcv|data[7]~4_combout\ : std_logic;
SIGNAL \u_remote_rcv|data[7]~5_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[1]~1\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[2]~3\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[3]~5\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[4]~7_cout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[2]~2_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~39_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[1]~0_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~41_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[75]~43_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[1]~1\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[2]~3\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[3]~4_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[3]~4_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[78]~37_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[3]~5\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[4]~7_cout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[83]~44_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[2]~2_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~45_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~46_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[80]~49_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[1]~1\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[2]~3\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[3]~5\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[4]~7_cout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[1]~0_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~69_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~68_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[88]~65_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~52_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[85]~54_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[1]~1\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[2]~3\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[3]~5\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[4]~7_cout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[2]~2_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[93]~66_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[1]~0_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~70_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[1]~0_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~61_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[90]~57_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[1]~1\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[2]~3\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[3]~5\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[4]~7_cout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[1]~0_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[96]~62_combout\ : std_logic;
SIGNAL \u_seg_led|Mux2~0_combout\ : std_logic;
SIGNAL \u_seg_led|Mux2~1_combout\ : std_logic;
SIGNAL \u_seg_led|Mux2~2_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[3]~4_combout\ : std_logic;
SIGNAL \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[98]~64_combout\ : std_logic;
SIGNAL \u_seg_led|Mux0~0_combout\ : std_logic;
SIGNAL \u_seg_led|Mux0~1_combout\ : std_logic;
SIGNAL \u_seg_led|Mux0~2_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[2]~1\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[3]~3\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[4]~5\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[5]~7\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[6]~9\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[7]~11_cout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|StageOut[150]~1_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[5]~6_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|StageOut[149]~3_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|StageOut[148]~4_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[3]~2_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|StageOut[147]~7_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[2]~0_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|StageOut[146]~9_combout\ : std_logic;
SIGNAL \u_remote_rcv|data[2]~feeder_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[1]~14_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|StageOut[145]~11_combout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[2]~1_cout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[3]~3_cout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[4]~5_cout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[5]~7_cout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[6]~9_cout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[7]~11_cout\ : std_logic;
SIGNAL \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[8]~12_combout\ : std_logic;
SIGNAL \u_seg_led|num[8]~6_combout\ : std_logic;
SIGNAL \u_seg_led|Mux3~0_combout\ : std_logic;
SIGNAL \u_seg_led|Mux3~1_combout\ : std_logic;
SIGNAL \u_seg_led|WideOr11~0_combout\ : std_logic;
SIGNAL \u_seg_led|WideOr10~0_combout\ : std_logic;
SIGNAL \u_seg_led|WideOr9~0_combout\ : std_logic;
SIGNAL \u_seg_led|WideOr8~0_combout\ : std_logic;
SIGNAL \u_seg_led|WideOr7~0_combout\ : std_logic;
SIGNAL \u_seg_led|WideOr6~0_combout\ : std_logic;
SIGNAL \u_seg_led|WideOr5~0_combout\ : std_logic;
SIGNAL \sys_clk~input_o\ : std_logic;
SIGNAL \sys_clk~inputclkctrl_outclk\ : std_logic;
SIGNAL \u_remote_rcv|repeat_en~0_combout\ : std_logic;
SIGNAL \u_remote_rcv|repeat_en~q\ : std_logic;
SIGNAL \u_led_ctrl|repeat_en_d0~feeder_combout\ : std_logic;
SIGNAL \u_led_ctrl|repeat_en_d0~q\ : std_logic;
SIGNAL \u_led_ctrl|repeat_en_d1~feeder_combout\ : std_logic;
SIGNAL \u_led_ctrl|repeat_en_d1~q\ : std_logic;
SIGNAL \u_led_ctrl|pos_repeat_en~combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[0]~26\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[1]~28\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[2]~29_combout\ : std_logic;
SIGNAL \~GND~combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[19]~64\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[20]~65_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[20]~66\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[21]~67_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[21]~68\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[22]~69_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[1]~27_combout\ : std_logic;
SIGNAL \u_led_ctrl|Equal0~3_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[4]~33_combout\ : std_logic;
SIGNAL \u_led_ctrl|Equal0~4_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[0]~25_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[10]~45_combout\ : std_logic;
SIGNAL \u_led_ctrl|Equal0~0_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[7]~39_combout\ : std_logic;
SIGNAL \u_led_ctrl|Equal0~1_combout\ : std_logic;
SIGNAL \u_led_ctrl|Equal0~2_combout\ : std_logic;
SIGNAL \u_led_ctrl|Equal0~7_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[4]~71_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[2]~30\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[3]~31_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[3]~32\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[4]~34\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[5]~35_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[5]~36\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[6]~37_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[6]~38\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[7]~40\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[8]~41_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[8]~42\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[9]~43_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[9]~feeder_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[9]~44\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[10]~46\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[11]~47_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[11]~48\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[12]~49_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[12]~50\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[13]~51_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[13]~52\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[14]~54\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[15]~55_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[15]~56\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[16]~58\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[17]~60\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[18]~61_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[18]~62\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[19]~63_combout\ : std_logic;
SIGNAL \u_led_ctrl|led_cnt[17]~59_combout\ : std_logic;
SIGNAL \u_led_ctrl|led~0_combout\ : std_logic;
SIGNAL \u_led_ctrl|led~1_combout\ : std_logic;
SIGNAL \u_led_ctrl|led~2_combout\ : std_logic;
SIGNAL \u_led_ctrl|led~3_combout\ : std_logic;
SIGNAL \u_led_ctrl|led~q\ : std_logic;
SIGNAL \u_seg_led|num_disp\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \u_remote_rcv|data\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \u_seg_led|num\ : std_logic_vector(23 DOWNTO 0);
SIGNAL \u_seg_led|cnt_sel\ : std_logic_vector(2 DOWNTO 0);
SIGNAL \u_remote_rcv|time_cnt\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \u_seg_led|seg_led\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \u_seg_led|seg_sel\ : std_logic_vector(5 DOWNTO 0);
SIGNAL \u_remote_rcv|data_cnt\ : std_logic_vector(5 DOWNTO 0);
SIGNAL \u_seg_led|clk_cnt\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \u_remote_rcv|data_temp\ : std_logic_vector(15 DOWNTO 0);
SIGNAL \u_remote_rcv|div_cnt\ : std_logic_vector(11 DOWNTO 0);
SIGNAL \u_seg_led|cnt0\ : std_logic_vector(12 DOWNTO 0);
SIGNAL \u_led_ctrl|led_cnt\ : std_logic_vector(22 DOWNTO 0);
SIGNAL \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\ : std_logic;
SIGNAL \u_seg_led|ALT_INV_seg_led\ : std_logic_vector(6 DOWNTO 6);
SIGNAL \u_seg_led|ALT_INV_seg_sel\ : std_logic_vector(5 DOWNTO 0);

BEGIN

ww_sys_clk <= sys_clk;
ww_sys_rst_n <= sys_rst_n;
ww_remote_in <= remote_in;
sel <= ww_sel;
seg_led <= ww_seg_led;
led <= ww_led;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\sys_clk~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \sys_clk~input_o\);

\u_remote_rcv|div_clk~clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \u_remote_rcv|div_clk~q\);

\u_seg_led|dri_clk~clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \u_seg_led|dri_clk~q\);
\u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\ <= NOT \u_seg_led|dri_clk~clkctrl_outclk\;
\u_seg_led|ALT_INV_seg_led\(6) <= NOT \u_seg_led|seg_led\(6);
\u_seg_led|ALT_INV_seg_sel\(5) <= NOT \u_seg_led|seg_sel\(5);
\u_seg_led|ALT_INV_seg_sel\(4) <= NOT \u_seg_led|seg_sel\(4);
\u_seg_led|ALT_INV_seg_sel\(3) <= NOT \u_seg_led|seg_sel\(3);
\u_seg_led|ALT_INV_seg_sel\(2) <= NOT \u_seg_led|seg_sel\(2);
\u_seg_led|ALT_INV_seg_sel\(1) <= NOT \u_seg_led|seg_sel\(1);
\u_seg_led|ALT_INV_seg_sel\(0) <= NOT \u_seg_led|seg_sel\(0);

-- Location: FF_X91_Y24_N7
\u_led_ctrl|led_cnt[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[14]~53_combout\,
	asdata => VCC,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(14));

-- Location: FF_X91_Y24_N11
\u_led_ctrl|led_cnt[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[16]~57_combout\,
	asdata => \~GND~combout\,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(16));

-- Location: LCCOMB_X91_Y24_N6
\u_led_ctrl|led_cnt[14]~53\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[14]~53_combout\ = (\u_led_ctrl|led_cnt\(14) & ((GND) # (!\u_led_ctrl|led_cnt[13]~52\))) # (!\u_led_ctrl|led_cnt\(14) & (\u_led_ctrl|led_cnt[13]~52\ $ (GND)))
-- \u_led_ctrl|led_cnt[14]~54\ = CARRY((\u_led_ctrl|led_cnt\(14)) # (!\u_led_ctrl|led_cnt[13]~52\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101010101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(14),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[13]~52\,
	combout => \u_led_ctrl|led_cnt[14]~53_combout\,
	cout => \u_led_ctrl|led_cnt[14]~54\);

-- Location: LCCOMB_X91_Y24_N10
\u_led_ctrl|led_cnt[16]~57\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[16]~57_combout\ = (\u_led_ctrl|led_cnt\(16) & ((GND) # (!\u_led_ctrl|led_cnt[15]~56\))) # (!\u_led_ctrl|led_cnt\(16) & (\u_led_ctrl|led_cnt[15]~56\ $ (GND)))
-- \u_led_ctrl|led_cnt[16]~58\ = CARRY((\u_led_ctrl|led_cnt\(16)) # (!\u_led_ctrl|led_cnt[15]~56\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101010101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(16),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[15]~56\,
	combout => \u_led_ctrl|led_cnt[16]~57_combout\,
	cout => \u_led_ctrl|led_cnt[16]~58\);

-- Location: FF_X105_Y29_N29
\u_seg_led|cnt0[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt0[12]~37_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_seg_led|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt0\(12));

-- Location: FF_X105_Y29_N23
\u_seg_led|cnt0[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt0[9]~31_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_seg_led|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt0\(9));

-- Location: FF_X105_Y29_N13
\u_seg_led|cnt0[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt0[4]~21_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_seg_led|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt0\(4));

-- Location: LCCOMB_X97_Y21_N22
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[1]~0_combout\ = \u_remote_rcv|data\(5) $ (VCC)
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[1]~1\ = CARRY(\u_remote_rcv|data\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|data\(5),
	datad => VCC,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[1]~0_combout\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[1]~1\);

-- Location: LCCOMB_X97_Y21_N24
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[2]~2_combout\ = (\u_remote_rcv|data\(6) & (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[1]~1\ & VCC)) # (!\u_remote_rcv|data\(6) & 
-- (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[1]~1\))
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[2]~3\ = CARRY((!\u_remote_rcv|data\(6) & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[1]~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data\(6),
	datad => VCC,
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[1]~1\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[2]~2_combout\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[2]~3\);

-- Location: LCCOMB_X97_Y21_N26
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[3]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[3]~4_combout\ = (\u_remote_rcv|data\(7) & (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[2]~3\ $ (GND))) # (!\u_remote_rcv|data\(7) & 
-- (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[2]~3\ & VCC))
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[3]~5\ = CARRY((\u_remote_rcv|data\(7) & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[2]~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|data\(7),
	datad => VCC,
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[2]~3\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[3]~4_combout\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[3]~5\);

-- Location: LCCOMB_X97_Y21_N28
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[4]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[4]~7_cout\ = CARRY(!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[3]~5\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => VCC,
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[3]~5\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[4]~7_cout\);

-- Location: LCCOMB_X97_Y21_N30
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ = \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[4]~7_cout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\);

-- Location: LCCOMB_X97_Y21_N12
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[1]~0_combout\ = (((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[75]~42_combout\) # (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[75]~43_combout\)))
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[1]~1\ = CARRY((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[75]~42_combout\) # (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[75]~43_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[75]~42_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[75]~43_combout\,
	datad => VCC,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[1]~0_combout\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[1]~1\);

-- Location: LCCOMB_X97_Y21_N14
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[2]~2_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[1]~1\ & (((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~41_combout\) # 
-- (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~40_combout\)))) # (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[1]~1\ & (!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~41_combout\ & 
-- (!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~40_combout\)))
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[2]~3\ = CARRY((!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~41_combout\ & (!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~40_combout\ & 
-- !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~41_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~40_combout\,
	datad => VCC,
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[1]~1\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[2]~2_combout\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[2]~3\);

-- Location: LCCOMB_X97_Y21_N16
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[3]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[3]~4_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[2]~3\ & (((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~38_combout\) # 
-- (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~39_combout\)))) # (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[2]~3\ & ((((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~38_combout\) # 
-- (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~39_combout\)))))
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[3]~5\ = CARRY((!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[2]~3\ & ((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~38_combout\) # 
-- (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~39_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~38_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~39_combout\,
	datad => VCC,
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[2]~3\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[3]~4_combout\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[3]~5\);

-- Location: LCCOMB_X97_Y21_N18
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[4]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[4]~7_cout\ = CARRY((!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[78]~36_combout\ & (!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[78]~37_combout\ & 
-- !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[78]~36_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[78]~37_combout\,
	datad => VCC,
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[3]~5\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[4]~7_cout\);

-- Location: LCCOMB_X97_Y21_N20
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ = \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[4]~7_cout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\);

-- Location: LCCOMB_X98_Y21_N4
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[1]~0_combout\ = (((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[80]~48_combout\) # (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[80]~49_combout\)))
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[1]~1\ = CARRY((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[80]~48_combout\) # (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[80]~49_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[80]~48_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[80]~49_combout\,
	datad => VCC,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[1]~0_combout\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[1]~1\);

-- Location: LCCOMB_X98_Y21_N6
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[2]~2_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[1]~1\ & (((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~47_combout\) # 
-- (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~46_combout\)))) # (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[1]~1\ & (!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~47_combout\ & 
-- (!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~46_combout\)))
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[2]~3\ = CARRY((!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~47_combout\ & (!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~46_combout\ & 
-- !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~47_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~46_combout\,
	datad => VCC,
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[1]~1\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[2]~2_combout\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[2]~3\);

-- Location: LCCOMB_X98_Y21_N8
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[3]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[3]~4_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[2]~3\ & (((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~45_combout\) # 
-- (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~65_combout\)))) # (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[2]~3\ & ((((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~45_combout\) # 
-- (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~65_combout\)))))
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[3]~5\ = CARRY((!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[2]~3\ & ((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~45_combout\) # 
-- (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~65_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~45_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~65_combout\,
	datad => VCC,
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[2]~3\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[3]~4_combout\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[3]~5\);

-- Location: LCCOMB_X98_Y21_N10
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[4]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[4]~7_cout\ = CARRY((!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[83]~64_combout\ & (!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[83]~44_combout\ & 
-- !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[83]~64_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[83]~44_combout\,
	datad => VCC,
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[3]~5\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[4]~7_cout\);

-- Location: LCCOMB_X98_Y21_N12
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ = \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[4]~7_cout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\);

-- Location: LCCOMB_X99_Y20_N14
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[1]~0_combout\ = (((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[85]~55_combout\) # (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[85]~54_combout\)))
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[1]~1\ = CARRY((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[85]~55_combout\) # (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[85]~54_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[85]~55_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[85]~54_combout\,
	datad => VCC,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[1]~0_combout\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[1]~1\);

-- Location: LCCOMB_X99_Y20_N16
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[2]~2_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[1]~1\ & (((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~53_combout\) # 
-- (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~52_combout\)))) # (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[1]~1\ & (!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~53_combout\ & 
-- (!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~52_combout\)))
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[2]~3\ = CARRY((!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~53_combout\ & (!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~52_combout\ & 
-- !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~53_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~52_combout\,
	datad => VCC,
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[1]~1\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[2]~2_combout\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[2]~3\);

-- Location: LCCOMB_X99_Y20_N18
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[3]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[3]~4_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[2]~3\ & (((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~51_combout\) # 
-- (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~66_combout\)))) # (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[2]~3\ & ((((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~51_combout\) # 
-- (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~66_combout\)))))
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[3]~5\ = CARRY((!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[2]~3\ & ((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~51_combout\) # 
-- (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~66_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~51_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~66_combout\,
	datad => VCC,
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[2]~3\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[3]~4_combout\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[3]~5\);

-- Location: LCCOMB_X99_Y20_N20
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[4]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[4]~7_cout\ = CARRY((!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[88]~62_combout\ & (!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[88]~50_combout\ & 
-- !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[88]~62_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[88]~50_combout\,
	datad => VCC,
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[3]~5\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[4]~7_cout\);

-- Location: LCCOMB_X99_Y20_N22
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ = \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[4]~7_cout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\);

-- Location: LCCOMB_X98_Y20_N10
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[1]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[1]~1_cout\ = CARRY((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[90]~61_combout\) # (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[90]~60_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[90]~61_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[90]~60_combout\,
	datad => VCC,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[1]~1_cout\);

-- Location: LCCOMB_X98_Y20_N12
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[2]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[2]~3_cout\ = CARRY((!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[91]~58_combout\ & (!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[91]~59_combout\ & 
-- !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[1]~1_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[91]~58_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[91]~59_combout\,
	datad => VCC,
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[1]~1_cout\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[2]~3_cout\);

-- Location: LCCOMB_X98_Y20_N14
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[3]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[3]~5_cout\ = CARRY((!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[2]~3_cout\ & ((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[92]~67_combout\) # 
-- (\u_seg_led|Div0|auto_generated|divider|divider|StageOut[92]~57_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[92]~67_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[92]~57_combout\,
	datad => VCC,
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[2]~3_cout\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[3]~5_cout\);

-- Location: LCCOMB_X98_Y20_N16
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[4]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[4]~7_cout\ = CARRY((!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[93]~63_combout\ & (!\u_seg_led|Div0|auto_generated|divider|divider|StageOut[93]~56_combout\ & 
-- !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[3]~5_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[93]~63_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[93]~56_combout\,
	datad => VCC,
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[3]~5_cout\,
	cout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[4]~7_cout\);

-- Location: LCCOMB_X98_Y20_N18
\u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[5]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\ = \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[4]~7_cout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\);

-- Location: LCCOMB_X98_Y20_N8
\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[0]~0_combout\ = !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[0]~0_combout\);

-- Location: LCCOMB_X97_Y20_N10
\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[1]~0_combout\ = \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ $ (GND)
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[1]~1\ = CARRY(!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	datad => VCC,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[1]~0_combout\,
	cout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[1]~1\);

-- Location: LCCOMB_X97_Y20_N12
\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[2]~2_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ & (!\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[1]~1\)) # 
-- (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ & (\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[1]~1\ & VCC))
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[2]~3\ = CARRY((\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ & !\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[1]~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101000001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[1]~1\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[2]~2_combout\,
	cout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[2]~3\);

-- Location: LCCOMB_X97_Y20_N14
\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[3]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[3]~4_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & (!\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[2]~3\ & VCC)) 
-- # (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & (\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[2]~3\ $ (GND)))
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[3]~5\ = CARRY((!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & !\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[2]~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101000000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[2]~3\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[3]~4_combout\,
	cout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[3]~5\);

-- Location: LCCOMB_X97_Y20_N16
\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[4]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[4]~7_cout\ = CARRY(!\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[3]~5\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => VCC,
	cin => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[3]~5\,
	cout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[4]~7_cout\);

-- Location: LCCOMB_X97_Y20_N18
\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ = \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[4]~7_cout\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\);

-- Location: LCCOMB_X97_Y20_N20
\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[1]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[1]~2_combout\ = (((\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~6_combout\) # (\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~7_combout\)))
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[1]~3\ = CARRY((\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~6_combout\) # (\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~6_combout\,
	datab => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~7_combout\,
	datad => VCC,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[1]~2_combout\,
	cout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[1]~3\);

-- Location: LCCOMB_X97_Y20_N22
\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[2]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[2]~4_combout\ = (\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[1]~3\ & (((\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~5_combout\) # 
-- (\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~4_combout\)))) # (!\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[1]~3\ & (!\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~5_combout\ & 
-- (!\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~4_combout\)))
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[2]~5\ = CARRY((!\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~5_combout\ & (!\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~4_combout\ & 
-- !\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[1]~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~5_combout\,
	datab => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~4_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[1]~3\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[2]~4_combout\,
	cout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[2]~5\);

-- Location: LCCOMB_X97_Y20_N24
\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[3]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[3]~6_combout\ = (\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[2]~5\ & (((\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~2_combout\) # 
-- (\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~3_combout\)))) # (!\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[2]~5\ & ((((\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~2_combout\) # 
-- (\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~3_combout\)))))
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[3]~7\ = CARRY((!\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[2]~5\ & ((\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~2_combout\) # 
-- (\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~2_combout\,
	datab => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~3_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[2]~5\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[3]~6_combout\,
	cout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[3]~7\);

-- Location: LCCOMB_X97_Y20_N26
\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[4]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[4]~9_cout\ = CARRY((!\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[93]~1_combout\ & (!\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[93]~0_combout\ & 
-- !\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[3]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[93]~1_combout\,
	datab => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[93]~0_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[3]~7\,
	cout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[4]~9_cout\);

-- Location: LCCOMB_X97_Y20_N28
\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10_combout\ = \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[4]~9_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[4]~9_cout\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10_combout\);

-- Location: LCCOMB_X100_Y20_N18
\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[4]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[4]~4_combout\ = (\u_remote_rcv|data\(5) & ((GND) # (!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[3]~3\))) # (!\u_remote_rcv|data\(5) & 
-- (\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[3]~3\ $ (GND)))
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[4]~5\ = CARRY((\u_remote_rcv|data\(5)) # (!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[3]~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|data\(5),
	datad => VCC,
	cin => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[3]~3\,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[4]~4_combout\,
	cout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[4]~5\);

-- Location: LCCOMB_X100_Y20_N22
\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[6]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[6]~8_combout\ = (\u_remote_rcv|data\(7) & (\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[5]~7\ $ (GND))) # (!\u_remote_rcv|data\(7) & 
-- (!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[5]~7\ & VCC))
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[6]~9\ = CARRY((\u_remote_rcv|data\(7) & !\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[5]~7\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data\(7),
	datad => VCC,
	cin => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[5]~7\,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[6]~8_combout\,
	cout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[6]~9\);

-- Location: LCCOMB_X101_Y21_N26
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[3]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[3]~4_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[2]~3\ & (((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~68_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~45_combout\)))) # (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[2]~3\ & ((((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~68_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~45_combout\)))))
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[3]~5\ = CARRY((!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[2]~3\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~68_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~45_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~68_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~45_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[2]~3\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[3]~4_combout\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[3]~5\);

-- Location: LCCOMB_X100_Y21_N2
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[2]~2_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[1]~1\ & (((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~53_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~52_combout\)))) # (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[1]~1\ & (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~53_combout\ & 
-- (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~52_combout\)))
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[2]~3\ = CARRY((!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~53_combout\ & (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~52_combout\ & 
-- !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~53_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~52_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[1]~1\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[2]~2_combout\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[2]~3\);

-- Location: LCCOMB_X100_Y21_N4
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[3]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[3]~4_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[2]~3\ & (((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~51_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~69_combout\)))) # (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[2]~3\ & ((((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~51_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~69_combout\)))))
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[3]~5\ = CARRY((!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[2]~3\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~51_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~69_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~51_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~69_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[2]~3\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[3]~4_combout\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[3]~5\);

-- Location: LCCOMB_X99_Y21_N20
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[2]~2_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[1]~1\ & (((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~60_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~61_combout\)))) # (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[1]~1\ & (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~60_combout\ & 
-- (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~61_combout\)))
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[2]~3\ = CARRY((!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~60_combout\ & (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~61_combout\ & 
-- !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~60_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~61_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[1]~1\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[2]~2_combout\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[2]~3\);

-- Location: LCCOMB_X105_Y29_N12
\u_seg_led|cnt0[4]~21\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt0[4]~21_combout\ = (\u_seg_led|cnt0\(4) & (\u_seg_led|cnt0[3]~20\ $ (GND))) # (!\u_seg_led|cnt0\(4) & (!\u_seg_led|cnt0[3]~20\ & VCC))
-- \u_seg_led|cnt0[4]~22\ = CARRY((\u_seg_led|cnt0\(4) & !\u_seg_led|cnt0[3]~20\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt0\(4),
	datad => VCC,
	cin => \u_seg_led|cnt0[3]~20\,
	combout => \u_seg_led|cnt0[4]~21_combout\,
	cout => \u_seg_led|cnt0[4]~22\);

-- Location: LCCOMB_X105_Y29_N22
\u_seg_led|cnt0[9]~31\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt0[9]~31_combout\ = (\u_seg_led|cnt0\(9) & (!\u_seg_led|cnt0[8]~30\)) # (!\u_seg_led|cnt0\(9) & ((\u_seg_led|cnt0[8]~30\) # (GND)))
-- \u_seg_led|cnt0[9]~32\ = CARRY((!\u_seg_led|cnt0[8]~30\) # (!\u_seg_led|cnt0\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt0\(9),
	datad => VCC,
	cin => \u_seg_led|cnt0[8]~30\,
	combout => \u_seg_led|cnt0[9]~31_combout\,
	cout => \u_seg_led|cnt0[9]~32\);

-- Location: LCCOMB_X105_Y29_N26
\u_seg_led|cnt0[11]~35\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt0[11]~35_combout\ = (\u_seg_led|cnt0\(11) & (!\u_seg_led|cnt0[10]~34\)) # (!\u_seg_led|cnt0\(11) & ((\u_seg_led|cnt0[10]~34\) # (GND)))
-- \u_seg_led|cnt0[11]~36\ = CARRY((!\u_seg_led|cnt0[10]~34\) # (!\u_seg_led|cnt0\(11)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt0\(11),
	datad => VCC,
	cin => \u_seg_led|cnt0[10]~34\,
	combout => \u_seg_led|cnt0[11]~35_combout\,
	cout => \u_seg_led|cnt0[11]~36\);

-- Location: LCCOMB_X105_Y29_N28
\u_seg_led|cnt0[12]~37\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt0[12]~37_combout\ = \u_seg_led|cnt0[11]~36\ $ (!\u_seg_led|cnt0\(12))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \u_seg_led|cnt0\(12),
	cin => \u_seg_led|cnt0[11]~36\,
	combout => \u_seg_led|cnt0[12]~37_combout\);

-- Location: FF_X99_Y22_N13
\u_remote_rcv|data_cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_cnt[1]~10_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_remote_rcv|pos_remote_in~combout\,
	ena => \u_remote_rcv|data_cnt[5]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_cnt\(1));

-- Location: LCCOMB_X99_Y22_N12
\u_remote_rcv|data_cnt[1]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_cnt[1]~10_combout\ = (\u_remote_rcv|data_cnt\(1) & (!\u_remote_rcv|data_cnt[0]~9\)) # (!\u_remote_rcv|data_cnt\(1) & ((\u_remote_rcv|data_cnt[0]~9\) # (GND)))
-- \u_remote_rcv|data_cnt[1]~11\ = CARRY((!\u_remote_rcv|data_cnt[0]~9\) # (!\u_remote_rcv|data_cnt\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data_cnt\(1),
	datad => VCC,
	cin => \u_remote_rcv|data_cnt[0]~9\,
	combout => \u_remote_rcv|data_cnt[1]~10_combout\,
	cout => \u_remote_rcv|data_cnt[1]~11\);

-- Location: LCCOMB_X98_Y24_N2
\u_remote_rcv|Add0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Add0~0_combout\ = \u_remote_rcv|div_cnt\(0) $ (VCC)
-- \u_remote_rcv|Add0~1\ = CARRY(\u_remote_rcv|div_cnt\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|div_cnt\(0),
	datad => VCC,
	combout => \u_remote_rcv|Add0~0_combout\,
	cout => \u_remote_rcv|Add0~1\);

-- Location: LCCOMB_X98_Y24_N4
\u_remote_rcv|Add0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Add0~2_combout\ = (\u_remote_rcv|div_cnt\(1) & (!\u_remote_rcv|Add0~1\)) # (!\u_remote_rcv|div_cnt\(1) & ((\u_remote_rcv|Add0~1\) # (GND)))
-- \u_remote_rcv|Add0~3\ = CARRY((!\u_remote_rcv|Add0~1\) # (!\u_remote_rcv|div_cnt\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|div_cnt\(1),
	datad => VCC,
	cin => \u_remote_rcv|Add0~1\,
	combout => \u_remote_rcv|Add0~2_combout\,
	cout => \u_remote_rcv|Add0~3\);

-- Location: LCCOMB_X98_Y24_N6
\u_remote_rcv|Add0~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Add0~4_combout\ = (\u_remote_rcv|div_cnt\(2) & (\u_remote_rcv|Add0~3\ $ (GND))) # (!\u_remote_rcv|div_cnt\(2) & (!\u_remote_rcv|Add0~3\ & VCC))
-- \u_remote_rcv|Add0~5\ = CARRY((\u_remote_rcv|div_cnt\(2) & !\u_remote_rcv|Add0~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|div_cnt\(2),
	datad => VCC,
	cin => \u_remote_rcv|Add0~3\,
	combout => \u_remote_rcv|Add0~4_combout\,
	cout => \u_remote_rcv|Add0~5\);

-- Location: LCCOMB_X98_Y24_N8
\u_remote_rcv|Add0~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Add0~6_combout\ = (\u_remote_rcv|div_cnt\(3) & (!\u_remote_rcv|Add0~5\)) # (!\u_remote_rcv|div_cnt\(3) & ((\u_remote_rcv|Add0~5\) # (GND)))
-- \u_remote_rcv|Add0~7\ = CARRY((!\u_remote_rcv|Add0~5\) # (!\u_remote_rcv|div_cnt\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|div_cnt\(3),
	datad => VCC,
	cin => \u_remote_rcv|Add0~5\,
	combout => \u_remote_rcv|Add0~6_combout\,
	cout => \u_remote_rcv|Add0~7\);

-- Location: LCCOMB_X98_Y24_N10
\u_remote_rcv|Add0~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Add0~8_combout\ = (\u_remote_rcv|div_cnt\(4) & (\u_remote_rcv|Add0~7\ $ (GND))) # (!\u_remote_rcv|div_cnt\(4) & (!\u_remote_rcv|Add0~7\ & VCC))
-- \u_remote_rcv|Add0~9\ = CARRY((\u_remote_rcv|div_cnt\(4) & !\u_remote_rcv|Add0~7\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|div_cnt\(4),
	datad => VCC,
	cin => \u_remote_rcv|Add0~7\,
	combout => \u_remote_rcv|Add0~8_combout\,
	cout => \u_remote_rcv|Add0~9\);

-- Location: LCCOMB_X98_Y24_N12
\u_remote_rcv|Add0~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Add0~10_combout\ = (\u_remote_rcv|div_cnt\(5) & (!\u_remote_rcv|Add0~9\)) # (!\u_remote_rcv|div_cnt\(5) & ((\u_remote_rcv|Add0~9\) # (GND)))
-- \u_remote_rcv|Add0~11\ = CARRY((!\u_remote_rcv|Add0~9\) # (!\u_remote_rcv|div_cnt\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|div_cnt\(5),
	datad => VCC,
	cin => \u_remote_rcv|Add0~9\,
	combout => \u_remote_rcv|Add0~10_combout\,
	cout => \u_remote_rcv|Add0~11\);

-- Location: LCCOMB_X98_Y24_N14
\u_remote_rcv|Add0~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Add0~12_combout\ = (\u_remote_rcv|div_cnt\(6) & (\u_remote_rcv|Add0~11\ $ (GND))) # (!\u_remote_rcv|div_cnt\(6) & (!\u_remote_rcv|Add0~11\ & VCC))
-- \u_remote_rcv|Add0~13\ = CARRY((\u_remote_rcv|div_cnt\(6) & !\u_remote_rcv|Add0~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|div_cnt\(6),
	datad => VCC,
	cin => \u_remote_rcv|Add0~11\,
	combout => \u_remote_rcv|Add0~12_combout\,
	cout => \u_remote_rcv|Add0~13\);

-- Location: LCCOMB_X98_Y24_N16
\u_remote_rcv|Add0~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Add0~14_combout\ = (\u_remote_rcv|div_cnt\(7) & (!\u_remote_rcv|Add0~13\)) # (!\u_remote_rcv|div_cnt\(7) & ((\u_remote_rcv|Add0~13\) # (GND)))
-- \u_remote_rcv|Add0~15\ = CARRY((!\u_remote_rcv|Add0~13\) # (!\u_remote_rcv|div_cnt\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|div_cnt\(7),
	datad => VCC,
	cin => \u_remote_rcv|Add0~13\,
	combout => \u_remote_rcv|Add0~14_combout\,
	cout => \u_remote_rcv|Add0~15\);

-- Location: LCCOMB_X98_Y24_N18
\u_remote_rcv|Add0~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Add0~16_combout\ = (\u_remote_rcv|div_cnt\(8) & (\u_remote_rcv|Add0~15\ $ (GND))) # (!\u_remote_rcv|div_cnt\(8) & (!\u_remote_rcv|Add0~15\ & VCC))
-- \u_remote_rcv|Add0~17\ = CARRY((\u_remote_rcv|div_cnt\(8) & !\u_remote_rcv|Add0~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|div_cnt\(8),
	datad => VCC,
	cin => \u_remote_rcv|Add0~15\,
	combout => \u_remote_rcv|Add0~16_combout\,
	cout => \u_remote_rcv|Add0~17\);

-- Location: LCCOMB_X98_Y24_N20
\u_remote_rcv|Add0~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Add0~18_combout\ = (\u_remote_rcv|div_cnt\(9) & (!\u_remote_rcv|Add0~17\)) # (!\u_remote_rcv|div_cnt\(9) & ((\u_remote_rcv|Add0~17\) # (GND)))
-- \u_remote_rcv|Add0~19\ = CARRY((!\u_remote_rcv|Add0~17\) # (!\u_remote_rcv|div_cnt\(9)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|div_cnt\(9),
	datad => VCC,
	cin => \u_remote_rcv|Add0~17\,
	combout => \u_remote_rcv|Add0~18_combout\,
	cout => \u_remote_rcv|Add0~19\);

-- Location: LCCOMB_X98_Y24_N22
\u_remote_rcv|Add0~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Add0~20_combout\ = (\u_remote_rcv|div_cnt\(10) & (\u_remote_rcv|Add0~19\ $ (GND))) # (!\u_remote_rcv|div_cnt\(10) & (!\u_remote_rcv|Add0~19\ & VCC))
-- \u_remote_rcv|Add0~21\ = CARRY((\u_remote_rcv|div_cnt\(10) & !\u_remote_rcv|Add0~19\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|div_cnt\(10),
	datad => VCC,
	cin => \u_remote_rcv|Add0~19\,
	combout => \u_remote_rcv|Add0~20_combout\,
	cout => \u_remote_rcv|Add0~21\);

-- Location: LCCOMB_X98_Y24_N24
\u_remote_rcv|Add0~22\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Add0~22_combout\ = \u_remote_rcv|div_cnt\(11) $ (\u_remote_rcv|Add0~21\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|div_cnt\(11),
	cin => \u_remote_rcv|Add0~21\,
	combout => \u_remote_rcv|Add0~22_combout\);

-- Location: FF_X105_Y20_N11
\u_seg_led|num_disp[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|Mux1~1_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num_disp\(2));

-- Location: LCCOMB_X91_Y24_N30
\u_led_ctrl|Equal0~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|Equal0~5_combout\ = (!\u_led_ctrl|led_cnt\(14) & (!\u_led_ctrl|led_cnt\(9) & (!\u_led_ctrl|led_cnt\(15) & !\u_led_ctrl|led_cnt\(16))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(14),
	datab => \u_led_ctrl|led_cnt\(9),
	datac => \u_led_ctrl|led_cnt\(15),
	datad => \u_led_ctrl|led_cnt\(16),
	combout => \u_led_ctrl|Equal0~5_combout\);

-- Location: LCCOMB_X92_Y24_N22
\u_led_ctrl|Equal0~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|Equal0~6_combout\ = (!\u_led_ctrl|led_cnt\(17) & (!\u_led_ctrl|led_cnt\(18) & (!\u_led_ctrl|led_cnt\(19) & \u_led_ctrl|Equal0~5_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(17),
	datab => \u_led_ctrl|led_cnt\(18),
	datac => \u_led_ctrl|led_cnt\(19),
	datad => \u_led_ctrl|Equal0~5_combout\,
	combout => \u_led_ctrl|Equal0~6_combout\);

-- Location: LCCOMB_X92_Y24_N30
\u_led_ctrl|Equal0~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|Equal0~8_combout\ = (!\u_led_ctrl|led_cnt\(20) & (!\u_led_ctrl|led_cnt\(21) & !\u_led_ctrl|led_cnt\(22)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(20),
	datac => \u_led_ctrl|led_cnt\(21),
	datad => \u_led_ctrl|led_cnt\(22),
	combout => \u_led_ctrl|Equal0~8_combout\);

-- Location: FF_X98_Y20_N3
\u_seg_led|num[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[95]~8_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num\(4));

-- Location: FF_X99_Y21_N13
\u_seg_led|num[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|num[0]~feeder_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num\(0));

-- Location: FF_X103_Y20_N21
\u_seg_led|num[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|num~2_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num\(9));

-- Location: FF_X98_Y20_N21
\u_seg_led|num[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|num~3_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num\(5));

-- Location: FF_X97_Y20_N9
\u_seg_led|num[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[97]~11_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num\(6));

-- Location: FF_X99_Y21_N17
\u_seg_led|num[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[97]~63_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num\(2));

-- Location: LCCOMB_X105_Y20_N16
\u_seg_led|Mux1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mux1~0_combout\ = (\u_seg_led|cnt_sel\(0) & (\u_seg_led|num\(6))) # (!\u_seg_led|cnt_sel\(0) & ((\u_seg_led|num\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num\(6),
	datac => \u_seg_led|num\(2),
	datad => \u_seg_led|cnt_sel\(0),
	combout => \u_seg_led|Mux1~0_combout\);

-- Location: LCCOMB_X105_Y20_N10
\u_seg_led|Mux1~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mux1~1_combout\ = (!\u_seg_led|cnt_sel\(1) & (!\u_seg_led|cnt_sel\(2) & \u_seg_led|Mux1~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt_sel\(1),
	datac => \u_seg_led|cnt_sel\(2),
	datad => \u_seg_led|Mux1~0_combout\,
	combout => \u_seg_led|Mux1~1_combout\);

-- Location: FF_X98_Y20_N27
\u_seg_led|num[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|num~4_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num\(7));

-- Location: FF_X103_Y20_N13
\u_seg_led|num[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|WideOr3~combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num\(11));

-- Location: FF_X97_Y21_N9
\u_remote_rcv|data[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	asdata => \u_remote_rcv|data_temp\(7),
	clrn => \sys_rst_n~input_o\,
	sload => VCC,
	ena => \u_remote_rcv|data[7]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data\(7));

-- Location: LCCOMB_X97_Y21_N10
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[78]~36\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[78]~36_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & \u_remote_rcv|data\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datad => \u_remote_rcv|data\(7),
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[78]~36_combout\);

-- Location: LCCOMB_X97_Y21_N4
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[78]~37\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[78]~37_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[3]~4_combout\ & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[3]~4_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[78]~37_combout\);

-- Location: LCCOMB_X97_Y21_N8
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~38\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~38_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & \u_remote_rcv|data\(6))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datad => \u_remote_rcv|data\(6),
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~38_combout\);

-- Location: LCCOMB_X97_Y21_N2
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~39\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~39_combout\ = (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[2]~2_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[77]~39_combout\);

-- Location: LCCOMB_X97_Y21_N6
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~40\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~40_combout\ = (\u_remote_rcv|data\(5) & \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|data\(5),
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~40_combout\);

-- Location: LCCOMB_X96_Y21_N16
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~41\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~41_combout\ = (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[1]~0_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[76]~41_combout\);

-- Location: LCCOMB_X97_Y21_N0
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[75]~42\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[75]~42_combout\ = (\u_remote_rcv|data\(4) & \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data\(4),
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[75]~42_combout\);

-- Location: LCCOMB_X98_Y21_N24
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[75]~43\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[75]~43_combout\ = (\u_remote_rcv|data\(4) & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_remote_rcv|data\(4),
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[75]~43_combout\);

-- Location: LCCOMB_X98_Y21_N2
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[83]~44\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[83]~44_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[3]~4_combout\ & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[3]~4_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[83]~44_combout\);

-- Location: LCCOMB_X98_Y21_N26
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~45\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~45_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[2]~2_combout\ & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[2]~2_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~45_combout\);

-- Location: LCCOMB_X98_Y21_N16
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~46\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~46_combout\ = (\u_remote_rcv|data\(4) & \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|data\(4),
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~46_combout\);

-- Location: LCCOMB_X98_Y21_N22
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~47\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~47_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[1]~0_combout\ & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[1]~0_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[81]~47_combout\);

-- Location: LCCOMB_X98_Y21_N30
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[80]~48\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[80]~48_combout\ = (\u_remote_rcv|data\(3) & \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_remote_rcv|data\(3),
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[80]~48_combout\);

-- Location: LCCOMB_X98_Y21_N0
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[80]~49\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[80]~49_combout\ = (\u_remote_rcv|data\(3) & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_remote_rcv|data\(3),
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[80]~49_combout\);

-- Location: LCCOMB_X98_Y21_N28
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[88]~50\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[88]~50_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[3]~4_combout\ & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[3]~4_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[88]~50_combout\);

-- Location: LCCOMB_X98_Y21_N18
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~51\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~51_combout\ = (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ & \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[2]~2_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~51_combout\);

-- Location: LCCOMB_X99_Y20_N8
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~52\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~52_combout\ = (\u_remote_rcv|data\(3) & \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_remote_rcv|data\(3),
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~52_combout\);

-- Location: LCCOMB_X99_Y20_N26
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~53\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~53_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[1]~0_combout\ & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[1]~0_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[86]~53_combout\);

-- Location: LCCOMB_X99_Y20_N4
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[85]~54\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[85]~54_combout\ = (\u_remote_rcv|data\(2) & \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_remote_rcv|data\(2),
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[85]~54_combout\);

-- Location: LCCOMB_X99_Y20_N10
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[85]~55\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[85]~55_combout\ = (\u_remote_rcv|data\(2) & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_remote_rcv|data\(2),
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[85]~55_combout\);

-- Location: LCCOMB_X98_Y20_N0
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[93]~56\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[93]~56_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[3]~4_combout\ & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[3]~4_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[93]~56_combout\);

-- Location: LCCOMB_X99_Y20_N28
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[92]~57\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[92]~57_combout\ = (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ & \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[2]~2_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[92]~57_combout\);

-- Location: LCCOMB_X99_Y20_N30
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[91]~58\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[91]~58_combout\ = (\u_remote_rcv|data\(2) & \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|data\(2),
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[91]~58_combout\);

-- Location: LCCOMB_X99_Y20_N24
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[91]~59\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[91]~59_combout\ = (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ & \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[1]~0_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[91]~59_combout\);

-- Location: LCCOMB_X98_Y20_N24
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[90]~60\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[90]~60_combout\ = (\u_remote_rcv|data\(1) & \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_remote_rcv|data\(1),
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[90]~60_combout\);

-- Location: LCCOMB_X98_Y20_N6
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[90]~61\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[90]~61_combout\ = (\u_remote_rcv|data\(1) & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_remote_rcv|data\(1),
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[90]~61_combout\);

-- Location: LCCOMB_X97_Y20_N2
\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[93]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[93]~0_combout\ = (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[93]~0_combout\);

-- Location: LCCOMB_X96_Y20_N16
\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[93]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[93]~1_combout\ = (\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[3]~4_combout\ & !\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[3]~4_combout\,
	datad => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[93]~1_combout\);

-- Location: LCCOMB_X96_Y20_N14
\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~2_combout\ = (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ & \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~2_combout\);

-- Location: LCCOMB_X97_Y20_N4
\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~3_combout\ = (\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[2]~2_combout\ & !\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[2]~2_combout\,
	datad => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~3_combout\);

-- Location: LCCOMB_X98_Y20_N28
\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~4_combout\ = (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ & \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~4_combout\);

-- Location: LCCOMB_X97_Y20_N30
\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~5_combout\ = (\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[1]~0_combout\ & !\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[1]~0_combout\,
	datad => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~5_combout\);

-- Location: LCCOMB_X98_Y20_N30
\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~6_combout\ = (\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~6_combout\);

-- Location: LCCOMB_X97_Y20_N0
\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~7_combout\ = (!\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~7_combout\);

-- Location: LCCOMB_X98_Y20_N2
\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[95]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[95]~8_combout\ = (\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10_combout\ & (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\)) # 
-- (!\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10_combout\ & ((\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[0]~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\,
	datac => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[0]~0_combout\,
	datad => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10_combout\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[95]~8_combout\);

-- Location: FF_X99_Y21_N29
\u_remote_rcv|data[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data[0]~feeder_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_remote_rcv|data[7]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data\(0));

-- Location: LCCOMB_X100_Y20_N12
\u_seg_led|Div1|auto_generated|divider|divider|StageOut[150]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|StageOut[150]~0_combout\ = (\u_remote_rcv|data\(7) & \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data\(7),
	datac => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[150]~0_combout\);

-- Location: LCCOMB_X100_Y20_N8
\u_seg_led|Div1|auto_generated|divider|divider|StageOut[149]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|StageOut[149]~2_combout\ = (\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\ & \u_remote_rcv|data\(6))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\,
	datad => \u_remote_rcv|data\(6),
	combout => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[149]~2_combout\);

-- Location: LCCOMB_X100_Y20_N10
\u_seg_led|Div1|auto_generated|divider|divider|StageOut[148]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|StageOut[148]~5_combout\ = (!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\ & \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[4]~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\,
	datad => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[4]~4_combout\,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[148]~5_combout\);

-- Location: LCCOMB_X100_Y20_N0
\u_seg_led|Div1|auto_generated|divider|divider|StageOut[147]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|StageOut[147]~6_combout\ = (\u_remote_rcv|data\(4) & \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|data\(4),
	datac => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[147]~6_combout\);

-- Location: LCCOMB_X100_Y20_N2
\u_seg_led|Div1|auto_generated|divider|divider|StageOut[146]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|StageOut[146]~8_combout\ = (\u_remote_rcv|data\(3) & \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data\(3),
	datac => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[146]~8_combout\);

-- Location: LCCOMB_X101_Y20_N12
\u_seg_led|Div1|auto_generated|divider|divider|StageOut[145]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|StageOut[145]~10_combout\ = (\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\ & \u_remote_rcv|data\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\,
	datad => \u_remote_rcv|data\(2),
	combout => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[145]~10_combout\);

-- Location: LCCOMB_X103_Y20_N20
\u_seg_led|num~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|num~2_combout\ = (\u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[8]~12_combout\) # (!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\,
	datad => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[8]~12_combout\,
	combout => \u_seg_led|num~2_combout\);

-- Location: LCCOMB_X98_Y20_N4
\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[96]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[96]~9_combout\ = (\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10_combout\ & ((\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~6_combout\) # 
-- ((\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~7_combout\)))) # (!\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10_combout\ & 
-- (((\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[1]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~6_combout\,
	datab => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[1]~2_combout\,
	datac => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[90]~7_combout\,
	datad => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10_combout\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[96]~9_combout\);

-- Location: LCCOMB_X103_Y20_N12
\u_seg_led|WideOr3\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|WideOr3~combout\ = (\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\ & \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[8]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\,
	datad => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[8]~12_combout\,
	combout => \u_seg_led|WideOr3~combout\);

-- Location: LCCOMB_X97_Y20_N6
\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[98]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[98]~10_combout\ = (\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10_combout\ & ((\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~2_combout\) # 
-- ((\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~3_combout\)))) # (!\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10_combout\ & 
-- (((\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[3]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~2_combout\,
	datab => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[92]~3_combout\,
	datac => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10_combout\,
	datad => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[3]~6_combout\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[98]~10_combout\);

-- Location: LCCOMB_X97_Y20_N8
\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[97]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[97]~11_combout\ = (\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10_combout\ & ((\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~5_combout\) # 
-- ((\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~4_combout\)))) # (!\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10_combout\ & 
-- (((\u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[2]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~5_combout\,
	datab => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[91]~4_combout\,
	datac => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[2]~4_combout\,
	datad => \u_seg_led|Mod1|auto_generated|divider|divider|add_sub_19_result_int[5]~10_combout\,
	combout => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[97]~11_combout\);

-- Location: LCCOMB_X98_Y20_N20
\u_seg_led|num~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|num~3_combout\ = (\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[96]~9_combout\) # ((\u_seg_led|num~5_combout\ & (!\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[98]~10_combout\ & 
-- !\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[97]~11_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num~5_combout\,
	datab => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[96]~9_combout\,
	datac => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[98]~10_combout\,
	datad => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[97]~11_combout\,
	combout => \u_seg_led|num~3_combout\);

-- Location: LCCOMB_X102_Y21_N30
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[78]~36\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[78]~36_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & \u_remote_rcv|data\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datad => \u_remote_rcv|data\(7),
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[78]~36_combout\);

-- Location: LCCOMB_X101_Y21_N16
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~38\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~38_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & \u_remote_rcv|data\(6))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datad => \u_remote_rcv|data\(6),
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~38_combout\);

-- Location: LCCOMB_X102_Y21_N26
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~40\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~40_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & \u_remote_rcv|data\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datad => \u_remote_rcv|data\(5),
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~40_combout\);

-- Location: LCCOMB_X102_Y21_N12
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[75]~42\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[75]~42_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & \u_remote_rcv|data\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datad => \u_remote_rcv|data\(4),
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[75]~42_combout\);

-- Location: LCCOMB_X101_Y21_N10
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~47\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~47_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[1]~0_combout\ & !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[1]~0_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~47_combout\);

-- Location: LCCOMB_X101_Y21_N12
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[80]~48\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[80]~48_combout\ = (\u_remote_rcv|data\(3) & \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_remote_rcv|data\(3),
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[80]~48_combout\);

-- Location: LCCOMB_X101_Y21_N20
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[88]~50\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[88]~50_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[3]~4_combout\ & !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[3]~4_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[88]~50_combout\);

-- Location: LCCOMB_X100_Y21_N22
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~51\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~51_combout\ = (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ & \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[2]~2_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~51_combout\);

-- Location: LCCOMB_X100_Y21_N10
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~53\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~53_combout\ = (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ & \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[1]~0_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~53_combout\);

-- Location: LCCOMB_X100_Y21_N26
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[85]~55\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[85]~55_combout\ = (\u_remote_rcv|data\(2) & !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data\(2),
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[85]~55_combout\);

-- Location: LCCOMB_X99_Y21_N10
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[90]~56\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[90]~56_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ & \u_remote_rcv|data\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	datad => \u_remote_rcv|data\(1),
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[90]~56_combout\);

-- Location: LCCOMB_X100_Y21_N20
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[93]~58\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[93]~58_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[3]~4_combout\ & !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[3]~4_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[93]~58_combout\);

-- Location: LCCOMB_X100_Y21_N30
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~59\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~59_combout\ = (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ & \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[2]~2_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~59_combout\);

-- Location: LCCOMB_X99_Y21_N30
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~60\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~60_combout\ = (\u_remote_rcv|data\(2) & \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|data\(2),
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~60_combout\);

-- Location: LCCOMB_X99_Y21_N16
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[97]~63\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[97]~63_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~60_combout\) # 
-- ((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~61_combout\)))) # (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\ & 
-- (((\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~60_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~61_combout\,
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[2]~2_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[97]~63_combout\);

-- Location: LCCOMB_X98_Y20_N26
\u_seg_led|num~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|num~4_combout\ = (\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[98]~10_combout\) # ((\u_seg_led|num~5_combout\ & (!\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[96]~9_combout\ & 
-- !\u_seg_led|Mod1|auto_generated|divider|divider|StageOut[97]~11_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num~5_combout\,
	datab => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[96]~9_combout\,
	datac => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[98]~10_combout\,
	datad => \u_seg_led|Mod1|auto_generated|divider|divider|StageOut[97]~11_combout\,
	combout => \u_seg_led|num~4_combout\);

-- Location: FF_X99_Y24_N17
\u_remote_rcv|div_clk\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_remote_rcv|div_clk~feeder_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|div_clk~q\);

-- Location: FF_X97_Y22_N31
\u_remote_rcv|data_temp[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_temp~7_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_remote_rcv|data_temp[7]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(0));

-- Location: LCCOMB_X97_Y22_N14
\u_remote_rcv|data[7]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data[7]~1_combout\ = (\u_remote_rcv|data_temp\(11) & (!\u_remote_rcv|data_temp\(3) & (\u_remote_rcv|data_temp\(2) $ (\u_remote_rcv|data_temp\(10))))) # (!\u_remote_rcv|data_temp\(11) & (\u_remote_rcv|data_temp\(3) & 
-- (\u_remote_rcv|data_temp\(2) $ (\u_remote_rcv|data_temp\(10)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001001001001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data_temp\(11),
	datab => \u_remote_rcv|data_temp\(2),
	datac => \u_remote_rcv|data_temp\(3),
	datad => \u_remote_rcv|data_temp\(10),
	combout => \u_remote_rcv|data[7]~1_combout\);

-- Location: LCCOMB_X99_Y22_N30
\u_remote_rcv|Selector3~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector3~1_combout\ = (\u_remote_rcv|time_done~q\ & \u_remote_rcv|cur_state.st_start_judge~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|time_done~q\,
	datac => \u_remote_rcv|cur_state.st_start_judge~q\,
	combout => \u_remote_rcv|Selector3~1_combout\);

-- Location: FF_X97_Y24_N1
\u_remote_rcv|div_cnt[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_remote_rcv|div_cnt~0_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|div_cnt\(11));

-- Location: FF_X98_Y24_N29
\u_remote_rcv|div_cnt[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_remote_rcv|div_cnt~1_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|div_cnt\(10));

-- Location: FF_X98_Y24_N21
\u_remote_rcv|div_cnt[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_remote_rcv|Add0~18_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|div_cnt\(9));

-- Location: FF_X98_Y24_N19
\u_remote_rcv|div_cnt[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_remote_rcv|Add0~16_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|div_cnt\(8));

-- Location: LCCOMB_X97_Y24_N22
\u_remote_rcv|Equal0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Equal0~0_combout\ = (!\u_remote_rcv|div_cnt\(9) & (\u_remote_rcv|div_cnt\(11) & (!\u_remote_rcv|div_cnt\(8) & \u_remote_rcv|div_cnt\(10))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|div_cnt\(9),
	datab => \u_remote_rcv|div_cnt\(11),
	datac => \u_remote_rcv|div_cnt\(8),
	datad => \u_remote_rcv|div_cnt\(10),
	combout => \u_remote_rcv|Equal0~0_combout\);

-- Location: FF_X98_Y24_N27
\u_remote_rcv|div_cnt[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_remote_rcv|div_cnt~2_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|div_cnt\(5));

-- Location: FF_X98_Y24_N1
\u_remote_rcv|div_cnt[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_remote_rcv|div_cnt~3_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|div_cnt\(4));

-- Location: FF_X98_Y24_N17
\u_remote_rcv|div_cnt[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_remote_rcv|Add0~14_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|div_cnt\(7));

-- Location: FF_X98_Y24_N15
\u_remote_rcv|div_cnt[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_remote_rcv|Add0~12_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|div_cnt\(6));

-- Location: LCCOMB_X97_Y24_N8
\u_remote_rcv|Equal0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Equal0~1_combout\ = (!\u_remote_rcv|div_cnt\(7) & (!\u_remote_rcv|div_cnt\(6) & (\u_remote_rcv|div_cnt\(4) & \u_remote_rcv|div_cnt\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|div_cnt\(7),
	datab => \u_remote_rcv|div_cnt\(6),
	datac => \u_remote_rcv|div_cnt\(4),
	datad => \u_remote_rcv|div_cnt\(5),
	combout => \u_remote_rcv|Equal0~1_combout\);

-- Location: FF_X99_Y24_N7
\u_remote_rcv|div_cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_remote_rcv|div_cnt~4_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|div_cnt\(2));

-- Location: FF_X98_Y24_N9
\u_remote_rcv|div_cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_remote_rcv|Add0~6_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|div_cnt\(3));

-- Location: FF_X98_Y24_N5
\u_remote_rcv|div_cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_remote_rcv|Add0~2_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|div_cnt\(1));

-- Location: FF_X98_Y24_N31
\u_remote_rcv|div_cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_remote_rcv|div_cnt~5_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|div_cnt\(0));

-- Location: LCCOMB_X99_Y24_N22
\u_remote_rcv|Equal0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Equal0~2_combout\ = (\u_remote_rcv|div_cnt\(2) & (!\u_remote_rcv|div_cnt\(1) & (!\u_remote_rcv|div_cnt\(0) & !\u_remote_rcv|div_cnt\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|div_cnt\(2),
	datab => \u_remote_rcv|div_cnt\(1),
	datac => \u_remote_rcv|div_cnt\(0),
	datad => \u_remote_rcv|div_cnt\(3),
	combout => \u_remote_rcv|Equal0~2_combout\);

-- Location: LCCOMB_X99_Y24_N0
\u_remote_rcv|div_clk~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|div_clk~0_combout\ = \u_remote_rcv|div_clk~q\ $ (((\u_remote_rcv|Equal0~2_combout\ & (\u_remote_rcv|Equal0~0_combout\ & \u_remote_rcv|Equal0~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|Equal0~2_combout\,
	datab => \u_remote_rcv|div_clk~q\,
	datac => \u_remote_rcv|Equal0~0_combout\,
	datad => \u_remote_rcv|Equal0~1_combout\,
	combout => \u_remote_rcv|div_clk~0_combout\);

-- Location: LCCOMB_X96_Y22_N8
\u_remote_rcv|always5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|always5~0_combout\ = (\u_remote_rcv|time_cnt\(4)) # (!\u_remote_rcv|time_cnt\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_remote_rcv|time_cnt\(3),
	datad => \u_remote_rcv|time_cnt\(4),
	combout => \u_remote_rcv|always5~0_combout\);

-- Location: LCCOMB_X97_Y22_N30
\u_remote_rcv|data_temp~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp~7_combout\ = (\u_remote_rcv|data_temp\(1) & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|remote_in_d1~q\,
	datac => \u_remote_rcv|remote_in_d0~q\,
	datad => \u_remote_rcv|data_temp\(1),
	combout => \u_remote_rcv|data_temp~7_combout\);

-- Location: LCCOMB_X98_Y22_N6
\u_remote_rcv|always5~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|always5~3_combout\ = (\u_remote_rcv|always5~0_combout\) # (((!\u_remote_rcv|time_cnt\(2) & !\u_remote_rcv|time_cnt\(1))) # (!\u_remote_rcv|always5~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101110111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|always5~0_combout\,
	datab => \u_remote_rcv|always5~1_combout\,
	datac => \u_remote_rcv|time_cnt\(2),
	datad => \u_remote_rcv|time_cnt\(1),
	combout => \u_remote_rcv|always5~3_combout\);

-- Location: LCCOMB_X95_Y22_N16
\u_remote_rcv|always5~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|always5~10_combout\ = (!\u_remote_rcv|time_cnt\(5) & (\u_remote_rcv|time_cnt\(6) & (!\u_remote_rcv|time_cnt\(7) & !\u_remote_rcv|time_cnt\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|time_cnt\(5),
	datab => \u_remote_rcv|time_cnt\(6),
	datac => \u_remote_rcv|time_cnt\(7),
	datad => \u_remote_rcv|time_cnt\(4),
	combout => \u_remote_rcv|always5~10_combout\);

-- Location: LCCOMB_X97_Y24_N0
\u_remote_rcv|div_cnt~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|div_cnt~0_combout\ = (\u_remote_rcv|Add0~22_combout\ & (((!\u_remote_rcv|Equal0~2_combout\) # (!\u_remote_rcv|Equal0~1_combout\)) # (!\u_remote_rcv|Equal0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|Equal0~0_combout\,
	datab => \u_remote_rcv|Equal0~1_combout\,
	datac => \u_remote_rcv|Equal0~2_combout\,
	datad => \u_remote_rcv|Add0~22_combout\,
	combout => \u_remote_rcv|div_cnt~0_combout\);

-- Location: LCCOMB_X98_Y24_N28
\u_remote_rcv|div_cnt~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|div_cnt~1_combout\ = (\u_remote_rcv|Add0~20_combout\ & (((!\u_remote_rcv|Equal0~2_combout\) # (!\u_remote_rcv|Equal0~0_combout\)) # (!\u_remote_rcv|Equal0~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|Equal0~1_combout\,
	datab => \u_remote_rcv|Equal0~0_combout\,
	datac => \u_remote_rcv|Add0~20_combout\,
	datad => \u_remote_rcv|Equal0~2_combout\,
	combout => \u_remote_rcv|div_cnt~1_combout\);

-- Location: LCCOMB_X98_Y24_N26
\u_remote_rcv|div_cnt~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|div_cnt~2_combout\ = (\u_remote_rcv|Add0~10_combout\ & (((!\u_remote_rcv|Equal0~2_combout\) # (!\u_remote_rcv|Equal0~0_combout\)) # (!\u_remote_rcv|Equal0~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|Equal0~1_combout\,
	datab => \u_remote_rcv|Equal0~0_combout\,
	datac => \u_remote_rcv|Equal0~2_combout\,
	datad => \u_remote_rcv|Add0~10_combout\,
	combout => \u_remote_rcv|div_cnt~2_combout\);

-- Location: LCCOMB_X98_Y24_N0
\u_remote_rcv|div_cnt~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|div_cnt~3_combout\ = (\u_remote_rcv|Add0~8_combout\ & (((!\u_remote_rcv|Equal0~2_combout\) # (!\u_remote_rcv|Equal0~0_combout\)) # (!\u_remote_rcv|Equal0~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|Equal0~1_combout\,
	datab => \u_remote_rcv|Equal0~0_combout\,
	datac => \u_remote_rcv|Equal0~2_combout\,
	datad => \u_remote_rcv|Add0~8_combout\,
	combout => \u_remote_rcv|div_cnt~3_combout\);

-- Location: LCCOMB_X99_Y24_N6
\u_remote_rcv|div_cnt~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|div_cnt~4_combout\ = (\u_remote_rcv|Add0~4_combout\ & (((!\u_remote_rcv|Equal0~1_combout\) # (!\u_remote_rcv|Equal0~0_combout\)) # (!\u_remote_rcv|Equal0~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|Equal0~2_combout\,
	datab => \u_remote_rcv|Equal0~0_combout\,
	datac => \u_remote_rcv|Add0~4_combout\,
	datad => \u_remote_rcv|Equal0~1_combout\,
	combout => \u_remote_rcv|div_cnt~4_combout\);

-- Location: LCCOMB_X98_Y24_N30
\u_remote_rcv|div_cnt~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|div_cnt~5_combout\ = (\u_remote_rcv|Add0~0_combout\ & (((!\u_remote_rcv|Equal0~0_combout\) # (!\u_remote_rcv|Equal0~2_combout\)) # (!\u_remote_rcv|Equal0~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|Equal0~1_combout\,
	datab => \u_remote_rcv|Add0~0_combout\,
	datac => \u_remote_rcv|Equal0~2_combout\,
	datad => \u_remote_rcv|Equal0~0_combout\,
	combout => \u_remote_rcv|div_cnt~5_combout\);

-- Location: LCCOMB_X99_Y20_N12
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[88]~62\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[88]~62_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ & ((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~65_combout\) # 
-- ((\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[2]~2_combout\ & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[2]~2_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	datac => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~65_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[88]~62_combout\);

-- Location: LCCOMB_X99_Y20_N2
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[93]~63\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[93]~63_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ & ((\u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~66_combout\) # 
-- ((\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[2]~2_combout\ & !\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[2]~2_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~66_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[93]~63_combout\);

-- Location: LCCOMB_X98_Y20_N22
\u_seg_led|num~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|num~5_combout\ = (\u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[8]~12_combout\ & (\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\ & 
-- \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[8]~12_combout\,
	datac => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\,
	combout => \u_seg_led|num~5_combout\);

-- Location: LCCOMB_X98_Y21_N20
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[83]~64\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[83]~64_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ & ((\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & 
-- ((\u_remote_rcv|data\(6)))) # (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[2]~2_combout\,
	datab => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datac => \u_remote_rcv|data\(6),
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[83]~64_combout\);

-- Location: LCCOMB_X98_Y21_N14
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~65\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~65_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ & ((\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & 
-- (\u_remote_rcv|data\(5))) # (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & ((\u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data\(5),
	datab => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_15_result_int[1]~0_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[82]~65_combout\);

-- Location: LCCOMB_X99_Y20_N0
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~66\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~66_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ & ((\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ & 
-- (\u_remote_rcv|data\(4))) # (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ & ((\u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data\(4),
	datab => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_16_result_int[1]~0_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[87]~66_combout\);

-- Location: LCCOMB_X99_Y20_N6
\u_seg_led|Div0|auto_generated|divider|divider|StageOut[92]~67\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div0|auto_generated|divider|divider|StageOut[92]~67_combout\ = (\u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ & ((\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ & 
-- (\u_remote_rcv|data\(3))) # (!\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ & ((\u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data\(3),
	datab => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[1]~0_combout\,
	datac => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	datad => \u_seg_led|Div0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	combout => \u_seg_led|Div0|auto_generated|divider|divider|StageOut[92]~67_combout\);

-- Location: LCCOMB_X101_Y21_N14
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[83]~67\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[83]~67_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & 
-- ((\u_remote_rcv|data\(6)))) # (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[2]~2_combout\,
	datab => \u_remote_rcv|data\(6),
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[83]~67_combout\);

-- Location: CLKCTRL_G9
\u_remote_rcv|div_clk~clkctrl\ : cycloneive_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \u_remote_rcv|div_clk~clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \u_remote_rcv|div_clk~clkctrl_outclk\);

-- Location: LCCOMB_X99_Y21_N12
\u_seg_led|num[0]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|num[0]~feeder_combout\ = \u_remote_rcv|data\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_remote_rcv|data\(0),
	combout => \u_seg_led|num[0]~feeder_combout\);

-- Location: LCCOMB_X99_Y21_N28
\u_remote_rcv|data[0]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data[0]~feeder_combout\ = \u_remote_rcv|data_temp\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_remote_rcv|data_temp\(0),
	combout => \u_remote_rcv|data[0]~feeder_combout\);

-- Location: LCCOMB_X99_Y24_N16
\u_remote_rcv|div_clk~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|div_clk~feeder_combout\ = \u_remote_rcv|div_clk~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|div_clk~0_combout\,
	combout => \u_remote_rcv|div_clk~feeder_combout\);

-- Location: IOOBUF_X115_Y20_N2
\sel[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_seg_led|ALT_INV_seg_sel\(0),
	devoe => ww_devoe,
	o => \sel[0]~output_o\);

-- Location: IOOBUF_X115_Y20_N9
\sel[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_seg_led|ALT_INV_seg_sel\(1),
	devoe => ww_devoe,
	o => \sel[1]~output_o\);

-- Location: IOOBUF_X115_Y22_N16
\sel[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_seg_led|ALT_INV_seg_sel\(2),
	devoe => ww_devoe,
	o => \sel[2]~output_o\);

-- Location: IOOBUF_X115_Y19_N2
\sel[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_seg_led|ALT_INV_seg_sel\(3),
	devoe => ww_devoe,
	o => \sel[3]~output_o\);

-- Location: IOOBUF_X115_Y19_N9
\sel[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_seg_led|ALT_INV_seg_sel\(4),
	devoe => ww_devoe,
	o => \sel[4]~output_o\);

-- Location: IOOBUF_X115_Y21_N16
\sel[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_seg_led|ALT_INV_seg_sel\(5),
	devoe => ww_devoe,
	o => \sel[5]~output_o\);

-- Location: IOOBUF_X115_Y25_N16
\seg_led[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_seg_led|seg_led\(0),
	devoe => ww_devoe,
	o => \seg_led[0]~output_o\);

-- Location: IOOBUF_X115_Y29_N2
\seg_led[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_seg_led|seg_led\(1),
	devoe => ww_devoe,
	o => \seg_led[1]~output_o\);

-- Location: IOOBUF_X100_Y0_N2
\seg_led[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_seg_led|seg_led\(2),
	devoe => ww_devoe,
	o => \seg_led[2]~output_o\);

-- Location: IOOBUF_X111_Y0_N2
\seg_led[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_seg_led|seg_led\(3),
	devoe => ww_devoe,
	o => \seg_led[3]~output_o\);

-- Location: IOOBUF_X105_Y0_N23
\seg_led[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_seg_led|seg_led\(4),
	devoe => ww_devoe,
	o => \seg_led[4]~output_o\);

-- Location: IOOBUF_X105_Y0_N9
\seg_led[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_seg_led|seg_led\(5),
	devoe => ww_devoe,
	o => \seg_led[5]~output_o\);

-- Location: IOOBUF_X105_Y0_N2
\seg_led[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_seg_led|ALT_INV_seg_led\(6),
	devoe => ww_devoe,
	o => \seg_led[6]~output_o\);

-- Location: IOOBUF_X1_Y73_N2
\seg_led[7]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \seg_led[7]~output_o\);

-- Location: IOOBUF_X69_Y73_N16
\led~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \u_led_ctrl|led~q\,
	devoe => ww_devoe,
	o => \led~output_o\);

-- Location: LCCOMB_X114_Y33_N24
\u_seg_led|clk_cnt[3]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|clk_cnt[3]~1_combout\ = \u_seg_led|clk_cnt\(3) $ (((\u_seg_led|clk_cnt\(1) & (\u_seg_led|clk_cnt\(2) & \u_seg_led|clk_cnt\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|clk_cnt\(1),
	datab => \u_seg_led|clk_cnt\(2),
	datac => \u_seg_led|clk_cnt\(3),
	datad => \u_seg_led|clk_cnt\(0),
	combout => \u_seg_led|clk_cnt[3]~1_combout\);

-- Location: IOIBUF_X115_Y14_N8
\sys_rst_n~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sys_rst_n,
	o => \sys_rst_n~input_o\);

-- Location: FF_X114_Y33_N25
\u_seg_led|clk_cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_seg_led|clk_cnt[3]~1_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|clk_cnt\(3));

-- Location: LCCOMB_X114_Y33_N22
\u_seg_led|clk_cnt~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|clk_cnt~0_combout\ = (\u_seg_led|clk_cnt\(1) & ((\u_seg_led|clk_cnt\(2) $ (\u_seg_led|clk_cnt\(0))))) # (!\u_seg_led|clk_cnt\(1) & (\u_seg_led|clk_cnt\(2) & ((\u_seg_led|clk_cnt\(3)) # (\u_seg_led|clk_cnt\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101011100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|clk_cnt\(1),
	datab => \u_seg_led|clk_cnt\(3),
	datac => \u_seg_led|clk_cnt\(2),
	datad => \u_seg_led|clk_cnt\(0),
	combout => \u_seg_led|clk_cnt~0_combout\);

-- Location: FF_X114_Y33_N23
\u_seg_led|clk_cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_seg_led|clk_cnt~0_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|clk_cnt\(2));

-- Location: LCCOMB_X114_Y33_N30
\u_seg_led|clk_cnt~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|clk_cnt~3_combout\ = (!\u_seg_led|clk_cnt\(0) & ((\u_seg_led|clk_cnt\(1)) # ((\u_seg_led|clk_cnt\(3)) # (!\u_seg_led|clk_cnt\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|clk_cnt\(1),
	datab => \u_seg_led|clk_cnt\(2),
	datac => \u_seg_led|clk_cnt\(0),
	datad => \u_seg_led|clk_cnt\(3),
	combout => \u_seg_led|clk_cnt~3_combout\);

-- Location: FF_X114_Y33_N31
\u_seg_led|clk_cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_seg_led|clk_cnt~3_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|clk_cnt\(0));

-- Location: LCCOMB_X114_Y33_N14
\u_seg_led|clk_cnt[1]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|clk_cnt[1]~2_combout\ = \u_seg_led|clk_cnt\(1) $ (\u_seg_led|clk_cnt\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|clk_cnt\(1),
	datad => \u_seg_led|clk_cnt\(0),
	combout => \u_seg_led|clk_cnt[1]~2_combout\);

-- Location: FF_X114_Y33_N15
\u_seg_led|clk_cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_seg_led|clk_cnt[1]~2_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|clk_cnt\(1));

-- Location: LCCOMB_X114_Y33_N18
\u_seg_led|Equal0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Equal0~0_combout\ = (\u_seg_led|clk_cnt\(2) & (!\u_seg_led|clk_cnt\(1) & (!\u_seg_led|clk_cnt\(0) & !\u_seg_led|clk_cnt\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|clk_cnt\(2),
	datab => \u_seg_led|clk_cnt\(1),
	datac => \u_seg_led|clk_cnt\(0),
	datad => \u_seg_led|clk_cnt\(3),
	combout => \u_seg_led|Equal0~0_combout\);

-- Location: LCCOMB_X114_Y33_N20
\u_seg_led|dri_clk~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|dri_clk~0_combout\ = \u_seg_led|dri_clk~q\ $ (\u_seg_led|Equal0~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|dri_clk~q\,
	datad => \u_seg_led|Equal0~0_combout\,
	combout => \u_seg_led|dri_clk~0_combout\);

-- Location: LCCOMB_X114_Y33_N10
\u_seg_led|dri_clk~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|dri_clk~feeder_combout\ = \u_seg_led|dri_clk~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|dri_clk~0_combout\,
	combout => \u_seg_led|dri_clk~feeder_combout\);

-- Location: FF_X114_Y33_N11
\u_seg_led|dri_clk\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_seg_led|dri_clk~feeder_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|dri_clk~q\);

-- Location: CLKCTRL_G6
\u_seg_led|dri_clk~clkctrl\ : cycloneive_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \u_seg_led|dri_clk~clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \u_seg_led|dri_clk~clkctrl_outclk\);

-- Location: LCCOMB_X103_Y20_N28
\u_seg_led|cnt_sel~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt_sel~0_combout\ = (!\u_seg_led|cnt_sel\(0) & ((!\u_seg_led|cnt_sel\(2)) # (!\u_seg_led|cnt_sel\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|cnt_sel\(1),
	datac => \u_seg_led|cnt_sel\(0),
	datad => \u_seg_led|cnt_sel\(2),
	combout => \u_seg_led|cnt_sel~0_combout\);

-- Location: LCCOMB_X105_Y29_N4
\u_seg_led|cnt0[0]~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt0[0]~13_combout\ = \u_seg_led|cnt0\(0) $ (VCC)
-- \u_seg_led|cnt0[0]~14\ = CARRY(\u_seg_led|cnt0\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt0\(0),
	datad => VCC,
	combout => \u_seg_led|cnt0[0]~13_combout\,
	cout => \u_seg_led|cnt0[0]~14\);

-- Location: LCCOMB_X105_Y29_N6
\u_seg_led|cnt0[1]~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt0[1]~15_combout\ = (\u_seg_led|cnt0\(1) & (!\u_seg_led|cnt0[0]~14\)) # (!\u_seg_led|cnt0\(1) & ((\u_seg_led|cnt0[0]~14\) # (GND)))
-- \u_seg_led|cnt0[1]~16\ = CARRY((!\u_seg_led|cnt0[0]~14\) # (!\u_seg_led|cnt0\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|cnt0\(1),
	datad => VCC,
	cin => \u_seg_led|cnt0[0]~14\,
	combout => \u_seg_led|cnt0[1]~15_combout\,
	cout => \u_seg_led|cnt0[1]~16\);

-- Location: FF_X105_Y29_N7
\u_seg_led|cnt0[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt0[1]~15_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_seg_led|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt0\(1));

-- Location: LCCOMB_X105_Y29_N8
\u_seg_led|cnt0[2]~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt0[2]~17_combout\ = (\u_seg_led|cnt0\(2) & (\u_seg_led|cnt0[1]~16\ $ (GND))) # (!\u_seg_led|cnt0\(2) & (!\u_seg_led|cnt0[1]~16\ & VCC))
-- \u_seg_led|cnt0[2]~18\ = CARRY((\u_seg_led|cnt0\(2) & !\u_seg_led|cnt0[1]~16\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt0\(2),
	datad => VCC,
	cin => \u_seg_led|cnt0[1]~16\,
	combout => \u_seg_led|cnt0[2]~17_combout\,
	cout => \u_seg_led|cnt0[2]~18\);

-- Location: LCCOMB_X105_Y29_N10
\u_seg_led|cnt0[3]~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt0[3]~19_combout\ = (\u_seg_led|cnt0\(3) & (!\u_seg_led|cnt0[2]~18\)) # (!\u_seg_led|cnt0\(3) & ((\u_seg_led|cnt0[2]~18\) # (GND)))
-- \u_seg_led|cnt0[3]~20\ = CARRY((!\u_seg_led|cnt0[2]~18\) # (!\u_seg_led|cnt0\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|cnt0\(3),
	datad => VCC,
	cin => \u_seg_led|cnt0[2]~18\,
	combout => \u_seg_led|cnt0[3]~19_combout\,
	cout => \u_seg_led|cnt0[3]~20\);

-- Location: FF_X105_Y29_N11
\u_seg_led|cnt0[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt0[3]~19_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_seg_led|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt0\(3));

-- Location: LCCOMB_X105_Y29_N14
\u_seg_led|cnt0[5]~23\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt0[5]~23_combout\ = (\u_seg_led|cnt0\(5) & (!\u_seg_led|cnt0[4]~22\)) # (!\u_seg_led|cnt0\(5) & ((\u_seg_led|cnt0[4]~22\) # (GND)))
-- \u_seg_led|cnt0[5]~24\ = CARRY((!\u_seg_led|cnt0[4]~22\) # (!\u_seg_led|cnt0\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|cnt0\(5),
	datad => VCC,
	cin => \u_seg_led|cnt0[4]~22\,
	combout => \u_seg_led|cnt0[5]~23_combout\,
	cout => \u_seg_led|cnt0[5]~24\);

-- Location: FF_X105_Y29_N15
\u_seg_led|cnt0[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt0[5]~23_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_seg_led|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt0\(5));

-- Location: LCCOMB_X105_Y29_N16
\u_seg_led|cnt0[6]~25\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt0[6]~25_combout\ = (\u_seg_led|cnt0\(6) & (\u_seg_led|cnt0[5]~24\ $ (GND))) # (!\u_seg_led|cnt0\(6) & (!\u_seg_led|cnt0[5]~24\ & VCC))
-- \u_seg_led|cnt0[6]~26\ = CARRY((\u_seg_led|cnt0\(6) & !\u_seg_led|cnt0[5]~24\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|cnt0\(6),
	datad => VCC,
	cin => \u_seg_led|cnt0[5]~24\,
	combout => \u_seg_led|cnt0[6]~25_combout\,
	cout => \u_seg_led|cnt0[6]~26\);

-- Location: FF_X105_Y29_N17
\u_seg_led|cnt0[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt0[6]~25_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_seg_led|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt0\(6));

-- Location: LCCOMB_X105_Y29_N18
\u_seg_led|cnt0[7]~27\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt0[7]~27_combout\ = (\u_seg_led|cnt0\(7) & (!\u_seg_led|cnt0[6]~26\)) # (!\u_seg_led|cnt0\(7) & ((\u_seg_led|cnt0[6]~26\) # (GND)))
-- \u_seg_led|cnt0[7]~28\ = CARRY((!\u_seg_led|cnt0[6]~26\) # (!\u_seg_led|cnt0\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|cnt0\(7),
	datad => VCC,
	cin => \u_seg_led|cnt0[6]~26\,
	combout => \u_seg_led|cnt0[7]~27_combout\,
	cout => \u_seg_led|cnt0[7]~28\);

-- Location: FF_X105_Y29_N19
\u_seg_led|cnt0[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt0[7]~27_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_seg_led|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt0\(7));

-- Location: LCCOMB_X105_Y29_N20
\u_seg_led|cnt0[8]~29\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt0[8]~29_combout\ = (\u_seg_led|cnt0\(8) & (\u_seg_led|cnt0[7]~28\ $ (GND))) # (!\u_seg_led|cnt0\(8) & (!\u_seg_led|cnt0[7]~28\ & VCC))
-- \u_seg_led|cnt0[8]~30\ = CARRY((\u_seg_led|cnt0\(8) & !\u_seg_led|cnt0[7]~28\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|cnt0\(8),
	datad => VCC,
	cin => \u_seg_led|cnt0[7]~28\,
	combout => \u_seg_led|cnt0[8]~29_combout\,
	cout => \u_seg_led|cnt0[8]~30\);

-- Location: FF_X105_Y29_N21
\u_seg_led|cnt0[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt0[8]~29_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_seg_led|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt0\(8));

-- Location: LCCOMB_X105_Y29_N24
\u_seg_led|cnt0[10]~33\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt0[10]~33_combout\ = (\u_seg_led|cnt0\(10) & (\u_seg_led|cnt0[9]~32\ $ (GND))) # (!\u_seg_led|cnt0\(10) & (!\u_seg_led|cnt0[9]~32\ & VCC))
-- \u_seg_led|cnt0[10]~34\ = CARRY((\u_seg_led|cnt0\(10) & !\u_seg_led|cnt0[9]~32\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|cnt0\(10),
	datad => VCC,
	cin => \u_seg_led|cnt0[9]~32\,
	combout => \u_seg_led|cnt0[10]~33_combout\,
	cout => \u_seg_led|cnt0[10]~34\);

-- Location: FF_X105_Y29_N25
\u_seg_led|cnt0[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt0[10]~33_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_seg_led|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt0\(10));

-- Location: FF_X105_Y29_N27
\u_seg_led|cnt0[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt0[11]~35_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_seg_led|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt0\(11));

-- Location: FF_X105_Y29_N9
\u_seg_led|cnt0[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt0[2]~17_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_seg_led|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt0\(2));

-- Location: FF_X105_Y29_N5
\u_seg_led|cnt0[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt0[0]~13_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_seg_led|LessThan0~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt0\(0));

-- Location: LCCOMB_X105_Y29_N2
\u_seg_led|LessThan0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|LessThan0~0_combout\ = (!\u_seg_led|cnt0\(3) & (((!\u_seg_led|cnt0\(1)) # (!\u_seg_led|cnt0\(0))) # (!\u_seg_led|cnt0\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001010101010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt0\(3),
	datab => \u_seg_led|cnt0\(2),
	datac => \u_seg_led|cnt0\(0),
	datad => \u_seg_led|cnt0\(1),
	combout => \u_seg_led|LessThan0~0_combout\);

-- Location: LCCOMB_X105_Y29_N30
\u_seg_led|LessThan0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|LessThan0~1_combout\ = (!\u_seg_led|cnt0\(4) & (!\u_seg_led|cnt0\(6) & (!\u_seg_led|cnt0\(5) & \u_seg_led|LessThan0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt0\(4),
	datab => \u_seg_led|cnt0\(6),
	datac => \u_seg_led|cnt0\(5),
	datad => \u_seg_led|LessThan0~0_combout\,
	combout => \u_seg_led|LessThan0~1_combout\);

-- Location: LCCOMB_X106_Y29_N4
\u_seg_led|LessThan0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|LessThan0~2_combout\ = (\u_seg_led|cnt0\(9) & (\u_seg_led|cnt0\(7) & (\u_seg_led|cnt0\(8) & !\u_seg_led|LessThan0~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt0\(9),
	datab => \u_seg_led|cnt0\(7),
	datac => \u_seg_led|cnt0\(8),
	datad => \u_seg_led|LessThan0~1_combout\,
	combout => \u_seg_led|LessThan0~2_combout\);

-- Location: LCCOMB_X105_Y29_N0
\u_seg_led|LessThan0~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|LessThan0~3_combout\ = (\u_seg_led|cnt0\(12) & ((\u_seg_led|cnt0\(10)) # ((\u_seg_led|cnt0\(11)) # (\u_seg_led|LessThan0~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt0\(12),
	datab => \u_seg_led|cnt0\(10),
	datac => \u_seg_led|cnt0\(11),
	datad => \u_seg_led|LessThan0~2_combout\,
	combout => \u_seg_led|LessThan0~3_combout\);

-- Location: FF_X105_Y29_N1
\u_seg_led|flag\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|LessThan0~3_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|flag~q\);

-- Location: FF_X103_Y20_N29
\u_seg_led|cnt_sel[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt_sel~0_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_seg_led|flag~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt_sel\(0));

-- Location: LCCOMB_X103_Y20_N4
\u_seg_led|cnt_sel~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt_sel~2_combout\ = (!\u_seg_led|cnt_sel\(2) & (\u_seg_led|cnt_sel\(1) $ (\u_seg_led|cnt_sel\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|cnt_sel\(2),
	datac => \u_seg_led|cnt_sel\(1),
	datad => \u_seg_led|cnt_sel\(0),
	combout => \u_seg_led|cnt_sel~2_combout\);

-- Location: FF_X103_Y20_N5
\u_seg_led|cnt_sel[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt_sel~2_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_seg_led|flag~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt_sel\(1));

-- Location: LCCOMB_X103_Y20_N2
\u_seg_led|cnt_sel~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|cnt_sel~1_combout\ = (\u_seg_led|cnt_sel\(1) & (!\u_seg_led|cnt_sel\(2) & \u_seg_led|cnt_sel\(0))) # (!\u_seg_led|cnt_sel\(1) & (\u_seg_led|cnt_sel\(2) & !\u_seg_led|cnt_sel\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|cnt_sel\(1),
	datac => \u_seg_led|cnt_sel\(2),
	datad => \u_seg_led|cnt_sel\(0),
	combout => \u_seg_led|cnt_sel~1_combout\);

-- Location: FF_X103_Y20_N3
\u_seg_led|cnt_sel[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|cnt_sel~1_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_seg_led|flag~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|cnt_sel\(2));

-- Location: LCCOMB_X105_Y20_N24
\u_seg_led|Decoder0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Decoder0~0_combout\ = (!\u_seg_led|cnt_sel\(1) & (!\u_seg_led|cnt_sel\(2) & !\u_seg_led|cnt_sel\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt_sel\(1),
	datac => \u_seg_led|cnt_sel\(2),
	datad => \u_seg_led|cnt_sel\(0),
	combout => \u_seg_led|Decoder0~0_combout\);

-- Location: FF_X105_Y20_N25
\u_seg_led|seg_sel[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|Decoder0~0_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|seg_sel\(0));

-- Location: LCCOMB_X105_Y20_N2
\u_seg_led|Decoder0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Decoder0~1_combout\ = (!\u_seg_led|cnt_sel\(1) & (!\u_seg_led|cnt_sel\(2) & \u_seg_led|cnt_sel\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt_sel\(1),
	datac => \u_seg_led|cnt_sel\(2),
	datad => \u_seg_led|cnt_sel\(0),
	combout => \u_seg_led|Decoder0~1_combout\);

-- Location: FF_X105_Y20_N3
\u_seg_led|seg_sel[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|Decoder0~1_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|seg_sel\(1));

-- Location: LCCOMB_X105_Y20_N4
\u_seg_led|Decoder0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Decoder0~2_combout\ = (\u_seg_led|cnt_sel\(1) & (!\u_seg_led|cnt_sel\(2) & !\u_seg_led|cnt_sel\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt_sel\(1),
	datac => \u_seg_led|cnt_sel\(2),
	datad => \u_seg_led|cnt_sel\(0),
	combout => \u_seg_led|Decoder0~2_combout\);

-- Location: FF_X105_Y20_N5
\u_seg_led|seg_sel[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|Decoder0~2_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|seg_sel\(2));

-- Location: LCCOMB_X105_Y20_N30
\u_seg_led|Decoder0~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Decoder0~3_combout\ = (\u_seg_led|cnt_sel\(1) & (!\u_seg_led|cnt_sel\(2) & \u_seg_led|cnt_sel\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt_sel\(1),
	datac => \u_seg_led|cnt_sel\(2),
	datad => \u_seg_led|cnt_sel\(0),
	combout => \u_seg_led|Decoder0~3_combout\);

-- Location: FF_X105_Y20_N31
\u_seg_led|seg_sel[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|Decoder0~3_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|seg_sel\(3));

-- Location: LCCOMB_X105_Y20_N8
\u_seg_led|Decoder0~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Decoder0~4_combout\ = (!\u_seg_led|cnt_sel\(1) & (\u_seg_led|cnt_sel\(2) & !\u_seg_led|cnt_sel\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt_sel\(1),
	datac => \u_seg_led|cnt_sel\(2),
	datad => \u_seg_led|cnt_sel\(0),
	combout => \u_seg_led|Decoder0~4_combout\);

-- Location: FF_X105_Y20_N9
\u_seg_led|seg_sel[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|Decoder0~4_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|seg_sel\(4));

-- Location: LCCOMB_X105_Y20_N26
\u_seg_led|Decoder0~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Decoder0~5_combout\ = (!\u_seg_led|cnt_sel\(1) & (\u_seg_led|cnt_sel\(2) & \u_seg_led|cnt_sel\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt_sel\(1),
	datac => \u_seg_led|cnt_sel\(2),
	datad => \u_seg_led|cnt_sel\(0),
	combout => \u_seg_led|Decoder0~5_combout\);

-- Location: FF_X105_Y20_N27
\u_seg_led|seg_sel[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|Decoder0~5_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|seg_sel\(5));

-- Location: LCCOMB_X103_Y20_N24
\u_seg_led|num[13]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|num[13]~feeder_combout\ = VCC

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \u_seg_led|num[13]~feeder_combout\);

-- Location: FF_X103_Y20_N25
\u_seg_led|num[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|num[13]~feeder_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num\(13));

-- Location: IOIBUF_X56_Y0_N1
\remote_in~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_remote_in,
	o => \remote_in~input_o\);

-- Location: FF_X97_Y22_N9
\u_remote_rcv|remote_in_d0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	asdata => \remote_in~input_o\,
	clrn => \sys_rst_n~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|remote_in_d0~q\);

-- Location: FF_X97_Y22_N11
\u_remote_rcv|remote_in_d1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	asdata => \u_remote_rcv|remote_in_d0~q\,
	clrn => \sys_rst_n~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|remote_in_d1~q\);

-- Location: LCCOMB_X98_Y22_N24
\u_remote_rcv|data_temp~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp~2_combout\ = (\u_remote_rcv|data_temp\(8) & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001010100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data_temp\(8),
	datab => \u_remote_rcv|remote_in_d0~q\,
	datac => \u_remote_rcv|remote_in_d1~q\,
	combout => \u_remote_rcv|data_temp~2_combout\);

-- Location: LCCOMB_X97_Y22_N4
\u_remote_rcv|pos_remote_in\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|pos_remote_in~combout\ = (\u_remote_rcv|remote_in_d0~q\ & !\u_remote_rcv|remote_in_d1~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|remote_in_d0~q\,
	datad => \u_remote_rcv|remote_in_d1~q\,
	combout => \u_remote_rcv|pos_remote_in~combout\);

-- Location: LCCOMB_X99_Y22_N10
\u_remote_rcv|data_cnt[0]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_cnt[0]~8_combout\ = \u_remote_rcv|data_cnt\(0) $ (VCC)
-- \u_remote_rcv|data_cnt[0]~9\ = CARRY(\u_remote_rcv|data_cnt\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|data_cnt\(0),
	datad => VCC,
	combout => \u_remote_rcv|data_cnt[0]~8_combout\,
	cout => \u_remote_rcv|data_cnt[0]~9\);

-- Location: LCCOMB_X99_Y22_N26
\u_remote_rcv|data_cnt[5]~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_cnt[5]~20_combout\ = (\u_remote_rcv|cur_state.st_rec_data~q\ & (\u_remote_rcv|data_temp[7]~3_combout\ & (\u_remote_rcv|remote_in_d1~q\ $ (\u_remote_rcv|remote_in_d0~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|cur_state.st_rec_data~q\,
	datab => \u_remote_rcv|remote_in_d1~q\,
	datac => \u_remote_rcv|remote_in_d0~q\,
	datad => \u_remote_rcv|data_temp[7]~3_combout\,
	combout => \u_remote_rcv|data_cnt[5]~20_combout\);

-- Location: FF_X99_Y22_N11
\u_remote_rcv|data_cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_cnt[0]~8_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_remote_rcv|pos_remote_in~combout\,
	ena => \u_remote_rcv|data_cnt[5]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_cnt\(0));

-- Location: LCCOMB_X99_Y22_N14
\u_remote_rcv|data_cnt[2]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_cnt[2]~12_combout\ = (\u_remote_rcv|data_cnt\(2) & (\u_remote_rcv|data_cnt[1]~11\ $ (GND))) # (!\u_remote_rcv|data_cnt\(2) & (!\u_remote_rcv|data_cnt[1]~11\ & VCC))
-- \u_remote_rcv|data_cnt[2]~13\ = CARRY((\u_remote_rcv|data_cnt\(2) & !\u_remote_rcv|data_cnt[1]~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data_cnt\(2),
	datad => VCC,
	cin => \u_remote_rcv|data_cnt[1]~11\,
	combout => \u_remote_rcv|data_cnt[2]~12_combout\,
	cout => \u_remote_rcv|data_cnt[2]~13\);

-- Location: LCCOMB_X99_Y22_N16
\u_remote_rcv|data_cnt[3]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_cnt[3]~14_combout\ = (\u_remote_rcv|data_cnt\(3) & (!\u_remote_rcv|data_cnt[2]~13\)) # (!\u_remote_rcv|data_cnt\(3) & ((\u_remote_rcv|data_cnt[2]~13\) # (GND)))
-- \u_remote_rcv|data_cnt[3]~15\ = CARRY((!\u_remote_rcv|data_cnt[2]~13\) # (!\u_remote_rcv|data_cnt\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data_cnt\(3),
	datad => VCC,
	cin => \u_remote_rcv|data_cnt[2]~13\,
	combout => \u_remote_rcv|data_cnt[3]~14_combout\,
	cout => \u_remote_rcv|data_cnt[3]~15\);

-- Location: LCCOMB_X99_Y22_N18
\u_remote_rcv|data_cnt[4]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_cnt[4]~16_combout\ = (\u_remote_rcv|data_cnt\(4) & (\u_remote_rcv|data_cnt[3]~15\ $ (GND))) # (!\u_remote_rcv|data_cnt\(4) & (!\u_remote_rcv|data_cnt[3]~15\ & VCC))
-- \u_remote_rcv|data_cnt[4]~17\ = CARRY((\u_remote_rcv|data_cnt\(4) & !\u_remote_rcv|data_cnt[3]~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|data_cnt\(4),
	datad => VCC,
	cin => \u_remote_rcv|data_cnt[3]~15\,
	combout => \u_remote_rcv|data_cnt[4]~16_combout\,
	cout => \u_remote_rcv|data_cnt[4]~17\);

-- Location: FF_X99_Y22_N19
\u_remote_rcv|data_cnt[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_cnt[4]~16_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_remote_rcv|pos_remote_in~combout\,
	ena => \u_remote_rcv|data_cnt[5]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_cnt\(4));

-- Location: FF_X99_Y22_N15
\u_remote_rcv|data_cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_cnt[2]~12_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_remote_rcv|pos_remote_in~combout\,
	ena => \u_remote_rcv|data_cnt[5]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_cnt\(2));

-- Location: FF_X99_Y22_N17
\u_remote_rcv|data_cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_cnt[3]~14_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_remote_rcv|pos_remote_in~combout\,
	ena => \u_remote_rcv|data_cnt[5]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_cnt\(3));

-- Location: LCCOMB_X99_Y22_N22
\u_remote_rcv|Equal1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Equal1~0_combout\ = (!\u_remote_rcv|data_cnt\(1) & (!\u_remote_rcv|data_cnt\(0) & (!\u_remote_rcv|data_cnt\(2) & !\u_remote_rcv|data_cnt\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data_cnt\(1),
	datab => \u_remote_rcv|data_cnt\(0),
	datac => \u_remote_rcv|data_cnt\(2),
	datad => \u_remote_rcv|data_cnt\(3),
	combout => \u_remote_rcv|Equal1~0_combout\);

-- Location: LCCOMB_X98_Y22_N10
\u_remote_rcv|data_temp[7]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp[7]~3_combout\ = ((\u_remote_rcv|data_cnt\(5) & (!\u_remote_rcv|data_cnt\(4) & \u_remote_rcv|Equal1~0_combout\))) # (!\u_remote_rcv|pos_remote_in~combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data_cnt\(5),
	datab => \u_remote_rcv|data_cnt\(4),
	datac => \u_remote_rcv|pos_remote_in~combout\,
	datad => \u_remote_rcv|Equal1~0_combout\,
	combout => \u_remote_rcv|data_temp[7]~3_combout\);

-- Location: LCCOMB_X99_Y22_N20
\u_remote_rcv|data_cnt[5]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_cnt[5]~18_combout\ = \u_remote_rcv|data_cnt[4]~17\ $ (\u_remote_rcv|data_cnt\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \u_remote_rcv|data_cnt\(5),
	cin => \u_remote_rcv|data_cnt[4]~17\,
	combout => \u_remote_rcv|data_cnt[5]~18_combout\);

-- Location: FF_X99_Y22_N21
\u_remote_rcv|data_cnt[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_cnt[5]~18_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_remote_rcv|pos_remote_in~combout\,
	ena => \u_remote_rcv|data_cnt[5]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_cnt\(5));

-- Location: LCCOMB_X97_Y22_N18
\u_remote_rcv|data_temp[15]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp[15]~4_combout\ = (\u_remote_rcv|remote_in_d1~q\ & (!\u_remote_rcv|remote_in_d0~q\ & (!\u_remote_rcv|data_cnt\(5) & \u_remote_rcv|data_cnt\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|remote_in_d1~q\,
	datab => \u_remote_rcv|remote_in_d0~q\,
	datac => \u_remote_rcv|data_cnt\(5),
	datad => \u_remote_rcv|data_cnt\(4),
	combout => \u_remote_rcv|data_temp[15]~4_combout\);

-- Location: LCCOMB_X96_Y22_N16
\u_remote_rcv|time_cnt[0]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|time_cnt[0]~8_combout\ = \u_remote_rcv|time_cnt\(0) $ (VCC)
-- \u_remote_rcv|time_cnt[0]~9\ = CARRY(\u_remote_rcv|time_cnt\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|time_cnt\(0),
	datad => VCC,
	combout => \u_remote_rcv|time_cnt[0]~8_combout\,
	cout => \u_remote_rcv|time_cnt[0]~9\);

-- Location: LCCOMB_X98_Y22_N28
\u_remote_rcv|Selector3~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector3~0_combout\ = (\u_remote_rcv|data_cnt\(5) & (!\u_remote_rcv|data_cnt\(4) & (\u_remote_rcv|pos_remote_in~combout\ & \u_remote_rcv|Equal1~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data_cnt\(5),
	datab => \u_remote_rcv|data_cnt\(4),
	datac => \u_remote_rcv|pos_remote_in~combout\,
	datad => \u_remote_rcv|Equal1~0_combout\,
	combout => \u_remote_rcv|Selector3~0_combout\);

-- Location: LCCOMB_X96_Y22_N24
\u_remote_rcv|time_cnt[4]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|time_cnt[4]~16_combout\ = (\u_remote_rcv|time_cnt\(4) & (\u_remote_rcv|time_cnt[3]~15\ $ (GND))) # (!\u_remote_rcv|time_cnt\(4) & (!\u_remote_rcv|time_cnt[3]~15\ & VCC))
-- \u_remote_rcv|time_cnt[4]~17\ = CARRY((\u_remote_rcv|time_cnt\(4) & !\u_remote_rcv|time_cnt[3]~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|time_cnt\(4),
	datad => VCC,
	cin => \u_remote_rcv|time_cnt[3]~15\,
	combout => \u_remote_rcv|time_cnt[4]~16_combout\,
	cout => \u_remote_rcv|time_cnt[4]~17\);

-- Location: LCCOMB_X96_Y22_N26
\u_remote_rcv|time_cnt[5]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|time_cnt[5]~18_combout\ = (\u_remote_rcv|time_cnt\(5) & (!\u_remote_rcv|time_cnt[4]~17\)) # (!\u_remote_rcv|time_cnt\(5) & ((\u_remote_rcv|time_cnt[4]~17\) # (GND)))
-- \u_remote_rcv|time_cnt[5]~19\ = CARRY((!\u_remote_rcv|time_cnt[4]~17\) # (!\u_remote_rcv|time_cnt\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|time_cnt\(5),
	datad => VCC,
	cin => \u_remote_rcv|time_cnt[4]~17\,
	combout => \u_remote_rcv|time_cnt[5]~18_combout\,
	cout => \u_remote_rcv|time_cnt[5]~19\);

-- Location: FF_X96_Y22_N27
\u_remote_rcv|time_cnt[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|time_cnt[5]~18_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_remote_rcv|time_cnt_clr~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|time_cnt\(5));

-- Location: LCCOMB_X96_Y22_N28
\u_remote_rcv|time_cnt[6]~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|time_cnt[6]~20_combout\ = (\u_remote_rcv|time_cnt\(6) & (\u_remote_rcv|time_cnt[5]~19\ $ (GND))) # (!\u_remote_rcv|time_cnt\(6) & (!\u_remote_rcv|time_cnt[5]~19\ & VCC))
-- \u_remote_rcv|time_cnt[6]~21\ = CARRY((\u_remote_rcv|time_cnt\(6) & !\u_remote_rcv|time_cnt[5]~19\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|time_cnt\(6),
	datad => VCC,
	cin => \u_remote_rcv|time_cnt[5]~19\,
	combout => \u_remote_rcv|time_cnt[6]~20_combout\,
	cout => \u_remote_rcv|time_cnt[6]~21\);

-- Location: LCCOMB_X96_Y22_N30
\u_remote_rcv|time_cnt[7]~22\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|time_cnt[7]~22_combout\ = \u_remote_rcv|time_cnt[6]~21\ $ (\u_remote_rcv|time_cnt\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \u_remote_rcv|time_cnt\(7),
	cin => \u_remote_rcv|time_cnt[6]~21\,
	combout => \u_remote_rcv|time_cnt[7]~22_combout\);

-- Location: FF_X96_Y22_N31
\u_remote_rcv|time_cnt[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|time_cnt[7]~22_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_remote_rcv|time_cnt_clr~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|time_cnt\(7));

-- Location: LCCOMB_X96_Y22_N20
\u_remote_rcv|time_cnt[2]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|time_cnt[2]~12_combout\ = (\u_remote_rcv|time_cnt\(2) & (\u_remote_rcv|time_cnt[1]~11\ $ (GND))) # (!\u_remote_rcv|time_cnt\(2) & (!\u_remote_rcv|time_cnt[1]~11\ & VCC))
-- \u_remote_rcv|time_cnt[2]~13\ = CARRY((\u_remote_rcv|time_cnt\(2) & !\u_remote_rcv|time_cnt[1]~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|time_cnt\(2),
	datad => VCC,
	cin => \u_remote_rcv|time_cnt[1]~11\,
	combout => \u_remote_rcv|time_cnt[2]~12_combout\,
	cout => \u_remote_rcv|time_cnt[2]~13\);

-- Location: FF_X96_Y22_N21
\u_remote_rcv|time_cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|time_cnt[2]~12_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_remote_rcv|time_cnt_clr~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|time_cnt\(2));

-- Location: LCCOMB_X96_Y22_N14
\u_remote_rcv|always5~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|always5~4_combout\ = (\u_remote_rcv|time_cnt\(5) & ((\u_remote_rcv|time_cnt\(1)) # ((\u_remote_rcv|time_cnt\(2)) # (\u_remote_rcv|time_cnt\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|time_cnt\(5),
	datab => \u_remote_rcv|time_cnt\(1),
	datac => \u_remote_rcv|time_cnt\(2),
	datad => \u_remote_rcv|time_cnt\(0),
	combout => \u_remote_rcv|always5~4_combout\);

-- Location: LCCOMB_X96_Y22_N4
\u_remote_rcv|always5~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|always5~5_combout\ = (!\u_remote_rcv|time_cnt\(6) & (!\u_remote_rcv|time_cnt\(7) & (\u_remote_rcv|always5~4_combout\ & !\u_remote_rcv|LessThan5~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|time_cnt\(6),
	datab => \u_remote_rcv|time_cnt\(7),
	datac => \u_remote_rcv|always5~4_combout\,
	datad => \u_remote_rcv|LessThan5~1_combout\,
	combout => \u_remote_rcv|always5~5_combout\);

-- Location: LCCOMB_X96_Y22_N10
\u_remote_rcv|always5~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|always5~6_combout\ = (\u_remote_rcv|time_cnt\(2) & ((\u_remote_rcv|time_cnt\(1) & (!\u_remote_rcv|time_cnt\(3))) # (!\u_remote_rcv|time_cnt\(1) & ((\u_remote_rcv|time_cnt\(0))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|time_cnt\(3),
	datab => \u_remote_rcv|time_cnt\(1),
	datac => \u_remote_rcv|time_cnt\(2),
	datad => \u_remote_rcv|time_cnt\(0),
	combout => \u_remote_rcv|always5~6_combout\);

-- Location: FF_X96_Y22_N29
\u_remote_rcv|time_cnt[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|time_cnt[6]~20_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_remote_rcv|time_cnt_clr~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|time_cnt\(6));

-- Location: LCCOMB_X96_Y22_N2
\u_remote_rcv|always5~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|always5~1_combout\ = (!\u_remote_rcv|time_cnt\(6) & (!\u_remote_rcv|time_cnt\(7) & !\u_remote_rcv|time_cnt\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|time_cnt\(6),
	datac => \u_remote_rcv|time_cnt\(7),
	datad => \u_remote_rcv|time_cnt\(5),
	combout => \u_remote_rcv|always5~1_combout\);

-- Location: LCCOMB_X99_Y22_N24
\u_remote_rcv|always5~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|always5~7_combout\ = ((\u_remote_rcv|time_cnt\(3) & ((\u_remote_rcv|time_cnt\(4)) # (!\u_remote_rcv|time_cnt\(0))))) # (!\u_remote_rcv|always5~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|time_cnt\(3),
	datab => \u_remote_rcv|time_cnt\(0),
	datac => \u_remote_rcv|time_cnt\(4),
	datad => \u_remote_rcv|always5~1_combout\,
	combout => \u_remote_rcv|always5~7_combout\);

-- Location: LCCOMB_X99_Y22_N2
\u_remote_rcv|always5~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|always5~8_combout\ = (\u_remote_rcv|always5~6_combout\) # ((\u_remote_rcv|always5~7_combout\) # ((!\u_remote_rcv|LessThan5~0_combout\ & !\u_remote_rcv|time_cnt\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|LessThan5~0_combout\,
	datab => \u_remote_rcv|time_cnt\(4),
	datac => \u_remote_rcv|always5~6_combout\,
	datad => \u_remote_rcv|always5~7_combout\,
	combout => \u_remote_rcv|always5~8_combout\);

-- Location: LCCOMB_X99_Y22_N4
\u_remote_rcv|judge_flag~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|judge_flag~1_combout\ = (\u_remote_rcv|judge_flag~0_combout\ & (((!\u_remote_rcv|always5~5_combout\ & \u_remote_rcv|judge_flag~q\)) # (!\u_remote_rcv|always5~8_combout\))) # (!\u_remote_rcv|judge_flag~0_combout\ & 
-- (((\u_remote_rcv|judge_flag~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111000011111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|judge_flag~0_combout\,
	datab => \u_remote_rcv|always5~5_combout\,
	datac => \u_remote_rcv|judge_flag~q\,
	datad => \u_remote_rcv|always5~8_combout\,
	combout => \u_remote_rcv|judge_flag~1_combout\);

-- Location: FF_X99_Y22_N5
\u_remote_rcv|judge_flag\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|judge_flag~1_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|judge_flag~q\);

-- Location: LCCOMB_X98_Y22_N14
\u_remote_rcv|Selector3~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector3~2_combout\ = (\u_remote_rcv|Selector3~1_combout\ & (((!\u_remote_rcv|Selector3~0_combout\ & \u_remote_rcv|cur_state.st_rec_data~q\)) # (!\u_remote_rcv|judge_flag~q\))) # (!\u_remote_rcv|Selector3~1_combout\ & 
-- (!\u_remote_rcv|Selector3~0_combout\ & (\u_remote_rcv|cur_state.st_rec_data~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000010111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|Selector3~1_combout\,
	datab => \u_remote_rcv|Selector3~0_combout\,
	datac => \u_remote_rcv|cur_state.st_rec_data~q\,
	datad => \u_remote_rcv|judge_flag~q\,
	combout => \u_remote_rcv|Selector3~2_combout\);

-- Location: FF_X98_Y22_N15
\u_remote_rcv|cur_state.st_rec_data\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|Selector3~2_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|cur_state.st_rec_data~q\);

-- Location: LCCOMB_X100_Y22_N16
\u_remote_rcv|Selector5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector5~0_combout\ = (\u_remote_rcv|cur_state.st_rec_data~q\ & (\u_remote_rcv|remote_in_d1~q\ $ (\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|remote_in_d1~q\,
	datac => \u_remote_rcv|remote_in_d0~q\,
	datad => \u_remote_rcv|cur_state.st_rec_data~q\,
	combout => \u_remote_rcv|Selector5~0_combout\);

-- Location: LCCOMB_X99_Y22_N8
\u_remote_rcv|Selector4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector4~0_combout\ = (\u_remote_rcv|Selector3~1_combout\ & ((\u_remote_rcv|judge_flag~q\) # ((\u_remote_rcv|cur_state.st_repeat_code~q\ & !\u_remote_rcv|pos_remote_in~combout\)))) # (!\u_remote_rcv|Selector3~1_combout\ & 
-- (((\u_remote_rcv|cur_state.st_repeat_code~q\ & !\u_remote_rcv|pos_remote_in~combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|Selector3~1_combout\,
	datab => \u_remote_rcv|judge_flag~q\,
	datac => \u_remote_rcv|cur_state.st_repeat_code~q\,
	datad => \u_remote_rcv|pos_remote_in~combout\,
	combout => \u_remote_rcv|Selector4~0_combout\);

-- Location: FF_X99_Y22_N9
\u_remote_rcv|cur_state.st_repeat_code\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|Selector4~0_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|cur_state.st_repeat_code~q\);

-- Location: LCCOMB_X99_Y22_N0
\u_remote_rcv|Selector5~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector5~1_combout\ = ((\u_remote_rcv|cur_state.st_idle~q\ & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|cur_state.st_repeat_code~q\)))) # (!\u_remote_rcv|remote_in_d0~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111100101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|cur_state.st_idle~q\,
	datab => \u_remote_rcv|cur_state.st_repeat_code~q\,
	datac => \u_remote_rcv|remote_in_d0~q\,
	datad => \u_remote_rcv|remote_in_d1~q\,
	combout => \u_remote_rcv|Selector5~1_combout\);

-- Location: LCCOMB_X96_Y22_N22
\u_remote_rcv|time_cnt[3]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|time_cnt[3]~14_combout\ = (\u_remote_rcv|time_cnt\(3) & (!\u_remote_rcv|time_cnt[2]~13\)) # (!\u_remote_rcv|time_cnt\(3) & ((\u_remote_rcv|time_cnt[2]~13\) # (GND)))
-- \u_remote_rcv|time_cnt[3]~15\ = CARRY((!\u_remote_rcv|time_cnt[2]~13\) # (!\u_remote_rcv|time_cnt\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|time_cnt\(3),
	datad => VCC,
	cin => \u_remote_rcv|time_cnt[2]~13\,
	combout => \u_remote_rcv|time_cnt[3]~14_combout\,
	cout => \u_remote_rcv|time_cnt[3]~15\);

-- Location: FF_X96_Y22_N23
\u_remote_rcv|time_cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|time_cnt[3]~14_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_remote_rcv|time_cnt_clr~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|time_cnt\(3));

-- Location: LCCOMB_X99_Y22_N28
\u_remote_rcv|always5~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|always5~9_combout\ = (\u_remote_rcv|time_cnt\(2) & (!\u_remote_rcv|time_cnt\(3) & ((\u_remote_rcv|time_cnt\(1)) # (\u_remote_rcv|time_cnt\(0))))) # (!\u_remote_rcv|time_cnt\(2) & (((\u_remote_rcv|time_cnt\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|time_cnt\(1),
	datab => \u_remote_rcv|time_cnt\(0),
	datac => \u_remote_rcv|time_cnt\(2),
	datad => \u_remote_rcv|time_cnt\(3),
	combout => \u_remote_rcv|always5~9_combout\);

-- Location: LCCOMB_X100_Y22_N20
\u_remote_rcv|judge_flag~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|judge_flag~2_combout\ = (!\u_remote_rcv|remote_in_d0~q\ & \u_remote_rcv|remote_in_d1~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_remote_rcv|remote_in_d0~q\,
	datad => \u_remote_rcv|remote_in_d1~q\,
	combout => \u_remote_rcv|judge_flag~2_combout\);

-- Location: LCCOMB_X100_Y22_N18
\u_remote_rcv|Selector7~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector7~0_combout\ = (\u_remote_rcv|cur_state.st_start_judge~q\ & (\u_remote_rcv|judge_flag~2_combout\ & (!\u_remote_rcv|always5~5_combout\ & \u_remote_rcv|always5~8_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|cur_state.st_start_judge~q\,
	datab => \u_remote_rcv|judge_flag~2_combout\,
	datac => \u_remote_rcv|always5~5_combout\,
	datad => \u_remote_rcv|always5~8_combout\,
	combout => \u_remote_rcv|Selector7~0_combout\);

-- Location: LCCOMB_X100_Y22_N24
\u_remote_rcv|Selector7~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector7~1_combout\ = (\u_remote_rcv|Selector7~0_combout\) # ((\u_remote_rcv|Selector6~1_combout\ & ((!\u_remote_rcv|always5~9_combout\) # (!\u_remote_rcv|always5~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111101110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|always5~10_combout\,
	datab => \u_remote_rcv|always5~9_combout\,
	datac => \u_remote_rcv|Selector6~1_combout\,
	datad => \u_remote_rcv|Selector7~0_combout\,
	combout => \u_remote_rcv|Selector7~1_combout\);

-- Location: FF_X100_Y22_N25
\u_remote_rcv|error_en\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|Selector7~1_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|error_en~q\);

-- Location: LCCOMB_X100_Y22_N10
\u_remote_rcv|Selector6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector6~0_combout\ = (\u_remote_rcv|cur_state.st_start_judge~q\ & (\u_remote_rcv|judge_flag~2_combout\ & ((\u_remote_rcv|always5~5_combout\) # (!\u_remote_rcv|always5~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|cur_state.st_start_judge~q\,
	datab => \u_remote_rcv|judge_flag~2_combout\,
	datac => \u_remote_rcv|always5~5_combout\,
	datad => \u_remote_rcv|always5~8_combout\,
	combout => \u_remote_rcv|Selector6~0_combout\);

-- Location: LCCOMB_X100_Y22_N4
\u_remote_rcv|Selector6~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector6~2_combout\ = (\u_remote_rcv|Selector6~0_combout\) # ((\u_remote_rcv|always5~10_combout\ & (\u_remote_rcv|always5~9_combout\ & \u_remote_rcv|Selector6~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|always5~10_combout\,
	datab => \u_remote_rcv|always5~9_combout\,
	datac => \u_remote_rcv|Selector6~1_combout\,
	datad => \u_remote_rcv|Selector6~0_combout\,
	combout => \u_remote_rcv|Selector6~2_combout\);

-- Location: FF_X100_Y22_N5
\u_remote_rcv|time_done\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|Selector6~2_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|time_done~q\);

-- Location: LCCOMB_X100_Y22_N12
\u_remote_rcv|Selector0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector0~0_combout\ = (\u_remote_rcv|error_en~q\ & (!\u_remote_rcv|time_done~q\ & ((\u_remote_rcv|cur_state.st_start_judge~q\) # (\u_remote_rcv|cur_state.st_start_low_9ms~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|cur_state.st_start_judge~q\,
	datab => \u_remote_rcv|error_en~q\,
	datac => \u_remote_rcv|time_done~q\,
	datad => \u_remote_rcv|cur_state.st_start_low_9ms~q\,
	combout => \u_remote_rcv|Selector0~0_combout\);

-- Location: LCCOMB_X99_Y22_N6
\u_remote_rcv|Selector0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector0~1_combout\ = (\u_remote_rcv|Selector5~1_combout\ & (!\u_remote_rcv|Selector0~0_combout\ & ((!\u_remote_rcv|Selector3~0_combout\) # (!\u_remote_rcv|cur_state.st_rec_data~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|cur_state.st_rec_data~q\,
	datab => \u_remote_rcv|Selector5~1_combout\,
	datac => \u_remote_rcv|Selector0~0_combout\,
	datad => \u_remote_rcv|Selector3~0_combout\,
	combout => \u_remote_rcv|Selector0~1_combout\);

-- Location: FF_X99_Y22_N7
\u_remote_rcv|cur_state.st_idle\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|Selector0~1_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|cur_state.st_idle~q\);

-- Location: LCCOMB_X100_Y22_N8
\u_remote_rcv|Selector1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector1~0_combout\ = (!\u_remote_rcv|error_en~q\ & (!\u_remote_rcv|time_done~q\ & \u_remote_rcv|cur_state.st_start_low_9ms~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|error_en~q\,
	datac => \u_remote_rcv|time_done~q\,
	datad => \u_remote_rcv|cur_state.st_start_low_9ms~q\,
	combout => \u_remote_rcv|Selector1~0_combout\);

-- Location: LCCOMB_X100_Y22_N0
\u_remote_rcv|Selector1~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector1~1_combout\ = (\u_remote_rcv|Selector1~0_combout\) # ((!\u_remote_rcv|cur_state.st_idle~q\ & !\u_remote_rcv|remote_in_d0~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|cur_state.st_idle~q\,
	datac => \u_remote_rcv|remote_in_d0~q\,
	datad => \u_remote_rcv|Selector1~0_combout\,
	combout => \u_remote_rcv|Selector1~1_combout\);

-- Location: FF_X100_Y22_N1
\u_remote_rcv|cur_state.st_start_low_9ms\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|Selector1~1_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|cur_state.st_start_low_9ms~q\);

-- Location: LCCOMB_X100_Y22_N22
\u_remote_rcv|Selector6~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector6~1_combout\ = (\u_remote_rcv|cur_state.st_start_low_9ms~q\ & (\u_remote_rcv|remote_in_d0~q\ & !\u_remote_rcv|remote_in_d1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|cur_state.st_start_low_9ms~q\,
	datac => \u_remote_rcv|remote_in_d0~q\,
	datad => \u_remote_rcv|remote_in_d1~q\,
	combout => \u_remote_rcv|Selector6~1_combout\);

-- Location: LCCOMB_X100_Y22_N30
\u_remote_rcv|Selector2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector2~0_combout\ = (\u_remote_rcv|time_done~q\ & (((\u_remote_rcv|cur_state.st_start_low_9ms~q\)))) # (!\u_remote_rcv|time_done~q\ & (!\u_remote_rcv|error_en~q\ & (\u_remote_rcv|cur_state.st_start_judge~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|time_done~q\,
	datab => \u_remote_rcv|error_en~q\,
	datac => \u_remote_rcv|cur_state.st_start_judge~q\,
	datad => \u_remote_rcv|cur_state.st_start_low_9ms~q\,
	combout => \u_remote_rcv|Selector2~0_combout\);

-- Location: FF_X100_Y22_N31
\u_remote_rcv|cur_state.st_start_judge\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|Selector2~0_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|cur_state.st_start_judge~q\);

-- Location: LCCOMB_X100_Y22_N6
\u_remote_rcv|judge_flag~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|judge_flag~0_combout\ = (!\u_remote_rcv|remote_in_d0~q\ & (\u_remote_rcv|cur_state.st_start_judge~q\ & \u_remote_rcv|remote_in_d1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|remote_in_d0~q\,
	datac => \u_remote_rcv|cur_state.st_start_judge~q\,
	datad => \u_remote_rcv|remote_in_d1~q\,
	combout => \u_remote_rcv|judge_flag~0_combout\);

-- Location: LCCOMB_X100_Y22_N26
\u_remote_rcv|Selector5~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|Selector5~2_combout\ = ((\u_remote_rcv|Selector5~0_combout\) # ((\u_remote_rcv|Selector6~1_combout\) # (\u_remote_rcv|judge_flag~0_combout\))) # (!\u_remote_rcv|Selector5~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|Selector5~1_combout\,
	datab => \u_remote_rcv|Selector5~0_combout\,
	datac => \u_remote_rcv|Selector6~1_combout\,
	datad => \u_remote_rcv|judge_flag~0_combout\,
	combout => \u_remote_rcv|Selector5~2_combout\);

-- Location: FF_X100_Y22_N27
\u_remote_rcv|time_cnt_clr\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|Selector5~2_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|time_cnt_clr~q\);

-- Location: FF_X96_Y22_N17
\u_remote_rcv|time_cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|time_cnt[0]~8_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_remote_rcv|time_cnt_clr~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|time_cnt\(0));

-- Location: LCCOMB_X96_Y22_N18
\u_remote_rcv|time_cnt[1]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|time_cnt[1]~10_combout\ = (\u_remote_rcv|time_cnt\(1) & (!\u_remote_rcv|time_cnt[0]~9\)) # (!\u_remote_rcv|time_cnt\(1) & ((\u_remote_rcv|time_cnt[0]~9\) # (GND)))
-- \u_remote_rcv|time_cnt[1]~11\ = CARRY((!\u_remote_rcv|time_cnt[0]~9\) # (!\u_remote_rcv|time_cnt\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|time_cnt\(1),
	datad => VCC,
	cin => \u_remote_rcv|time_cnt[0]~9\,
	combout => \u_remote_rcv|time_cnt[1]~10_combout\,
	cout => \u_remote_rcv|time_cnt[1]~11\);

-- Location: FF_X96_Y22_N19
\u_remote_rcv|time_cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|time_cnt[1]~10_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_remote_rcv|time_cnt_clr~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|time_cnt\(1));

-- Location: FF_X96_Y22_N25
\u_remote_rcv|time_cnt[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|time_cnt[4]~16_combout\,
	clrn => \sys_rst_n~input_o\,
	sclr => \u_remote_rcv|time_cnt_clr~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|time_cnt\(4));

-- Location: LCCOMB_X96_Y22_N0
\u_remote_rcv|LessThan5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|LessThan5~0_combout\ = (\u_remote_rcv|time_cnt\(2) & \u_remote_rcv|time_cnt\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|time_cnt\(2),
	datad => \u_remote_rcv|time_cnt\(1),
	combout => \u_remote_rcv|LessThan5~0_combout\);

-- Location: LCCOMB_X96_Y22_N6
\u_remote_rcv|LessThan5~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|LessThan5~1_combout\ = (\u_remote_rcv|time_cnt\(3)) # ((\u_remote_rcv|time_cnt\(4)) # ((\u_remote_rcv|time_cnt\(0) & \u_remote_rcv|LessThan5~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|time_cnt\(3),
	datab => \u_remote_rcv|time_cnt\(4),
	datac => \u_remote_rcv|time_cnt\(0),
	datad => \u_remote_rcv|LessThan5~0_combout\,
	combout => \u_remote_rcv|LessThan5~1_combout\);

-- Location: LCCOMB_X96_Y22_N12
\u_remote_rcv|always5~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|always5~2_combout\ = (\u_remote_rcv|always5~1_combout\ & ((\u_remote_rcv|time_cnt\(1)) # (\u_remote_rcv|time_cnt\(2))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|time_cnt\(1),
	datac => \u_remote_rcv|time_cnt\(2),
	datad => \u_remote_rcv|always5~1_combout\,
	combout => \u_remote_rcv|always5~2_combout\);

-- Location: LCCOMB_X97_Y22_N0
\u_remote_rcv|data_temp[7]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp[7]~5_combout\ = (((\u_remote_rcv|always5~0_combout\ & \u_remote_rcv|LessThan5~1_combout\)) # (!\u_remote_rcv|always5~2_combout\)) # (!\u_remote_rcv|data_temp[15]~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011001111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|always5~0_combout\,
	datab => \u_remote_rcv|data_temp[15]~4_combout\,
	datac => \u_remote_rcv|LessThan5~1_combout\,
	datad => \u_remote_rcv|always5~2_combout\,
	combout => \u_remote_rcv|data_temp[7]~5_combout\);

-- Location: LCCOMB_X97_Y22_N6
\u_remote_rcv|data_temp[7]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp[7]~6_combout\ = (\u_remote_rcv|cur_state.st_rec_data~q\ & (\u_remote_rcv|data_temp[7]~3_combout\ & ((\u_remote_rcv|pos_remote_in~combout\) # (!\u_remote_rcv|data_temp[7]~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|cur_state.st_rec_data~q\,
	datab => \u_remote_rcv|pos_remote_in~combout\,
	datac => \u_remote_rcv|data_temp[7]~3_combout\,
	datad => \u_remote_rcv|data_temp[7]~5_combout\,
	combout => \u_remote_rcv|data_temp[7]~6_combout\);

-- Location: FF_X98_Y22_N25
\u_remote_rcv|data_temp[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_temp~2_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_remote_rcv|data_temp[7]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(7));

-- Location: LCCOMB_X98_Y22_N20
\u_remote_rcv|data_temp~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp~20_combout\ = (\u_remote_rcv|data_temp\(7) & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|remote_in_d1~q\,
	datac => \u_remote_rcv|data_temp\(7),
	datad => \u_remote_rcv|remote_in_d0~q\,
	combout => \u_remote_rcv|data_temp~20_combout\);

-- Location: FF_X98_Y22_N21
\u_remote_rcv|data_temp[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_temp~20_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_remote_rcv|data_temp[7]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(6));

-- Location: LCCOMB_X98_Y22_N18
\u_remote_rcv|data_temp~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp~18_combout\ = (\u_remote_rcv|data_temp\(6) & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|data_temp\(6),
	datac => \u_remote_rcv|remote_in_d1~q\,
	datad => \u_remote_rcv|remote_in_d0~q\,
	combout => \u_remote_rcv|data_temp~18_combout\);

-- Location: FF_X97_Y22_N5
\u_remote_rcv|data_temp[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	asdata => \u_remote_rcv|data_temp~18_combout\,
	clrn => \sys_rst_n~input_o\,
	sload => VCC,
	ena => \u_remote_rcv|data_temp[7]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(5));

-- Location: LCCOMB_X98_Y22_N2
\u_remote_rcv|data_temp~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp~16_combout\ = (\u_remote_rcv|data_temp\(5) & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|remote_in_d1~q\,
	datac => \u_remote_rcv|data_temp\(5),
	datad => \u_remote_rcv|remote_in_d0~q\,
	combout => \u_remote_rcv|data_temp~16_combout\);

-- Location: FF_X98_Y22_N3
\u_remote_rcv|data_temp[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_temp~16_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_remote_rcv|data_temp[7]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(4));

-- Location: LCCOMB_X98_Y22_N12
\u_remote_rcv|data_temp~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp~14_combout\ = (\u_remote_rcv|data_temp\(4) & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|remote_in_d0~q\,
	datac => \u_remote_rcv|remote_in_d1~q\,
	datad => \u_remote_rcv|data_temp\(4),
	combout => \u_remote_rcv|data_temp~14_combout\);

-- Location: FF_X97_Y22_N15
\u_remote_rcv|data_temp[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	asdata => \u_remote_rcv|data_temp~14_combout\,
	clrn => \sys_rst_n~input_o\,
	sload => VCC,
	ena => \u_remote_rcv|data_temp[7]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(3));

-- Location: LCCOMB_X97_Y22_N28
\u_remote_rcv|data_temp~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp~12_combout\ = (\u_remote_rcv|data_temp\(3) & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|remote_in_d1~q\,
	datac => \u_remote_rcv|remote_in_d0~q\,
	datad => \u_remote_rcv|data_temp\(3),
	combout => \u_remote_rcv|data_temp~12_combout\);

-- Location: FF_X97_Y22_N29
\u_remote_rcv|data_temp[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_temp~12_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_remote_rcv|data_temp[7]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(2));

-- Location: LCCOMB_X97_Y22_N10
\u_remote_rcv|data_temp~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp~10_combout\ = (\u_remote_rcv|data_temp\(2) & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|remote_in_d0~q\,
	datac => \u_remote_rcv|remote_in_d1~q\,
	datad => \u_remote_rcv|data_temp\(2),
	combout => \u_remote_rcv|data_temp~10_combout\);

-- Location: FF_X97_Y22_N27
\u_remote_rcv|data_temp[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	asdata => \u_remote_rcv|data_temp~10_combout\,
	clrn => \sys_rst_n~input_o\,
	sload => VCC,
	ena => \u_remote_rcv|data_temp[7]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(1));

-- Location: LCCOMB_X100_Y22_N2
\u_remote_rcv|data[1]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data[1]~feeder_combout\ = \u_remote_rcv|data_temp\(1)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_remote_rcv|data_temp\(1),
	combout => \u_remote_rcv|data[1]~feeder_combout\);

-- Location: LCCOMB_X98_Y22_N8
\u_remote_rcv|data_temp[15]~21\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp[15]~21_combout\ = (\u_remote_rcv|cur_state.st_rec_data~q\ & ((\u_remote_rcv|Selector3~0_combout\) # (\u_remote_rcv|data_temp[15]~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|Selector3~0_combout\,
	datac => \u_remote_rcv|cur_state.st_rec_data~q\,
	datad => \u_remote_rcv|data_temp[15]~4_combout\,
	combout => \u_remote_rcv|data_temp[15]~21_combout\);

-- Location: LCCOMB_X97_Y22_N8
\u_remote_rcv|data_temp[15]~23\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp[15]~23_combout\ = (\u_remote_rcv|remote_in_d1~q\ & ((\u_remote_rcv|LessThan5~1_combout\) # ((!\u_remote_rcv|always5~2_combout\)))) # (!\u_remote_rcv|remote_in_d1~q\ & (!\u_remote_rcv|remote_in_d0~q\ & 
-- ((\u_remote_rcv|LessThan5~1_combout\) # (!\u_remote_rcv|always5~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|remote_in_d1~q\,
	datab => \u_remote_rcv|LessThan5~1_combout\,
	datac => \u_remote_rcv|remote_in_d0~q\,
	datad => \u_remote_rcv|always5~2_combout\,
	combout => \u_remote_rcv|data_temp[15]~23_combout\);

-- Location: LCCOMB_X98_Y22_N22
\u_remote_rcv|data_temp[15]~22\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp[15]~22_combout\ = (\u_remote_rcv|data_temp[15]~21_combout\ & (\u_remote_rcv|data_temp[15]~23_combout\ & ((\u_remote_rcv|data_temp\(15)) # (!\u_remote_rcv|always5~3_combout\)))) # (!\u_remote_rcv|data_temp[15]~21_combout\ & 
-- (((\u_remote_rcv|data_temp\(15)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|always5~3_combout\,
	datab => \u_remote_rcv|data_temp[15]~21_combout\,
	datac => \u_remote_rcv|data_temp\(15),
	datad => \u_remote_rcv|data_temp[15]~23_combout\,
	combout => \u_remote_rcv|data_temp[15]~22_combout\);

-- Location: FF_X98_Y22_N23
\u_remote_rcv|data_temp[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_temp[15]~22_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(15));

-- Location: LCCOMB_X98_Y22_N30
\u_remote_rcv|data_temp~19\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp~19_combout\ = (\u_remote_rcv|data_temp\(15) & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|remote_in_d1~q\,
	datac => \u_remote_rcv|data_temp\(15),
	datad => \u_remote_rcv|remote_in_d0~q\,
	combout => \u_remote_rcv|data_temp~19_combout\);

-- Location: FF_X98_Y22_N31
\u_remote_rcv|data_temp[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_temp~19_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_remote_rcv|data_temp[7]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(14));

-- Location: LCCOMB_X98_Y22_N4
\u_remote_rcv|data[7]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data[7]~3_combout\ = (\u_remote_rcv|data_temp\(15) & (!\u_remote_rcv|data_temp\(7) & (\u_remote_rcv|data_temp\(14) $ (\u_remote_rcv|data_temp\(6))))) # (!\u_remote_rcv|data_temp\(15) & (\u_remote_rcv|data_temp\(7) & 
-- (\u_remote_rcv|data_temp\(14) $ (\u_remote_rcv|data_temp\(6)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000011001100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data_temp\(15),
	datab => \u_remote_rcv|data_temp\(7),
	datac => \u_remote_rcv|data_temp\(14),
	datad => \u_remote_rcv|data_temp\(6),
	combout => \u_remote_rcv|data[7]~3_combout\);

-- Location: LCCOMB_X97_Y22_N2
\u_remote_rcv|data_temp~17\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp~17_combout\ = (\u_remote_rcv|data_temp\(14) & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data_temp\(14),
	datab => \u_remote_rcv|remote_in_d1~q\,
	datac => \u_remote_rcv|remote_in_d0~q\,
	combout => \u_remote_rcv|data_temp~17_combout\);

-- Location: FF_X97_Y22_N3
\u_remote_rcv|data_temp[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_temp~17_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_remote_rcv|data_temp[7]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(13));

-- Location: LCCOMB_X97_Y22_N16
\u_remote_rcv|data_temp~15\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp~15_combout\ = (\u_remote_rcv|data_temp\(13) & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|remote_in_d0~q\,
	datac => \u_remote_rcv|data_temp\(13),
	datad => \u_remote_rcv|remote_in_d1~q\,
	combout => \u_remote_rcv|data_temp~15_combout\);

-- Location: FF_X97_Y22_N17
\u_remote_rcv|data_temp[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_temp~15_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_remote_rcv|data_temp[7]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(12));

-- Location: LCCOMB_X97_Y22_N12
\u_remote_rcv|data_temp~13\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp~13_combout\ = (\u_remote_rcv|data_temp\(12) & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|remote_in_d1~q\,
	datab => \u_remote_rcv|data_temp\(12),
	datac => \u_remote_rcv|remote_in_d0~q\,
	combout => \u_remote_rcv|data_temp~13_combout\);

-- Location: FF_X97_Y22_N13
\u_remote_rcv|data_temp[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_temp~13_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_remote_rcv|data_temp[7]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(11));

-- Location: LCCOMB_X97_Y22_N20
\u_remote_rcv|data_temp~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp~11_combout\ = (\u_remote_rcv|data_temp\(11) & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|remote_in_d1~q\,
	datac => \u_remote_rcv|remote_in_d0~q\,
	datad => \u_remote_rcv|data_temp\(11),
	combout => \u_remote_rcv|data_temp~11_combout\);

-- Location: FF_X97_Y22_N21
\u_remote_rcv|data_temp[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_temp~11_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_remote_rcv|data_temp[7]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(10));

-- Location: LCCOMB_X97_Y22_N22
\u_remote_rcv|data_temp~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp~9_combout\ = (\u_remote_rcv|data_temp\(10) & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|data_temp\(10),
	datac => \u_remote_rcv|remote_in_d0~q\,
	datad => \u_remote_rcv|remote_in_d1~q\,
	combout => \u_remote_rcv|data_temp~9_combout\);

-- Location: FF_X97_Y22_N23
\u_remote_rcv|data_temp[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_temp~9_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_remote_rcv|data_temp[7]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(9));

-- Location: LCCOMB_X97_Y22_N24
\u_remote_rcv|data_temp~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data_temp~8_combout\ = (\u_remote_rcv|data_temp\(9) & ((\u_remote_rcv|remote_in_d1~q\) # (!\u_remote_rcv|remote_in_d0~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|remote_in_d0~q\,
	datab => \u_remote_rcv|remote_in_d1~q\,
	datad => \u_remote_rcv|data_temp\(9),
	combout => \u_remote_rcv|data_temp~8_combout\);

-- Location: FF_X97_Y22_N25
\u_remote_rcv|data_temp[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data_temp~8_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_remote_rcv|data_temp[7]~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data_temp\(8));

-- Location: LCCOMB_X97_Y22_N26
\u_remote_rcv|data[7]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data[7]~0_combout\ = (\u_remote_rcv|data_temp\(0) & (!\u_remote_rcv|data_temp\(8) & (\u_remote_rcv|data_temp\(1) $ (\u_remote_rcv|data_temp\(9))))) # (!\u_remote_rcv|data_temp\(0) & (\u_remote_rcv|data_temp\(8) & (\u_remote_rcv|data_temp\(1) 
-- $ (\u_remote_rcv|data_temp\(9)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000011001100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data_temp\(0),
	datab => \u_remote_rcv|data_temp\(8),
	datac => \u_remote_rcv|data_temp\(1),
	datad => \u_remote_rcv|data_temp\(9),
	combout => \u_remote_rcv|data[7]~0_combout\);

-- Location: LCCOMB_X98_Y22_N0
\u_remote_rcv|data[7]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data[7]~2_combout\ = (\u_remote_rcv|data_temp\(12) & (!\u_remote_rcv|data_temp\(4) & (\u_remote_rcv|data_temp\(5) $ (\u_remote_rcv|data_temp\(13))))) # (!\u_remote_rcv|data_temp\(12) & (\u_remote_rcv|data_temp\(4) & 
-- (\u_remote_rcv|data_temp\(5) $ (\u_remote_rcv|data_temp\(13)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000011001100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data_temp\(12),
	datab => \u_remote_rcv|data_temp\(4),
	datac => \u_remote_rcv|data_temp\(5),
	datad => \u_remote_rcv|data_temp\(13),
	combout => \u_remote_rcv|data[7]~2_combout\);

-- Location: LCCOMB_X98_Y22_N26
\u_remote_rcv|data[7]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data[7]~4_combout\ = (\u_remote_rcv|data[7]~1_combout\ & (\u_remote_rcv|data[7]~3_combout\ & (\u_remote_rcv|data[7]~0_combout\ & \u_remote_rcv|data[7]~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data[7]~1_combout\,
	datab => \u_remote_rcv|data[7]~3_combout\,
	datac => \u_remote_rcv|data[7]~0_combout\,
	datad => \u_remote_rcv|data[7]~2_combout\,
	combout => \u_remote_rcv|data[7]~4_combout\);

-- Location: LCCOMB_X98_Y22_N16
\u_remote_rcv|data[7]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data[7]~5_combout\ = (\u_remote_rcv|cur_state.st_rec_data~q\ & (\u_remote_rcv|data[7]~4_combout\ & \u_remote_rcv|Selector3~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|cur_state.st_rec_data~q\,
	datac => \u_remote_rcv|data[7]~4_combout\,
	datad => \u_remote_rcv|Selector3~0_combout\,
	combout => \u_remote_rcv|data[7]~5_combout\);

-- Location: FF_X100_Y22_N3
\u_remote_rcv|data[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data[1]~feeder_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_remote_rcv|data[7]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data\(1));

-- Location: FF_X98_Y21_N25
\u_remote_rcv|data[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	asdata => \u_remote_rcv|data_temp\(4),
	clrn => \sys_rst_n~input_o\,
	sload => VCC,
	ena => \u_remote_rcv|data[7]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data\(4));

-- Location: LCCOMB_X102_Y21_N0
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[1]~0_combout\ = \u_remote_rcv|data\(5) $ (VCC)
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[1]~1\ = CARRY(\u_remote_rcv|data\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data\(5),
	datad => VCC,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[1]~0_combout\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[1]~1\);

-- Location: LCCOMB_X102_Y21_N2
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[2]~2_combout\ = (\u_remote_rcv|data\(6) & (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[1]~1\ & VCC)) # (!\u_remote_rcv|data\(6) & 
-- (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[1]~1\))
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[2]~3\ = CARRY((!\u_remote_rcv|data\(6) & !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[1]~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data\(6),
	datad => VCC,
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[1]~1\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[2]~2_combout\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[2]~3\);

-- Location: LCCOMB_X102_Y21_N4
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[3]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[3]~4_combout\ = (\u_remote_rcv|data\(7) & (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[2]~3\ $ (GND))) # (!\u_remote_rcv|data\(7) & 
-- (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[2]~3\ & VCC))
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[3]~5\ = CARRY((\u_remote_rcv|data\(7) & !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[2]~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data\(7),
	datad => VCC,
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[2]~3\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[3]~4_combout\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[3]~5\);

-- Location: LCCOMB_X102_Y21_N6
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[4]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[4]~7_cout\ = CARRY(!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[3]~5\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => VCC,
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[3]~5\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[4]~7_cout\);

-- Location: LCCOMB_X102_Y21_N8
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ = \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[4]~7_cout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\);

-- Location: LCCOMB_X102_Y21_N14
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~39\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~39_combout\ = (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[2]~2_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~39_combout\);

-- Location: LCCOMB_X101_Y21_N6
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~41\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~41_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[1]~0_combout\ & !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[1]~0_combout\,
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~41_combout\);

-- Location: LCCOMB_X102_Y21_N10
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[75]~43\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[75]~43_combout\ = (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & \u_remote_rcv|data\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datad => \u_remote_rcv|data\(4),
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[75]~43_combout\);

-- Location: LCCOMB_X102_Y21_N16
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[1]~0_combout\ = (((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[75]~42_combout\) # (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[75]~43_combout\)))
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[1]~1\ = CARRY((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[75]~42_combout\) # (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[75]~43_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[75]~42_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[75]~43_combout\,
	datad => VCC,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[1]~0_combout\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[1]~1\);

-- Location: LCCOMB_X102_Y21_N18
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[2]~2_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[1]~1\ & (((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~40_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~41_combout\)))) # (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[1]~1\ & (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~40_combout\ & 
-- (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~41_combout\)))
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[2]~3\ = CARRY((!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~40_combout\ & (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~41_combout\ & 
-- !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~40_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[76]~41_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[1]~1\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[2]~2_combout\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[2]~3\);

-- Location: LCCOMB_X102_Y21_N20
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[3]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[3]~4_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[2]~3\ & (((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~38_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~39_combout\)))) # (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[2]~3\ & ((((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~38_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~39_combout\)))))
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[3]~5\ = CARRY((!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[2]~3\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~38_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~39_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~38_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[77]~39_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[2]~3\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[3]~4_combout\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[3]~5\);

-- Location: LCCOMB_X102_Y21_N28
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[78]~37\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[78]~37_combout\ = (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[3]~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[3]~4_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[78]~37_combout\);

-- Location: LCCOMB_X102_Y21_N22
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[4]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[4]~7_cout\ = CARRY((!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[78]~36_combout\ & (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[78]~37_combout\ & 
-- !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[78]~36_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[78]~37_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[3]~5\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[4]~7_cout\);

-- Location: LCCOMB_X102_Y21_N24
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ = \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[4]~7_cout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\);

-- Location: LCCOMB_X101_Y21_N0
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[83]~44\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[83]~44_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[3]~4_combout\ & !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[3]~4_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[83]~44_combout\);

-- Location: LCCOMB_X101_Y21_N18
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~45\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~45_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[2]~2_combout\ & !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[2]~2_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~45_combout\);

-- Location: LCCOMB_X101_Y21_N8
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~46\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~46_combout\ = (\u_remote_rcv|data\(4) & \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_remote_rcv|data\(4),
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~46_combout\);

-- Location: FF_X98_Y21_N1
\u_remote_rcv|data[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	asdata => \u_remote_rcv|data_temp\(3),
	clrn => \sys_rst_n~input_o\,
	sload => VCC,
	ena => \u_remote_rcv|data[7]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data\(3));

-- Location: LCCOMB_X101_Y21_N2
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[80]~49\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[80]~49_combout\ = (\u_remote_rcv|data\(3) & !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_remote_rcv|data\(3),
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[80]~49_combout\);

-- Location: LCCOMB_X101_Y21_N22
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[1]~0_combout\ = (((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[80]~48_combout\) # (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[80]~49_combout\)))
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[1]~1\ = CARRY((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[80]~48_combout\) # (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[80]~49_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[80]~48_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[80]~49_combout\,
	datad => VCC,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[1]~0_combout\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[1]~1\);

-- Location: LCCOMB_X101_Y21_N24
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[2]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[2]~2_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[1]~1\ & (((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~47_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~46_combout\)))) # (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[1]~1\ & (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~47_combout\ & 
-- (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~46_combout\)))
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[2]~3\ = CARRY((!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~47_combout\ & (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~46_combout\ & 
-- !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~47_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[81]~46_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[1]~1\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[2]~2_combout\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[2]~3\);

-- Location: LCCOMB_X101_Y21_N28
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[4]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[4]~7_cout\ = CARRY((!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[83]~67_combout\ & (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[83]~44_combout\ & 
-- !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[83]~67_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[83]~44_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[3]~5\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[4]~7_cout\);

-- Location: LCCOMB_X101_Y21_N30
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ = \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[4]~7_cout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\);

-- Location: LCCOMB_X100_Y21_N18
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~69\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~69_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ & 
-- (\u_remote_rcv|data\(4))) # (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	datab => \u_remote_rcv|data\(4),
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[1]~0_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~69_combout\);

-- Location: FF_X97_Y21_N1
\u_remote_rcv|data[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	asdata => \u_remote_rcv|data_temp\(5),
	clrn => \sys_rst_n~input_o\,
	sload => VCC,
	ena => \u_remote_rcv|data[7]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data\(5));

-- Location: LCCOMB_X101_Y21_N4
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~68\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~68_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & 
-- (\u_remote_rcv|data\(5))) # (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[5]~8_combout\,
	datab => \u_remote_rcv|data\(5),
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_15_result_int[1]~0_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~68_combout\);

-- Location: LCCOMB_X100_Y21_N14
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[88]~65\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[88]~65_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~68_combout\) # 
-- ((!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\ & \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[5]~8_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_16_result_int[2]~2_combout\,
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[82]~68_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[88]~65_combout\);

-- Location: LCCOMB_X100_Y21_N24
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~52\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~52_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ & \u_remote_rcv|data\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	datad => \u_remote_rcv|data\(3),
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[86]~52_combout\);

-- Location: LCCOMB_X100_Y21_N28
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[85]~54\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[85]~54_combout\ = (\u_remote_rcv|data\(2) & \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data\(2),
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[85]~54_combout\);

-- Location: LCCOMB_X100_Y21_N0
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[1]~0_combout\ = (((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[85]~55_combout\) # (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[85]~54_combout\)))
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[1]~1\ = CARRY((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[85]~55_combout\) # (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[85]~54_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[85]~55_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[85]~54_combout\,
	datad => VCC,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[1]~0_combout\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[1]~1\);

-- Location: LCCOMB_X100_Y21_N6
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[4]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[4]~7_cout\ = CARRY((!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[88]~50_combout\ & (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[88]~65_combout\ & 
-- !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[88]~50_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[88]~65_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[3]~5\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[4]~7_cout\);

-- Location: LCCOMB_X100_Y21_N8
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ = \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[4]~7_cout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\);

-- Location: LCCOMB_X100_Y21_N12
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[93]~66\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[93]~66_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~69_combout\) # 
-- ((!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ & \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[87]~69_combout\,
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[2]~2_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[93]~66_combout\);

-- Location: LCCOMB_X99_Y21_N0
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~70\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~70_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ & 
-- (\u_remote_rcv|data\(3))) # (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[5]~8_combout\,
	datab => \u_remote_rcv|data\(3),
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_17_result_int[1]~0_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~70_combout\);

-- Location: LCCOMB_X100_Y21_N16
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~61\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~61_combout\ = (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ & \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[1]~0_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[91]~61_combout\);

-- Location: LCCOMB_X99_Y21_N4
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[90]~57\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[90]~57_combout\ = (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\ & \u_remote_rcv|data\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_18_result_int[5]~8_combout\,
	datad => \u_remote_rcv|data\(1),
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[90]~57_combout\);

-- Location: LCCOMB_X99_Y21_N18
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[1]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[1]~0_combout\ = (((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[90]~56_combout\) # (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[90]~57_combout\)))
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[1]~1\ = CARRY((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[90]~56_combout\) # (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[90]~57_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[90]~56_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[90]~57_combout\,
	datad => VCC,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[1]~0_combout\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[1]~1\);

-- Location: LCCOMB_X99_Y21_N22
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[3]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[3]~4_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[2]~3\ & (((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~59_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~70_combout\)))) # (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[2]~3\ & ((((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~59_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~70_combout\)))))
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[3]~5\ = CARRY((!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[2]~3\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~59_combout\) # 
-- (\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~70_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~59_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~70_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[2]~3\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[3]~4_combout\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[3]~5\);

-- Location: LCCOMB_X99_Y21_N24
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[4]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[4]~7_cout\ = CARRY((!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[93]~58_combout\ & (!\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[93]~66_combout\ & 
-- !\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[93]~58_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[93]~66_combout\,
	datad => VCC,
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[3]~5\,
	cout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[4]~7_cout\);

-- Location: LCCOMB_X99_Y21_N26
\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[5]~8\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\ = \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[4]~7_cout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\);

-- Location: LCCOMB_X99_Y21_N6
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[96]~62\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[96]~62_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\ & (\u_remote_rcv|data\(1))) # 
-- (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[1]~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|data\(1),
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[1]~0_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[96]~62_combout\);

-- Location: FF_X99_Y21_N7
\u_seg_led|num[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[96]~62_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num\(1));

-- Location: LCCOMB_X103_Y20_N6
\u_seg_led|Mux2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mux2~0_combout\ = (\u_seg_led|cnt_sel\(1) & (((\u_seg_led|cnt_sel\(0))))) # (!\u_seg_led|cnt_sel\(1) & ((\u_seg_led|cnt_sel\(0) & (\u_seg_led|num\(5))) # (!\u_seg_led|cnt_sel\(0) & ((\u_seg_led|num\(1))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num\(5),
	datab => \u_seg_led|cnt_sel\(1),
	datac => \u_seg_led|num\(1),
	datad => \u_seg_led|cnt_sel\(0),
	combout => \u_seg_led|Mux2~0_combout\);

-- Location: LCCOMB_X103_Y20_N18
\u_seg_led|Mux2~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mux2~1_combout\ = (\u_seg_led|cnt_sel\(1) & ((\u_seg_led|Mux2~0_combout\ & ((\u_seg_led|num\(13)))) # (!\u_seg_led|Mux2~0_combout\ & (\u_seg_led|num\(9))))) # (!\u_seg_led|cnt_sel\(1) & (((\u_seg_led|Mux2~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num\(9),
	datab => \u_seg_led|num\(13),
	datac => \u_seg_led|cnt_sel\(1),
	datad => \u_seg_led|Mux2~0_combout\,
	combout => \u_seg_led|Mux2~1_combout\);

-- Location: LCCOMB_X103_Y20_N8
\u_seg_led|Mux2~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mux2~2_combout\ = (\u_seg_led|cnt_sel\(2) & (\u_seg_led|num\(13) & (!\u_seg_led|cnt_sel\(1)))) # (!\u_seg_led|cnt_sel\(2) & (((\u_seg_led|Mux2~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110100001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt_sel\(2),
	datab => \u_seg_led|num\(13),
	datac => \u_seg_led|cnt_sel\(1),
	datad => \u_seg_led|Mux2~1_combout\,
	combout => \u_seg_led|Mux2~2_combout\);

-- Location: FF_X103_Y20_N9
\u_seg_led|num_disp[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|Mux2~2_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num_disp\(1));

-- Location: LCCOMB_X99_Y21_N14
\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[98]~64\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[98]~64_combout\ = (\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\ & ((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~59_combout\) # 
-- ((\u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~70_combout\)))) # (!\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\ & 
-- (((\u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[3]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~59_combout\,
	datab => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[92]~70_combout\,
	datac => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[5]~8_combout\,
	datad => \u_seg_led|Mod0|auto_generated|divider|divider|add_sub_19_result_int[3]~4_combout\,
	combout => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[98]~64_combout\);

-- Location: FF_X99_Y21_N15
\u_seg_led|num[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|Mod0|auto_generated|divider|divider|StageOut[98]~64_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num\(3));

-- Location: LCCOMB_X103_Y20_N26
\u_seg_led|Mux0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mux0~0_combout\ = (\u_seg_led|cnt_sel\(0) & (((\u_seg_led|cnt_sel\(1))))) # (!\u_seg_led|cnt_sel\(0) & ((\u_seg_led|cnt_sel\(1) & (\u_seg_led|num\(11))) # (!\u_seg_led|cnt_sel\(1) & ((\u_seg_led|num\(3))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num\(11),
	datab => \u_seg_led|cnt_sel\(0),
	datac => \u_seg_led|cnt_sel\(1),
	datad => \u_seg_led|num\(3),
	combout => \u_seg_led|Mux0~0_combout\);

-- Location: LCCOMB_X103_Y20_N0
\u_seg_led|Mux0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mux0~1_combout\ = (\u_seg_led|cnt_sel\(0) & ((\u_seg_led|Mux0~0_combout\ & ((\u_seg_led|num\(13)))) # (!\u_seg_led|Mux0~0_combout\ & (\u_seg_led|num\(7))))) # (!\u_seg_led|cnt_sel\(0) & (((\u_seg_led|Mux0~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100000111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num\(7),
	datab => \u_seg_led|cnt_sel\(0),
	datac => \u_seg_led|Mux0~0_combout\,
	datad => \u_seg_led|num\(13),
	combout => \u_seg_led|Mux0~1_combout\);

-- Location: LCCOMB_X103_Y20_N10
\u_seg_led|Mux0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mux0~2_combout\ = (\u_seg_led|cnt_sel\(2) & (\u_seg_led|num\(13) & (!\u_seg_led|cnt_sel\(1)))) # (!\u_seg_led|cnt_sel\(2) & (((\u_seg_led|Mux0~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110100001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|cnt_sel\(2),
	datab => \u_seg_led|num\(13),
	datac => \u_seg_led|cnt_sel\(1),
	datad => \u_seg_led|Mux0~1_combout\,
	combout => \u_seg_led|Mux0~2_combout\);

-- Location: FF_X103_Y20_N11
\u_seg_led|num_disp[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|Mux0~2_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num_disp\(3));

-- Location: FF_X97_Y21_N7
\u_remote_rcv|data[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	asdata => \u_remote_rcv|data_temp\(6),
	clrn => \sys_rst_n~input_o\,
	sload => VCC,
	ena => \u_remote_rcv|data[7]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data\(6));

-- Location: LCCOMB_X100_Y20_N14
\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[2]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[2]~0_combout\ = \u_remote_rcv|data\(3) $ (VCC)
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[2]~1\ = CARRY(\u_remote_rcv|data\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|data\(3),
	datad => VCC,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[2]~0_combout\,
	cout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[2]~1\);

-- Location: LCCOMB_X100_Y20_N16
\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[3]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[3]~2_combout\ = (\u_remote_rcv|data\(4) & (\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[2]~1\ & VCC)) # (!\u_remote_rcv|data\(4) & 
-- (!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[2]~1\))
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[3]~3\ = CARRY((!\u_remote_rcv|data\(4) & !\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[2]~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|data\(4),
	datad => VCC,
	cin => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[2]~1\,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[3]~2_combout\,
	cout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[3]~3\);

-- Location: LCCOMB_X100_Y20_N20
\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[5]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[5]~6_combout\ = (\u_remote_rcv|data\(6) & (!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[4]~5\)) # (!\u_remote_rcv|data\(6) & 
-- ((\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[4]~5\) # (GND)))
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[5]~7\ = CARRY((!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[4]~5\) # (!\u_remote_rcv|data\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_remote_rcv|data\(6),
	datad => VCC,
	cin => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[4]~5\,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[5]~6_combout\,
	cout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[5]~7\);

-- Location: LCCOMB_X100_Y20_N24
\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[7]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[7]~11_cout\ = CARRY(!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[6]~9\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => VCC,
	cin => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[6]~9\,
	cout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[7]~11_cout\);

-- Location: LCCOMB_X100_Y20_N26
\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\ = \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[7]~11_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[7]~11_cout\,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\);

-- Location: LCCOMB_X100_Y20_N6
\u_seg_led|Div1|auto_generated|divider|divider|StageOut[150]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|StageOut[150]~1_combout\ = (\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[6]~8_combout\ & !\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[6]~8_combout\,
	datac => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[150]~1_combout\);

-- Location: LCCOMB_X100_Y20_N30
\u_seg_led|Div1|auto_generated|divider|divider|StageOut[149]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|StageOut[149]~3_combout\ = (!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\ & \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[5]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\,
	datad => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[5]~6_combout\,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[149]~3_combout\);

-- Location: LCCOMB_X100_Y20_N28
\u_seg_led|Div1|auto_generated|divider|divider|StageOut[148]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|StageOut[148]~4_combout\ = (\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\ & \u_remote_rcv|data\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\,
	datad => \u_remote_rcv|data\(5),
	combout => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[148]~4_combout\);

-- Location: LCCOMB_X100_Y20_N4
\u_seg_led|Div1|auto_generated|divider|divider|StageOut[147]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|StageOut[147]~7_combout\ = (!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\ & \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[3]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\,
	datad => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[3]~2_combout\,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[147]~7_combout\);

-- Location: LCCOMB_X101_Y20_N14
\u_seg_led|Div1|auto_generated|divider|divider|StageOut[146]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|StageOut[146]~9_combout\ = (!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\ & \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[2]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\,
	datad => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[2]~0_combout\,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[146]~9_combout\);

-- Location: LCCOMB_X100_Y22_N28
\u_remote_rcv|data[2]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|data[2]~feeder_combout\ = \u_remote_rcv|data_temp\(2)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_remote_rcv|data_temp\(2),
	combout => \u_remote_rcv|data[2]~feeder_combout\);

-- Location: FF_X100_Y22_N29
\u_remote_rcv|data[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|data[2]~feeder_combout\,
	clrn => \sys_rst_n~input_o\,
	ena => \u_remote_rcv|data[7]~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|data\(2));

-- Location: LCCOMB_X101_Y20_N0
\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[1]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[1]~14_combout\ = \u_remote_rcv|data\(2)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_remote_rcv|data\(2),
	combout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[1]~14_combout\);

-- Location: LCCOMB_X101_Y20_N2
\u_seg_led|Div1|auto_generated|divider|divider|StageOut[145]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|StageOut[145]~11_combout\ = (!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\ & \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[1]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[8]~12_combout\,
	datad => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_18_result_int[1]~14_combout\,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[145]~11_combout\);

-- Location: LCCOMB_X101_Y20_N18
\u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[2]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[2]~1_cout\ = CARRY((\u_seg_led|Div1|auto_generated|divider|divider|StageOut[145]~10_combout\) # (\u_seg_led|Div1|auto_generated|divider|divider|StageOut[145]~11_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[145]~10_combout\,
	datab => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[145]~11_combout\,
	datad => VCC,
	cout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[2]~1_cout\);

-- Location: LCCOMB_X101_Y20_N20
\u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[3]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[3]~3_cout\ = CARRY((!\u_seg_led|Div1|auto_generated|divider|divider|StageOut[146]~8_combout\ & (!\u_seg_led|Div1|auto_generated|divider|divider|StageOut[146]~9_combout\ & 
-- !\u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[2]~1_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[146]~8_combout\,
	datab => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[146]~9_combout\,
	datad => VCC,
	cin => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[2]~1_cout\,
	cout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[3]~3_cout\);

-- Location: LCCOMB_X101_Y20_N22
\u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[4]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[4]~5_cout\ = CARRY((\u_seg_led|Div1|auto_generated|divider|divider|StageOut[147]~6_combout\) # ((\u_seg_led|Div1|auto_generated|divider|divider|StageOut[147]~7_combout\) # 
-- (!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[3]~3_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[147]~6_combout\,
	datab => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[147]~7_combout\,
	datad => VCC,
	cin => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[3]~3_cout\,
	cout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[4]~5_cout\);

-- Location: LCCOMB_X101_Y20_N24
\u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[5]~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[5]~7_cout\ = CARRY(((!\u_seg_led|Div1|auto_generated|divider|divider|StageOut[148]~5_combout\ & !\u_seg_led|Div1|auto_generated|divider|divider|StageOut[148]~4_combout\)) # 
-- (!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[4]~5_cout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[148]~5_combout\,
	datab => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[148]~4_combout\,
	datad => VCC,
	cin => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[4]~5_cout\,
	cout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[5]~7_cout\);

-- Location: LCCOMB_X101_Y20_N26
\u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[6]~9\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[6]~9_cout\ = CARRY((!\u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[5]~7_cout\ & ((\u_seg_led|Div1|auto_generated|divider|divider|StageOut[149]~2_combout\) # 
-- (\u_seg_led|Div1|auto_generated|divider|divider|StageOut[149]~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[149]~2_combout\,
	datab => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[149]~3_combout\,
	datad => VCC,
	cin => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[5]~7_cout\,
	cout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[6]~9_cout\);

-- Location: LCCOMB_X101_Y20_N28
\u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[7]~11\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[7]~11_cout\ = CARRY((!\u_seg_led|Div1|auto_generated|divider|divider|StageOut[150]~0_combout\ & (!\u_seg_led|Div1|auto_generated|divider|divider|StageOut[150]~1_combout\ & 
-- !\u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[6]~9_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[150]~0_combout\,
	datab => \u_seg_led|Div1|auto_generated|divider|divider|StageOut[150]~1_combout\,
	datad => VCC,
	cin => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[6]~9_cout\,
	cout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[7]~11_cout\);

-- Location: LCCOMB_X101_Y20_N30
\u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[8]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[8]~12_combout\ = \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[7]~11_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[7]~11_cout\,
	combout => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[8]~12_combout\);

-- Location: LCCOMB_X103_Y20_N16
\u_seg_led|num[8]~6\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|num[8]~6_combout\ = !\u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[8]~12_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_seg_led|Div1|auto_generated|divider|divider|add_sub_19_result_int[8]~12_combout\,
	combout => \u_seg_led|num[8]~6_combout\);

-- Location: FF_X103_Y20_N17
\u_seg_led|num[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|num[8]~6_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num\(8));

-- Location: LCCOMB_X103_Y20_N22
\u_seg_led|Mux3~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mux3~0_combout\ = (\u_seg_led|cnt_sel\(1) & (((\u_seg_led|num\(8)) # (\u_seg_led|cnt_sel\(0))))) # (!\u_seg_led|cnt_sel\(1) & (\u_seg_led|num\(0) & ((!\u_seg_led|cnt_sel\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num\(0),
	datab => \u_seg_led|num\(8),
	datac => \u_seg_led|cnt_sel\(1),
	datad => \u_seg_led|cnt_sel\(0),
	combout => \u_seg_led|Mux3~0_combout\);

-- Location: LCCOMB_X103_Y20_N14
\u_seg_led|Mux3~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|Mux3~1_combout\ = (!\u_seg_led|cnt_sel\(2) & ((\u_seg_led|Mux3~0_combout\ & ((!\u_seg_led|cnt_sel\(0)))) # (!\u_seg_led|Mux3~0_combout\ & (\u_seg_led|num\(4) & \u_seg_led|cnt_sel\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num\(4),
	datab => \u_seg_led|cnt_sel\(2),
	datac => \u_seg_led|Mux3~0_combout\,
	datad => \u_seg_led|cnt_sel\(0),
	combout => \u_seg_led|Mux3~1_combout\);

-- Location: FF_X103_Y20_N15
\u_seg_led|num_disp[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|Mux3~1_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|num_disp\(0));

-- Location: LCCOMB_X105_Y20_N0
\u_seg_led|WideOr11~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|WideOr11~0_combout\ = (\u_seg_led|num_disp\(1) & (!\u_seg_led|num_disp\(2) & (\u_seg_led|num_disp\(3)))) # (!\u_seg_led|num_disp\(1) & (!\u_seg_led|num_disp\(3) & (\u_seg_led|num_disp\(2) $ (\u_seg_led|num_disp\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000101000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num_disp\(2),
	datab => \u_seg_led|num_disp\(1),
	datac => \u_seg_led|num_disp\(3),
	datad => \u_seg_led|num_disp\(0),
	combout => \u_seg_led|WideOr11~0_combout\);

-- Location: FF_X105_Y20_N1
\u_seg_led|seg_led[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|WideOr11~0_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|seg_led\(0));

-- Location: LCCOMB_X105_Y20_N14
\u_seg_led|WideOr10~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|WideOr10~0_combout\ = (\u_seg_led|num_disp\(2) & (!\u_seg_led|num_disp\(3) & (\u_seg_led|num_disp\(1) $ (\u_seg_led|num_disp\(0))))) # (!\u_seg_led|num_disp\(2) & (\u_seg_led|num_disp\(1) & (\u_seg_led|num_disp\(3))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100001001001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num_disp\(2),
	datab => \u_seg_led|num_disp\(1),
	datac => \u_seg_led|num_disp\(3),
	datad => \u_seg_led|num_disp\(0),
	combout => \u_seg_led|WideOr10~0_combout\);

-- Location: FF_X105_Y20_N15
\u_seg_led|seg_led[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|WideOr10~0_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|seg_led\(1));

-- Location: LCCOMB_X105_Y20_N28
\u_seg_led|WideOr9~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|WideOr9~0_combout\ = (!\u_seg_led|num_disp\(2) & (\u_seg_led|num_disp\(1) & ((\u_seg_led|num_disp\(3)) # (!\u_seg_led|num_disp\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num_disp\(2),
	datab => \u_seg_led|num_disp\(1),
	datac => \u_seg_led|num_disp\(3),
	datad => \u_seg_led|num_disp\(0),
	combout => \u_seg_led|WideOr9~0_combout\);

-- Location: FF_X105_Y20_N29
\u_seg_led|seg_led[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|WideOr9~0_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|seg_led\(2));

-- Location: LCCOMB_X105_Y20_N22
\u_seg_led|WideOr8~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|WideOr8~0_combout\ = (\u_seg_led|num_disp\(2) & (!\u_seg_led|num_disp\(3) & (\u_seg_led|num_disp\(1) $ (!\u_seg_led|num_disp\(0))))) # (!\u_seg_led|num_disp\(2) & ((\u_seg_led|num_disp\(1) & (\u_seg_led|num_disp\(3))) # 
-- (!\u_seg_led|num_disp\(1) & (!\u_seg_led|num_disp\(3) & \u_seg_led|num_disp\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100100101000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num_disp\(2),
	datab => \u_seg_led|num_disp\(1),
	datac => \u_seg_led|num_disp\(3),
	datad => \u_seg_led|num_disp\(0),
	combout => \u_seg_led|WideOr8~0_combout\);

-- Location: FF_X105_Y20_N23
\u_seg_led|seg_led[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|WideOr8~0_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|seg_led\(3));

-- Location: LCCOMB_X105_Y20_N20
\u_seg_led|WideOr7~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|WideOr7~0_combout\ = (\u_seg_led|num_disp\(2) & (!\u_seg_led|num_disp\(3) & ((\u_seg_led|num_disp\(0)) # (!\u_seg_led|num_disp\(1))))) # (!\u_seg_led|num_disp\(2) & ((\u_seg_led|num_disp\(0)) # ((\u_seg_led|num_disp\(1) & 
-- \u_seg_led|num_disp\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111101000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num_disp\(2),
	datab => \u_seg_led|num_disp\(1),
	datac => \u_seg_led|num_disp\(3),
	datad => \u_seg_led|num_disp\(0),
	combout => \u_seg_led|WideOr7~0_combout\);

-- Location: FF_X105_Y20_N21
\u_seg_led|seg_led[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|WideOr7~0_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|seg_led\(4));

-- Location: LCCOMB_X105_Y20_N18
\u_seg_led|WideOr6~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|WideOr6~0_combout\ = (\u_seg_led|num_disp\(2) & (\u_seg_led|num_disp\(1) & (!\u_seg_led|num_disp\(3) & \u_seg_led|num_disp\(0)))) # (!\u_seg_led|num_disp\(2) & ((\u_seg_led|num_disp\(1)) # ((!\u_seg_led|num_disp\(3) & 
-- \u_seg_led|num_disp\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100110101000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num_disp\(2),
	datab => \u_seg_led|num_disp\(1),
	datac => \u_seg_led|num_disp\(3),
	datad => \u_seg_led|num_disp\(0),
	combout => \u_seg_led|WideOr6~0_combout\);

-- Location: FF_X105_Y20_N19
\u_seg_led|seg_led[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|WideOr6~0_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|seg_led\(5));

-- Location: LCCOMB_X105_Y20_N12
\u_seg_led|WideOr5~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_seg_led|WideOr5~0_combout\ = (\u_seg_led|num_disp\(1) & ((\u_seg_led|num_disp\(0) & (!\u_seg_led|num_disp\(2))) # (!\u_seg_led|num_disp\(0) & ((!\u_seg_led|num_disp\(3)))))) # (!\u_seg_led|num_disp\(1) & (\u_seg_led|num_disp\(2) $ 
-- ((\u_seg_led|num_disp\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101011000011110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_seg_led|num_disp\(2),
	datab => \u_seg_led|num_disp\(1),
	datac => \u_seg_led|num_disp\(3),
	datad => \u_seg_led|num_disp\(0),
	combout => \u_seg_led|WideOr5~0_combout\);

-- Location: FF_X105_Y20_N13
\u_seg_led|seg_led[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_seg_led|ALT_INV_dri_clk~clkctrl_outclk\,
	d => \u_seg_led|WideOr5~0_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_seg_led|seg_led\(6));

-- Location: IOIBUF_X0_Y36_N15
\sys_clk~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_sys_clk,
	o => \sys_clk~input_o\);

-- Location: CLKCTRL_G4
\sys_clk~inputclkctrl\ : cycloneive_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \sys_clk~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \sys_clk~inputclkctrl_outclk\);

-- Location: LCCOMB_X92_Y24_N16
\u_remote_rcv|repeat_en~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_remote_rcv|repeat_en~0_combout\ = (\u_remote_rcv|remote_in_d0~q\ & (!\u_remote_rcv|remote_in_d1~q\ & \u_remote_rcv|cur_state.st_repeat_code~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_remote_rcv|remote_in_d0~q\,
	datac => \u_remote_rcv|remote_in_d1~q\,
	datad => \u_remote_rcv|cur_state.st_repeat_code~q\,
	combout => \u_remote_rcv|repeat_en~0_combout\);

-- Location: FF_X92_Y24_N17
\u_remote_rcv|repeat_en\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \u_remote_rcv|div_clk~clkctrl_outclk\,
	d => \u_remote_rcv|repeat_en~0_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_remote_rcv|repeat_en~q\);

-- Location: LCCOMB_X92_Y24_N2
\u_led_ctrl|repeat_en_d0~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|repeat_en_d0~feeder_combout\ = \u_remote_rcv|repeat_en~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_remote_rcv|repeat_en~q\,
	combout => \u_led_ctrl|repeat_en_d0~feeder_combout\);

-- Location: FF_X92_Y24_N3
\u_led_ctrl|repeat_en_d0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|repeat_en_d0~feeder_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|repeat_en_d0~q\);

-- Location: LCCOMB_X92_Y24_N8
\u_led_ctrl|repeat_en_d1~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|repeat_en_d1~feeder_combout\ = \u_led_ctrl|repeat_en_d0~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_led_ctrl|repeat_en_d0~q\,
	combout => \u_led_ctrl|repeat_en_d1~feeder_combout\);

-- Location: FF_X92_Y24_N9
\u_led_ctrl|repeat_en_d1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|repeat_en_d1~feeder_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|repeat_en_d1~q\);

-- Location: LCCOMB_X92_Y24_N10
\u_led_ctrl|pos_repeat_en\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|pos_repeat_en~combout\ = (!\u_led_ctrl|repeat_en_d1~q\ & \u_led_ctrl|repeat_en_d0~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \u_led_ctrl|repeat_en_d1~q\,
	datad => \u_led_ctrl|repeat_en_d0~q\,
	combout => \u_led_ctrl|pos_repeat_en~combout\);

-- Location: LCCOMB_X91_Y25_N10
\u_led_ctrl|led_cnt[0]~25\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[0]~25_combout\ = \u_led_ctrl|led_cnt\(0) $ (VCC)
-- \u_led_ctrl|led_cnt[0]~26\ = CARRY(\u_led_ctrl|led_cnt\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(0),
	datad => VCC,
	combout => \u_led_ctrl|led_cnt[0]~25_combout\,
	cout => \u_led_ctrl|led_cnt[0]~26\);

-- Location: LCCOMB_X91_Y25_N12
\u_led_ctrl|led_cnt[1]~27\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[1]~27_combout\ = (\u_led_ctrl|led_cnt\(1) & (\u_led_ctrl|led_cnt[0]~26\ & VCC)) # (!\u_led_ctrl|led_cnt\(1) & (!\u_led_ctrl|led_cnt[0]~26\))
-- \u_led_ctrl|led_cnt[1]~28\ = CARRY((!\u_led_ctrl|led_cnt\(1) & !\u_led_ctrl|led_cnt[0]~26\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(1),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[0]~26\,
	combout => \u_led_ctrl|led_cnt[1]~27_combout\,
	cout => \u_led_ctrl|led_cnt[1]~28\);

-- Location: LCCOMB_X91_Y25_N14
\u_led_ctrl|led_cnt[2]~29\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[2]~29_combout\ = (\u_led_ctrl|led_cnt\(2) & ((GND) # (!\u_led_ctrl|led_cnt[1]~28\))) # (!\u_led_ctrl|led_cnt\(2) & (\u_led_ctrl|led_cnt[1]~28\ $ (GND)))
-- \u_led_ctrl|led_cnt[2]~30\ = CARRY((\u_led_ctrl|led_cnt\(2)) # (!\u_led_ctrl|led_cnt[1]~28\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(2),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[1]~28\,
	combout => \u_led_ctrl|led_cnt[2]~29_combout\,
	cout => \u_led_ctrl|led_cnt[2]~30\);

-- Location: LCCOMB_X91_Y25_N8
\~GND\ : cycloneive_lcell_comb
-- Equation(s):
-- \~GND~combout\ = GND

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \~GND~combout\);

-- Location: LCCOMB_X91_Y24_N16
\u_led_ctrl|led_cnt[19]~63\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[19]~63_combout\ = (\u_led_ctrl|led_cnt\(19) & (\u_led_ctrl|led_cnt[18]~62\ & VCC)) # (!\u_led_ctrl|led_cnt\(19) & (!\u_led_ctrl|led_cnt[18]~62\))
-- \u_led_ctrl|led_cnt[19]~64\ = CARRY((!\u_led_ctrl|led_cnt\(19) & !\u_led_ctrl|led_cnt[18]~62\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(19),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[18]~62\,
	combout => \u_led_ctrl|led_cnt[19]~63_combout\,
	cout => \u_led_ctrl|led_cnt[19]~64\);

-- Location: LCCOMB_X91_Y24_N18
\u_led_ctrl|led_cnt[20]~65\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[20]~65_combout\ = (\u_led_ctrl|led_cnt\(20) & ((GND) # (!\u_led_ctrl|led_cnt[19]~64\))) # (!\u_led_ctrl|led_cnt\(20) & (\u_led_ctrl|led_cnt[19]~64\ $ (GND)))
-- \u_led_ctrl|led_cnt[20]~66\ = CARRY((\u_led_ctrl|led_cnt\(20)) # (!\u_led_ctrl|led_cnt[19]~64\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(20),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[19]~64\,
	combout => \u_led_ctrl|led_cnt[20]~65_combout\,
	cout => \u_led_ctrl|led_cnt[20]~66\);

-- Location: FF_X91_Y24_N19
\u_led_ctrl|led_cnt[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[20]~65_combout\,
	asdata => \~GND~combout\,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(20));

-- Location: LCCOMB_X91_Y24_N20
\u_led_ctrl|led_cnt[21]~67\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[21]~67_combout\ = (\u_led_ctrl|led_cnt\(21) & (\u_led_ctrl|led_cnt[20]~66\ & VCC)) # (!\u_led_ctrl|led_cnt\(21) & (!\u_led_ctrl|led_cnt[20]~66\))
-- \u_led_ctrl|led_cnt[21]~68\ = CARRY((!\u_led_ctrl|led_cnt\(21) & !\u_led_ctrl|led_cnt[20]~66\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(21),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[20]~66\,
	combout => \u_led_ctrl|led_cnt[21]~67_combout\,
	cout => \u_led_ctrl|led_cnt[21]~68\);

-- Location: FF_X91_Y24_N21
\u_led_ctrl|led_cnt[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[21]~67_combout\,
	asdata => \~GND~combout\,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(21));

-- Location: LCCOMB_X91_Y24_N22
\u_led_ctrl|led_cnt[22]~69\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[22]~69_combout\ = \u_led_ctrl|led_cnt\(22) $ (\u_led_ctrl|led_cnt[21]~68\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(22),
	cin => \u_led_ctrl|led_cnt[21]~68\,
	combout => \u_led_ctrl|led_cnt[22]~69_combout\);

-- Location: FF_X91_Y24_N23
\u_led_ctrl|led_cnt[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[22]~69_combout\,
	asdata => VCC,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(22));

-- Location: FF_X91_Y25_N13
\u_led_ctrl|led_cnt[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[1]~27_combout\,
	asdata => \~GND~combout\,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(1));

-- Location: LCCOMB_X92_Y24_N24
\u_led_ctrl|Equal0~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|Equal0~3_combout\ = (!\u_led_ctrl|led_cnt\(21) & (!\u_led_ctrl|led_cnt\(22) & (!\u_led_ctrl|led_cnt\(1) & !\u_led_ctrl|led_cnt\(20))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(21),
	datab => \u_led_ctrl|led_cnt\(22),
	datac => \u_led_ctrl|led_cnt\(1),
	datad => \u_led_ctrl|led_cnt\(20),
	combout => \u_led_ctrl|Equal0~3_combout\);

-- Location: LCCOMB_X91_Y25_N18
\u_led_ctrl|led_cnt[4]~33\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[4]~33_combout\ = (\u_led_ctrl|led_cnt\(4) & ((GND) # (!\u_led_ctrl|led_cnt[3]~32\))) # (!\u_led_ctrl|led_cnt\(4) & (\u_led_ctrl|led_cnt[3]~32\ $ (GND)))
-- \u_led_ctrl|led_cnt[4]~34\ = CARRY((\u_led_ctrl|led_cnt\(4)) # (!\u_led_ctrl|led_cnt[3]~32\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101010101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(4),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[3]~32\,
	combout => \u_led_ctrl|led_cnt[4]~33_combout\,
	cout => \u_led_ctrl|led_cnt[4]~34\);

-- Location: FF_X91_Y25_N19
\u_led_ctrl|led_cnt[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[4]~33_combout\,
	asdata => \~GND~combout\,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(4));

-- Location: LCCOMB_X91_Y25_N2
\u_led_ctrl|Equal0~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|Equal0~4_combout\ = (!\u_led_ctrl|led_cnt\(5) & (!\u_led_ctrl|led_cnt\(3) & (!\u_led_ctrl|led_cnt\(2) & !\u_led_ctrl|led_cnt\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(5),
	datab => \u_led_ctrl|led_cnt\(3),
	datac => \u_led_ctrl|led_cnt\(2),
	datad => \u_led_ctrl|led_cnt\(4),
	combout => \u_led_ctrl|Equal0~4_combout\);

-- Location: FF_X91_Y25_N11
\u_led_ctrl|led_cnt[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[0]~25_combout\,
	asdata => \~GND~combout\,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(0));

-- Location: LCCOMB_X91_Y25_N30
\u_led_ctrl|led_cnt[10]~45\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[10]~45_combout\ = (\u_led_ctrl|led_cnt\(10) & ((GND) # (!\u_led_ctrl|led_cnt[9]~44\))) # (!\u_led_ctrl|led_cnt\(10) & (\u_led_ctrl|led_cnt[9]~44\ $ (GND)))
-- \u_led_ctrl|led_cnt[10]~46\ = CARRY((\u_led_ctrl|led_cnt\(10)) # (!\u_led_ctrl|led_cnt[9]~44\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101010101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(10),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[9]~44\,
	combout => \u_led_ctrl|led_cnt[10]~45_combout\,
	cout => \u_led_ctrl|led_cnt[10]~46\);

-- Location: FF_X91_Y25_N31
\u_led_ctrl|led_cnt[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[10]~45_combout\,
	asdata => \~GND~combout\,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(10));

-- Location: LCCOMB_X92_Y24_N4
\u_led_ctrl|Equal0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|Equal0~0_combout\ = (!\u_led_ctrl|led_cnt\(11) & (!\u_led_ctrl|led_cnt\(13) & (!\u_led_ctrl|led_cnt\(10) & !\u_led_ctrl|led_cnt\(12))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(11),
	datab => \u_led_ctrl|led_cnt\(13),
	datac => \u_led_ctrl|led_cnt\(10),
	datad => \u_led_ctrl|led_cnt\(12),
	combout => \u_led_ctrl|Equal0~0_combout\);

-- Location: LCCOMB_X91_Y25_N24
\u_led_ctrl|led_cnt[7]~39\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[7]~39_combout\ = (\u_led_ctrl|led_cnt\(7) & (\u_led_ctrl|led_cnt[6]~38\ & VCC)) # (!\u_led_ctrl|led_cnt\(7) & (!\u_led_ctrl|led_cnt[6]~38\))
-- \u_led_ctrl|led_cnt[7]~40\ = CARRY((!\u_led_ctrl|led_cnt\(7) & !\u_led_ctrl|led_cnt[6]~38\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(7),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[6]~38\,
	combout => \u_led_ctrl|led_cnt[7]~39_combout\,
	cout => \u_led_ctrl|led_cnt[7]~40\);

-- Location: FF_X91_Y25_N25
\u_led_ctrl|led_cnt[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[7]~39_combout\,
	asdata => \~GND~combout\,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(7));

-- Location: LCCOMB_X91_Y25_N4
\u_led_ctrl|Equal0~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|Equal0~1_combout\ = (!\u_led_ctrl|led_cnt\(8) & (!\u_led_ctrl|led_cnt\(6) & !\u_led_ctrl|led_cnt\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(8),
	datac => \u_led_ctrl|led_cnt\(6),
	datad => \u_led_ctrl|led_cnt\(7),
	combout => \u_led_ctrl|Equal0~1_combout\);

-- Location: LCCOMB_X92_Y24_N18
\u_led_ctrl|Equal0~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|Equal0~2_combout\ = (!\u_led_ctrl|led_cnt\(0) & (\u_led_ctrl|Equal0~0_combout\ & \u_led_ctrl|Equal0~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(0),
	datac => \u_led_ctrl|Equal0~0_combout\,
	datad => \u_led_ctrl|Equal0~1_combout\,
	combout => \u_led_ctrl|Equal0~2_combout\);

-- Location: LCCOMB_X92_Y24_N28
\u_led_ctrl|Equal0~7\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|Equal0~7_combout\ = (\u_led_ctrl|Equal0~6_combout\ & (\u_led_ctrl|Equal0~3_combout\ & (\u_led_ctrl|Equal0~4_combout\ & \u_led_ctrl|Equal0~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|Equal0~6_combout\,
	datab => \u_led_ctrl|Equal0~3_combout\,
	datac => \u_led_ctrl|Equal0~4_combout\,
	datad => \u_led_ctrl|Equal0~2_combout\,
	combout => \u_led_ctrl|Equal0~7_combout\);

-- Location: LCCOMB_X92_Y24_N26
\u_led_ctrl|led_cnt[4]~71\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[4]~71_combout\ = ((\u_led_ctrl|repeat_en_d0~q\ & !\u_led_ctrl|repeat_en_d1~q\)) # (!\u_led_ctrl|Equal0~7_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|repeat_en_d0~q\,
	datac => \u_led_ctrl|repeat_en_d1~q\,
	datad => \u_led_ctrl|Equal0~7_combout\,
	combout => \u_led_ctrl|led_cnt[4]~71_combout\);

-- Location: FF_X91_Y25_N15
\u_led_ctrl|led_cnt[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[2]~29_combout\,
	asdata => \~GND~combout\,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(2));

-- Location: LCCOMB_X91_Y25_N16
\u_led_ctrl|led_cnt[3]~31\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[3]~31_combout\ = (\u_led_ctrl|led_cnt\(3) & (\u_led_ctrl|led_cnt[2]~30\ & VCC)) # (!\u_led_ctrl|led_cnt\(3) & (!\u_led_ctrl|led_cnt[2]~30\))
-- \u_led_ctrl|led_cnt[3]~32\ = CARRY((!\u_led_ctrl|led_cnt\(3) & !\u_led_ctrl|led_cnt[2]~30\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(3),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[2]~30\,
	combout => \u_led_ctrl|led_cnt[3]~31_combout\,
	cout => \u_led_ctrl|led_cnt[3]~32\);

-- Location: FF_X91_Y25_N17
\u_led_ctrl|led_cnt[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[3]~31_combout\,
	asdata => \~GND~combout\,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(3));

-- Location: LCCOMB_X91_Y25_N20
\u_led_ctrl|led_cnt[5]~35\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[5]~35_combout\ = (\u_led_ctrl|led_cnt\(5) & (\u_led_ctrl|led_cnt[4]~34\ & VCC)) # (!\u_led_ctrl|led_cnt\(5) & (!\u_led_ctrl|led_cnt[4]~34\))
-- \u_led_ctrl|led_cnt[5]~36\ = CARRY((!\u_led_ctrl|led_cnt\(5) & !\u_led_ctrl|led_cnt[4]~34\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(5),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[4]~34\,
	combout => \u_led_ctrl|led_cnt[5]~35_combout\,
	cout => \u_led_ctrl|led_cnt[5]~36\);

-- Location: FF_X91_Y25_N21
\u_led_ctrl|led_cnt[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[5]~35_combout\,
	asdata => \~GND~combout\,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(5));

-- Location: LCCOMB_X91_Y25_N22
\u_led_ctrl|led_cnt[6]~37\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[6]~37_combout\ = (\u_led_ctrl|led_cnt\(6) & ((GND) # (!\u_led_ctrl|led_cnt[5]~36\))) # (!\u_led_ctrl|led_cnt\(6) & (\u_led_ctrl|led_cnt[5]~36\ $ (GND)))
-- \u_led_ctrl|led_cnt[6]~38\ = CARRY((\u_led_ctrl|led_cnt\(6)) # (!\u_led_ctrl|led_cnt[5]~36\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(6),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[5]~36\,
	combout => \u_led_ctrl|led_cnt[6]~37_combout\,
	cout => \u_led_ctrl|led_cnt[6]~38\);

-- Location: FF_X91_Y25_N23
\u_led_ctrl|led_cnt[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[6]~37_combout\,
	asdata => VCC,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(6));

-- Location: LCCOMB_X91_Y25_N26
\u_led_ctrl|led_cnt[8]~41\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[8]~41_combout\ = (\u_led_ctrl|led_cnt\(8) & ((GND) # (!\u_led_ctrl|led_cnt[7]~40\))) # (!\u_led_ctrl|led_cnt\(8) & (\u_led_ctrl|led_cnt[7]~40\ $ (GND)))
-- \u_led_ctrl|led_cnt[8]~42\ = CARRY((\u_led_ctrl|led_cnt\(8)) # (!\u_led_ctrl|led_cnt[7]~40\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(8),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[7]~40\,
	combout => \u_led_ctrl|led_cnt[8]~41_combout\,
	cout => \u_led_ctrl|led_cnt[8]~42\);

-- Location: FF_X91_Y25_N27
\u_led_ctrl|led_cnt[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[8]~41_combout\,
	asdata => VCC,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(8));

-- Location: LCCOMB_X91_Y25_N28
\u_led_ctrl|led_cnt[9]~43\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[9]~43_combout\ = (\u_led_ctrl|led_cnt\(9) & (\u_led_ctrl|led_cnt[8]~42\ & VCC)) # (!\u_led_ctrl|led_cnt\(9) & (!\u_led_ctrl|led_cnt[8]~42\))
-- \u_led_ctrl|led_cnt[9]~44\ = CARRY((!\u_led_ctrl|led_cnt\(9) & !\u_led_ctrl|led_cnt[8]~42\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(9),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[8]~42\,
	combout => \u_led_ctrl|led_cnt[9]~43_combout\,
	cout => \u_led_ctrl|led_cnt[9]~44\);

-- Location: LCCOMB_X91_Y24_N28
\u_led_ctrl|led_cnt[9]~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[9]~feeder_combout\ = \u_led_ctrl|led_cnt[9]~43_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \u_led_ctrl|led_cnt[9]~43_combout\,
	combout => \u_led_ctrl|led_cnt[9]~feeder_combout\);

-- Location: FF_X91_Y24_N29
\u_led_ctrl|led_cnt[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[9]~feeder_combout\,
	asdata => VCC,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(9));

-- Location: LCCOMB_X91_Y24_N0
\u_led_ctrl|led_cnt[11]~47\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[11]~47_combout\ = (\u_led_ctrl|led_cnt\(11) & (\u_led_ctrl|led_cnt[10]~46\ & VCC)) # (!\u_led_ctrl|led_cnt\(11) & (!\u_led_ctrl|led_cnt[10]~46\))
-- \u_led_ctrl|led_cnt[11]~48\ = CARRY((!\u_led_ctrl|led_cnt\(11) & !\u_led_ctrl|led_cnt[10]~46\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(11),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[10]~46\,
	combout => \u_led_ctrl|led_cnt[11]~47_combout\,
	cout => \u_led_ctrl|led_cnt[11]~48\);

-- Location: FF_X91_Y24_N1
\u_led_ctrl|led_cnt[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[11]~47_combout\,
	asdata => VCC,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(11));

-- Location: LCCOMB_X91_Y24_N2
\u_led_ctrl|led_cnt[12]~49\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[12]~49_combout\ = (\u_led_ctrl|led_cnt\(12) & ((GND) # (!\u_led_ctrl|led_cnt[11]~48\))) # (!\u_led_ctrl|led_cnt\(12) & (\u_led_ctrl|led_cnt[11]~48\ $ (GND)))
-- \u_led_ctrl|led_cnt[12]~50\ = CARRY((\u_led_ctrl|led_cnt\(12)) # (!\u_led_ctrl|led_cnt[11]~48\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(12),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[11]~48\,
	combout => \u_led_ctrl|led_cnt[12]~49_combout\,
	cout => \u_led_ctrl|led_cnt[12]~50\);

-- Location: FF_X91_Y24_N3
\u_led_ctrl|led_cnt[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[12]~49_combout\,
	asdata => \~GND~combout\,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(12));

-- Location: LCCOMB_X91_Y24_N4
\u_led_ctrl|led_cnt[13]~51\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[13]~51_combout\ = (\u_led_ctrl|led_cnt\(13) & (\u_led_ctrl|led_cnt[12]~50\ & VCC)) # (!\u_led_ctrl|led_cnt\(13) & (!\u_led_ctrl|led_cnt[12]~50\))
-- \u_led_ctrl|led_cnt[13]~52\ = CARRY((!\u_led_ctrl|led_cnt\(13) & !\u_led_ctrl|led_cnt[12]~50\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(13),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[12]~50\,
	combout => \u_led_ctrl|led_cnt[13]~51_combout\,
	cout => \u_led_ctrl|led_cnt[13]~52\);

-- Location: FF_X91_Y24_N5
\u_led_ctrl|led_cnt[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[13]~51_combout\,
	asdata => \~GND~combout\,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(13));

-- Location: LCCOMB_X91_Y24_N8
\u_led_ctrl|led_cnt[15]~55\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[15]~55_combout\ = (\u_led_ctrl|led_cnt\(15) & (\u_led_ctrl|led_cnt[14]~54\ & VCC)) # (!\u_led_ctrl|led_cnt\(15) & (!\u_led_ctrl|led_cnt[14]~54\))
-- \u_led_ctrl|led_cnt[15]~56\ = CARRY((!\u_led_ctrl|led_cnt\(15) & !\u_led_ctrl|led_cnt[14]~54\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(15),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[14]~54\,
	combout => \u_led_ctrl|led_cnt[15]~55_combout\,
	cout => \u_led_ctrl|led_cnt[15]~56\);

-- Location: FF_X91_Y24_N9
\u_led_ctrl|led_cnt[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[15]~55_combout\,
	asdata => \~GND~combout\,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(15));

-- Location: LCCOMB_X91_Y24_N12
\u_led_ctrl|led_cnt[17]~59\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[17]~59_combout\ = (\u_led_ctrl|led_cnt\(17) & (\u_led_ctrl|led_cnt[16]~58\ & VCC)) # (!\u_led_ctrl|led_cnt\(17) & (!\u_led_ctrl|led_cnt[16]~58\))
-- \u_led_ctrl|led_cnt[17]~60\ = CARRY((!\u_led_ctrl|led_cnt\(17) & !\u_led_ctrl|led_cnt[16]~58\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(17),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[16]~58\,
	combout => \u_led_ctrl|led_cnt[17]~59_combout\,
	cout => \u_led_ctrl|led_cnt[17]~60\);

-- Location: LCCOMB_X91_Y24_N14
\u_led_ctrl|led_cnt[18]~61\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led_cnt[18]~61_combout\ = (\u_led_ctrl|led_cnt\(18) & ((GND) # (!\u_led_ctrl|led_cnt[17]~60\))) # (!\u_led_ctrl|led_cnt\(18) & (\u_led_ctrl|led_cnt[17]~60\ $ (GND)))
-- \u_led_ctrl|led_cnt[18]~62\ = CARRY((\u_led_ctrl|led_cnt\(18)) # (!\u_led_ctrl|led_cnt[17]~60\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \u_led_ctrl|led_cnt\(18),
	datad => VCC,
	cin => \u_led_ctrl|led_cnt[17]~60\,
	combout => \u_led_ctrl|led_cnt[18]~61_combout\,
	cout => \u_led_ctrl|led_cnt[18]~62\);

-- Location: FF_X91_Y24_N15
\u_led_ctrl|led_cnt[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[18]~61_combout\,
	asdata => VCC,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(18));

-- Location: FF_X91_Y24_N17
\u_led_ctrl|led_cnt[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[19]~63_combout\,
	asdata => VCC,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(19));

-- Location: FF_X91_Y24_N13
\u_led_ctrl|led_cnt[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led_cnt[17]~59_combout\,
	asdata => \~GND~combout\,
	clrn => \sys_rst_n~input_o\,
	sload => \u_led_ctrl|pos_repeat_en~combout\,
	ena => \u_led_ctrl|led_cnt[4]~71_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led_cnt\(17));

-- Location: LCCOMB_X91_Y24_N24
\u_led_ctrl|led~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led~0_combout\ = (\u_led_ctrl|led_cnt\(16) & (\u_led_ctrl|led_cnt\(19) & (\u_led_ctrl|led_cnt\(18) & \u_led_ctrl|led_cnt\(17))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(16),
	datab => \u_led_ctrl|led_cnt\(19),
	datac => \u_led_ctrl|led_cnt\(18),
	datad => \u_led_ctrl|led_cnt\(17),
	combout => \u_led_ctrl|led~0_combout\);

-- Location: LCCOMB_X92_Y24_N14
\u_led_ctrl|led~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led~1_combout\ = (\u_led_ctrl|led_cnt\(14) & (((\u_led_ctrl|led_cnt\(9) & !\u_led_ctrl|Equal0~1_combout\)) # (!\u_led_ctrl|Equal0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101010001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(14),
	datab => \u_led_ctrl|led_cnt\(9),
	datac => \u_led_ctrl|Equal0~0_combout\,
	datad => \u_led_ctrl|Equal0~1_combout\,
	combout => \u_led_ctrl|led~1_combout\);

-- Location: LCCOMB_X92_Y24_N20
\u_led_ctrl|led~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led~2_combout\ = (\u_led_ctrl|Equal0~7_combout\) # ((\u_led_ctrl|led~0_combout\ & ((\u_led_ctrl|led_cnt\(15)) # (\u_led_ctrl|led~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|led_cnt\(15),
	datab => \u_led_ctrl|led~0_combout\,
	datac => \u_led_ctrl|led~1_combout\,
	datad => \u_led_ctrl|Equal0~7_combout\,
	combout => \u_led_ctrl|led~2_combout\);

-- Location: LCCOMB_X92_Y24_N0
\u_led_ctrl|led~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \u_led_ctrl|led~3_combout\ = (\u_led_ctrl|pos_repeat_en~combout\) # ((\u_led_ctrl|led~q\ & ((\u_led_ctrl|led~2_combout\) # (!\u_led_ctrl|Equal0~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011011100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \u_led_ctrl|Equal0~8_combout\,
	datab => \u_led_ctrl|pos_repeat_en~combout\,
	datac => \u_led_ctrl|led~q\,
	datad => \u_led_ctrl|led~2_combout\,
	combout => \u_led_ctrl|led~3_combout\);

-- Location: FF_X92_Y24_N1
\u_led_ctrl|led\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \sys_clk~inputclkctrl_outclk\,
	d => \u_led_ctrl|led~3_combout\,
	clrn => \sys_rst_n~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \u_led_ctrl|led~q\);

ww_sel(0) <= \sel[0]~output_o\;

ww_sel(1) <= \sel[1]~output_o\;

ww_sel(2) <= \sel[2]~output_o\;

ww_sel(3) <= \sel[3]~output_o\;

ww_sel(4) <= \sel[4]~output_o\;

ww_sel(5) <= \sel[5]~output_o\;

ww_seg_led(0) <= \seg_led[0]~output_o\;

ww_seg_led(1) <= \seg_led[1]~output_o\;

ww_seg_led(2) <= \seg_led[2]~output_o\;

ww_seg_led(3) <= \seg_led[3]~output_o\;

ww_seg_led(4) <= \seg_led[4]~output_o\;

ww_seg_led(5) <= \seg_led[5]~output_o\;

ww_seg_led(6) <= \seg_led[6]~output_o\;

ww_seg_led(7) <= \seg_led[7]~output_o\;

ww_led <= \led~output_o\;
END structure;


