library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity segment is
    port (clk : in std_logic;
          rst_n : in std_logic;
          data : in std_logic_vector(7 downto 0);
          
          segcode1:out std_logic_vector(6 downto 0);
          segcode0:out std_logic_vector(6 downto 0));
end segment;

architecture bhv of segment is
begin
process(clk,rst_n,data)
begin
    if rising_edge(clk) then
            case data is
                when "00001111" => segcode1 <= "1000000";	--0x0F A
                                   segcode0 <= "0001110";
                when "00010011" => segcode1 <= "1111001";	--0x13 B
                                   segcode0 <= "0110000";
                when "00010000" => segcode1 <= "1111001";	--(...)
                                   segcode0 <= "1000000";
                when "00010010" => segcode1 <= "1111001";
                                   segcode0 <= "0100100";
                when "00000001" => segcode1 <= "1000000";
                                   segcode0 <= "1111001";
                when "00000010" => segcode1 <= "1000000";
                                   segcode0 <= "0100100";
                when "00000011" => segcode1 <= "1000000";
                                   segcode0 <= "0110000";
                when "00011010" => segcode1 <= "1111001";
                                   segcode0 <= "0001000";
                when "00000100" => segcode1 <= "1000000";
                                   segcode0 <= "0011001";
                when "00000101" => segcode1 <= "1000000";
                                   segcode0 <= "0010010";
                when "00000110" => segcode1 <= "1000000";
                                   segcode0 <= "0000010";
                when "00011110" => segcode1 <= "1111001";
                                   segcode0 <= "0000110";
                when "00000111" => segcode1 <= "1000000";
                                   segcode0 <= "1111000";
                when "00001000" => segcode1 <= "1000000";
                                   segcode0 <= "0000000";
                when "00001001" => segcode1 <= "1000000";
                                   segcode0 <= "0010000";
                when "00011011" => segcode1 <= "1111001";
                                   segcode0 <= "0000011";
                when "00010001" => segcode1 <= "1111001";
                                   segcode0 <= "1111001";
                when "00000000" => segcode1 <= "1000000";
                                   segcode0 <= "1000000";
                when "00010111" => segcode1 <= "1111001";
                                   segcode0 <= "1111000";
                when "00011111" => segcode1 <= "1111001";
                                   segcode0 <= "0001110";
                when "00010110" => segcode1 <= "1111001";
                                   segcode0 <= "0000010";
                when "00010100" => segcode1 <= "1111001";
                                   segcode0 <= "0011001";
                when "00011000" => segcode1 <= "1111001";
                                   segcode0 <= "0000000";
                when "00001100" => segcode1 <= "1000000";
                                   segcode0 <= "1000110";
                when others     => segcode1 <= "0001001";	--HH 体现错误输入
                                   segcode0 <= "0001001";
            end case;
    end if;
end process;
end bhv;

