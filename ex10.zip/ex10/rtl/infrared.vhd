library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity infrared is
    port (  sys_clk : in std_logic;
            sys_rst_n_in : in std_logic;
            remote_in : in std_logic;
            segcode1out : out std_logic_vector(6 downto 0);
            segcode0out : out std_logic_vector(6 downto 0);
            led : out std_logic;
            leds_out : out std_logic_vector(11 downto 0));
end infrared;

architecture bhv of infrared is
component infrared_rcv is
    port (sys_clk : in std_logic;
          sys_rst_n : in std_logic;
          
          remote_in : in std_logic; -- 红外接收信号
          repeat_en : out std_logic; -- 重复码有效信号
          data : out std_logic_vector(7 downto 0)); -- 红外控制码
end component;

component led_ctrl is
    port (sys_clk : in std_logic;
          sys_rst_n : in std_logic;
          repeat_en : in std_logic; -- 重复码触发信号
          data : in std_logic_vector(7 downto 0);
          
          led : out std_logic;
          leds : out std_logic_vector(11 downto 0));
end component;

component segment is
    port (clk : in std_logic;
          rst_n : in std_logic;
          data : in std_logic_vector(7 downto 0);
          
          segcode1:out std_logic_vector(6 downto 0);
          segcode0:out std_logic_vector(6 downto 0));
end component;

signal data_wire : std_logic_vector(7 downto 0);
signal repeat_en_wire : std_logic;

begin
    U1: infrared_rcv port map (sys_clk=>sys_clk,
                               sys_rst_n=>sys_rst_n_in,
                               remote_in=>remote_in,
                               repeat_en=>repeat_en_wire,
                               data=>data_wire);
    U2: led_ctrl port map (sys_clk=>sys_clk,
                           sys_rst_n=>sys_rst_n_in,
                           repeat_en=>repeat_en_wire,
                           data=>data_wire,
                           led=>led,
                           leds=>leds_out);
    U3: segment port map (clk=>sys_clk,
                          rst_n=>sys_rst_n_in,
                          data=>data_wire,
                          segcode1=>segcode1out,
                          segcode0=>segcode0out);
end bhv;