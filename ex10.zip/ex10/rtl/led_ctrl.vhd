library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity led_ctrl is
    port (sys_clk : in std_logic;
          sys_rst_n : in std_logic;
          repeat_en : in std_logic; -- 重复码触发信号
          data : in std_logic_vector(7 downto 0);
          
          led : out std_logic; --信号有效显示灯-LED12
          leds : out std_logic_vector(11 downto 0)); --控制led亮灭
end led_ctrl;

architecture bhv of led_ctrl is
signal repeat_en_d0 : std_logic;
signal repeat_en_d1 : std_logic;
signal led_cnt : std_logic_vector(22 downto 0);
signal leds_wire : std_logic_vector(11 downto 0);
signal last_leds_wire : std_logic_vector(11 downto 0);

signal pos_repeat_en : std_logic;

begin
    pos_repeat_en <= (not repeat_en_d1) and repeat_en_d0;
    --repeat_en信号打拍采沿
    process(sys_clk,sys_rst_n)
    begin
        if rising_edge(sys_clk) then
            if sys_rst_n = '0' then
                repeat_en_d0 <= '0';
                repeat_en_d1 <= '0';
            else 
                repeat_en_d0 <= repeat_en;
                repeat_en_d1 <= repeat_en_d0;
            end if;
        end if;
    end process;
    --控制信号显示有效灯
    process(sys_clk,sys_rst_n)
    begin
        if rising_edge(sys_clk) then
            if sys_rst_n = '0' then
                led_cnt <= (others => '0');
                led <= '0';
            else    
                if pos_repeat_en = '1' then
                    led_cnt <= "10011000100101101000000";
                    led <= '1';
                elsif led_cnt /= "00000000000000000000000" then
                    led_cnt <= led_cnt - '1';
                    if led_cnt < "00011110100001001000000" then
                        led <= '0';
                    end if;
                end if;
            end if;
        end if;
    end process;
    --控制led亮灭
    process(sys_clk,sys_rst_n,data,pos_repeat_en)
    begin
        if rising_edge(sys_clk) then
            if sys_rst_n = '0' then
                leds_wire <= (others => '0');
            elsif pos_repeat_en = '1' then
                case data is
                    when "00001111" => leds_wire <= "001000000000";     --A LEDR9亮 
                    when "00010011" => leds_wire <= "010000000000";		--B LEDR10亮
                    when "00010000" => leds_wire <= "100000000000";		--C LEDR11亮
						  
                    when "00010010" => leds_wire <= "111111111111";		--power对应全亮
						  
                    when "00000001" => leds_wire <= "000000000001";		--1对应LEDR0
                    when "00000010" => leds_wire <= "000000000010";		--2对应LEDR1
                    when "00000011" => leds_wire <= "000000000100";		--3
                    when "00000100" => leds_wire <= "000000001000";		--4
                    when "00000101" => leds_wire <= "000000010000";		--5
                    when "00000110" => leds_wire <= "000000100000";		--6
						  when "00000111" => leds_wire <= "000001000000";		--7
                    when "00001000" => leds_wire <= "000010000000";		--8
                    when "00001001" => leds_wire <= "000100000000";		--9
						  when "00000000" => leds_wire <= "000000000000";		--0 对应全灭
						  
                    when "00011110" => leds_wire <= '0' & last_leds_wire(11 downto 1); -- channel↓ 除以2
						  when "00011010" => leds_wire <= last_leds_wire(10 downto 0) & '0'; -- channel↑ 乘2
						  
                    
                    when "00011011" => leds_wire <= last_leds_wire + '1'; -- Volume↑ 加1
						  when "00011111" => leds_wire <= last_leds_wire - '1'; -- Volume↓减1
						  
                    when "00010111" => leds_wire <= last_leds_wire; 		--return 对应上一状态
   
                    when "00010100" => leds_wire <= last_leds_wire(10 downto 0) & last_leds_wire(11); --Adjust←左移
                    when "00011000" => leds_wire <= last_leds_wire(0) & last_leds_wire(11 downto 1);  --Adjust→右移
						  
                    when "00010001" => leds_wire <= null;					--menu 啥也不是
						  when "00010110" => leds_wire <= null;					--play 啥也不是
						  when "00001100" => leds_wire <= null;					--mute静音 啥也不是
						  
                    
                    when others     => leds_wire <= null;					--其他输入，不管
                end case;
					     last_leds_wire <= leds_wire;
            end if;
        end if;
    end process;
    --last_leds_wire <= leds_wire;
    leds <= leds_wire;
    
end bhv;