library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity infrared_rcv is
    port (sys_clk : in std_logic;
          sys_rst_n : in std_logic;
          
          remote_in : in std_logic; -- 红外接收信号
          repeat_en : out std_logic; -- 重复码有效信号
          data : out std_logic_vector(7 downto 0)); -- 红外控制码
end infrared_rcv;

architecture bhv of infrared_rcv is
    -- 状态机定义
    type state is ( st_idle, -- 空闲状态
                    st_start_low_9ms, -- 监测同步码低电平
                    st_start_judge, -- 判断重复码和同步码高电平(空闲信号)
                    st_rec_data, -- 接收数据
                    st_repeat_code); -- 重复码
    signal current_state : state := st_idle;
    signal next_state : state;

    signal div_cnt : std_logic_vector(11 downto 0); -- 分频计数器
    signal div_clk : std_logic; -- 分频时钟
    signal remote_in_d0 : std_logic; -- 对输入的红外信号延时打拍
    signal remote_in_d1 : std_logic;
    signal time_cnt : std_logic_vector(7 downto 0); -- 对红外的各个状态进行计数
    
    signal time_cnt_clr : std_logic; -- 计数器清零信号
    signal time_done : std_logic; -- 计时完成信号
    signal error_en : std_logic; -- 错误信号
    signal judge_flag : std_logic; -- 检测出的标志信号 0:同步码高电平(空闲信号)  1:重复码
    signal data_temp : std_logic_vector(15 downto 0); -- 暂存收到的控制码和控制反码
    signal data_cnt : std_logic_vector(5 downto 0); -- 对接收的数据进行计数 
    
    signal pos_remote_in : std_logic; -- 输入红外信号的上升沿
    signal neg_remote_in : std_logic; -- 输入红外信号的下降沿
    
begin
    -- 通过打两拍抓取红外信号上升和下降沿
    pos_remote_in <= (not remote_in_d1) and (remote_in_d0);
    neg_remote_in <= (remote_in_d1) and (not remote_in_d0);
    -- 时钟分频,50Mhz/(2*(3124+1))=8khz,T=0.125ms
    process(sys_clk,sys_rst_n)
    begin
        if rising_edge(sys_clk) then
            if div_cnt = "110000110100" then
                div_cnt <= (others => '0');
                div_clk <= not div_clk;
            else
                div_cnt <= div_cnt + '1';
            end if;
        end if;
    end process;
    -- 对输入的remote_in信号延时打拍
    process(div_clk,sys_rst_n)
    begin
        if rising_edge(div_clk) then
            if sys_rst_n = '0' then 
                remote_in_d0 <= '0';
                remote_in_d1 <= '0';
            else 
                remote_in_d0 <= remote_in;
                remote_in_d1 <= remote_in_d0;
            end if;
        end if;
    end process;
    -- 对红外的各个状态进行计数
    process(div_clk,sys_rst_n)
    begin
        if rising_edge(div_clk) then
            if sys_rst_n = '0' then 
                time_cnt <= (others => '0');
            elsif time_cnt_clr = '1' then
                time_cnt <= (others => '0');
            else
                time_cnt <= time_cnt + '1';
            end if;
        end if;
    end process;
    -- 状态机
    process(div_clk,sys_rst_n)
    begin
        if rising_edge(div_clk) then
            if sys_rst_n = '0' then
                current_state <= st_idle;
            else
                current_state <= next_state;
            end if;
        end if;
    end process;
    process(current_state,remote_in_d0,time_done,error_en,judge_flag,pos_remote_in,data_cnt)
    begin
        next_state <= st_idle;
        case current_state is
            when st_idle =>
                if remote_in_d0 = '0' then
                    next_state <= st_start_low_9ms;
                else
                    next_state <= st_idle;
                end if;
            when st_start_low_9ms =>
                if time_done = '1' then
                    next_state <= st_start_judge;
                elsif error_en = '1' then
                    next_state <= st_idle;
                else 
                    next_state <= st_start_low_9ms;
                end if;
            when st_start_judge =>
                if time_done = '1' then
                    if judge_flag = '0' then
                        next_state <= st_rec_data;
                    else
                        next_state <= st_repeat_code;
                    end if;
                elsif error_en = '1' then
                    next_state <= st_idle;
                else 
                    next_state <= st_start_judge;
                end if;
            when st_rec_data =>
                if pos_remote_in = '1' and data_cnt = "100000" then
                    next_state <= st_idle;
                else 
                    next_state <= st_rec_data;
                end if;
            when st_repeat_code =>
                if pos_remote_in = '1' then 
                    next_state <= st_idle;
                else
                    next_state <= st_repeat_code;
                end if;
            when others =>
                next_state <= st_idle;
        end case;
    end process;
    process(div_clk,sys_rst_n,current_state,remote_in_d0,pos_remote_in,time_cnt,neg_remote_in,pos_remote_in,data_cnt,data_temp)
    begin
        if rising_edge(div_clk) then
            if sys_rst_n = '0' then
                time_cnt_clr <= '0';
                time_done <= '0';
                error_en <= '0';
                judge_flag <= '0';
                data <= (others => '0');
                repeat_en <= '0';
                data_cnt <= (others => '0');
                data_temp <= (others => '0');
            else
                time_cnt_clr <= '0';
                time_done <= '0';
                error_en <= '0';
                repeat_en <= '0';
                case current_state is
                    when st_idle =>
                        time_cnt_clr <= '1';
                        if remote_in_d0 = '0' then
                            time_cnt_clr <= '0';
                        end if;
                    when st_start_low_9ms =>
                        if pos_remote_in = '1' then
                            time_cnt_clr <= '1';
                            if (time_cnt >= 69 and time_cnt <= 75) then
                                time_done <= '1';
                            else 
                                error_en <= '1';
                            end if;
                        end if;
                    when st_start_judge =>
                        if neg_remote_in = '1' then
                            time_cnt_clr <= '1';
                            --重复码高电平2.25ms 2.25/0.125 = 18
                            if (time_cnt>=15 and time_cnt<=20) then
                                time_done <= '1';
                                judge_flag <= '1';
                            --数据信号前的空闲信号4.5ms
                            elsif (time_cnt>=33 and time_cnt<=38) then
                                time_done <= '1';
                                judge_flag <= '0';
                            else 
                                error_en <= '1';
                            end if;
                        end if;
                    when st_rec_data =>
                        if pos_remote_in = '1' then
                            time_cnt_clr <= '1';
                            if data_cnt = "100000" then
                                data_cnt <= (others => '0');
                                data_temp <= (others => '0');
                                if (data_temp(7 downto 0)=not data_temp(15 downto 8)) then
                                    data <= data_temp(7 downto 0);
                                end if;
                            end if;
                        elsif neg_remote_in = '1' then
                            time_cnt_clr <= '1';
                            data_cnt <= data_cnt + '1';
                            if (data_cnt>="010000" and data_cnt<="011111") then
                                if (time_cnt>=2 and time_cnt<=6) then
                                    data_temp <= '0' & data_temp(15 downto 1);
                                elsif (time_cnt>=10 and time_cnt<=15) then
                                    data_temp <= '1' & data_temp(15 downto 1);
                                end if;
                            end if;
                        end if;
                    when st_repeat_code =>
                        if pos_remote_in = '1' then
                            time_cnt_clr <= '1';
                            repeat_en <= '1';
                        end if;
                    when others =>
                        null;
                end case;
            end if;
        end if;
    end process;
    
end bhv;