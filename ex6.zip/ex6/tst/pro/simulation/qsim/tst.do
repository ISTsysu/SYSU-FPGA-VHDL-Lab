onerror {quit -f}
vlib work
vlog -work work tst.vo
vlog -work work tst.vt
vsim -novopt -c -t 1ps -L cycloneive_ver -L altera_ver -L altera_mf_ver -L 220model_ver -L sgate work.vga_colorbar_vlg_vec_tst
vcd file -direction tst.msim.vcd
vcd add -internal vga_colorbar_vlg_vec_tst/*
vcd add -internal vga_colorbar_vlg_vec_tst/i1/*
add wave /*
run -all
