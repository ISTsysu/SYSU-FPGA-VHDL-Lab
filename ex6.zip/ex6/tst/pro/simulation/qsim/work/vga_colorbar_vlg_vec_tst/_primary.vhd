library verilog;
use verilog.vl_types.all;
entity vga_colorbar_vlg_vec_tst is
end vga_colorbar_vlg_vec_tst;
