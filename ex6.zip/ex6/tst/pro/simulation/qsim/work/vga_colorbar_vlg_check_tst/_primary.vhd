library verilog;
use verilog.vl_types.all;
entity vga_colorbar_vlg_check_tst is
    port(
        b               : in     vl_logic_vector(7 downto 0);
        blankout        : in     vl_logic;
        clk_out         : in     vl_logic;
        g               : in     vl_logic_vector(7 downto 0);
        hsync           : in     vl_logic;
        r               : in     vl_logic_vector(7 downto 0);
        syncout         : in     vl_logic;
        vsync           : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end vga_colorbar_vlg_check_tst;
