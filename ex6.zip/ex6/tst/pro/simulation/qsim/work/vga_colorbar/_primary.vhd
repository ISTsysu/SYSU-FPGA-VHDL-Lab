library verilog;
use verilog.vl_types.all;
entity vga_colorbar is
    port(
        sys_clk         : in     vl_logic;
        sys_rst_n       : in     vl_logic;
        hsync           : out    vl_logic;
        vsync           : out    vl_logic;
        r               : out    vl_logic_vector(7 downto 0);
        g               : out    vl_logic_vector(7 downto 0);
        b               : out    vl_logic_vector(7 downto 0);
        blankout        : out    vl_logic;
        syncout         : out    vl_logic;
        clk_out         : out    vl_logic
    );
end vga_colorbar;
