library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity VGA_Controller is
    Port (
        clk : in STD_LOGIC;  -- Pixel clock input
        reset : in STD_LOGIC;
        VGA_HS : out STD_LOGIC;
        VGA_VS : out STD_LOGIC;
        rgb : out STD_LOGIC_VECTOR(7 downto 0);
		  VGA_CLK:out std_logic;
		  VGA_SYNC_N:out std_logic;
		  VGA_BLANK_N：out std_logic;
        pixel_x : out INTEGER range 0 to 639;
        pixel_y : out INTEGER range 0 to 479
    );
end VGA_Controller;

architecture Behavioral of VGA_Controller is
    signal h_count : INTEGER range 0 to 799 := 0;
    signal v_count : INTEGER range 0 to 524 := 0;
begin
    process(clk, reset)
    begin
        if reset = '1' then
            h_count <= 0;
            v_count <= 0;
        elsif rising_edge(clk) then
            if h_count = 799 then
                h_count <= 0;
                if v_count = 524 then
                    v_count <= 0;
                else
                    v_count <= v_count + 1;
                end if;
            else
                h_count <= h_count + 1;
            end if;
        end if;
    end process;

    -- Generate sync pulses
    VGA_HS <= '0' when (h_count >= 640 + 16 and h_count < 640 + 16 + 96) else '1';
    VGA_VS <= '0' when (v_count >= 480 + 10 and v_count < 480 + 10 + 2) else '1';
	 VGA_SYNC_N<='0';
    -- Generate pixel coordinates
    pixel_x <= h_count when h_count < 640 else 0;
    pixel_y <= v_count when v_count < 480 else 0;

    -- RGB output
    process(h_count, v_count)
    begin
        if h_count < 640 and v_count < 480 then
            -- Define color output (example: simple color bars)
				VGA_BLANK_N<='1';
            if (h_count / 80) mod 2 = 0 then
                rgb <= "11100000";  -- Red
            else
                rgb <= "00011100";  -- Green
            end if;
        else
				VGA_BLANK_N<='0';
            rgb <= "00000000";  -- Black
        end if;
    end process;
	 VGA_CLK<=clk;
end Behavioral;
