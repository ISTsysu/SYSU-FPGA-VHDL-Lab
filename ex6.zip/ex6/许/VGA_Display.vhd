library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity VGA_Display is
    Port (
        clk : in STD_LOGIC;
        reset : in STD_LOGIC;
        hsync : out STD_LOGIC;
        vsync : out STD_LOGIC;
        rgb : out STD_LOGIC_VECTOR(7 downto 0)
		  VGA_CLK:out std_logic;
		  VGA_SYNC_N:out std_logic;
		  VGA_BLANK_N：out std_logic;
    );
end VGA_Display;

architecture Behavioral of VGA_Display is
    component VGA_Controller
        Port (
            clk : in STD_LOGIC;  -- Pixel clock input
        reset : in STD_LOGIC;
        VGA_HS : out STD_LOGIC;
        VGA_VS : out STD_LOGIC;
        rgb : out STD_LOGIC_VECTOR(7 downto 0);
		  VGA_CLK:out std_logic;
		  VGA_SYNC_N:out std_logic;
		  VGA_BLANK_N：out std_logic;
        pixel_x : out INTEGER range 0 to 639;
        pixel_y : out INTEGER range 0 to 479
        );
    end component;

    signal pixel_x, pixel_y : INTEGER range 0 to 639;
    signal current_rgb : STD_LOGIC_VECTOR(7 downto 0);

    type state_type is (color_bars, vertical_bars, grid);
    signal state : state_type := color_bars;
	 signal clk1:STD_LOGIC;
	 signal cnt:STD_LOGIC_VECTOR(1 DOWNTO 0):="00";
begin
	process(clk)
	begin
	if(clk'event and clk='1')then
			if(cnt = "11") then
				cnt <= (others => '0');
		   else
				cnt <= cnt + 1;
			end if;
	 end if;
	 clk1<=cnt(1);
end process;
    U1: VGA_Controller
        Port map (
            clk => clk1,
            reset => reset,
            VGA_HS => hsync,
            VGA_VS => vsync,
            rgb => current_rgb,
				VGA_SYNC_N=>VGA_SYNC_N,
				VGA_BLANK_N=>VGA_BLANK_N,
            pixel_x => pixel_x,
            pixel_y => pixel_y
        );

--    process(clk1, reset)
  --  begin
  --      if reset = '1' then
   --         state <= color_bars;
   --     elsif rising_edge(clk1) then
   --        case state is
   --             when color_bars =>
    --                -- Define color bars
    --                if pixel_x < 160 then
     --                   current_rgb <= "11100000"; -- Red
    --                elsif pixel_x < 320 then
     --                   current_rgb <= "00011100"; -- Green
     --               elsif pixel_x < 480 then
     --                   current_rgb <= "00000011"; -- Blue
     --               elsif pixel_x < 640 then
     --                   current_rgb <= "11111100"; -- Yellow
      --              end if;

     --           when vertical_bars =>
                    -- Define vertical bars
      --              if (pixel_x / 160) mod 2 = 0 then
     --                   current_rgb <= "11100000";  -- Red
     --               else
     --                   current_rgb <= "00011100";  -- Green
     --               end if;

      --          when grid =>
                    -- Define grid
       --             if (pixel_x / 64) mod 2 = 0 and (pixel_y / 64) mod 2 = 0 then
        --                current_rgb <= "00000000";  -- Black
       --             else
       --                 current_rgb <= "11111111";  -- White
      --              end if;
--
       --         when others =>
      --              current_rgb <= "00000000";  -- Default to black
       --     end case;
       -- end if;
  --  end process;

    -- Output RGB
    rgb <= current_rgb;

end Behavioral;
