library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity vga_display is
    port ( clk : in std_logic;
           reset : in std_logic;
           key1,key2 : in std_logic;
           
           pixel_xpos : in std_logic_vector(9 downto 0);--像素点横坐标
           pixel_ypos : in std_logic_vector(9 downto 0);--像素点纵坐标
           pixel_data : out std_logic_vector(23 downto 0));--像素点数据
end vga_display;

architecture Behavioral of vga_display is
    constant h_disp : integer := 640; --分辨率——行
    constant v_disp : integer := 480; --分辨率——列
    constant white  : std_logic_vector(23 downto 0) := "111111111111111111111111";--rgb888白色
    constant black  : std_logic_vector(23 downto 0) := "000000000000000000000000";--rgb888黑色
    constant red    : std_logic_vector(23 downto 0) := "111111110000000000000000";--rgb888红色
    constant green  : std_logic_vector(23 downto 0) := "000000001111111100000000";--rgb888绿色
    constant blue   : std_logic_vector(23 downto 0) := "000000000000000011111111";--rgb888蓝色
    
begin
    process(clk,reset)
    begin
        if rising_edge(clk) then
            if reset = '0' then
                pixel_data <= "000000000000000000000000";
            else
                if key1 = '0' and key2 = '0' then
                    if (pixel_xpos >= "0000000000") and (pixel_xpos < (h_disp/5)*1) then
                        pixel_data <= white;
                    elsif (pixel_xpos >= (h_disp/5)*1)and(pixel_xpos < (h_disp/5)*2) then
                        pixel_data <= black;
                    elsif (pixel_xpos >= (h_disp/5)*2)and(pixel_xpos < (h_disp/5)*3) then
                        pixel_data <= red;
                    elsif (pixel_xpos >= (h_disp/5)*3)and(pixel_xpos < (h_disp/5)*4) then
                        pixel_data <= green;
                    else
                        pixel_data <= blue;
                    end if;
                elsif key1 = '0' and key2 = '1' then
                    if (pixel_ypos >= "0000000000") and (pixel_ypos < (v_disp/5)*1) then
                        pixel_data <= white;
                    elsif (pixel_ypos >= (v_disp/5)*1)and(pixel_ypos < (v_disp/5)*2) then
                        pixel_data <= black;
                    elsif (pixel_ypos >= (v_disp/5)*2)and(pixel_ypos < (v_disp/5)*3) then
                        pixel_data <= red;
                    elsif (pixel_ypos >= (v_disp/5)*3)and(pixel_ypos < (v_disp/5)*4) then
                        pixel_data <= green;
                    else
                        pixel_data <= blue;
                    end if;
                else 
                    if (pixel_xpos >= "0000000000") and (pixel_xpos <= (h_disp/5)*1)
                        and (pixel_ypos >= "0000000000") and (pixel_ypos <= (v_disp/5)*1) then
                        pixel_data <= white;
                    elsif (pixel_xpos >= "0000000000") and (pixel_xpos <= (h_disp/5)*1)
                        and (pixel_ypos >= (v_disp/5)*1)and(pixel_ypos <= (v_disp/5)*2) then
                        pixel_data <= red;
                    elsif (pixel_xpos >= "0000000000") and (pixel_xpos <= (h_disp/5)*1)
                        and (pixel_ypos >= (v_disp/5)*2)and(pixel_ypos <= (v_disp/5)*3) then
                        pixel_data <= green;
                    elsif (pixel_xpos >= "0000000000") and (pixel_xpos <= (h_disp/5)*1)
                        and (pixel_ypos >= (v_disp/5)*3)and(pixel_ypos <= (v_disp/5)*4) then
                        pixel_data <= black;
                    elsif (pixel_xpos >= (h_disp/5)*1)and(pixel_xpos <= (h_disp/5)*2)
                        and (pixel_ypos >= (v_disp/5)*4)and(pixel_ypos <= (v_disp/5)*5) then
                        pixel_data <= green;
                    elsif (pixel_xpos >= (h_disp/5)*2)and(pixel_xpos <= (h_disp/5)*3)
                        and (pixel_ypos >= "0000000000") and (pixel_ypos <= (v_disp/5)*1) then
                        pixel_data <= red;
                    elsif (pixel_xpos >= (h_disp/5)*3)and(pixel_xpos <= (h_disp/5)*4)
                        and (pixel_ypos >= "0000000000") and (pixel_ypos <= (v_disp/5)*1) then
                        pixel_data <= green;
                    elsif (pixel_xpos >= (h_disp/5)*1)and(pixel_xpos <= (h_disp/5)*2)
                        and (pixel_ypos >= (v_disp/5)*1)and(pixel_ypos <= (v_disp/5)*2) then
                        pixel_data <= black;
                    elsif (pixel_xpos >= (h_disp/5)*1)and(pixel_xpos <= (h_disp/5)*2)
                        and (pixel_ypos >= (v_disp/5)*2)and(pixel_ypos <= (v_disp/5)*3) then
                        pixel_data <= white;
                    elsif (pixel_xpos >= (h_disp/5)*1)and(pixel_xpos <= (h_disp/5)*2)
                        and (pixel_ypos >= (v_disp/5)*3)and(pixel_ypos <= (v_disp/5)*4) then
                        pixel_data <= red;
                    elsif (pixel_xpos >= (h_disp/5)*1)and(pixel_xpos <= (h_disp/5)*2)
                        and (pixel_ypos >= (v_disp/5)*1)and(pixel_ypos <= (v_disp/5)*2) then
                        pixel_data <= green;
                    elsif (pixel_xpos >= (h_disp/5)*2)and(pixel_xpos <= (h_disp/5)*3)
                        and (pixel_ypos >= (v_disp/5)*1)and(pixel_ypos <= (v_disp/5)*2) then
                        pixel_data <= green;
                    elsif (pixel_xpos >= (h_disp/5)*2)and(pixel_xpos <= (h_disp/5)*3)
                        and (pixel_ypos >= (v_disp/5)*2)and(pixel_ypos <= (v_disp/5)*3) then
                        pixel_data <= red;
                    elsif (pixel_xpos >= (h_disp/5)*2)and(pixel_xpos <= (h_disp/5)*3)
                        and (pixel_ypos >= (v_disp/5)*3)and(pixel_ypos <= (v_disp/5)*4) then
                        pixel_data <= white;
                    elsif (pixel_xpos >= (h_disp/5)*2)and(pixel_xpos <= (h_disp/5)*3)
                        and (pixel_ypos >= (v_disp/5)*4)and(pixel_ypos <= (v_disp/5)*5) then
                        pixel_data <= black;
                    elsif (pixel_xpos >= (h_disp/5)*3)and(pixel_xpos <= (h_disp/5)*4)
                        and (pixel_ypos >= (v_disp/5)*3)and(pixel_ypos <= (v_disp/5)*4) then
                        pixel_data <= green;
                    elsif (pixel_xpos >= (h_disp/5)*1)and(pixel_xpos <= (h_disp/5)*2)
                        and (pixel_ypos >= "0000000000") and (pixel_ypos <= (v_disp/5)*1)  then
                        pixel_data <= green;
                    elsif (pixel_xpos >= (h_disp/5)*2)and(pixel_xpos <= (h_disp/5)*3)
                        and (pixel_ypos >= "0000000000") and (pixel_ypos <= (v_disp/5)*1)  then
                        pixel_data <= black;
                    elsif (pixel_xpos >= (h_disp/5)*3)and(pixel_xpos <= (h_disp/5)*4)
                        and (pixel_ypos >= (v_disp/5)*2)and(pixel_ypos <= (v_disp/5)*3)   then
                        pixel_data <= white;
                    elsif (pixel_xpos >= (h_disp/5)*4)and(pixel_xpos <= (h_disp/5)*5)
                        and (pixel_ypos >= (v_disp/5)*3)and(pixel_ypos <= (v_disp/5)*4) then
                        pixel_data <= red;
                    elsif (pixel_xpos >= (h_disp/5)*4)and(pixel_xpos <= (h_disp/5)*5)
                        and (pixel_ypos >= (v_disp/5)*1)and(pixel_ypos <= (v_disp/5)*2) then
                        pixel_data <= white;
                    elsif (pixel_xpos >= (h_disp/5)*4)and(pixel_xpos <= (h_disp/5)*5)
                        and (pixel_ypos >= (v_disp/5)*2)and(pixel_ypos <= (v_disp/5)*3) then
                        pixel_data <= black;
                    elsif (pixel_xpos >= (h_disp/5)*4)and(pixel_xpos <= (h_disp/5)*5)
                        and (pixel_ypos >= (v_disp/5)*4)and(pixel_ypos <= (v_disp/5)*5) then
                        pixel_data <= green;
                    else
                        pixel_data <= blue;
                    end if;
                end if;
            end if;
        end if;
    end process;
end Behavioral;