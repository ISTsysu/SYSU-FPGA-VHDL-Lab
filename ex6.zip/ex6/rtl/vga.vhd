library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity vga is
    Port ( clk : in STD_LOGIC;
           reset : in STD_LOGIC;
           key1,key2 : in std_logic;
           
           hsync : out STD_LOGIC;
           vsync : out STD_LOGIC;
           vga_rgb: out STD_LOGIC_VECTOR(23 downto 0); --三原色输出
           vga_sync_n : out std_logic;
           vga_clk : out std_logic;
           vga_blank_nout : out std_logic);
end vga;

architecture bhv of vga is
component ip is
    port(areset: in std_logic  := '0';
         inclk0: in std_logic  := '0';
         c0    : out std_logic ;
         locked: out std_logic );
end component;

component vga_driver is
    Port ( clk : in STD_LOGIC;
           reset : in STD_LOGIC;
           hsync : out STD_LOGIC;
           vsync : out STD_LOGIC;
           vga_rgb : out STD_LOGIC_VECTOR(23 downto 0);--三原色输出
           pixel_data : in std_logic_vector(23 downto 0);--像素点数据
           pixel_xpos : out STD_LOGIC_VECTOR(9 downto 0);--像素点横坐标
           pixel_ypos : out STD_LOGIC_VECTOR(9 downto 0)--像素点纵坐标
           );
end component;

component vga_display is
    port ( clk : in std_logic;
           reset : in std_logic;
           key1,key2 : in std_logic;
           
           pixel_xpos : in std_logic_vector(9 downto 0);--像素点横坐标
           pixel_ypos : in std_logic_vector(9 downto 0);--像素点纵坐标
           pixel_data : out std_logic_vector(23 downto 0));--像素点数据
end component;

signal vga_clk_w : std_logic;--PLL分频得到25MHz时钟
signal locked_w : std_logic;--PLL输出稳定信号
signal rst_n_w : std_logic;--内部复位信号
signal pixel_data_w : std_logic_vector(23 downto 0);--像素点数据
signal pixel_xpos_w : std_logic_vector(9 downto 0);--像素点横坐标
signal pixel_ypos_w : std_logic_vector(9 downto 0);--像素点纵坐标
    
begin
    VGA_SYNC_N <= '0';
    vga_clk <= vga_clk_w;
    vga_blank_nout <= '1';
    rst_n_w <= reset and locked_w;
    U1: ip port map (areset=>not reset, inclk0=>clk, c0=>vga_clk_w, locked=>locked_w);
    U2: vga_driver port map (clk=>vga_clk_w,
                             reset=>rst_n_w,
                             hsync=>hsync,
                             vsync=>vsync,
                             vga_rgb=>vga_rgb,
                             pixel_data=>pixel_data_w,
                             pixel_xpos=>pixel_xpos_w,
                             pixel_ypos=>pixel_ypos_w);
    U3 : vga_display port map(clk=>vga_clk_w,
                              reset=>rst_n_w,
                              key1=>key1,
                              key2=>key2, 
                              pixel_xpos=>pixel_xpos_w,
                              pixel_ypos=>pixel_ypos_w,
                              pixel_data=>pixel_data_w);
end bhv;