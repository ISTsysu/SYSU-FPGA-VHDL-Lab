library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity vga_driver is
    Port ( clk : in STD_LOGIC;
           reset : in STD_LOGIC;
           
           hsync : out STD_LOGIC;
           vsync : out STD_LOGIC;
           vga_rgb: out STD_LOGIC_VECTOR(23 downto 0);--三原色输出
           
           pixel_data : in std_logic_vector(23 downto 0);--像素点数据
           pixel_xpos : out STD_LOGIC_VECTOR(9 downto 0);--像素点横坐标
           pixel_ypos  : out STD_LOGIC_VECTOR(9 downto 0)--像素点纵坐标
           );
end vga_driver;

architecture Behavioral of vga_driver is
    -- VGA timing constants
    constant h_sync      : integer := 96; --行同步
    constant h_back_porch: integer := 48; --行显示后沿
    constant h_visible   : integer := 640; --行有效数据
    constant h_front_porch: integer := 16; --行显示前沿
    constant h_total : integer := 800; --行扫描周期
    
    constant v_sync      : integer := 2; --行同步
    constant v_back_porch: integer := 33; --行显示后沿
    constant v_visible   : integer := 480; --行有效数据
    constant v_front_porch: integer := 10; --行显示前沿
    constant v_total : integer := 525; --行扫描周期
    
    signal cnt_h:std_logic_vector(9 downto 0):="0000000000";
    signal cnt_v:std_logic_vector(9 downto 0):="0000000000";
    
    signal vga_en:std_logic:='1';
    signal data_req:std_logic:='1';
    
begin
    process(clk, reset)
    begin
        --行计数器对像素时钟计数
        if rising_edge(clk) then
            if reset = '0' then
                cnt_h <= (others => '0');
            else
                if cnt_h = h_total -1 then
                    cnt_h <= (others => '0');
                else
                    cnt_h <= cnt_h+"0000000001";
                end if;
            end if;
        end if;
        --场计数器对行计数
        if rising_edge(clk) then
            if reset = '0' then
                cnt_v <= (others => '0');
            elsif((cnt_v = v_total - 1) and (cnt_h = h_total-1)) then
                cnt_v <= (others => '0');
            elsif(cnt_h = h_total - 1) then
                 cnt_v <= cnt_v + "0000000001" ;
            else
                 cnt_v <= cnt_v ;
            --elsif cnt_h < h_total -1 then
            --    if cnt_v < v_total -1 then
            --        cnt_v <= cnt_v+'1';
            --    else
            --        cnt_v <= (others => '0');
            --    end if;
            end if;
        end if;
    end process;
    
    process(cnt_h,cnt_v,clk,reset)
    begin
        --vga行同步信号
        if (cnt_h <= h_sync-1)then
            hsync <= '0';
        else
            hsync <= '1';
        end if;
        --vga场同步信号
        if (cnt_v <= v_sync-1) then
            vsync <= '0';
        else
            vsync <= '1';
        end if;
        --使能rgb888数据输出
        if ((cnt_h >= h_sync+h_back_porch)and(cnt_h < h_sync+h_back_porch+h_visible))
            and((cnt_v >= v_sync+v_back_porch)and(cnt_v < v_sync+v_back_porch+v_visible)) then
            vga_en <= '1';
        else
            vga_en <= '0';
        end if;
        --rgb888数据输出
        if vga_en = '1' then
            vga_rgb <= pixel_data;
        else
            vga_rgb <= "000000000000000000000000";
        end if;
        --请求像素点颜色数据输入
        if ((cnt_h >= h_sync+h_back_porch-1)and(cnt_h < h_sync+h_back_porch+h_visible-1))
            and((cnt_v >= v_sync+v_back_porch)and(cnt_v < v_sync+v_back_porch+v_visible)) then
            data_req <= '1';
        else
            data_req <= '0';
        end if;
        --像素点坐标
        if data_req = '1' then
            pixel_xpos <= cnt_h-(h_sync+h_back_porch-1);
            pixel_ypos <= cnt_v-(v_sync+v_back_porch-1);
        else
            pixel_xpos <= "1111111111";
            pixel_ypos <= "1111111111";
        end if;
    end process;

end Behavioral;