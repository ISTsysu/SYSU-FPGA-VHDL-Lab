module VGA(CLK,MD,HS,VS,R,G,B); //VGA显 示器 彩条发生器
input CLK;input MD;output HS,VS,R,G,B;   
wire R,G,B,VS,HS;         //红、绿、蓝，场同步，行同步信号
wire FCLK,CCLK;
reg HS1,VS1;reg [1:0]MMD;reg [5:0]FS;
reg [4:0]CC;    //行同步，竖彩条生成
reg [8:0]LL;    //场同步，横彩条生成
reg [3:1]GRBX,GRBY,GRBP;
wire[3:1]GRB;
assign GRB[2]=(GRBP[2]^MD)&HS1&VS1;
assign GRB[3]=(GRBP[3]^MD)&HS1&VS1;
assign GRB[1]=(GRBP[1]^MD)&HS1&VS1;
always @(posedge MD)begin
     if (MMD==2'b10)MMD<=2'b00;else MMD<=MMD+1;end
always @(MMD) begin
     if (MMD==2'b00)GRBP<=GRBX; //选择竖彩条
else if (MMD==2'b01)GRBP<=GRBY; //选择横彩条
else if (MMD==2'b10)GRBP<=GRBX^GRBY; //选择棋盘格
else GRBP<=3'b000;end
always @(posedge CLK)begin      //20MHz    21分频
     if (FS==49)FS<=0;else FS<=(FS+1); end
always @(posedge FCLK)begin
     if (CC==29)CC<=0;else CC<=CC+1; end
always @(posedge CCLK)begin
     if (LL==481)LL<=0;else LL<=LL+1; end
always @(CC or LL)begin
     if (CC>23)HS1<=1'b0;else HS1<=1'b1;  //行同步
     if (LL>479)VS1<=1'b0;else VS1<=1'b1;end  //场同步
always @(CC or LL)begin
     if (CC<3)GRBX<=3'b111;      //竖彩条
else if (CC<6)GRBX<=3'b110;
else if (CC<9)GRBX<=3'b101;
else if (CC<12)GRBX<=3'b100;
else if (CC<15)GRBX<=3'b011;
else if (CC<18)GRBX<=3'b010;
else if (CC<21)GRBX<=3'b001;
else GRBX<=3'b000;
if (LL<60)GRBY<=3'b111;      //横彩条
else if (LL<120)GRBY<=3'b110;
else if (LL<180)GRBY<=3'b101;
else if (LL<240)GRBY<=3'b100;
else if (LL<300)GRBY<=3'b011;
else if (LL<360)GRBY<=3'b010;
else if (LL<420)GRBY<=3'b001;
else GRBY<=0; end
assign HS=HS1; assign FCLK=FS[5];
assign HS=HS1;assign VS=VS1;assign R=GRB[2];
assign G=GRB[3];assign B=GRB[1];assign CCLK=CC[4];
endmodule