library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity vga_color_bars is
    Port ( clk : in STD_LOGIC;
           reset : in STD_LOGIC;
           hsync : out STD_LOGIC;
           vsync : out STD_LOGIC;
           red   : out STD_LOGIC_VECTOR(1 downto 0);
           green : out STD_LOGIC_VECTOR(1 downto 0);
           blue  : out STD_LOGIC_VECTOR(1 downto 0));
end vga_color_bars;

architecture Behavioral of vga_color_bars is
    -- VGA timing constants
    constant h_visible   : integer := 640;
    constant h_front_porch: integer := 16;
    constant h_sync      : integer := 96;
    constant h_back_porch: integer := 48;
    constant v_visible   : integer := 480;
    constant v_front_porch: integer := 10;
    constant v_sync      : integer := 2;
    constant v_back_porch: integer := 33;
    
    signal h_count, v_count: integer range 0 to h_visible + h_front_porch + h_sync + h_back_porch - 1;
    signal color_bar: STD_LOGIC_VECTOR(1 downto 0);
begin
    process(clk, reset)
    variable line: integer;
    begin
        if reset = '1' then
            h_count <= 0;
            v_count <= 0;
            hsync <= '0';
            vsync <= '0';
            red   <= "00";
            green <= "00";
            blue  <= "00";
        elsif rising_edge(clk) then
            if h_count = 0 and v_count = 0 then
                hsync <= '1';
                vsync <= '1';
            elsif h_count = h_visible + h_front_porch and v_count = 0 then
                hsync <= '0';
            elsif h_count = h_visible + h_front_porch + h_sync and v_count = 0 then
                h_count <= 0;
                if v_count = v_visible + v_front_porch then
                    vsync <= '0';
                    v_count <= 0;
                else
                    v_count <= v_count + 1;
                end if;
            else
                if h_count = 0 then
                    vsync <= '1';
                end if;
            end if;

            if h_count < h_visible then
                -- Color bar logic
                line := (v_count / 48) mod 4; -- Divide the screen into 4 color bars
                case line is
                    when 0 => color_bar <= "00"; -- Red
                    when 1 => color_bar <= "01"; -- Green
                    when 2 => color_bar <= "10"; -- Blue
                    when others => color_bar <= "11"; -- Yellow
                end case;
                red   <= color_bar;
                green <= (not color_bar) and "10";
                blue  <= (not color_bar) and "01";
            else
                h_count <= h_count + 1;
            end if;
        end if;
    end process;
end Behavioral;