library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_arith.all; 
use ieee.std_logic_unsigned.all; -------------------------------------------------------------------- 
entity vga is 
port( clk : in std_logic; --Clock Signal 
        key : in std_logic; --this key is used to control the mode of --the colorful strip 
        hs,vs : buffer std_logic; --Horizontal Synchronization and Vertical --Synchronization 
        r,g,b : out std_logic); --red,green and blue color dirver 
end vga; -------------------------------------------------------------------- 
architecture behave of vga is 
    signal fclk,cclk : std_logic; 
    signal mmd : std_logic_vector(1 downto 0); --mode select 
    signal fs : std_logic_vector(3 downto 0); 
    signal cc : std_logic_vector(4 downto 0); --Horizontal Synchronization 
    signal ll : std_logic_vector(8 downto 0); --Vertical 
    --Synchronization 
    signal grbx : std_logic_vector(2 downto 0); --horizontal strip of X
    signal grby : std_logic_vector(2 downto 0); --vertical strip of Y 
    signal grbp : std_logic_vector(2 downto 0); 
    signal delay : std_logic_vector(15 downto 0); 
begin 
    b<=grbp(0) and hs and vs; 
    r<=grbp(1) and hs and vs; 
    g<=grbp(2) and hs and vs; 
process(clk) --mode of strip generation 
 begin 
    if(clk'event and clk='1') then 
        if(key='0') then 
            if(delay<60000) then 
                delay<=delay+1; 
            end if; 
        else 
            delay<="0000000000000000"; 
        end if; 
        if(delay=10000 and mmd<3) then 
            mmd<=mmd+1; 
        elsif(mmd=3) then 
            mmd<="00"; 
        end if; 
    end if; 
end process; 

process(mmd) 
 begin 
    case mmd is 
        when "00"=>grbp<=grbx; --choose horizontal strip 
        when "01"=>grbp<=grby; --choose vertical strip 
        when "10"=>grbp<=grbx xor grby; --choose tessellated designation 
        when others=>grbp<="000"; 
    end case; 
end process;  

process(clk) 
 begin 
    if(clk'event and clk='1') then --12MHz clock signal devided by 13 
        if(fs=12) then 
            fs<="0000"; 
        else 
            fs<=fs+1; 
        end if; 
    end if; 
end process; 
fclk<=fs(3);
 …… 
cclk<=cc(4); 

process(cclk) 
 begin 
    if(cclk'event and cclk='1') then 
        if(ll=481) then 
            ll<="000000000"; 
        else 
            ll<=ll+1; 
        end if; 
    end if; 
end process; 

process(clk) 
 begin 
    if(clk'event and clk='1') then 
        if(cc>23) then 
            hs<='0'; --horizontal synchronization 
        else 
            hs<='1'; 
        end if; 
        if(ll>479) then 
            vs<='0'; --vertical synchronization 
        else 
            vs<='1'; 
        end if; 
    end if; 
end process; 

process(clk) 
 begin 
    if(clk'event and clk='1') then 
        if(cc<3) then 
            grbx<="111"; 
            …… 
        else 
            grbx<="000"; 
        end if; 
    end if; 
end process; 

process(clk) 
 begin 
    if(clk'event and clk='1') then 
        if(ll<60) then 
            grby<="111"; 
            …… 
        elsif(ll<420) then 
            grby<="001"; 
        else 
            grby<="000"; 
        end if; 
    end if; 
end process; 
end behave; 
