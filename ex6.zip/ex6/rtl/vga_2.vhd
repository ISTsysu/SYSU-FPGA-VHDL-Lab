library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity VGA_Controller is
    Port (
        clk : in STD_LOGIC;
        reset : in STD_LOGIC;
        hsync : out STD_LOGIC;
        vsync : out STD_LOGIC;
        red   : out STD_LOGIC_VECTOR(1 downto 0);
        green : out STD_LOGIC_VECTOR(1 downto 0);
        blue  : out STD_LOGIC_VECTOR(1 downto 0)
    );
end VGA_Controller;

architecture Behavioral of VGA_Controller is
    -- Define states for the FSM
    type state_type is (HORIZONTAL_BAR, VERTICAL_BAR, GRID, IDLE);
    
    -- State variable
    signal current_state : state_type := IDLE;
    
    -- VGA timing constants (example values, adjust as needed)
    constant h_visible   : integer := 640;
    constant h_front_porch: integer := 16;
    constant h_sync      : integer := 96;
    constant h_back_porch: integer := 48;
    constant v_visible   : integer := 480;
    constant v_front_porch: integer := 10;
    constant v_sync      : integer := 2;
    constant v_back_porch: integer := 33;
    
    -- Horizontal and Vertical counters
    signal h_count, v_count: integer range 0 to h_visible + h_front_porch + h_sync + h_back_porch - 1;
    signal color_bar: STD_LOGIC_VECTOR(1 downto 0);
begin
    process(clk, reset)
    variable line, column: integer;
    begin
        if reset = '1' then
            -- Reset all outputs and counters
            current_state <= IDLE;
            h_count <= 0;
            v_count <= 0;
            hsync <= '0';
            vsync <= '0';
            red   <= "00";
            green <= "00";
            blue  <= "00";
        elsif rising_edge(clk) then
            case current_state is
                when HORIZONTAL_BAR =>
                    -- Logic to generate horizontal color bars
                    -- ...
                when VERTICAL_BAR =>
                    -- Logic to generate vertical color bars
                    -- ...
                when GRID =>
                    -- Logic to generate a grid pattern
                    line := v_count / 48; -- Divide the screen into rows
                    column := h_count / 48; -- Divide the screen into columns
                    if (line mod 2 = 0 and column mod 2 = 0) or (line mod 2 = 1 and column mod 2 = 1) then
                        red   <= "11";
                        green <= "11";
                        blue  <= "11"; -- White for grid lines
                    else
                        red   <= "00";
                        green <= "00";
                        blue  <= "00"; -- Black for background
                    end if;
                when others => -- Default to IDLE state
                    -- ...
            end case;
            
            -- Common VGA sync signal generation
            if h_count = h_visible + h_front_porch + h_sync - 1 then
                h_count <= 0;
                if v_count = v_visible + v_front_porch + v_sync - 1 then
                    v_count <= 0;
                else
                    v_count <= v_count + 1;
                end if;
                hsync <= '0';
            else
                h_count <= h_count + 1;
            end if;
            
            if v_count = v_visible + v_front_porch - 1 then
                vsync <= '0';
            else
                vsync <= '1';
            end if;
        end if;
    end process;
end Behavioral;