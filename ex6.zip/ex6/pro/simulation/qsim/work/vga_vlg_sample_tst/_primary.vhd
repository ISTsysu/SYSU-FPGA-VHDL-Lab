library verilog;
use verilog.vl_types.all;
entity vga_vlg_sample_tst is
    port(
        clk             : in     vl_logic;
        key1            : in     vl_logic;
        key2            : in     vl_logic;
        reset           : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end vga_vlg_sample_tst;
