library verilog;
use verilog.vl_types.all;
entity vga is
    port(
        clk             : in     vl_logic;
        reset           : in     vl_logic;
        key1            : in     vl_logic;
        key2            : in     vl_logic;
        hsync           : out    vl_logic;
        vsync           : out    vl_logic;
        vga_rgb         : out    vl_logic_vector(23 downto 0);
        vga_sync_n      : out    vl_logic;
        vga_clk         : out    vl_logic;
        vga_blank_nout  : out    vl_logic
    );
end vga;
