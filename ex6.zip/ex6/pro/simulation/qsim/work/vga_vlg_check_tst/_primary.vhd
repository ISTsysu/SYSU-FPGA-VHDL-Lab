library verilog;
use verilog.vl_types.all;
entity vga_vlg_check_tst is
    port(
        hsync           : in     vl_logic;
        vga_blank_nout  : in     vl_logic;
        vga_clk         : in     vl_logic;
        vga_rgb         : in     vl_logic_vector(23 downto 0);
        vga_sync_n      : in     vl_logic;
        vsync           : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end vga_vlg_check_tst;
