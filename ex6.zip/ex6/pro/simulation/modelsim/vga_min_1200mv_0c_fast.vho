-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.0.0 Build 156 04/24/2013 SJ Full Version"

-- DATE "06/05/2024 15:57:56"

-- 
-- Device: Altera EP4CE115F29C7 Package FBGA780
-- 

-- 
-- This VHDL file should be used for ModelSim (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIVE;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIVE.CYCLONEIVE_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	vga IS
    PORT (
	clk : IN std_logic;
	reset : IN std_logic;
	key1 : IN std_logic;
	key2 : IN std_logic;
	hsync : OUT std_logic;
	vsync : OUT std_logic;
	vga_rgb : OUT std_logic_vector(23 DOWNTO 0);
	vga_sync_n : OUT std_logic;
	vga_clk : OUT std_logic;
	vga_blank_nout : OUT std_logic
	);
END vga;

-- Design Ports Information
-- hsync	=>  Location: PIN_G13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vsync	=>  Location: PIN_C13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[0]	=>  Location: PIN_B10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[1]	=>  Location: PIN_A10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[2]	=>  Location: PIN_C11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[3]	=>  Location: PIN_B11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[4]	=>  Location: PIN_A11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[5]	=>  Location: PIN_C12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[6]	=>  Location: PIN_D11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[7]	=>  Location: PIN_D12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[8]	=>  Location: PIN_G8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[9]	=>  Location: PIN_G11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[10]	=>  Location: PIN_F8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[11]	=>  Location: PIN_H12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[12]	=>  Location: PIN_C8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[13]	=>  Location: PIN_B8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[14]	=>  Location: PIN_F10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[15]	=>  Location: PIN_C9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[16]	=>  Location: PIN_E12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[17]	=>  Location: PIN_E11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[18]	=>  Location: PIN_D10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[19]	=>  Location: PIN_F12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[20]	=>  Location: PIN_G10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[21]	=>  Location: PIN_J12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[22]	=>  Location: PIN_H8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_rgb[23]	=>  Location: PIN_H10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_sync_n	=>  Location: PIN_C10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_clk	=>  Location: PIN_A12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- vga_blank_nout	=>  Location: PIN_F11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- key1	=>  Location: PIN_AC28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- key2	=>  Location: PIN_AB28,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- reset	=>  Location: PIN_AC27,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk	=>  Location: PIN_Y2,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF vga IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk : std_logic;
SIGNAL ww_reset : std_logic;
SIGNAL ww_key1 : std_logic;
SIGNAL ww_key2 : std_logic;
SIGNAL ww_hsync : std_logic;
SIGNAL ww_vsync : std_logic;
SIGNAL ww_vga_rgb : std_logic_vector(23 DOWNTO 0);
SIGNAL ww_vga_sync_n : std_logic;
SIGNAL ww_vga_clk : std_logic;
SIGNAL ww_vga_blank_nout : std_logic;
SIGNAL \U1|altpll_component|auto_generated|pll1_INCLK_bus\ : std_logic_vector(1 DOWNTO 0);
SIGNAL \U1|altpll_component|auto_generated|pll1_CLK_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \U2|cnt_v[1]~12_combout\ : std_logic;
SIGNAL \U2|cnt_h[0]~10_combout\ : std_logic;
SIGNAL \U2|cnt_h[2]~14_combout\ : std_logic;
SIGNAL \U2|process_0~0_combout\ : std_logic;
SIGNAL \U2|LessThan2~1_combout\ : std_logic;
SIGNAL \U2|process_1~2_combout\ : std_logic;
SIGNAL \key1~input_o\ : std_logic;
SIGNAL \key2~input_o\ : std_logic;
SIGNAL \U2|cnt_h[0]~11\ : std_logic;
SIGNAL \U2|cnt_h[1]~12_combout\ : std_logic;
SIGNAL \clk~input_o\ : std_logic;
SIGNAL \U1|altpll_component|auto_generated|wire_pll1_fbout\ : std_logic;
SIGNAL \U1|altpll_component|auto_generated|wire_pll1_locked\ : std_logic;
SIGNAL \U2|Equal3~0_combout\ : std_logic;
SIGNAL \U2|cnt_h[8]~27_combout\ : std_logic;
SIGNAL \U2|Equal3~1_combout\ : std_logic;
SIGNAL \U2|cnt_h[3]~16_combout\ : std_logic;
SIGNAL \U2|Equal3~2_combout\ : std_logic;
SIGNAL \U1|altpll_component|auto_generated|pll_lock_sync~feeder_combout\ : std_logic;
SIGNAL \reset~input_o\ : std_logic;
SIGNAL \U1|altpll_component|auto_generated|pll_lock_sync~q\ : std_logic;
SIGNAL \U2|cnt_h[7]~20_combout\ : std_logic;
SIGNAL \U2|cnt_h[1]~13\ : std_logic;
SIGNAL \U2|cnt_h[2]~15\ : std_logic;
SIGNAL \U2|cnt_h[3]~17\ : std_logic;
SIGNAL \U2|cnt_h[4]~18_combout\ : std_logic;
SIGNAL \U2|cnt_h[4]~19\ : std_logic;
SIGNAL \U2|cnt_h[5]~21_combout\ : std_logic;
SIGNAL \U2|cnt_h[5]~22\ : std_logic;
SIGNAL \U2|cnt_h[6]~23_combout\ : std_logic;
SIGNAL \U2|cnt_h[6]~24\ : std_logic;
SIGNAL \U2|cnt_h[7]~25_combout\ : std_logic;
SIGNAL \U2|cnt_h[7]~26\ : std_logic;
SIGNAL \U2|cnt_h[8]~28\ : std_logic;
SIGNAL \U2|cnt_h[9]~29_combout\ : std_logic;
SIGNAL \U2|LessThan2~0_combout\ : std_logic;
SIGNAL \U2|LessThan3~0_combout\ : std_logic;
SIGNAL \U2|cnt_v[0]~11\ : std_logic;
SIGNAL \U2|cnt_v[1]~13\ : std_logic;
SIGNAL \U2|cnt_v[2]~14_combout\ : std_logic;
SIGNAL \~GND~combout\ : std_logic;
SIGNAL \rst_n_w~0_combout\ : std_logic;
SIGNAL \U2|cnt_v[0]~10_combout\ : std_logic;
SIGNAL \U2|process_1~1_combout\ : std_logic;
SIGNAL \U2|cnt_v[6]~22_combout\ : std_logic;
SIGNAL \U2|process_1~0_combout\ : std_logic;
SIGNAL \U2|process_1~3_combout\ : std_logic;
SIGNAL \U2|cnt_v[2]~15\ : std_logic;
SIGNAL \U2|cnt_v[3]~16_combout\ : std_logic;
SIGNAL \U2|cnt_v[3]~17\ : std_logic;
SIGNAL \U2|cnt_v[4]~18_combout\ : std_logic;
SIGNAL \U2|cnt_v[4]~19\ : std_logic;
SIGNAL \U2|cnt_v[5]~20_combout\ : std_logic;
SIGNAL \U2|cnt_v[5]~21\ : std_logic;
SIGNAL \U2|cnt_v[6]~23\ : std_logic;
SIGNAL \U2|cnt_v[7]~24_combout\ : std_logic;
SIGNAL \U2|cnt_v[7]~25\ : std_logic;
SIGNAL \U2|cnt_v[8]~27\ : std_logic;
SIGNAL \U2|cnt_v[9]~28_combout\ : std_logic;
SIGNAL \U2|LessThan4~0_combout\ : std_logic;
SIGNAL \U2|vga_rgb[0]~0_combout\ : std_logic;
SIGNAL \U2|vga_rgb[0]~1_combout\ : std_logic;
SIGNAL \U2|cnt_v[8]~26_combout\ : std_logic;
SIGNAL \U2|vga_rgb[0]~2_combout\ : std_logic;
SIGNAL \U2|vga_rgb[0]~3_combout\ : std_logic;
SIGNAL \U2|vga_rgb[0]~4_combout\ : std_logic;
SIGNAL \U2|vga_rgb[0]~5_combout\ : std_logic;
SIGNAL \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\ : std_logic;
SIGNAL \U1|altpll_component|auto_generated|wire_pll1_clk\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \U2|cnt_v\ : std_logic_vector(9 DOWNTO 0);
SIGNAL \U2|cnt_h\ : std_logic_vector(9 DOWNTO 0);
SIGNAL \U3|pixel_data\ : std_logic_vector(23 DOWNTO 0);
SIGNAL \ALT_INV_reset~input_o\ : std_logic;
SIGNAL \ALT_INV_rst_n_w~0_combout\ : std_logic;

BEGIN

ww_clk <= clk;
ww_reset <= reset;
ww_key1 <= key1;
ww_key2 <= key2;
hsync <= ww_hsync;
vsync <= ww_vsync;
vga_rgb <= ww_vga_rgb;
vga_sync_n <= ww_vga_sync_n;
vga_clk <= ww_vga_clk;
vga_blank_nout <= ww_vga_blank_nout;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\U1|altpll_component|auto_generated|pll1_INCLK_bus\ <= (gnd & \clk~input_o\);

\U1|altpll_component|auto_generated|wire_pll1_clk\(0) <= \U1|altpll_component|auto_generated|pll1_CLK_bus\(0);
\U1|altpll_component|auto_generated|wire_pll1_clk\(1) <= \U1|altpll_component|auto_generated|pll1_CLK_bus\(1);
\U1|altpll_component|auto_generated|wire_pll1_clk\(2) <= \U1|altpll_component|auto_generated|pll1_CLK_bus\(2);
\U1|altpll_component|auto_generated|wire_pll1_clk\(3) <= \U1|altpll_component|auto_generated|pll1_CLK_bus\(3);
\U1|altpll_component|auto_generated|wire_pll1_clk\(4) <= \U1|altpll_component|auto_generated|pll1_CLK_bus\(4);

\U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \U1|altpll_component|auto_generated|wire_pll1_clk\(0));
\ALT_INV_reset~input_o\ <= NOT \reset~input_o\;
\ALT_INV_rst_n_w~0_combout\ <= NOT \rst_n_w~0_combout\;

-- Location: FF_X5_Y6_N13
\U2|cnt_v[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_v[1]~12_combout\,
	asdata => \~GND~combout\,
	sclr => \ALT_INV_rst_n_w~0_combout\,
	sload => \U2|process_1~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_v\(1));

-- Location: FF_X3_Y6_N7
\U2|cnt_h[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_h[0]~10_combout\,
	sclr => \U2|cnt_h[7]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_h\(0));

-- Location: FF_X3_Y6_N11
\U2|cnt_h[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_h[2]~14_combout\,
	sclr => \U2|cnt_h[7]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_h\(2));

-- Location: LCCOMB_X5_Y6_N12
\U2|cnt_v[1]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_v[1]~12_combout\ = (\U2|cnt_v\(1) & (!\U2|cnt_v[0]~11\)) # (!\U2|cnt_v\(1) & ((\U2|cnt_v[0]~11\) # (GND)))
-- \U2|cnt_v[1]~13\ = CARRY((!\U2|cnt_v[0]~11\) # (!\U2|cnt_v\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_v\(1),
	datad => VCC,
	cin => \U2|cnt_v[0]~11\,
	combout => \U2|cnt_v[1]~12_combout\,
	cout => \U2|cnt_v[1]~13\);

-- Location: LCCOMB_X3_Y6_N6
\U2|cnt_h[0]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_h[0]~10_combout\ = \U2|cnt_h\(0) $ (VCC)
-- \U2|cnt_h[0]~11\ = CARRY(\U2|cnt_h\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_h\(0),
	datad => VCC,
	combout => \U2|cnt_h[0]~10_combout\,
	cout => \U2|cnt_h[0]~11\);

-- Location: LCCOMB_X3_Y6_N10
\U2|cnt_h[2]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_h[2]~14_combout\ = (\U2|cnt_h\(2) & (\U2|cnt_h[1]~13\ $ (GND))) # (!\U2|cnt_h\(2) & (!\U2|cnt_h[1]~13\ & VCC))
-- \U2|cnt_h[2]~15\ = CARRY((\U2|cnt_h\(2) & !\U2|cnt_h[1]~13\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_h\(2),
	datad => VCC,
	cin => \U2|cnt_h[1]~13\,
	combout => \U2|cnt_h[2]~14_combout\,
	cout => \U2|cnt_h[2]~15\);

-- Location: LCCOMB_X4_Y6_N24
\U2|process_0~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|process_0~0_combout\ = (!\U2|cnt_v\(6) & (!\U2|cnt_v\(7) & (!\U2|cnt_v\(8) & !\U2|cnt_v\(9))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_v\(6),
	datab => \U2|cnt_v\(7),
	datac => \U2|cnt_v\(8),
	datad => \U2|cnt_v\(9),
	combout => \U2|process_0~0_combout\);

-- Location: FF_X4_Y6_N17
\U3|pixel_data[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \rst_n_w~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U3|pixel_data\(0));

-- Location: LCCOMB_X3_Y6_N2
\U2|LessThan2~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|LessThan2~1_combout\ = (!\U2|cnt_h\(5) & (!\U2|cnt_h\(6) & (!\U2|cnt_h\(8) & !\U2|cnt_h\(9))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_h\(5),
	datab => \U2|cnt_h\(6),
	datac => \U2|cnt_h\(8),
	datad => \U2|cnt_h\(9),
	combout => \U2|LessThan2~1_combout\);

-- Location: LCCOMB_X5_Y6_N6
\U2|process_1~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|process_1~2_combout\ = (\U2|cnt_v\(9) & !\U2|cnt_v\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|cnt_v\(9),
	datad => \U2|cnt_v\(4),
	combout => \U2|process_1~2_combout\);

-- Location: IOOBUF_X38_Y73_N16
\hsync~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_hsync);

-- Location: IOOBUF_X54_Y73_N2
\vsync~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vsync);

-- Location: IOOBUF_X38_Y73_N9
\vga_rgb[0]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|vga_rgb[0]~5_combout\,
	devoe => ww_devoe,
	o => ww_vga_rgb(0));

-- Location: IOOBUF_X38_Y73_N2
\vga_rgb[1]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|vga_rgb[0]~5_combout\,
	devoe => ww_devoe,
	o => ww_vga_rgb(1));

-- Location: IOOBUF_X23_Y73_N2
\vga_rgb[2]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|vga_rgb[0]~5_combout\,
	devoe => ww_devoe,
	o => ww_vga_rgb(2));

-- Location: IOOBUF_X42_Y73_N9
\vga_rgb[3]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|vga_rgb[0]~5_combout\,
	devoe => ww_devoe,
	o => ww_vga_rgb(3));

-- Location: IOOBUF_X42_Y73_N2
\vga_rgb[4]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|vga_rgb[0]~5_combout\,
	devoe => ww_devoe,
	o => ww_vga_rgb(4));

-- Location: IOOBUF_X52_Y73_N16
\vga_rgb[5]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|vga_rgb[0]~5_combout\,
	devoe => ww_devoe,
	o => ww_vga_rgb(5));

-- Location: IOOBUF_X23_Y73_N9
\vga_rgb[6]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|vga_rgb[0]~5_combout\,
	devoe => ww_devoe,
	o => ww_vga_rgb(6));

-- Location: IOOBUF_X52_Y73_N23
\vga_rgb[7]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U2|vga_rgb[0]~5_combout\,
	devoe => ww_devoe,
	o => ww_vga_rgb(7));

-- Location: IOOBUF_X11_Y73_N16
\vga_rgb[8]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(8));

-- Location: IOOBUF_X25_Y73_N16
\vga_rgb[9]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(9));

-- Location: IOOBUF_X11_Y73_N9
\vga_rgb[10]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(10));

-- Location: IOOBUF_X25_Y73_N23
\vga_rgb[11]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(11));

-- Location: IOOBUF_X16_Y73_N9
\vga_rgb[12]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(12));

-- Location: IOOBUF_X16_Y73_N2
\vga_rgb[13]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(13));

-- Location: IOOBUF_X20_Y73_N2
\vga_rgb[14]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(14));

-- Location: IOOBUF_X23_Y73_N16
\vga_rgb[15]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(15));

-- Location: IOOBUF_X33_Y73_N2
\vga_rgb[16]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(16));

-- Location: IOOBUF_X31_Y73_N2
\vga_rgb[17]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(17));

-- Location: IOOBUF_X35_Y73_N23
\vga_rgb[18]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(18));

-- Location: IOOBUF_X33_Y73_N9
\vga_rgb[19]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(19));

-- Location: IOOBUF_X20_Y73_N9
\vga_rgb[20]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(20));

-- Location: IOOBUF_X40_Y73_N9
\vga_rgb[21]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(21));

-- Location: IOOBUF_X11_Y73_N23
\vga_rgb[22]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(22));

-- Location: IOOBUF_X20_Y73_N16
\vga_rgb[23]~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_rgb(23));

-- Location: IOOBUF_X35_Y73_N16
\vga_sync_n~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => ww_vga_sync_n);

-- Location: IOOBUF_X47_Y73_N2
\vga_clk~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	devoe => ww_devoe,
	o => ww_vga_clk);

-- Location: IOOBUF_X31_Y73_N9
\vga_blank_nout~output\ : cycloneive_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => ww_vga_blank_nout);

-- Location: LCCOMB_X3_Y6_N8
\U2|cnt_h[1]~12\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_h[1]~12_combout\ = (\U2|cnt_h\(1) & (!\U2|cnt_h[0]~11\)) # (!\U2|cnt_h\(1) & ((\U2|cnt_h[0]~11\) # (GND)))
-- \U2|cnt_h[1]~13\ = CARRY((!\U2|cnt_h[0]~11\) # (!\U2|cnt_h\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|cnt_h\(1),
	datad => VCC,
	cin => \U2|cnt_h[0]~11\,
	combout => \U2|cnt_h[1]~12_combout\,
	cout => \U2|cnt_h[1]~13\);

-- Location: IOIBUF_X0_Y36_N15
\clk~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk,
	o => \clk~input_o\);

-- Location: PLL_1
\U1|altpll_component|auto_generated|pll1\ : cycloneive_pll
-- pragma translate_off
GENERIC MAP (
	auto_settings => "false",
	bandwidth_type => "medium",
	c0_high => 12,
	c0_initial => 1,
	c0_low => 12,
	c0_mode => "even",
	c0_ph => 0,
	c1_high => 0,
	c1_initial => 0,
	c1_low => 0,
	c1_mode => "bypass",
	c1_ph => 0,
	c1_use_casc_in => "off",
	c2_high => 0,
	c2_initial => 0,
	c2_low => 0,
	c2_mode => "bypass",
	c2_ph => 0,
	c2_use_casc_in => "off",
	c3_high => 0,
	c3_initial => 0,
	c3_low => 0,
	c3_mode => "bypass",
	c3_ph => 0,
	c3_use_casc_in => "off",
	c4_high => 0,
	c4_initial => 0,
	c4_low => 0,
	c4_mode => "bypass",
	c4_ph => 0,
	c4_use_casc_in => "off",
	charge_pump_current_bits => 1,
	clk0_counter => "c0",
	clk0_divide_by => 2,
	clk0_duty_cycle => 50,
	clk0_multiply_by => 1,
	clk0_phase_shift => "0",
	clk1_counter => "unused",
	clk1_divide_by => 0,
	clk1_duty_cycle => 50,
	clk1_multiply_by => 0,
	clk1_phase_shift => "0",
	clk2_counter => "unused",
	clk2_divide_by => 0,
	clk2_duty_cycle => 50,
	clk2_multiply_by => 0,
	clk2_phase_shift => "0",
	clk3_counter => "unused",
	clk3_divide_by => 0,
	clk3_duty_cycle => 50,
	clk3_multiply_by => 0,
	clk3_phase_shift => "0",
	clk4_counter => "unused",
	clk4_divide_by => 0,
	clk4_duty_cycle => 50,
	clk4_multiply_by => 0,
	clk4_phase_shift => "0",
	compensate_clock => "clock0",
	inclk0_input_frequency => 20000,
	inclk1_input_frequency => 0,
	loop_filter_c_bits => 0,
	loop_filter_r_bits => 27,
	m => 12,
	m_initial => 1,
	m_ph => 0,
	n => 1,
	operation_mode => "normal",
	pfd_max => 200000,
	pfd_min => 3076,
	pll_compensation_delay => 3789,
	self_reset_on_loss_lock => "off",
	simulation_type => "timing",
	switch_over_type => "auto",
	vco_center => 1538,
	vco_divide_by => 0,
	vco_frequency_control => "auto",
	vco_max => 3333,
	vco_min => 1538,
	vco_multiply_by => 0,
	vco_phase_shift_step => 208,
	vco_post_scale => 2)
-- pragma translate_on
PORT MAP (
	areset => \ALT_INV_reset~input_o\,
	fbin => \U1|altpll_component|auto_generated|wire_pll1_fbout\,
	inclk => \U1|altpll_component|auto_generated|pll1_INCLK_bus\,
	locked => \U1|altpll_component|auto_generated|wire_pll1_locked\,
	fbout => \U1|altpll_component|auto_generated|wire_pll1_fbout\,
	clk => \U1|altpll_component|auto_generated|pll1_CLK_bus\);

-- Location: LCCOMB_X3_Y6_N28
\U2|Equal3~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Equal3~0_combout\ = (\U2|cnt_h\(5)) # ((\U2|cnt_h\(6)) # ((\U2|cnt_h\(7)) # (!\U2|cnt_h\(4))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_h\(5),
	datab => \U2|cnt_h\(6),
	datac => \U2|cnt_h\(4),
	datad => \U2|cnt_h\(7),
	combout => \U2|Equal3~0_combout\);

-- Location: LCCOMB_X3_Y6_N22
\U2|cnt_h[8]~27\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_h[8]~27_combout\ = (\U2|cnt_h\(8) & (\U2|cnt_h[7]~26\ $ (GND))) # (!\U2|cnt_h\(8) & (!\U2|cnt_h[7]~26\ & VCC))
-- \U2|cnt_h[8]~28\ = CARRY((\U2|cnt_h\(8) & !\U2|cnt_h[7]~26\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_h\(8),
	datad => VCC,
	cin => \U2|cnt_h[7]~26\,
	combout => \U2|cnt_h[8]~27_combout\,
	cout => \U2|cnt_h[8]~28\);

-- Location: FF_X3_Y6_N23
\U2|cnt_h[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_h[8]~27_combout\,
	sclr => \U2|cnt_h[7]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_h\(8));

-- Location: LCCOMB_X3_Y6_N26
\U2|Equal3~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Equal3~1_combout\ = (((!\U2|cnt_h\(9)) # (!\U2|cnt_h\(8))) # (!\U2|cnt_h\(1))) # (!\U2|cnt_h\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_h\(0),
	datab => \U2|cnt_h\(1),
	datac => \U2|cnt_h\(8),
	datad => \U2|cnt_h\(9),
	combout => \U2|Equal3~1_combout\);

-- Location: LCCOMB_X3_Y6_N12
\U2|cnt_h[3]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_h[3]~16_combout\ = (\U2|cnt_h\(3) & (!\U2|cnt_h[2]~15\)) # (!\U2|cnt_h\(3) & ((\U2|cnt_h[2]~15\) # (GND)))
-- \U2|cnt_h[3]~17\ = CARRY((!\U2|cnt_h[2]~15\) # (!\U2|cnt_h\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_h\(3),
	datad => VCC,
	cin => \U2|cnt_h[2]~15\,
	combout => \U2|cnt_h[3]~16_combout\,
	cout => \U2|cnt_h[3]~17\);

-- Location: FF_X3_Y6_N13
\U2|cnt_h[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_h[3]~16_combout\,
	sclr => \U2|cnt_h[7]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_h\(3));

-- Location: LCCOMB_X3_Y6_N4
\U2|Equal3~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|Equal3~2_combout\ = ((\U2|Equal3~0_combout\) # ((\U2|Equal3~1_combout\) # (!\U2|cnt_h\(3)))) # (!\U2|cnt_h\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_h\(2),
	datab => \U2|Equal3~0_combout\,
	datac => \U2|Equal3~1_combout\,
	datad => \U2|cnt_h\(3),
	combout => \U2|Equal3~2_combout\);

-- Location: LCCOMB_X4_Y6_N2
\U1|altpll_component|auto_generated|pll_lock_sync~feeder\ : cycloneive_lcell_comb
-- Equation(s):
-- \U1|altpll_component|auto_generated|pll_lock_sync~feeder_combout\ = VCC

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \U1|altpll_component|auto_generated|pll_lock_sync~feeder_combout\);

-- Location: IOIBUF_X115_Y15_N8
\reset~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_reset,
	o => \reset~input_o\);

-- Location: FF_X4_Y6_N3
\U1|altpll_component|auto_generated|pll_lock_sync\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_locked\,
	d => \U1|altpll_component|auto_generated|pll_lock_sync~feeder_combout\,
	clrn => \reset~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U1|altpll_component|auto_generated|pll_lock_sync~q\);

-- Location: LCCOMB_X3_Y6_N30
\U2|cnt_h[7]~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_h[7]~20_combout\ = (((!\U1|altpll_component|auto_generated|pll_lock_sync~q\) # (!\U2|Equal3~2_combout\)) # (!\U1|altpll_component|auto_generated|wire_pll1_locked\)) # (!\reset~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \reset~input_o\,
	datab => \U1|altpll_component|auto_generated|wire_pll1_locked\,
	datac => \U2|Equal3~2_combout\,
	datad => \U1|altpll_component|auto_generated|pll_lock_sync~q\,
	combout => \U2|cnt_h[7]~20_combout\);

-- Location: FF_X3_Y6_N9
\U2|cnt_h[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_h[1]~12_combout\,
	sclr => \U2|cnt_h[7]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_h\(1));

-- Location: LCCOMB_X3_Y6_N14
\U2|cnt_h[4]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_h[4]~18_combout\ = (\U2|cnt_h\(4) & (\U2|cnt_h[3]~17\ $ (GND))) # (!\U2|cnt_h\(4) & (!\U2|cnt_h[3]~17\ & VCC))
-- \U2|cnt_h[4]~19\ = CARRY((\U2|cnt_h\(4) & !\U2|cnt_h[3]~17\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|cnt_h\(4),
	datad => VCC,
	cin => \U2|cnt_h[3]~17\,
	combout => \U2|cnt_h[4]~18_combout\,
	cout => \U2|cnt_h[4]~19\);

-- Location: FF_X3_Y6_N15
\U2|cnt_h[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_h[4]~18_combout\,
	sclr => \U2|cnt_h[7]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_h\(4));

-- Location: LCCOMB_X3_Y6_N16
\U2|cnt_h[5]~21\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_h[5]~21_combout\ = (\U2|cnt_h\(5) & (!\U2|cnt_h[4]~19\)) # (!\U2|cnt_h\(5) & ((\U2|cnt_h[4]~19\) # (GND)))
-- \U2|cnt_h[5]~22\ = CARRY((!\U2|cnt_h[4]~19\) # (!\U2|cnt_h\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|cnt_h\(5),
	datad => VCC,
	cin => \U2|cnt_h[4]~19\,
	combout => \U2|cnt_h[5]~21_combout\,
	cout => \U2|cnt_h[5]~22\);

-- Location: FF_X3_Y6_N17
\U2|cnt_h[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_h[5]~21_combout\,
	sclr => \U2|cnt_h[7]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_h\(5));

-- Location: LCCOMB_X3_Y6_N18
\U2|cnt_h[6]~23\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_h[6]~23_combout\ = (\U2|cnt_h\(6) & (\U2|cnt_h[5]~22\ $ (GND))) # (!\U2|cnt_h\(6) & (!\U2|cnt_h[5]~22\ & VCC))
-- \U2|cnt_h[6]~24\ = CARRY((\U2|cnt_h\(6) & !\U2|cnt_h[5]~22\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|cnt_h\(6),
	datad => VCC,
	cin => \U2|cnt_h[5]~22\,
	combout => \U2|cnt_h[6]~23_combout\,
	cout => \U2|cnt_h[6]~24\);

-- Location: FF_X3_Y6_N19
\U2|cnt_h[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_h[6]~23_combout\,
	sclr => \U2|cnt_h[7]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_h\(6));

-- Location: LCCOMB_X3_Y6_N20
\U2|cnt_h[7]~25\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_h[7]~25_combout\ = (\U2|cnt_h\(7) & (!\U2|cnt_h[6]~24\)) # (!\U2|cnt_h\(7) & ((\U2|cnt_h[6]~24\) # (GND)))
-- \U2|cnt_h[7]~26\ = CARRY((!\U2|cnt_h[6]~24\) # (!\U2|cnt_h\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|cnt_h\(7),
	datad => VCC,
	cin => \U2|cnt_h[6]~24\,
	combout => \U2|cnt_h[7]~25_combout\,
	cout => \U2|cnt_h[7]~26\);

-- Location: FF_X3_Y6_N21
\U2|cnt_h[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_h[7]~25_combout\,
	sclr => \U2|cnt_h[7]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_h\(7));

-- Location: LCCOMB_X3_Y6_N24
\U2|cnt_h[9]~29\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_h[9]~29_combout\ = \U2|cnt_h[8]~28\ $ (\U2|cnt_h\(9))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \U2|cnt_h\(9),
	cin => \U2|cnt_h[8]~28\,
	combout => \U2|cnt_h[9]~29_combout\);

-- Location: FF_X3_Y6_N25
\U2|cnt_h[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_h[9]~29_combout\,
	sclr => \U2|cnt_h[7]~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_h\(9));

-- Location: LCCOMB_X3_Y6_N0
\U2|LessThan2~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|LessThan2~0_combout\ = (!\U2|cnt_h\(5) & (!\U2|cnt_h\(6) & (!\U2|cnt_h\(4) & !\U2|cnt_h\(7))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_h\(5),
	datab => \U2|cnt_h\(6),
	datac => \U2|cnt_h\(4),
	datad => \U2|cnt_h\(7),
	combout => \U2|LessThan2~0_combout\);

-- Location: LCCOMB_X4_Y6_N20
\U2|LessThan3~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|LessThan3~0_combout\ = ((\U2|LessThan2~0_combout\) # (!\U2|cnt_h\(8))) # (!\U2|cnt_h\(9))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \U2|cnt_h\(9),
	datac => \U2|LessThan2~0_combout\,
	datad => \U2|cnt_h\(8),
	combout => \U2|LessThan3~0_combout\);

-- Location: LCCOMB_X5_Y6_N10
\U2|cnt_v[0]~10\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_v[0]~10_combout\ = (\U2|cnt_v\(0) & (\U2|Equal3~2_combout\ $ (GND))) # (!\U2|cnt_v\(0) & (!\U2|Equal3~2_combout\ & VCC))
-- \U2|cnt_v[0]~11\ = CARRY((\U2|cnt_v\(0) & !\U2|Equal3~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001100100100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_v\(0),
	datab => \U2|Equal3~2_combout\,
	datad => VCC,
	combout => \U2|cnt_v[0]~10_combout\,
	cout => \U2|cnt_v[0]~11\);

-- Location: LCCOMB_X5_Y6_N14
\U2|cnt_v[2]~14\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_v[2]~14_combout\ = (\U2|cnt_v\(2) & (\U2|cnt_v[1]~13\ $ (GND))) # (!\U2|cnt_v\(2) & (!\U2|cnt_v[1]~13\ & VCC))
-- \U2|cnt_v[2]~15\ = CARRY((\U2|cnt_v\(2) & !\U2|cnt_v[1]~13\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|cnt_v\(2),
	datad => VCC,
	cin => \U2|cnt_v[1]~13\,
	combout => \U2|cnt_v[2]~14_combout\,
	cout => \U2|cnt_v[2]~15\);

-- Location: LCCOMB_X5_Y6_N30
\~GND\ : cycloneive_lcell_comb
-- Equation(s):
-- \~GND~combout\ = GND

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \~GND~combout\);

-- Location: LCCOMB_X4_Y6_N16
\rst_n_w~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \rst_n_w~0_combout\ = (\U1|altpll_component|auto_generated|wire_pll1_locked\ & (\reset~input_o\ & \U1|altpll_component|auto_generated|pll_lock_sync~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U1|altpll_component|auto_generated|wire_pll1_locked\,
	datac => \reset~input_o\,
	datad => \U1|altpll_component|auto_generated|pll_lock_sync~q\,
	combout => \rst_n_w~0_combout\);

-- Location: FF_X5_Y6_N11
\U2|cnt_v[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_v[0]~10_combout\,
	asdata => \~GND~combout\,
	sclr => \ALT_INV_rst_n_w~0_combout\,
	sload => \U2|process_1~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_v\(0));

-- Location: LCCOMB_X5_Y6_N4
\U2|process_1~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|process_1~1_combout\ = (!\U2|cnt_v\(1) & (\U2|cnt_v\(3) & (\U2|cnt_v\(2) & !\U2|cnt_v\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_v\(1),
	datab => \U2|cnt_v\(3),
	datac => \U2|cnt_v\(2),
	datad => \U2|cnt_v\(0),
	combout => \U2|process_1~1_combout\);

-- Location: LCCOMB_X5_Y6_N22
\U2|cnt_v[6]~22\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_v[6]~22_combout\ = (\U2|cnt_v\(6) & (\U2|cnt_v[5]~21\ $ (GND))) # (!\U2|cnt_v\(6) & (!\U2|cnt_v[5]~21\ & VCC))
-- \U2|cnt_v[6]~23\ = CARRY((\U2|cnt_v\(6) & !\U2|cnt_v[5]~21\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_v\(6),
	datad => VCC,
	cin => \U2|cnt_v[5]~21\,
	combout => \U2|cnt_v[6]~22_combout\,
	cout => \U2|cnt_v[6]~23\);

-- Location: FF_X5_Y6_N23
\U2|cnt_v[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_v[6]~22_combout\,
	asdata => \~GND~combout\,
	sclr => \ALT_INV_rst_n_w~0_combout\,
	sload => \U2|process_1~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_v\(6));

-- Location: LCCOMB_X5_Y6_N2
\U2|process_1~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|process_1~0_combout\ = (!\U2|cnt_v\(8) & (!\U2|cnt_v\(7) & (!\U2|cnt_v\(6) & !\U2|cnt_v\(5))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_v\(8),
	datab => \U2|cnt_v\(7),
	datac => \U2|cnt_v\(6),
	datad => \U2|cnt_v\(5),
	combout => \U2|process_1~0_combout\);

-- Location: LCCOMB_X5_Y6_N8
\U2|process_1~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|process_1~3_combout\ = (\U2|process_1~2_combout\ & (\U2|process_1~1_combout\ & (!\U2|Equal3~2_combout\ & \U2|process_1~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|process_1~2_combout\,
	datab => \U2|process_1~1_combout\,
	datac => \U2|Equal3~2_combout\,
	datad => \U2|process_1~0_combout\,
	combout => \U2|process_1~3_combout\);

-- Location: FF_X5_Y6_N15
\U2|cnt_v[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_v[2]~14_combout\,
	asdata => \~GND~combout\,
	sclr => \ALT_INV_rst_n_w~0_combout\,
	sload => \U2|process_1~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_v\(2));

-- Location: LCCOMB_X5_Y6_N16
\U2|cnt_v[3]~16\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_v[3]~16_combout\ = (\U2|cnt_v\(3) & (!\U2|cnt_v[2]~15\)) # (!\U2|cnt_v\(3) & ((\U2|cnt_v[2]~15\) # (GND)))
-- \U2|cnt_v[3]~17\ = CARRY((!\U2|cnt_v[2]~15\) # (!\U2|cnt_v\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|cnt_v\(3),
	datad => VCC,
	cin => \U2|cnt_v[2]~15\,
	combout => \U2|cnt_v[3]~16_combout\,
	cout => \U2|cnt_v[3]~17\);

-- Location: FF_X5_Y6_N17
\U2|cnt_v[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_v[3]~16_combout\,
	asdata => \~GND~combout\,
	sclr => \ALT_INV_rst_n_w~0_combout\,
	sload => \U2|process_1~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_v\(3));

-- Location: LCCOMB_X5_Y6_N18
\U2|cnt_v[4]~18\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_v[4]~18_combout\ = (\U2|cnt_v\(4) & (\U2|cnt_v[3]~17\ $ (GND))) # (!\U2|cnt_v\(4) & (!\U2|cnt_v[3]~17\ & VCC))
-- \U2|cnt_v[4]~19\ = CARRY((\U2|cnt_v\(4) & !\U2|cnt_v[3]~17\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|cnt_v\(4),
	datad => VCC,
	cin => \U2|cnt_v[3]~17\,
	combout => \U2|cnt_v[4]~18_combout\,
	cout => \U2|cnt_v[4]~19\);

-- Location: FF_X5_Y6_N19
\U2|cnt_v[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_v[4]~18_combout\,
	asdata => \~GND~combout\,
	sclr => \ALT_INV_rst_n_w~0_combout\,
	sload => \U2|process_1~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_v\(4));

-- Location: LCCOMB_X5_Y6_N20
\U2|cnt_v[5]~20\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_v[5]~20_combout\ = (\U2|cnt_v\(5) & (!\U2|cnt_v[4]~19\)) # (!\U2|cnt_v\(5) & ((\U2|cnt_v[4]~19\) # (GND)))
-- \U2|cnt_v[5]~21\ = CARRY((!\U2|cnt_v[4]~19\) # (!\U2|cnt_v\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|cnt_v\(5),
	datad => VCC,
	cin => \U2|cnt_v[4]~19\,
	combout => \U2|cnt_v[5]~20_combout\,
	cout => \U2|cnt_v[5]~21\);

-- Location: FF_X5_Y6_N21
\U2|cnt_v[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_v[5]~20_combout\,
	asdata => \~GND~combout\,
	sclr => \ALT_INV_rst_n_w~0_combout\,
	sload => \U2|process_1~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_v\(5));

-- Location: LCCOMB_X5_Y6_N24
\U2|cnt_v[7]~24\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_v[7]~24_combout\ = (\U2|cnt_v\(7) & (!\U2|cnt_v[6]~23\)) # (!\U2|cnt_v\(7) & ((\U2|cnt_v[6]~23\) # (GND)))
-- \U2|cnt_v[7]~25\ = CARRY((!\U2|cnt_v[6]~23\) # (!\U2|cnt_v\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \U2|cnt_v\(7),
	datad => VCC,
	cin => \U2|cnt_v[6]~23\,
	combout => \U2|cnt_v[7]~24_combout\,
	cout => \U2|cnt_v[7]~25\);

-- Location: FF_X5_Y6_N25
\U2|cnt_v[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_v[7]~24_combout\,
	asdata => \~GND~combout\,
	sclr => \ALT_INV_rst_n_w~0_combout\,
	sload => \U2|process_1~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_v\(7));

-- Location: LCCOMB_X5_Y6_N26
\U2|cnt_v[8]~26\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_v[8]~26_combout\ = (\U2|cnt_v\(8) & (\U2|cnt_v[7]~25\ $ (GND))) # (!\U2|cnt_v\(8) & (!\U2|cnt_v[7]~25\ & VCC))
-- \U2|cnt_v[8]~27\ = CARRY((\U2|cnt_v\(8) & !\U2|cnt_v[7]~25\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_v\(8),
	datad => VCC,
	cin => \U2|cnt_v[7]~25\,
	combout => \U2|cnt_v[8]~26_combout\,
	cout => \U2|cnt_v[8]~27\);

-- Location: LCCOMB_X5_Y6_N28
\U2|cnt_v[9]~28\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|cnt_v[9]~28_combout\ = \U2|cnt_v[8]~27\ $ (\U2|cnt_v\(9))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \U2|cnt_v\(9),
	cin => \U2|cnt_v[8]~27\,
	combout => \U2|cnt_v[9]~28_combout\);

-- Location: FF_X5_Y6_N29
\U2|cnt_v[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_v[9]~28_combout\,
	asdata => \~GND~combout\,
	sclr => \ALT_INV_rst_n_w~0_combout\,
	sload => \U2|process_1~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_v\(9));

-- Location: LCCOMB_X5_Y6_N0
\U2|LessThan4~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|LessThan4~0_combout\ = (!\U2|cnt_v\(3) & (!\U2|cnt_v\(2) & ((!\U2|cnt_v\(0)) # (!\U2|cnt_v\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_v\(1),
	datab => \U2|cnt_v\(3),
	datac => \U2|cnt_v\(2),
	datad => \U2|cnt_v\(0),
	combout => \U2|LessThan4~0_combout\);

-- Location: LCCOMB_X4_Y6_N10
\U2|vga_rgb[0]~0\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|vga_rgb[0]~0_combout\ = (\U2|LessThan4~0_combout\ & ((\U2|cnt_v\(4) & ((!\U2|cnt_v\(9)))) # (!\U2|cnt_v\(4) & (!\U2|process_0~0_combout\)))) # (!\U2|LessThan4~0_combout\ & (((!\U2|cnt_v\(9)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001101010011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|process_0~0_combout\,
	datab => \U2|cnt_v\(9),
	datac => \U2|LessThan4~0_combout\,
	datad => \U2|cnt_v\(4),
	combout => \U2|vga_rgb[0]~0_combout\);

-- Location: LCCOMB_X4_Y6_N22
\U2|vga_rgb[0]~1\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|vga_rgb[0]~1_combout\ = (\U2|LessThan3~0_combout\ & (\U2|vga_rgb[0]~0_combout\ & ((\U2|cnt_v\(9)) # (!\U2|process_1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|process_1~0_combout\,
	datab => \U2|LessThan3~0_combout\,
	datac => \U2|vga_rgb[0]~0_combout\,
	datad => \U2|cnt_v\(9),
	combout => \U2|vga_rgb[0]~1_combout\);

-- Location: FF_X5_Y6_N27
\U2|cnt_v[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\,
	d => \U2|cnt_v[8]~26_combout\,
	asdata => \~GND~combout\,
	sclr => \ALT_INV_rst_n_w~0_combout\,
	sload => \U2|process_1~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \U2|cnt_v\(8));

-- Location: LCCOMB_X4_Y6_N26
\U2|vga_rgb[0]~2\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|vga_rgb[0]~2_combout\ = (\U3|pixel_data\(0) & ((\U2|cnt_h\(9)) # ((\U2|cnt_h\(7)) # (\U2|cnt_h\(8)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U3|pixel_data\(0),
	datab => \U2|cnt_h\(9),
	datac => \U2|cnt_h\(7),
	datad => \U2|cnt_h\(8),
	combout => \U2|vga_rgb[0]~2_combout\);

-- Location: LCCOMB_X4_Y6_N12
\U2|vga_rgb[0]~3\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|vga_rgb[0]~3_combout\ = ((!\U2|cnt_v\(6) & (!\U2|cnt_v\(7) & !\U2|cnt_v\(5)))) # (!\U2|cnt_v\(9))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|cnt_v\(6),
	datab => \U2|cnt_v\(7),
	datac => \U2|cnt_v\(5),
	datad => \U2|cnt_v\(9),
	combout => \U2|vga_rgb[0]~3_combout\);

-- Location: LCCOMB_X4_Y6_N6
\U2|vga_rgb[0]~4\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|vga_rgb[0]~4_combout\ = (\U2|vga_rgb[0]~2_combout\ & (\U2|vga_rgb[0]~3_combout\ & ((\U2|cnt_h\(4)) # (!\U2|LessThan2~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|LessThan2~1_combout\,
	datab => \U2|cnt_h\(4),
	datac => \U2|vga_rgb[0]~2_combout\,
	datad => \U2|vga_rgb[0]~3_combout\,
	combout => \U2|vga_rgb[0]~4_combout\);

-- Location: LCCOMB_X4_Y6_N0
\U2|vga_rgb[0]~5\ : cycloneive_lcell_comb
-- Equation(s):
-- \U2|vga_rgb[0]~5_combout\ = (\U2|vga_rgb[0]~1_combout\ & (\U2|vga_rgb[0]~4_combout\ & ((!\U2|cnt_v\(8)) # (!\U2|cnt_v\(9)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \U2|vga_rgb[0]~1_combout\,
	datab => \U2|cnt_v\(9),
	datac => \U2|cnt_v\(8),
	datad => \U2|vga_rgb[0]~4_combout\,
	combout => \U2|vga_rgb[0]~5_combout\);

-- Location: CLKCTRL_G3
\U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl\ : cycloneive_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \U1|altpll_component|auto_generated|wire_pll1_clk[0]~clkctrl_outclk\);

-- Location: IOIBUF_X115_Y14_N1
\key1~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_key1,
	o => \key1~input_o\);

-- Location: IOIBUF_X115_Y17_N1
\key2~input\ : cycloneive_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_key2,
	o => \key2~input_o\);
END structure;


